import "@fontsource-variable/archivo/wdth.css";
import "@fontsource-variable/martian-mono/index.css";
import "./globals.css";

export const metadata = {
  title: "Meridian — Take your time",
  description:
    "Meridian is a timeline-based motion editor for the web. Block the shot on real tracks, bend every curve by hand, and ship production-ready code.",
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' fill='%23eef3f6'/><path d='M9 5h14l-7 9z' fill='%23e93820'/><rect x='14.75' y='5' width='2.5' height='23' fill='%23e93820'/></svg>",
  },
};

export const viewport = {
  themeColor: "#eef3f6",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <script
          dangerouslySetInnerHTML={{
            __html:
              "document.documentElement.classList.add('js');try{if(new URLSearchParams(location.search).has('prm')){document.documentElement.classList.add('prm-force')}}catch(e){}",
          }}
        />
        {children}
      </body>
    </html>
  );
}
