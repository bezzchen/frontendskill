import TopBar from "./components/TopBar";
import Hero from "./components/hero/Hero";
import CurveEditor from "./components/CurveEditor";
import Waitlist from "./components/Waitlist";
import Reveal from "./components/Reveal";

const h2 = "mt-4 text-4xl font-[770] leading-[1.02] tracking-[-0.02em] sm:text-[44px]";

function Kicker({ children }) {
  return <p className="u-label text-ink2">{children}</p>;
}

function CardRegs() {
  return (
    <span aria-hidden="true">
      <span className="reg left-[-6px] top-[-6px]" />
      <span className="reg right-[-6px] bottom-[-6px]" />
    </span>
  );
}

export default function Home() {
  return (
    <>
      <a href="#main" className="skip">Skip to content</a>
      <TopBar />

      <main id="main">
        <Hero />

        {/* ---------------- SHEET 02 · capabilities ---------------- */}
        <section id="table" aria-labelledby="h-table" className="scroll-mt-16 border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-24">
            <div data-reveal>
              <Kicker>Sheet 02 · Capabilities</Kicker>
              <h2 id="h-table" className={h2} style={{ fontStretch: "106%" }}>
                On the light table
              </h2>
              <p className="mt-5 max-w-[58ch] text-[16px] leading-relaxed text-ink2">
                Everything you sketch stays in non-photo blue until you ship it. Then it
                becomes ink — real code, not an approximation of your intent.
              </p>
            </div>

            <div className="mt-12 grid gap-5 md:grid-cols-3">
              <article className="cel-card" data-reveal>
                <CardRegs />
                <svg viewBox="0 0 240 88" className="w-full" aria-hidden="true">
                  <line x1="0" y1="24" x2="240" y2="24" stroke="var(--color-line)" />
                  <line x1="0" y1="56" x2="240" y2="56" stroke="var(--color-line)" />
                  <rect x="18" y="14" width="92" height="20" rx="3" fill="var(--color-wash)" stroke="var(--color-line2)" />
                  <rect x="14.5" y="20.5" width="7" height="7" fill="var(--color-ink)" transform="rotate(45 18 24)" />
                  <rect x="106.5" y="20.5" width="7" height="7" fill="var(--color-ink)" transform="rotate(45 110 24)" />
                  <rect x="70" y="46" width="120" height="20" rx="3" fill="var(--color-wash)" stroke="var(--color-line2)" />
                  <rect x="66.5" y="52.5" width="7" height="7" fill="var(--color-ink)" transform="rotate(45 70 56)" />
                  <path d="M127 4h10l-5 7z" fill="var(--color-signal)" />
                  <line x1="132" y1="4" x2="132" y2="84" stroke="var(--color-signal)" strokeWidth="1.5" />
                </svg>
                <h3 className="mt-5 text-xl font-[680]">Tracks, not stylesheets</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink2">
                  Clips, keyframes, and a playhead you can trust. Nudge a cue by one
                  frame, retime a whole scene by the handful.
                </p>
              </article>

              <article className="cel-card" data-reveal style={{ "--rd": "90ms" }}>
                <CardRegs />
                <svg viewBox="0 0 240 88" className="w-full" aria-hidden="true">
                  <line x1="16" y1="14" x2="16" y2="76" stroke="var(--color-line)" />
                  <line x1="16" y1="76" x2="224" y2="76" stroke="var(--color-line)" />
                  <line x1="16" y1="16" x2="224" y2="16" stroke="var(--color-line)" strokeDasharray="3 4" />
                  <line x1="16" y1="76" x2="104" y2="76" stroke="var(--color-cyan)" strokeWidth="1.5" />
                  <line x1="224" y1="16" x2="128" y2="6" stroke="var(--color-signal)" strokeWidth="1.5" />
                  <path d="M16 76 C 104 76, 128 6, 224 16" fill="none" stroke="var(--color-ink)" strokeWidth="2.5" />
                  <circle cx="104" cy="76" r="5" fill="var(--color-sheet)" stroke="var(--color-cyan)" strokeWidth="2.5" />
                  <circle cx="128" cy="6" r="5" fill="var(--color-sheet)" stroke="var(--color-signal)" strokeWidth="2.5" />
                </svg>
                <h3 className="mt-5 text-xl font-[680]">Curves you can grab</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink2">
                  Overshoot, anticipation, spring-fit — sculpted by hand in a real curve
                  editor and previewed before you commit.
                </p>
              </article>

              <article className="cel-card" data-reveal style={{ "--rd": "180ms" }}>
                <CardRegs />
                <pre className="codeblock codeblock-sm" aria-label="Example of exported CSS">
{`.headline { animation: rise .7s
    cubic-bezier(.22,1,.36,1) both; }
@keyframes rise { from {
    translate: 0 130%; } }`}
                </pre>
                <h3 className="mt-5 text-xl font-[680]">Ink that ships</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink2">
                  Export CSS, Web Animations, or framework-native code. Readable,
                  diffable, yours — no runtime lock-in.
                </p>
              </article>
            </div>
          </div>
        </section>

        {/* ---------------- SHEET 03 · the curve room ---------------- */}
        <section id="curves" aria-labelledby="h-curves" className="scroll-mt-16 border-t border-line bg-sheet/60">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 py-24 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
            <div data-reveal>
              <Kicker>Sheet 03 · The curve room</Kicker>
              <h2 id="h-curves" className={h2} style={{ fontStretch: "106%" }}>
                Easing, by hand
              </h2>
              <p className="mt-5 max-w-[52ch] text-[16px] leading-relaxed text-ink2">
                Motion gets its character from the curve, so Meridian gives the curve a
                room of its own. Grab a handle — the cyan one eases you out of the start,
                the red one lands you at the end. Pull above the box for overshoot,
                below it for anticipation.
              </p>
              <p className="mt-4 max-w-[52ch] text-[16px] leading-relaxed text-ink2">
                This is the actual editor control, embedded — not a video of it. Copy the
                curve out when it feels inevitable.
              </p>
              <p className="u-label mt-6 text-ink2/80">
                Same colors as the onion skin above: cyan sketches, red lands.
              </p>
            </div>
            <div data-reveal style={{ "--rd": "90ms" }}>
              <CurveEditor />
            </div>
          </div>
        </section>

        {/* ---------------- SHEET 04 · workflow ---------------- */}
        <section id="workflow" aria-labelledby="h-flow" className="scroll-mt-16 border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-24">
            <div data-reveal>
              <Kicker>Sheet 04 · Workflow</Kicker>
              <h2 id="h-flow" className={h2} style={{ fontStretch: "106%" }}>
                Blue pencil to ink
              </h2>
            </div>

            <ol className="mt-12 grid list-none gap-5 p-0 md:grid-cols-3">
              <li className="cel-card" data-reveal>
                <p className="u-label text-cyan">01 · Block</p>
                <p className="mt-3 text-[15px] leading-relaxed text-ink2">
                  Rough the shot in on tracks — entrances, holds, exits. Twelve frames
                  here, eight there, the way an editor blocks a scene.
                </p>
              </li>
              <li className="cel-card" data-reveal style={{ "--rd": "90ms" }}>
                <p className="u-label text-cyan">02 · Tune</p>
                <p className="mt-3 text-[15px] leading-relaxed text-ink2">
                  Open the curve room. Bend the easing until the motion has weight, and
                  watch the preview loop until it feels inevitable.
                </p>
              </li>
              <li className="cel-card" data-reveal style={{ "--rd": "180ms" }}>
                <p className="u-label text-cyan">03 · Ship</p>
                <p className="mt-3 text-[15px] leading-relaxed text-ink2">
                  Export ink. Meridian writes the code you previewed — same frames, same
                  curves, ready for review.
                </p>
              </li>
            </ol>

            <figure className="mt-12" data-reveal>
              <figcaption className="u-label mb-3 text-ink2">
                Export · Shot 01 — the hero you just scrubbed
              </figcaption>
              <pre className="codeblock">
{`// hero.entrance.meridian → export/timeline.js
`}<span className="c2">{`export const entrance`}</span>{` = timeline([
  clip(`}<span className="c3">{`"headline"`}</span>{`, maskRise(),                   { at: `}<span className="c3">0.50</span>{`, dur: `}<span className="c3">1.15</span>{`, stagger: `}<span className="c3">0.18</span>{` }),
  clip(`}<span className="c3">{`"retime"`}</span>{`,   fontStretch([`}<span className="c3">62</span>{`, `}<span className="c3">125</span>{`]),      { at: `}<span className="c3">1.35</span>{`, ease: overshoot(`}<span className="c3">1.4</span>{`) }),
  clip(`}<span className="c3">{`"ghosts"`}</span>{`,   onionSkin({ prev: `}<span className="c3">{`"cyan"`}</span>{`, next: `}<span className="c3">{`"red"`}</span>{` }), { at: `}<span className="c3">1.60</span>{` }),
  clip(`}<span className="c3">{`"lock"`}</span>{`,     stamp(),                      { at: `}<span className="c3">2.90</span>{`, ease: back(`}<span className="c3">3</span>{`) }),
])
`}<span className="c1">{`// 120 frames @ 30fps — byte-for-byte the entrance at the top of this page`}</span>
              </pre>
            </figure>
          </div>
        </section>

        {/* ---------------- SHEET 05 · access ---------------- */}
        <section id="access" aria-labelledby="h-access" className="scroll-mt-16 border-t border-line bg-sheet/60">
          <div className="mx-auto max-w-6xl px-5 py-24">
            <div data-reveal>
              <Kicker>Sheet 05 · Access</Kicker>
              <h2 id="h-access" className={h2} style={{ fontStretch: "106%" }}>
                Get on the call sheet
              </h2>
              <p className="mt-5 max-w-[54ch] text-[16px] leading-relaxed text-ink2">
                Meridian is in private beta while we finish the export pipeline. Seats
                open in small batches — designers and the engineers they ship with first.
              </p>
            </div>
            <div className="mt-10" data-reveal style={{ "--rd": "90ms" }}>
              <Waitlist />
              <p className="u-label mt-5 text-ink2/70">
                No spam — one email when your seat is ready · hello@meridian.tools
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* ---------------- footer: the ink ---------------- */}
      <footer className="bg-ink text-cel">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-3">
          <div>
            <p className="font-mono text-[13px] font-[600] tracking-[0.18em]">
              MERIDIAN<span className="text-signal">°</span>
            </p>
            <p className="mt-3 text-[15px] text-cel/80">Motion, on the record.</p>
          </div>
          <p className="m-0 font-mono text-[11px] leading-[2] text-cel/60">
            Drawn in non-photo blue. Shipped in ink.
            <br />
            Set in Archivo and Martian Mono.
            <br />
            The hero up top is a real timeline — go scrub it.
          </p>
          <div className="font-mono text-[11px] leading-[2] text-cel/60 md:text-right">
            <a href="mailto:hello@meridian.tools" className="text-cel/80 no-underline hover:text-cel">
              hello@meridian.tools
            </a>
            <br />© 2026 Meridian
          </div>
        </div>
        <div className="border-t border-cel/15">
          <div className="u-label mx-auto flex max-w-6xl items-center justify-between px-5 py-4 text-cel/45">
            <span>— End of reel —</span>
            <span>TC 00:00:04:00 · F120</span>
          </div>
        </div>
      </footer>

      <Reveal />
    </>
  );
}
