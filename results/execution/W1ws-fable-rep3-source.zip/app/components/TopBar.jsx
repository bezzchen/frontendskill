"use client";
import { useEffect, useRef } from "react";
import { smpte } from "./hero/score";

/**
 * Sticky header. The timecode reads the scroll position (600px = 1s),
 * so the whole page reads as footage you scrub by scrolling.
 * Event-driven only: no work happens while the page is idle.
 */
export default function TopBar() {
  const tcRef = useRef(null);
  const barRef = useRef(null);

  useEffect(() => {
    let scheduled = false;
    const update = () => {
      scheduled = false;
      const doc = document.documentElement;
      const max = Math.max(1, doc.scrollHeight - window.innerHeight);
      const y = window.scrollY;
      if (barRef.current) barRef.current.style.transform = `scaleX(${Math.min(1, y / max)})`;
      if (tcRef.current) tcRef.current.textContent = smpte(y / 600);
    };
    const onScroll = () => {
      if (!scheduled) {
        scheduled = true;
        requestAnimationFrame(update);
      }
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const link = "u-label text-ink2 hover:text-ink no-underline";

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-cel/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-6 px-5 py-3">
        <a href="#top" className="no-underline text-ink font-mono text-[13px] font-[600] tracking-[0.18em]">
          MERIDIAN<span className="text-signal">°</span>
        </a>
        <nav aria-label="Sections" className="hidden items-center gap-5 md:flex">
          <a className={link} href="#shot-01">Timeline</a>
          <a className={link} href="#curves">Curves</a>
          <a className={link} href="#workflow">Workflow</a>
          <a className={link} href="#access">Access</a>
        </nav>
        <p className="tc ml-auto" aria-hidden="true">
          SCRL <output ref={tcRef} aria-live="off">00:00:00:00</output>
        </p>
      </div>
      <div
        ref={barRef}
        aria-hidden="true"
        className="absolute bottom-[-1px] left-0 h-[2px] w-full origin-left bg-signal"
        style={{ transform: "scaleX(0)" }}
      />
    </header>
  );
}
