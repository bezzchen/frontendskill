"use client";
import { useRef, useState } from "react";

export default function Waitlist() {
  const inputRef = useRef(null);
  const [state, setState] = useState("idle"); // idle | error | done

  const submit = (e) => {
    e.preventDefault();
    const input = inputRef.current;
    if (!input.value || !input.checkValidity()) {
      setState("error");
      input.focus();
      return;
    }
    setState("done");
  };

  if (state === "done") {
    return (
      <p role="status" className="chip font-mono text-[12px] tracking-[0.08em] text-ink">
        <span aria-hidden="true" className="inline-block size-2 rounded-full bg-cyan" />
        SLATED — you are on the call sheet. One email when your seat is ready.
      </p>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="flex max-w-xl flex-col gap-3 sm:flex-row">
      <div className="flex-1">
        <label htmlFor="wl-email" className="u-label mb-2 block text-ink2">
          Email
        </label>
        <input
          ref={inputRef}
          id="wl-email"
          name="email"
          type="email"
          required
          autoComplete="email"
          placeholder="you@studio.tld"
          className="input"
          aria-describedby={state === "error" ? "wl-err" : undefined}
          onChange={() => state === "error" && setState("idle")}
        />
        {state === "error" && (
          <p id="wl-err" role="alert" className="mt-2 font-mono text-[11px] tracking-[0.05em] text-signal">
            Enter a valid email so we can cue you.
          </p>
        )}
      </div>
      <button type="submit" className="btn self-start sm:mt-[26px]">
        Request access
      </button>
    </form>
  );
}
