"use client";
import { useEffect, useRef, useState } from "react";

// Plot geometry: progress 0..1 maps to x, value -0.5..1.5 visible (overshoot room)
const W = 560, H = 560, PX0 = 40, PXW = 480, PY0 = 396, PYH = 240;
const px = (x) => PX0 + x * PXW;
const py = (v) => PY0 - v * PYH;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const fmt = (n) => String(Math.round(n * 100) / 100);

const PRESETS = [
  { name: "Glide", v: [0.22, 1, 0.36, 1] },
  { name: "Snap", v: [0.7, 0, 0.16, 1] },
  { name: "Overshoot", v: [0.34, 1.56, 0.64, 1] },
  { name: "Anticipate", v: [0.55, -0.42, 0.6, 1] },
];

const XS = [0, 0.25, 0.5, 0.75, 1];
const VS = [-0.5, -0.25, 0, 0.25, 0.5, 0.75, 1, 1.25, 1.5];

export default function CurveEditor() {
  const [pts, setPts] = useState({ x1: 0.34, y1: 1.56, x2: 0.64, y2: 1 });
  const [copied, setCopied] = useState(false);
  const svgRef = useRef(null);
  const dragRef = useRef(null);
  const chipRef = useRef(null);
  const trackRef = useRef(null);
  const animRef = useRef(null);
  const tRef = useRef(null);

  const css = `cubic-bezier(${fmt(pts.x1)}, ${fmt(pts.y1)}, ${fmt(pts.x2)}, ${fmt(pts.y2)})`;

  const toLocal = (e) => {
    const r = svgRef.current.getBoundingClientRect();
    const sx = ((e.clientX - r.left) / r.width) * W;
    const sy = ((e.clientY - r.top) / r.height) * H;
    return { x: clamp((sx - PX0) / PXW, 0, 1), y: clamp((PY0 - sy) / PYH, -0.6, 1.6) };
  };
  const apply = (which, p) =>
    setPts((prev) => (which === 1 ? { ...prev, x1: p.x, y1: p.y } : { ...prev, x2: p.x, y2: p.y }));
  const startDrag = (which) => (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    dragRef.current = which;
    svgRef.current.setPointerCapture(e.pointerId);
    apply(which, toLocal(e));
  };
  const onMove = (e) => {
    if (dragRef.current) apply(dragRef.current, toLocal(e));
  };
  const onUp = () => {
    dragRef.current = null;
  };

  const keyFor = (which) => (e) => {
    const dx = e.shiftKey ? 0.1 : 0.02;
    const dy = e.shiftKey ? 0.25 : 0.05;
    const m = { ArrowLeft: [-dx, 0], ArrowRight: [dx, 0], ArrowUp: [0, dy], ArrowDown: [0, -dy] }[e.key];
    if (!m) return;
    e.preventDefault();
    setPts((prev) => {
      const [kx, ky] = which === 1 ? ["x1", "y1"] : ["x2", "y2"];
      return { ...prev, [kx]: clamp(prev[kx] + m[0], 0, 1), [ky]: clamp(prev[ky] + m[1], -0.6, 1.6) };
    });
  };

  // Finite, user-initiated preview (WAAPI) — allowed under reduced motion because it is explicitly requested.
  const run = () => {
    const chip = chipRef.current;
    const track = trackRef.current;
    if (!chip || !track) return;
    animRef.current?.cancel();
    const dist = Math.max(0, track.clientWidth - 40);
    animRef.current = chip.animate(
      [{ transform: "translateX(0px)" }, { transform: `translateX(${dist}px)` }],
      { duration: 900, easing: css, fill: "forwards" }
    );
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(css);
      setCopied(true);
      clearTimeout(tRef.current);
      tRef.current = setTimeout(() => setCopied(false), 1600);
    } catch {
      /* clipboard unavailable — the code is selectable */
    }
  };

  useEffect(
    () => () => {
      clearTimeout(tRef.current);
      animRef.current?.cancel();
    },
    []
  );

  const handle = (which, cx, cy, color, label) => (
    <g
      className="handle"
      tabIndex={0}
      role="slider"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round((which === 1 ? pts.x1 : pts.x2) * 100)}
      aria-valuetext={`x ${fmt(which === 1 ? pts.x1 : pts.x2)}, y ${fmt(which === 1 ? pts.y1 : pts.y2)}`}
      onPointerDown={startDrag(which)}
      onKeyDown={keyFor(which)}
    >
      <circle className="focusring" cx={cx} cy={cy} r={15} fill="none" stroke="var(--color-ink)" strokeDasharray="3 3" />
      <circle cx={cx} cy={cy} r={17} fill="transparent" />
      <circle cx={cx} cy={cy} r={8} fill="var(--color-sheet)" stroke={color} strokeWidth={3.5} />
    </g>
  );

  return (
    <div>
      <div className="cel-card p-3 sm:p-4">
        <svg
          ref={svgRef}
          className="curve-svg"
          viewBox={`0 0 ${W} ${H}`}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
          role="img"
          aria-label={`Easing curve editor, currently ${css}`}
        >
          {/* construction grid */}
          {XS.map((x) => (
            <line key={`x${x}`} x1={px(x)} y1={py(1.5)} x2={px(x)} y2={py(-0.5)} stroke="var(--color-line)" strokeWidth="1" />
          ))}
          {VS.map((v) => (
            <line key={`v${v}`} x1={px(0)} y1={py(v)} x2={px(1)} y2={py(v)} stroke="var(--color-line)" strokeWidth="1" />
          ))}
          {/* the 0..1 box */}
          <rect x={px(0)} y={py(1)} width={PXW} height={PYH} fill="none" stroke="var(--color-line2)" strokeWidth="1.5" />
          <text x={px(0) - 14} y={py(0) + 4} fontSize="10" fill="var(--color-ink2)" fontFamily="var(--font-mono)" textAnchor="end">0</text>
          <text x={px(0) - 14} y={py(1) + 4} fontSize="10" fill="var(--color-ink2)" fontFamily="var(--font-mono)" textAnchor="end">1</text>
          <text x={px(1)} y={py(-0.5) + 26} fontSize="10" fill="var(--color-ink2)" fontFamily="var(--font-mono)" textAnchor="end" letterSpacing="2">TIME →</text>
          <text x={px(0) - 26} y={py(1.5) + 40} fontSize="10" fill="var(--color-ink2)" fontFamily="var(--font-mono)" letterSpacing="2" transform={`rotate(-90 ${px(0) - 26} ${py(1.5) + 40})`} textAnchor="end">VALUE ↑</text>

          {/* stems */}
          <line x1={px(0)} y1={py(0)} x2={px(pts.x1)} y2={py(pts.y1)} stroke="var(--color-cyan)" strokeWidth="1.5" />
          <line x1={px(1)} y1={py(1)} x2={px(pts.x2)} y2={py(pts.y2)} stroke="var(--color-signal)" strokeWidth="1.5" />

          {/* the curve */}
          <path
            d={`M ${px(0)} ${py(0)} C ${px(pts.x1)} ${py(pts.y1)}, ${px(pts.x2)} ${py(pts.y2)}, ${px(1)} ${py(1)}`}
            fill="none"
            stroke="var(--color-ink)"
            strokeWidth="3"
            strokeLinecap="round"
          />

          {/* anchors */}
          <rect x={px(0) - 4.5} y={py(0) - 4.5} width="9" height="9" fill="var(--color-ink)" />
          <rect x={px(1) - 4.5} y={py(1) - 4.5} width="9" height="9" fill="var(--color-ink)" />

          {handle(1, px(pts.x1), py(pts.y1), "var(--color-cyan)", "Control point 1 — drag or use arrow keys")}
          {handle(2, px(pts.x2), py(pts.y2), "var(--color-signal)", "Control point 2 — drag or use arrow keys")}
        </svg>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.name}
            type="button"
            className="btn-ghost btn-sm font-mono text-[10px] uppercase tracking-[0.12em]"
            onClick={() => setPts({ x1: p.v[0], y1: p.v[1], x2: p.v[2], y2: p.v[3] })}
          >
            {p.name}
          </button>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <code className="rounded border border-line bg-sheet px-3 py-2 font-mono text-[11.5px] text-ink">{css}</code>
        <button type="button" className="btn-ghost btn-sm" onClick={copy}>
          {copied ? "Copied ✓" : "Copy"}
        </button>
        <span aria-live="polite" className="sr-only">{copied ? "Copied to clipboard" : ""}</span>
      </div>

      <div className="mt-5">
        <div ref={trackRef} className="relative h-11 rounded border border-line bg-wash/40">
          <div ref={chipRef} className="absolute left-[6px] top-[6px] size-7 rounded-[3px] bg-ink" aria-hidden="true" />
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button type="button" className="btn btn-sm" onClick={run}>Run preview</button>
          <span className="u-label text-ink2/80">Runs once, on your cue — with the curve above</span>
        </div>
      </div>
    </div>
  );
}
