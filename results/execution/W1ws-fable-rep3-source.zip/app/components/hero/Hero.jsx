"use client";
import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { TRACKS, DUR, FPS, FRAMES, LOOP, smpte, frameOf } from "./score";
import { governLoop } from "../../lib/governor";
import { usePrm, prmNow } from "../../lib/usePrm";

gsap.registerPlugin(useGSAP);

const WORDS = ["Take", "your", "time."];
const pct = (t) => `${(t / DUR) * 100}%`;

function HeroLine({ ghost }) {
  return WORDS.map((w, i) => (
    <span key={i}>
      <span className="mask">
        <span className={`${ghost ? "wordg" : "word"}${w === "time." ? " js-time" : ""}`}>{w}</span>
      </span>
      {i < WORDS.length - 1 ? " " : ""}
    </span>
  ));
}

const IconPlay = (
  <svg viewBox="0 0 14 14" width="12" height="12" aria-hidden="true">
    <path d="M3.5 2l9 5-9 5z" fill="currentColor" />
  </svg>
);
const IconPause = (
  <svg viewBox="0 0 14 14" width="12" height="12" aria-hidden="true">
    <rect x="3" y="2" width="3" height="10" fill="currentColor" />
    <rect x="8.4" y="2" width="3" height="10" fill="currentColor" />
  </svg>
);
const IconStart = (
  <svg viewBox="0 0 14 14" width="12" height="12" aria-hidden="true">
    <rect x="2.6" y="2" width="1.6" height="10" fill="currentColor" />
    <path d="M11.8 2L5.6 7l6.2 5z" fill="currentColor" />
  </svg>
);
const IconStepB = (
  <svg viewBox="0 0 14 14" width="12" height="12" aria-hidden="true">
    <path d="M10 2L4.6 7 10 12z" fill="currentColor" />
    <rect x="3" y="2" width="1.4" height="10" fill="currentColor" />
  </svg>
);
const IconStepF = (
  <svg viewBox="0 0 14 14" width="12" height="12" aria-hidden="true">
    <path d="M4 2l5.4 5L4 12z" fill="currentColor" />
    <rect x="9.6" y="2" width="1.4" height="10" fill="currentColor" />
  </svg>
);

export default function Hero() {
  const stageRef = useRef(null);
  const fieldRef = useRef(null);
  const rulerRef = useRef(null);
  const playheadRef = useRef(null);
  const flagRef = useRef(null);
  const tcRef = useRef(null);

  const tlRef = useRef(null);
  const loopTweenRef = useRef(null);
  const govRef = useRef(null);
  const heldRef = useRef(null); // "main" | "loop" | null — what the governor suspended
  const pendingStartRef = useRef(null);
  const scrubbingRef = useRef(false);
  const fieldWRef = useRef(1);
  const lastFRef = useRef(-1);

  const [playing, setPlaying] = useState(false);
  const [loopOn, setLoopOn] = useState(true);
  const loopOnRef = useRef(true);
  loopOnRef.current = loopOn;
  const prm = usePrm();

  /* ---------- playhead / readout sync (driven by the timeline itself) ---------- */
  const sync = () => {
    const tl = tlRef.current;
    if (!tl) return;
    const t = tl.time();
    if (playheadRef.current)
      playheadRef.current.style.transform = `translate3d(${(t / DUR) * fieldWRef.current}px,0,0)`;
    if (flagRef.current) {
      const flip = t / DUR > 0.86;
      flagRef.current.style.left = flip ? "auto" : "5px";
      flagRef.current.style.right = flip ? "5px" : "auto";
    }
    const f = frameOf(t);
    if (f !== lastFRef.current) {
      lastFRef.current = f;
      const fs = String(f).padStart(3, "0");
      if (flagRef.current) flagRef.current.textContent = `F${fs}`;
      if (tcRef.current) tcRef.current.textContent = `${smpte(t)} · F${fs}/${FRAMES}`;
      const r = rulerRef.current;
      if (r) {
        r.setAttribute("aria-valuenow", String(f));
        r.setAttribute("aria-valuetext", `frame ${f} of ${FRAMES} — ${smpte(t)}`);
      }
    }
  };

  const killLoop = () => {
    if (loopTweenRef.current) {
      loopTweenRef.current.kill();
      loopTweenRef.current = null;
    }
  };

  const startRegionLoop = () => {
    killLoop();
    loopTweenRef.current = tlRef.current.tweenFromTo(LOOP[0], LOOP[1], { repeat: -1, ease: "none" });
  };

  /* Route every start through the governor so nothing can run while occluded. */
  const requestStart = (fn) => {
    const g = govRef.current;
    if (!g) return;
    if (g.state().running) fn();
    else {
      pendingStartRef.current = fn;
      g.setWants(true);
    }
  };

  const stopAll = () => {
    killLoop();
    pendingStartRef.current = null;
    tlRef.current?.pause();
    govRef.current?.setWants(false);
    setPlaying(false);
  };

  const seek = (t) => {
    const tl = tlRef.current;
    if (!tl) return;
    tl.time(Math.max(0, Math.min(DUR, t)), true);
    sync();
  };

  /* ---------- transport ---------- */
  const togglePlay = () => {
    if (playing) {
      stopAll();
      return;
    }
    requestStart(() => {
      const tl = tlRef.current;
      if (tl.progress() >= 0.999) tl.play(0);
      else tl.play();
    });
    setPlaying(true);
  };

  const restart = () => {
    killLoop();
    requestStart(() => tlRef.current.play(0));
    setPlaying(true);
  };

  const step = (df) => {
    const tl = tlRef.current;
    if (!tl) return;
    stopAll();
    seek(tl.time() + df / FPS);
  };

  const toggleLoop = () => {
    const nv = !loopOnRef.current;
    if (!nv) {
      if (loopTweenRef.current || heldRef.current === "loop") {
        killLoop();
        heldRef.current = null;
        govRef.current?.setWants(false);
        setPlaying(false);
      }
    } else {
      const tl = tlRef.current;
      if (tl && !tl.isActive() && !loopTweenRef.current && tl.progress() >= 0.999 && !prmNow()) {
        requestStart(startRegionLoop);
        setPlaying(true);
      }
    }
    setLoopOn(nv);
  };

  /* ---------- scrub (pointer) ---------- */
  const timeAt = (clientX) => {
    const r = fieldRef.current.getBoundingClientRect();
    return ((clientX - r.left) / Math.max(1, r.width)) * DUR;
  };
  const onDown = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    stopAll();
    scrubbingRef.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
    seek(timeAt(e.clientX));
  };
  const onMove = (e) => {
    if (scrubbingRef.current) seek(timeAt(e.clientX));
  };
  const onUp = () => {
    scrubbingRef.current = false;
  };

  /* ---------- keyboard (playhead is a slider) ---------- */
  const onKey = (e) => {
    const tl = tlRef.current;
    if (!tl) return;
    const nudge = (df) => {
      stopAll();
      seek(tl.time() + df / FPS);
    };
    switch (e.key) {
      case "ArrowLeft": nudge(e.shiftKey ? -10 : -1); break;
      case "ArrowRight": nudge(e.shiftKey ? 10 : 1); break;
      case "PageUp": nudge(30); break;
      case "PageDown": nudge(-30); break;
      case "Home": stopAll(); seek(0); break;
      case "End": stopAll(); seek(DUR); break;
      case " ": case "k": case "Enter": togglePlay(); break;
      default: return;
    }
    e.preventDefault();
  };

  /* ---------- build the timeline from the score ---------- */
  useGSAP(
    () => {
      const stage = stageRef.current;
      const S = (sel) => stage.querySelectorAll(sel);

      const tl = gsap.timeline({
        paused: true,
        defaults: { ease: "power3.out" },
        onUpdate: sync,
        onComplete: () => {
          if (loopOnRef.current && !prmNow()) {
            startRegionLoop();
          } else {
            govRef.current?.setWants(false);
            setPlaying(false);
          }
        },
      });

      // Reveal the word masks on the timeline's first render (the CSS gate hides
      // them pre-hydration; transforms stay exclusively GSAP-owned).
      tl.set(S(".mask"), { opacity: 1 }, 0);

      // Track 1 — construction grid
      tl.fromTo(S('[data-a="fade"]'), { opacity: 0 }, { opacity: 1, duration: 0.6, ease: "power1.inOut" }, 0)
        .fromTo(S("[data-reg]"), { scale: 0 }, { scale: 1, duration: 0.35, stagger: 0.05, ease: "back.out(2.5)" }, 0.1)
        // Track 2 — kicker
        .fromTo(S('[data-a="kicker"]'), { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5 }, 0.25)
        // Track 3 — headline words rise out of their masks
        .fromTo(S(".word"), { yPercent: 130 }, { yPercent: 0, duration: 0.7, stagger: 0.18, ease: "power4.out" }, 0.5)
        // Track 4 — retime: the word "time." is literally time-stretched (wdth 62 -> 125)
        .fromTo(stage, { "--wdthTime": "62%" }, { "--wdthTime": "125%", duration: 0.85, ease: "back.out(1.4)" }, 1.35)
        // Track 5 — onion-skin ghosts converge
        .fromTo(S(".ghost-cyan"), { opacity: 0 }, { opacity: 0.44, duration: 0.9, ease: "power2.out" }, 1.6)
        .fromTo(S(".ghost-red"), { opacity: 0 }, { opacity: 0.4, duration: 0.9, ease: "power2.out" }, 1.6)
        .fromTo(stage, { "--gxc": "-0.34em" }, { "--gxc": "-0.05em", duration: 0.9, ease: "power2.out" }, 1.6)
        .fromTo(stage, { "--gxr": "0.34em" }, { "--gxr": "0.05em", duration: 0.9, ease: "power2.out" }, 1.6)
        // Track 6 — subhead
        .fromTo(S('[data-a="sub"]'), { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6 }, 2.2)
        // Track 7 — actions
        .fromTo(S('[data-a="cta"]'), { y: 16, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, stagger: 0.12 }, 2.5)
        // Track 8 — picture lock stamp
        .fromTo(
          S('[data-a="stamp"]'),
          { opacity: 0, scale: 1.7, rotation: -9 },
          { opacity: 1, scale: 1, rotation: -3, duration: 0.3, ease: "back.out(3)" },
          2.9
        )
        // Loop-region content (3.2 -> 4.0): ghost drift, seamless at both ends
        .to(stage, { keyframes: [
          { "--gxc": "-0.095em", duration: 0.4, ease: "sine.inOut" },
          { "--gxc": "-0.05em", duration: 0.4, ease: "sine.inOut" },
        ] }, LOOP[0])
        .to(stage, { keyframes: [
          { "--gxr": "0.095em", duration: 0.4, ease: "sine.inOut" },
          { "--gxr": "0.05em", duration: 0.4, ease: "sine.inOut" },
        ] }, LOOP[0]);

      tlRef.current = tl;

      // Reduced motion: settle the finished frame before first paint. Content intact.
      if (prmNow()) {
        tl.progress(1, true);
      }
      sync();
    },
    { scope: stageRef }
  );

  /* ---------- governor + measurements + debug registry ---------- */
  useEffect(() => {
    const gov = governLoop("hero", stageRef.current, {
      onPlay: () => {
        const pend = pendingStartRef.current;
        if (pend) {
          pendingStartRef.current = null;
          heldRef.current = null;
          pend();
          return;
        }
        if (heldRef.current === "loop") loopTweenRef.current?.resume();
        else if (heldRef.current === "main") tlRef.current?.play();
        heldRef.current = null;
      },
      onPause: () => {
        if (loopTweenRef.current?.isActive()) {
          heldRef.current = "loop";
          loopTweenRef.current.pause();
        } else if (tlRef.current?.isActive()) {
          heldRef.current = "main";
          tlRef.current.pause();
        } else {
          heldRef.current = null;
        }
      },
    });
    govRef.current = gov;

    const measure = () => {
      fieldWRef.current = fieldRef.current?.clientWidth || 1;
      sync();
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(fieldRef.current);

    const w = (window.__meridian ||= { loops: {} });
    w.prm = prmNow();
    w.hero = {
      time: () => tlRef.current?.time() ?? 0,
      frame: () => frameOf(tlRef.current?.time() ?? 0),
      active: () => !!(tlRef.current?.isActive() || loopTweenRef.current?.isActive()),
      mode: () => (loopTweenRef.current?.isActive() ? "loop" : tlRef.current?.isActive() ? "main" : "idle"),
      tick: () => gsap.ticker.frame, // advances only while GSAP's rAF ticker is awake
    };

    return () => {
      killLoop();
      ro.disconnect();
      gov.dispose();
      govRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- autoplay once fonts are in (skipped under reduced motion) ---------- */
  useEffect(() => {
    if (prmNow()) return;
    let cancelled = false;
    const kick = () => {
      if (cancelled || !tlRef.current || scrubbingRef.current) return;
      requestStart(() => tlRef.current.play(0));
      setPlaying(true);
    };
    const ready = document.fonts?.ready ?? Promise.resolve();
    const t0 = new Promise((r) => setTimeout(r, 900));
    let timer;
    Promise.race([ready, t0]).then(() => {
      if (!cancelled) timer = setTimeout(kick, 200);
    });
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- live change of the reduced-motion preference ---------- */
  useEffect(() => {
    if (window.__meridian) window.__meridian.prm = prm ?? prmNow();
    if (prm === true && tlRef.current) {
      stopAll();
      tlRef.current.progress(1, true);
      sync();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prm]);

  /* ================================================================ */
  return (
    <section id="top" ref={stageRef} aria-labelledby="hero-h1" className="relative scroll-mt-16 overflow-hidden">
      {/* the light table */}
      <div data-a="fade" aria-hidden="true" className="construction construction-fade pointer-events-none absolute inset-0">
        <span data-reg className="reg left-[3%] top-[10%]" />
        <span data-reg className="reg right-[5%] top-[16%]" />
        <span data-reg className="reg left-[38%] top-[6%]" />
        <span data-reg className="reg left-[7%] top-[64%]" />
        <span data-reg className="reg right-[24%] top-[58%]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-5 pb-10 pt-14 sm:pt-20">
        <p data-a="kicker" className="chip u-label">
          <span className="inline-block size-2 rounded-full bg-signal" aria-hidden="true" />
          Shot 01 · a motion editor for the web · private beta
        </p>

        <div className="relative mt-8 max-w-[15ch]">
          <p className="ghost ghost-cyan hero-h1" aria-hidden="true"><HeroLine ghost /></p>
          <p className="ghost ghost-red hero-h1" aria-hidden="true"><HeroLine ghost /></p>
          <h1 id="hero-h1" className="hero-h1 relative z-[1]"><HeroLine /></h1>
        </div>

        <p data-a="sub" className="mt-7 max-w-[56ch] text-[17px] leading-relaxed text-ink2 sm:text-lg">
          Meridian is a timeline-based motion editor for the web. Block the shot on real
          tracks, bend every curve by hand, and ship the exact code you previewed —
          CSS, Web Animations, or your framework.
        </p>

        <div className="mt-9 flex flex-wrap items-center gap-4">
          <a data-a="cta" className="btn" href="#access">Request early access</a>
          <a data-a="cta" className="btn-ghost" href="#shot-01">Scrub the timeline ↓</a>
        </div>

        <div data-a="stamp" className="stamp absolute right-6 top-16 hidden lg:block" aria-hidden="true">
          PICTURE LOCK ★ TAKE 07
        </div>
      </div>

      {/* ---------- the dope sheet: this page's own entrance, scrubbable ---------- */}
      <div className="relative mx-auto max-w-6xl px-5 pb-16">
        <div id="shot-01" className="panel scroll-mt-24" role="group" aria-label="Shot 01 — the hero entrance timeline (live)">
          <div className="transport">
            <span className="u-label text-ink2">Shot 01 · hero entrance</span>
            <div className="ml-auto flex items-center gap-1.5 sm:ml-6" role="group" aria-label="Transport">
              <button type="button" className="tbtn" aria-label="Back to start" onClick={restart}>{IconStart}</button>
              <button type="button" className="tbtn" aria-label="Step back one frame" onClick={() => step(-1)}>{IconStepB}</button>
              <button type="button" className="tbtn" aria-label={playing ? "Pause" : "Play"} aria-pressed={playing} onClick={togglePlay}>
                {playing ? IconPause : IconPlay}
              </button>
              <button type="button" className="tbtn" aria-label="Step forward one frame" onClick={() => step(1)}>{IconStepF}</button>
              <button
                type="button"
                className="tbtn tbtn-wide font-mono text-[9px] tracking-[0.1em]"
                aria-label="Loop the preview region"
                aria-pressed={loopOn}
                onClick={toggleLoop}
              >
                LOOP
              </button>
            </div>
            <output ref={tcRef} className="tc" aria-live="off">00:00:00:00 · F000/120</output>
            <span className="u-label hidden text-ink2/70 xl:inline">space plays · ← → steps 1f · ⇧ 10f</span>
          </div>

          <div className="flex px-3 pb-3 sm:px-4 sm:pb-4">
            <div className="flex w-[74px] shrink-0 flex-col sm:w-[150px]">
              <div className="h-[34px]" aria-hidden="true" />
              {TRACKS.map((t) => (
                <div key={t.id} className="trklabel h-[27px] border-t border-line/70">
                  <span className="hidden sm:inline">{t.label}</span>
                  <span className="sm:hidden">{t.abbr}</span>
                </div>
              ))}
            </div>

            <div
              ref={fieldRef}
              className="field flex-1"
              onPointerDown={onDown}
              onPointerMove={onMove}
              onPointerUp={onUp}
              onPointerCancel={onUp}
            >
              <div
                ref={rulerRef}
                className="ruler"
                role="slider"
                tabIndex={0}
                aria-label="Playhead — scrub the hero entrance"
                aria-orientation="horizontal"
                aria-valuemin={0}
                aria-valuemax={FRAMES}
                aria-valuenow={0}
                aria-valuetext="frame 0 of 120"
                onKeyDown={onKey}
              >
                <div className="loopregion" style={{ left: pct(LOOP[0]), width: pct(LOOP[1] - LOOP[0]) }} aria-hidden="true">
                  <span className="looptag">LOOP</span>
                </div>
                {[0, 1, 2, 3].map((s) => (
                  <span key={s} className="ruler-sec" style={{ left: pct(s) }} aria-hidden="true">{s}s</span>
                ))}
                <div className="ruler-ticks" aria-hidden="true" />
              </div>

              {TRACKS.map((t) => (
                <div key={t.id} className="lane">
                  {t.clips.map((c, i) => (
                    <span key={i} className="clip" style={{ left: pct(c.at), width: pct(c.dur) }} aria-hidden="true">
                      <i className="key key-a" />
                      <em className="clipname hidden md:block">{c.name}</em>
                      <i className="key key-b" />
                    </span>
                  ))}
                </div>
              ))}

              <div ref={playheadRef} className="playhead" aria-hidden="true">
                <span ref={flagRef} className="phflag">F000</span>
              </div>
            </div>
          </div>
        </div>

        <p className="u-label mt-4 text-ink2/80">
          The panel is live — drag the playhead. Your scrub, not a video.
        </p>
      </div>
    </section>
  );
}
