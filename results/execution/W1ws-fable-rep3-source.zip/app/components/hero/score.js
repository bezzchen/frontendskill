// The single source of truth for Shot 01 — the hero's own entrance.
// The GSAP timeline and the visible dope sheet are both built from this data,
// so the panel can never drift from the motion it claims to show.

export const FPS = 30;
export const DUR = 4.0;
export const FRAMES = Math.round(DUR * FPS); // 120
export const LOOP = [3.2, 4.0]; // preview loop region — contains only loop-safe clips

export const TRACKS = [
  { id: "grid", label: "Construction", abbr: "GRID", clips: [{ at: 0.0, dur: 0.6, name: "fade up" }] },
  { id: "kicker", label: "Kicker", abbr: "KICK", clips: [{ at: 0.25, dur: 0.5, name: "rise" }] },
  { id: "headline", label: "Headline", abbr: "HEAD", clips: [{ at: 0.5, dur: 1.15, name: "mask rise ×3" }] },
  { id: "retime", label: "Retime · wdth", abbr: "WDTH", clips: [{ at: 1.35, dur: 0.85, name: "62 → 125" }] },
  { id: "ghosts", label: "Onion skin", abbr: "GHST", clips: [{ at: 1.6, dur: 0.9, name: "converge" }, { at: 3.2, dur: 0.8, name: "drift (loop)" }] },
  { id: "subhead", label: "Subhead", abbr: "SUB", clips: [{ at: 2.2, dur: 0.6, name: "rise" }] },
  { id: "actions", label: "Actions", abbr: "CTA", clips: [{ at: 2.5, dur: 0.62, name: "rise ×2" }] },
  { id: "lock", label: "Picture lock", abbr: "LOCK", clips: [{ at: 2.9, dur: 0.3, name: "stamp" }] },
];

const p2 = (n) => String(n).padStart(2, "0");

/** SMPTE-style timecode at 30fps: 00:MM:SS:FF */
export function smpte(sec) {
  const s = Math.max(0, sec);
  return `00:${p2(Math.floor(s / 60))}:${p2(Math.floor(s % 60))}:${p2(Math.floor((s * FPS) % FPS))}`;
}

export const frameOf = (sec) => Math.max(0, Math.min(FRAMES, Math.round(sec * FPS)));
