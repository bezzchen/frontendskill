"use client";

import { useEffect, useRef, useState } from "react";

const NOTIFICATION_OPTIONS = [
  {
    key: "activity",
    label: "Account activity",
    description: "Sign-ins, new devices, and security events.",
  },
  {
    key: "product",
    label: "Product updates",
    description: "Occasional notes when features ship.",
  },
  {
    key: "digest",
    label: "Weekly digest",
    description: "A short summary of your week, sent on Mondays.",
  },
];

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values) {
  const errors = {};
  if (!values.name.trim()) {
    errors.name = "Enter your name.";
  }
  if (!values.email.trim()) {
    errors.email = "Enter your email address.";
  } else if (!EMAIL_PATTERN.test(values.email.trim())) {
    errors.email = "Enter a valid email address, like name@example.com.";
  }
  if (values.password && values.password.length < 8) {
    errors.password = "Use at least 8 characters.";
  }
  return errors;
}

function ErrorMessage({ id, children }) {
  return (
    <p className="fade-in flex items-start gap-1.5 text-sm text-[var(--danger)]" id={id}>
      <svg aria-hidden="true" className="mt-0.5 h-4 w-4 flex-none" fill="none" viewBox="0 0 16 16">
        <circle cx="8" cy="8" r="6.25" stroke="currentColor" strokeWidth="1.5" />
        <path d="M8 4.75v3.75" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
        <circle cx="8" cy="11" fill="currentColor" r="0.9" />
      </svg>
      <span>{children}</span>
    </p>
  );
}

function SettingsCard({ id, title, description, children }) {
  return (
    <section
      aria-labelledby={id + "-title"}
      className="rounded-xl border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-6"
    >
      <h3 className="text-lg font-semibold" id={id + "-title"}>
        {title}
      </h3>
      <p className="mt-1 text-sm text-[var(--muted)]">{description}</p>
      <div className="mt-5">{children}</div>
    </section>
  );
}

export function SettingsPanel() {
  const [values, setValues] = useState({
    name: "Jordan Lee",
    email: "jordan@example.com",
    password: "",
  });
  const [notifications, setNotifications] = useState({
    activity: true,
    product: true,
    digest: false,
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | dirty | saving | saved
  const [showPassword, setShowPassword] = useState(false);

  const editSeqRef = useRef(0);
  const saveTimerRef = useRef(null);
  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const passwordRef = useRef(null);
  const fieldRefs = { name: nameRef, email: emailRef, password: passwordRef };

  useEffect(() => () => clearTimeout(saveTimerRef.current), []);

  function markEdited() {
    editSeqRef.current += 1;
    setStatus((current) => (current === "saving" ? "saving" : "dirty"));
  }

  function updateField(field, value) {
    setValues((current) => ({ ...current, [field]: value }));
    markEdited();
    if (errors[field]) {
      // A field that is already showing an error re-validates as you type,
      // so the message clears the moment the input becomes valid.
      const next = validate({ ...values, [field]: value });
      setErrors((current) => ({ ...current, [field]: next[field] }));
    }
  }

  function validateOnBlur(field) {
    const next = validate(values);
    setErrors((current) => ({ ...current, [field]: next[field] }));
  }

  function toggleNotification(key) {
    setNotifications((current) => ({ ...current, [key]: !current[key] }));
    markEdited();
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (status === "saving") return;

    const nextErrors = validate(values);
    setErrors(nextErrors);
    const firstInvalid = ["name", "email", "password"].find((field) => nextErrors[field]);
    if (firstInvalid) {
      fieldRefs[firstInvalid].current?.focus();
      return;
    }

    const startedSeq = editSeqRef.current;
    setStatus("saving");
    saveTimerRef.current = setTimeout(() => {
      if (editSeqRef.current === startedSeq) {
        // The new password was applied; clear the field so it never lingers.
        setValues((current) => ({ ...current, password: "" }));
        setShowPassword(false);
        setStatus("saved");
      } else {
        // The user kept editing while the save was in flight.
        setStatus("dirty");
      }
    }, 700);
  }

  const isSaving = status === "saving";

  return (
    <form
      aria-busy={isSaving}
      aria-labelledby="settings-title"
      className="space-y-6"
      noValidate
      onSubmit={handleSubmit}
    >
      <SettingsCard description="How you appear across the site." id="settings-profile" title="Profile">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium" htmlFor="settings-name">
              Name
            </label>
            <input
              aria-describedby={errors.name ? "settings-name-error" : undefined}
              aria-invalid={errors.name ? true : undefined}
              autoComplete="name"
              className="field"
              id="settings-name"
              name="name"
              onBlur={() => validateOnBlur("name")}
              onChange={(event) => updateField("name", event.target.value)}
              ref={nameRef}
              value={values.name}
            />
            {errors.name ? <ErrorMessage id="settings-name-error">{errors.name}</ErrorMessage> : null}
          </div>

          <div className="space-y-1.5">
            <label className="block text-sm font-medium" htmlFor="settings-email">
              Email
            </label>
            <input
              aria-describedby={
                errors.email ? "settings-email-error settings-email-hint" : "settings-email-hint"
              }
              aria-invalid={errors.email ? true : undefined}
              autoComplete="email"
              className="field"
              id="settings-email"
              name="email"
              onBlur={() => validateOnBlur("email")}
              onChange={(event) => updateField("email", event.target.value)}
              ref={emailRef}
              type="email"
              value={values.email}
            />
            {errors.email ? <ErrorMessage id="settings-email-error">{errors.email}</ErrorMessage> : null}
            <p className="text-sm text-[var(--muted)]" id="settings-email-hint">
              Used for sign-in and notifications.
            </p>
          </div>
        </div>
      </SettingsCard>

      <SettingsCard
        description="Choose what lands in your inbox."
        id="settings-notifications"
        title="Notifications"
      >
        <div className="divide-y divide-[var(--line)]">
          {NOTIFICATION_OPTIONS.map((option) => {
            const inputId = "notify-" + option.key;
            return (
              <label
                className="flex cursor-pointer items-start justify-between gap-4 py-3.5 select-none first:pt-0 last:pb-0"
                htmlFor={inputId}
                key={option.key}
              >
                <span className="min-w-0">
                  <span className="block text-sm font-medium leading-6" id={inputId + "-label"}>
                    {option.label}
                  </span>
                  <span className="mt-0.5 block text-sm leading-5 text-[var(--muted)]" id={inputId + "-desc"}>
                    {option.description}
                  </span>
                </span>
                <input
                  aria-describedby={inputId + "-desc"}
                  aria-labelledby={inputId + "-label"}
                  checked={notifications[option.key]}
                  className="toggle-input sr-only"
                  id={inputId}
                  onChange={() => toggleNotification(option.key)}
                  role="switch"
                  type="checkbox"
                />
                <span aria-hidden="true" className="toggle-track" />
              </label>
            );
          })}
        </div>
      </SettingsCard>

      <SettingsCard description="Set a new password for your account." id="settings-password-section" title="Password">
        <div className="space-y-1.5">
          <label className="block text-sm font-medium" htmlFor="settings-password">
            New password
          </label>
          <div className="relative">
            <input
              aria-describedby={
                errors.password
                  ? "settings-password-error settings-password-hint"
                  : "settings-password-hint"
              }
              aria-invalid={errors.password ? true : undefined}
              autoComplete="new-password"
              className="field pr-12"
              id="settings-password"
              name="password"
              onBlur={() => validateOnBlur("password")}
              onChange={(event) => updateField("password", event.target.value)}
              ref={passwordRef}
              type={showPassword ? "text" : "password"}
              value={values.password}
            />
            <button
              aria-label="Show password"
              aria-pressed={showPassword}
              className="absolute inset-y-1.5 right-1.5 flex w-9 items-center justify-center rounded-md text-[var(--muted)] transition-colors duration-150 hover:text-[var(--foreground)]"
              onClick={() => setShowPassword((current) => !current)}
              type="button"
            >
              {showPassword ? (
                <svg aria-hidden="true" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 16 16">
                  <path d="M1.75 8s2.25-4.25 6.25-4.25S14.25 8 14.25 8 12 12.25 8 12.25 1.75 8 1.75 8Z" strokeLinejoin="round" />
                  <circle cx="8" cy="8" r="2" />
                  <path d="M2.5 13.5 13.5 2.5" strokeLinecap="round" />
                </svg>
              ) : (
                <svg aria-hidden="true" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 16 16">
                  <path d="M1.75 8s2.25-4.25 6.25-4.25S14.25 8 14.25 8 12 12.25 8 12.25 1.75 8 1.75 8Z" strokeLinejoin="round" />
                  <circle cx="8" cy="8" r="2" />
                </svg>
              )}
            </button>
          </div>
          {errors.password ? (
            <ErrorMessage id="settings-password-error">{errors.password}</ErrorMessage>
          ) : null}
          <p className="text-sm text-[var(--muted)]" id="settings-password-hint">
            At least 8 characters. Leave blank to keep your current password.
          </p>
        </div>
      </SettingsCard>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
        <button
          aria-disabled={isSaving || undefined}
          className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-[var(--foreground)] px-5 py-2 font-medium text-[var(--background)] transition-opacity duration-150 hover:opacity-90 active:opacity-75 aria-disabled:opacity-60 sm:w-auto"
          type="submit"
        >
          Save changes
        </button>
        <div aria-live="polite" className="flex min-h-6 items-center text-sm text-[var(--muted)]" role="status">
          {status === "saving" ? (
            <span className="fade-in flex items-center gap-2" key="saving">
              <span aria-hidden="true" className="spinner" />
              Saving…
            </span>
          ) : null}
          {status === "saved" ? (
            <span className="fade-in flex items-center gap-2" key="saved">
              <svg aria-hidden="true" className="h-4 w-4 flex-none text-[var(--ok)]" fill="none" viewBox="0 0 16 16">
                <path d="M3.5 8.5 6.5 11.5 12.5 4.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
              Saved
            </span>
          ) : null}
          {status === "dirty" ? (
            <span className="fade-in flex items-center gap-2" key="dirty">
              <span aria-hidden="true" className="h-1.5 w-1.5 flex-none rounded-full bg-[var(--muted)]" />
              Unsaved changes
            </span>
          ) : null}
        </div>
      </div>
    </form>
  );
}
