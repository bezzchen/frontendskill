"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  CHAPTERS,
  DEFAULT_CURVE,
  DUR,
  PX_PER_SEC,
  STILL_T,
  actState,
  chapterAt,
  clamp01,
  cubicBezier,
  easeIO,
  evalCamera,
  fmtTC,
  solveBezierU,
  typeReveal,
} from "@/lib/composition";
import { createEngine } from "@/lib/engine";
import { Dock } from "./dock";
import { Acts } from "./acts";

const STORE_KEY = "mdn-motion";

export default function Experience() {
  const [motion, setMotion] = useState("full");
  const [gfxOk, setGfxOk] = useState(true);
  const [chapter, setChapter] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [curve, setCurve] = useState(() => DEFAULT_CURVE.slice());

  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const sections = useRef([]);
  const headings = useRef([]);
  const tcRef = useRef(null);
  const playheadRef = useRef(null);
  const scrubRef = useRef(null);
  const fpsRef = useRef(null);
  const puckRef = useRef(null);
  const codeRef = useRef(null);
  const liveRef = useRef(null);
  const statRefs = {
    fps: useRef(null),
    ms: useRef(null),
    draws: useRef(null),
    count: useRef(null),
  };

  const st = useRef({
    scrub: 0,
    time: 4,
    now: 0,
    bootAt: 0,
    playing: false,
    motion: "full",
    gfxOk: true,
    curve: DEFAULT_CURVE.slice(),
    curveFn: cubicBezier(...DEFAULT_CURVE),
    onionU: new Float32Array(9),
    pointer: [0, 0],
    pointerT: [0, 0],
    raf: 0,
    running: false,
    scrubbing: false,
    scrubHold: 0,
    pinned: null,
    prevMode: null,
    chapter: 0,
    lastReveal: [],
    lastHidden: [],
    lastCodeN: -1,
    lastStat: 0,
    frame: 0,
    hidden: false,
    onscreen: true,
    explicitMotion: false,
    eye: [0, 0, 9],
    tgt: [0, 0, 0],
  }).current;

  const staticMode = motion === "reduced" || !gfxOk;

  const recomputeOnion = useCallback(() => {
    for (let i = 0; i < 9; i++) {
      st.onionU[i] = solveBezierU(st.curve[0], st.curve[2], i / 8);
    }
  }, [st]);

  /* ------------------------------------------------------------ still frame */

  const renderStill = useCallback(
    (i) => {
      const engine = engineRef.current;
      if (!engine) return;
      const t = STILL_T[i];
      const a = actState(t);
      const fov = evalCamera(t, st.eye, st.tgt);
      const stage = canvasRef.current?.parentElement;
      if (stage) engine.setSize(stage.clientWidth, stage.clientHeight);
      engine.frame({
        time: 6 + i * 5.3,
        scrub: t,
        boot: 1,
        actA: a.a,
        actB: a.b,
        mix: a.mix,
        curve: st.curve,
        puckU: 0.5,
        onion: true,
        onionU: st.onionU,
        camEye: st.eye,
        camTgt: st.tgt,
        fov,
        pointer: [0, 0],
        reduced: true,
      });
      if (playheadRef.current)
        playheadRef.current.style.left = `${(CHAPTERS[i].start / DUR) * 100}%`;
      if (tcRef.current) tcRef.current.textContent = fmtTC(CHAPTERS[i].start);
    },
    [st]
  );

  /* ----------------------------------------------------------------- seeks */

  const stopPlay = useCallback(() => {
    if (!st.playing) return;
    st.playing = false;
    setPlaying(false);
  }, [st]);

  const seek = useCallback(
    (t, announce) => {
      if (st.motion === "reduced" || !st.gfxOk) {
        const i = chapterAt(t);
        sections.current[i]?.scrollIntoView({ block: "start" });
      } else {
        window.scrollTo(0, t * PX_PER_SEC + 1);
      }
      if (announce && liveRef.current) {
        const c = CHAPTERS[chapterAt(t)];
        liveRef.current.textContent = `${c.num} — ${c.name}`;
      }
    },
    [st]
  );

  const seekChapter = useCallback(
    (i) => {
      stopPlay();
      seek(CHAPTERS[i].start + 0.05, true);
      const h = headings.current[i];
      if (h) setTimeout(() => h.focus({ preventScroll: true }), 350);
    },
    [seek, stopPlay]
  );

  const startPlay = useCallback(() => {
    if (st.motion === "reduced" || !st.gfxOk) return;
    if (window.scrollY >= DUR * PX_PER_SEC - 4) window.scrollTo(0, 0);
    st.lastAutoY = null;
    st.playing = true;
    setPlaying(true);
  }, [st]);

  const onPlayToggle = useCallback(() => {
    if (st.playing) stopPlay();
    else startPlay();
  }, [st, startPlay, stopPlay]);

  const onPlayFromStart = useCallback(() => {
    seek(0, false);
    st.scrub = 0;
    startPlay();
  }, [seek, st, startPlay]);

  const onCurveChange = useCallback(
    (next, commit) => {
      st.curve = next.slice();
      st.curveFn = cubicBezier(...next);
      recomputeOnion();
      setCurve(next.slice());
      if (commit && (st.motion === "reduced" || !st.gfxOk)) {
        renderStill(st.chapter);
      }
    },
    [st, recomputeOnion, renderStill]
  );

  const toggleMotion = useCallback(() => {
    st.explicitMotion = true;
    setMotion((m) => {
      const next = m === "full" ? "reduced" : "full";
      try {
        localStorage.setItem(STORE_KEY, next);
      } catch (e) {}
      return next;
    });
  }, [st]);

  /* -------------------------------------------------------- one-time setup */

  useEffect(() => {
    recomputeOnion();
    // deep link: /?t=37 opens the composition at that second
    let deepLinkTimer = 0;
    try {
      const q = new URLSearchParams(location.search).get("t");
      if (q !== null && !Number.isNaN(parseFloat(q))) {
        const t0 = Math.min(DUR, Math.max(0, parseFloat(q)));
        deepLinkTimer = setTimeout(() => {
          if (st.motion === "reduced" || !st.gfxOk) {
            sections.current[chapterAt(t0)]?.scrollIntoView({ block: "start" });
          } else {
            window.scrollTo(0, t0 * PX_PER_SEC + 1);
            st.scrub = t0;
          }
        }, 180);
      }
    } catch (e) {}
    // QA hook: pin the playhead to a time regardless of scroll (null to release)
    window.__mdnPin = (t) => {
      st.pinned = typeof t === "number" ? Math.min(DUR, Math.max(0, t)) : null;
    };
    // QA hook: render one still frame at time t (works while the loop is paused)
    window.__mdnStill = (t, mixOverride) => {
      const engine0 = engineRef.current;
      if (!engine0) return "no engine";
      st.pinned = t;
      st.scrub = t;
      const a = actState(t);
      const fov = evalCamera(t, st.eye, st.tgt);
      applyReveals(t);
      const phase = 0.35;
      engine0.frame({
        time: 5 + t * 0.7,
        scrub: t,
        boot: 1,
        actA: a.a,
        actB: a.b,
        mix: mixOverride ?? a.mix,
        curve: st.curve,
        puckU: solveBezierU(st.curve[0], st.curve[2], phase),
        onion: false,
        onionU: st.onionU,
        camEye: st.eye,
        camTgt: st.tgt,
        fov,
        pointer: [0, 0],
        reduced: true,
      });
      if (playheadRef.current)
        playheadRef.current.style.left = `${((t / DUR) * 100).toFixed(3)}%`;
      if (tcRef.current) tcRef.current.textContent = fmtTC(t);
      if (codeRef.current) {
        const rr = clamp01((t - 32.4) / 5.2);
        const kids = codeRef.current.children;
        const n = Math.min(kids.length, Math.floor(rr * (kids.length + 0.99)));
        for (let i = 0; i < kids.length; i++) kids[i].classList.toggle("on", i < n);
      }
      const ci = chapterAt(t);
      if (ci !== st.chapter) { st.chapter = ci; setChapter(ci); }
      return "still@" + t;
    };
    const initialMotion = document.documentElement.dataset.motion === "reduced" ? "reduced" : "full";
    setMotion(initialMotion);
    st.motion = initialMotion;
    try {
      st.explicitMotion = !!localStorage.getItem(STORE_KEY);
    } catch (e) {}

    const coarse =
      window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 820;
    const engine = createEngine(canvasRef.current, coarse ? 2 : 0);
    if (!engine) {
      document.documentElement.dataset.gfx = "off";
      st.gfxOk = false;
      setGfxOk(false);
    } else {
      engineRef.current = engine;
    }

    const size = () => {
      const stage = canvasRef.current?.parentElement;
      if (stage && engineRef.current)
        engineRef.current.setSize(stage.clientWidth, stage.clientHeight);
    };
    size();
    window.addEventListener("resize", size);

    // boot choreography
    const bootNow = () => {
      if (st.bootAt) return;
      st.bootAt = performance.now();
      document.documentElement.dataset.boot = "1";
    };
    const bootTimer = setTimeout(bootNow, 900);
    if (document.fonts?.ready) document.fonts.ready.then(() => setTimeout(bootNow, 120));

    // pointer sway (fine pointers only)
    const fine = window.matchMedia("(pointer: fine)").matches;
    const onMove = (e) => {
      st.pointerT[0] = (e.clientX / window.innerWidth) * 2 - 1;
      st.pointerT[1] = (e.clientY / window.innerHeight) * 2 - 1;
    };
    if (fine) window.addEventListener("pointermove", onMove, { passive: true });

    // OS reduced-motion preference (only when the user hasn't chosen)
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onMq = () => {
      if (!st.explicitMotion) setMotion(mq.matches ? "reduced" : "full");
    };
    mq.addEventListener?.("change", onMq);

    // interrupt autoplay on user scroll intent
    const interrupt = () => stopPlay();
    window.addEventListener("wheel", interrupt, { passive: true });
    window.addEventListener("touchmove", interrupt, { passive: true });

    // transport keys
    const onKey = (e) => {
      if (st.motion === "reduced" || !st.gfxOk) return;
      const el = e.target;
      const onBody = el === document.body || el === document.documentElement;
      const isSpace = e.code === "Space" || e.key === " " || e.key === "Spacebar";
      if (isSpace && (onBody || el === scrubRef.current)) {
        e.preventDefault();
        st.playing ? stopPlay() : startPlay();
      } else if (e.key === "Escape") {
        stopPlay();
      } else if (e.key === "Home" && onBody) {
        e.preventDefault();
        stopPlay();
        seek(0, true);
      } else if (e.key === "End" && onBody) {
        e.preventDefault();
        stopPlay();
        seek(DUR, true);
      }
    };
    window.addEventListener("keydown", onKey);

    // pause when hidden / offscreen
    const onVis = () => {
      st.hidden = document.hidden;
      syncLoop();
    };
    document.addEventListener("visibilitychange", onVis);
    let io = null;
    if ("IntersectionObserver" in window && canvasRef.current) {
      io = new IntersectionObserver(
        (entries) => {
          st.onscreen = entries[0]?.isIntersecting !== false;
          syncLoop();
        },
        { threshold: 0 }
      );
      io.observe(canvasRef.current);
    }

    function syncLoop() {
      const want =
        !st.hidden && st.onscreen && st.motion === "full" && st.gfxOk;
      if (want && !st.running) {
        st.running = true;
        st.now = 0;
        engineRef.current?.resetClock();
        st.raf = requestAnimationFrame(tick);
      } else if (!want && st.running) {
        st.running = false;
        cancelAnimationFrame(st.raf);
      }
    }
    st.syncLoop = syncLoop;

    function applyReveals(t) {
      for (let i = 0; i < CHAPTERS.length; i++) {
        const el = sections.current[i];
        if (!el) continue;
        const r = typeReveal(t, i);
        if (Math.abs((st.lastReveal[i] ?? -1) - r) > 0.004) {
          st.lastReveal[i] = r;
          el.style.opacity = r.toFixed(3);
          el.style.transform = r > 0.999 ? "none" : `translateY(${((1 - r) * 26).toFixed(2)}px)`;
        }
        const hide = r < 0.015;
        if (st.lastHidden[i] !== hide) {
          st.lastHidden[i] = hide;
          el.dataset.hidden = hide ? "1" : "0";
          el.inert = hide;
        }
      }
    }

    /* ------------------------------------------------------- the main loop */

    const tick = (now) => {
      if (!st.running) return;
      st.raf = requestAnimationFrame(tick);
      const dt = st.now ? Math.min(0.05, (now - st.now) / 1000) : 0.016;
      st.now = now;
      st.frame++;

      const maxY = DUR * PX_PER_SEC;
      if (st.playing) {
        // a scroll we didn't write means the visitor took the wheel — yield
        if (st.lastAutoY != null && Math.abs(window.scrollY - st.lastAutoY) > 6) {
          stopPlay();
          st.lastAutoY = null;
        } else {
          const y = window.scrollY + dt * PX_PER_SEC;
          if (y >= maxY - 1) {
            window.scrollTo(0, maxY);
            stopPlay();
            st.lastAutoY = null;
          } else {
            window.scrollTo(0, y);
            st.lastAutoY = window.scrollY;
          }
        }
      }

      const target =
        st.pinned != null
          ? st.pinned
          : Math.min(DUR, Math.max(0, window.scrollY / PX_PER_SEC));
      const k = 1 - Math.exp(-dt * 6.5);
      st.scrub += (target - st.scrub) * k;
      if (Math.abs(target - st.scrub) < 0.0006) st.scrub = target;
      st.time += dt;

      st.pointer[0] += (st.pointerT[0] - st.pointer[0]) * (1 - Math.exp(-dt * 3.2));
      st.pointer[1] += (st.pointerT[1] - st.pointer[1]) * (1 - Math.exp(-dt * 3.2));

      const bootRaw = st.bootAt ? Math.min(1, (now - st.bootAt) / 2400) : 0;
      const boot = easeIO(bootRaw);

      const a = actState(st.scrub);
      const fov = evalCamera(st.scrub, st.eye, st.tgt);

      // evaluation comet + preview puck
      const phase = (st.time * 0.4) % 1;
      const eased = st.curveFn(phase);
      const puckU = solveBezierU(st.curve[0], st.curve[2], phase);
      if (puckRef.current) {
        puckRef.current.style.left = `calc(5px + ${(eased * 100).toFixed(2)}% - ${(
          eased * 10
        ).toFixed(2)}px)`;
      }

      // type track -> section reveals
      applyReveals(st.scrub);

      // dock
      if (playheadRef.current)
        playheadRef.current.style.left = `${((st.scrub / DUR) * 100).toFixed(3)}%`;
      if (tcRef.current && st.frame % 2 === 0)
        tcRef.current.textContent = fmtTC(st.scrub);
      if (scrubRef.current && !st.scrubbing && now > st.scrubHold) {
        scrubRef.current.value = st.scrub;
        if (st.frame % 12 === 0) {
          const c = CHAPTERS[chapterAt(st.scrub)];
          scrubRef.current.setAttribute(
            "aria-valuetext",
            `${fmtTC(st.scrub)} — ${c.num} ${c.name}`
          );
        }
      }

      const ci = chapterAt(st.scrub);
      if (ci !== st.chapter) {
        st.chapter = ci;
        setChapter(ci);
      }

      // code typing (act 03)
      if (codeRef.current) {
        const rr = clamp01((st.scrub - 32.4) / 5.2);
        const kids = codeRef.current.children;
        const n = Math.min(kids.length, Math.floor(rr * (kids.length + 0.99)));
        if (n !== st.lastCodeN) {
          st.lastCodeN = n;
          for (let i = 0; i < kids.length; i++) kids[i].classList.toggle("on", i < n);
        }
      }

      // stats readouts (4 Hz)
      const engine2 = engineRef.current;
      if (engine2 && now - st.lastStat > 250) {
        st.lastStat = now;
        const s = engine2.stats;
        if (fpsRef.current)
          fpsRef.current.textContent = `${s.fps} fps · ${s.ms.toFixed(1)} ms · tier ${s.tier}`;
        if (statRefs.fps.current) statRefs.fps.current.textContent = s.fps;
        if (statRefs.ms.current) statRefs.ms.current.textContent = s.ms.toFixed(1);
        if (statRefs.draws.current) statRefs.draws.current.textContent = s.draws;
        if (statRefs.count.current)
          statRefs.count.current.textContent = `${Math.round(s.count / 1000)}k`;
      }

      engine2?.frame({
        time: st.time,
        scrub: st.scrub,
        boot,
        actA: a.a,
        actB: a.b,
        mix: a.mix,
        curve: st.curve,
        puckU,
        onion: false,
        onionU: st.onionU,
        camEye: st.eye,
        camTgt: st.tgt,
        fov,
        pointer: st.pointer,
        reduced: false,
      });
    };

    syncLoop();

    return () => {
      st.running = false;
      cancelAnimationFrame(st.raf);
      clearTimeout(bootTimer);
      clearTimeout(deepLinkTimer);
      window.removeEventListener("resize", size);
      if (fine) window.removeEventListener("pointermove", onMove);
      mq.removeEventListener?.("change", onMq);
      window.removeEventListener("wheel", interrupt);
      window.removeEventListener("touchmove", interrupt);
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("visibilitychange", onVis);
      io?.disconnect();
      engineRef.current?.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ------------------------------------------------- mode (full/storyboard) */

  useEffect(() => {
    document.documentElement.dataset.motion = motion;
    st.motion = motion;
    const isStatic = motion === "reduced" || !gfxOk;
    const from = st.prevMode;
    st.prevMode = isStatic ? "static" : "full";

    if (isStatic) {
      stopPlay();
      st.syncLoop?.();
      document.documentElement.dataset.boot = "1";
      if (!st.bootAt) st.bootAt = 1;
      // clear any full-mode inline state
      sections.current.forEach((el) => {
        if (!el) return;
        el.style.opacity = "";
        el.style.transform = "";
        el.dataset.hidden = "0";
        el.inert = false;
      });
      st.lastReveal = [];
      st.lastHidden = [];

      let ioTimer = 0;
      const io = new IntersectionObserver(
        (entries) => {
          const vis = entries
            .filter((e) => e.isIntersecting)
            .sort((x, y) => y.intersectionRatio - x.intersectionRatio)[0];
          if (!vis) return;
          const i = sections.current.indexOf(vis.target);
          if (i >= 0 && i !== st.chapter) {
            st.chapter = i;
            setChapter(i);
            clearTimeout(ioTimer);
            ioTimer = setTimeout(() => renderStill(i), 60);
          }
        },
        { threshold: [0.5] }
      );
      sections.current.forEach((el) => el && io.observe(el));

      const onResize = () => renderStill(st.chapter);
      window.addEventListener("resize", onResize);

      const settle = setTimeout(() => {
        if (from === "full") sections.current[st.chapter]?.scrollIntoView({ block: "start" });
        renderStill(st.chapter);
      }, 30);

      return () => {
        io.disconnect();
        clearTimeout(ioTimer);
        clearTimeout(settle);
        window.removeEventListener("resize", onResize);
      };
    }

    // full mode
    const settle = setTimeout(() => {
      if (from === "static") {
        const t = CHAPTERS[st.chapter].start + 0.05;
        window.scrollTo(0, t * PX_PER_SEC);
        st.scrub = t;
      }
      st.syncLoop?.();
    }, 30);
    return () => clearTimeout(settle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [motion, gfxOk]);

  /* ---------------------------------------------------------------- render */

  const sectionRef = (i) => (el) => {
    sections.current[i] = el;
  };
  const headingRef = (i) => (el) => {
    headings.current[i] = el;
  };

  return (
    <>
      <a
        className="skip"
        href="#act-overture"
        onClick={() => headings.current[st.chapter]?.focus({ preventScroll: true })}
      >
        Skip to content
      </a>

      <header className="hdr">
        <a className="wordmark" href="#act-overture" data-reveal onClick={(e) => {
          if (st.motion === "full" && st.gfxOk) {
            e.preventDefault();
            stopPlay();
            seek(0, true);
          }
        }}>
          MERIDIAN
        </a>
        <div className="hdr-right" data-reveal style={{ transitionDelay: "0.2s" }}>
          <button type="button" className="btn btn-ghost btn-sm" onClick={toggleMotion}>
            motion · {motion === "full" ? "full" : "storyboard"}
          </button>
          <a
            className="btn btn-primary btn-sm btn-cta"
            href="mailto:hello@meridian.tools?subject=Meridian%20early%20access"
          >
            Early access
          </a>
        </div>
      </header>

      <div
        className="scroll-space"
        style={{ height: `calc(${DUR * PX_PER_SEC}px + 100vh)` }}
        aria-hidden="true"
      />

      <div className="stage">
        <canvas className="stage-canvas" ref={canvasRef} aria-hidden="true" />
        <div className="stage-fx" aria-hidden="true" />
        <Acts
          sectionRef={sectionRef}
          headingRef={headingRef}
          curve={curve}
          onCurveChange={onCurveChange}
          puckRef={puckRef}
          liveRef={liveRef}
          codeRef={codeRef}
          statRefs={statRefs}
          onSeek={(t, a) => {
            stopPlay();
            seek(t, a);
          }}
          onPlayFromStart={onPlayFromStart}
        />
      </div>

      <Dock
        chapter={chapter}
        playing={playing}
        onPlayToggle={onPlayToggle}
        onChapter={seekChapter}
        onScrubInput={(v) => {
          st.scrubHold = performance.now() + 700;
          stopPlay();
          seek(v, false);
        }}
        onScrubStart={() => {
          st.scrubbing = true;
          stopPlay();
        }}
        onScrubEnd={() => {
          st.scrubbing = false;
        }}
        tcRef={tcRef}
        playheadRef={playheadRef}
        scrubRef={scrubRef}
        fpsRef={fpsRef}
      />

      <p className="sr-only" aria-live="polite" ref={liveRef} />
    </>
  );
}
