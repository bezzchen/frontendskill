import "./globals.css";
import { Instrument_Serif, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";

const serif = Instrument_Serif({
  weight: "400",
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});
const sans = IBM_Plex_Sans({
  weight: ["400", "500"],
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});
const mono = IBM_Plex_Mono({
  weight: ["400", "500", "600"],
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata = {
  title: "Meridian — Direct time.",
  description:
    "Meridian is a timeline-based motion editor for the web. Compose animation on real tracks, sculpt easing by hand, and ship it as production CSS and Web Animations API code.",
};

export const viewport = {
  themeColor: "#070b16",
  width: "device-width",
  initialScale: 1,
};

const bootScript = `
document.documentElement.classList.remove('no-js');
try {
  var pref = null;
  try { pref = localStorage.getItem('mdn-motion'); } catch (e) {}
  var m = pref === 'full' || pref === 'reduced'
    ? pref
    : (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches ? 'reduced' : 'full');
  document.documentElement.dataset.motion = m;
} catch (e) {
  document.documentElement.dataset.motion = 'full';
}
`;

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={`no-js ${serif.variable} ${sans.variable} ${mono.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: bootScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
