"use client";

import { useCallback, useMemo, useRef } from "react";
import {
  CHAPTERS,
  CURVE_PRESETS,
  KEY_COUNT,
  TRACKS,
  cubicBezier,
  fmtTC,
} from "@/lib/composition";

/* ------------------------------------------------------------- curve editor */

const GX = (x) => 20 + x * 300; // svg x for time 0..1  (viewBox 340 x 240)
const GY = (v) => 190 - v * 140; // svg y for value

function CurveEditor({ curve, onCurveChange, puckRef, liveRef }) {
  const stageRef = useRef(null);
  const dragRef = useRef(null);
  const latest = useRef(curve);
  latest.current = curve;

  const toGraph = useCallback((e) => {
    const r = stageRef.current.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * 340;
    const py = ((e.clientY - r.top) / r.height) * 240;
    return [
      Math.min(1, Math.max(0, (px - 20) / 300)),
      Math.min(1.35, Math.max(-0.35, (190 - py) / 140)),
    ];
  }, []);

  const announce = useCallback(
    (c) => {
      if (liveRef.current) {
        liveRef.current.textContent = `Ease set to cubic-bezier ${c
          .map((v) => v.toFixed(2))
          .join(", ")}`;
      }
    },
    [liveRef]
  );

  const startDrag = (which) => (e) => {
    e.preventDefault();
    dragRef.current = which;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch (err) {}
  };
  const moveDrag = (which) => (e) => {
    if (dragRef.current !== which) return;
    const [x, y] = toGraph(e);
    const next = latest.current.slice();
    next[which * 2] = x;
    next[which * 2 + 1] = y;
    latest.current = next;
    onCurveChange(next, false);
  };
  const endDrag = (which) => (e) => {
    if (dragRef.current !== which) return;
    dragRef.current = null;
    onCurveChange(latest.current.slice(), true);
    announce(latest.current);
  };
  const keyNudge = (which) => (e) => {
    const step = e.shiftKey ? 0.1 : 0.02;
    const k = e.key.startsWith("Arrow") ? e.key.slice(5) : e.key;
    let dx = 0,
      dy = 0;
    if (k === "Left") dx = -step;
    else if (k === "Right") dx = step;
    else if (k === "Up") dy = step;
    else if (k === "Down") dy = -step;
    else return;
    e.preventDefault();
    const next = latest.current.slice();
    next[which * 2] = Math.min(1, Math.max(0, next[which * 2] + dx));
    next[which * 2 + 1] = Math.min(1.35, Math.max(-0.35, next[which * 2 + 1] + dy));
    latest.current = next;
    onCurveChange(next, true);
    announce(next);
  };

  const [x1, y1, x2, y2] = curve;
  const path = `M ${GX(0)} ${GY(0)} C ${GX(x1)} ${GY(y1)} ${GX(x2)} ${GY(y2)} ${GX(1)} ${GY(1)}`;
  const activePreset = CURVE_PRESETS.find((p) =>
    p.v.every((v, i) => Math.abs(v - curve[i]) < 0.005)
  );

  const easeFn = useMemo(() => cubicBezier(...curve), [curve]);
  const onion = useMemo(
    () => Array.from({ length: 9 }, (_, i) => easeFn(i / 8)),
    [easeFn]
  );

  return (
    <div className="ce panel aside">
      <div className="ce-head">
        <span>ease · hero-entrance</span>
        <span className="val">
          cubic-bezier({curve.map((v) => v.toFixed(2)).join(", ")})
        </span>
      </div>
      <div className="ce-stage" ref={stageRef}>
        <svg className="ce-graph" viewBox="0 0 340 240" aria-hidden="true">
          {[0.25, 0.5, 0.75].map((f) => (
            <line
              key={`v${f}`}
              x1={GX(f)}
              y1={GY(1.35)}
              x2={GX(f)}
              y2={GY(-0.35)}
              stroke="rgba(148,166,212,0.07)"
            />
          ))}
          {[0.25, 0.5, 0.75].map((f) => (
            <line
              key={`h${f}`}
              x1={GX(0)}
              y1={GY(f)}
              x2={GX(1)}
              y2={GY(f)}
              stroke="rgba(148,166,212,0.07)"
            />
          ))}
          <line x1={GX(0)} y1={GY(0)} x2={GX(1)} y2={GY(0)} stroke="rgba(148,166,212,0.22)" />
          <line x1={GX(0)} y1={GY(1)} x2={GX(1)} y2={GY(1)} stroke="rgba(148,166,212,0.22)" />
          <line
            x1={GX(0)}
            y1={GY(0)}
            x2={GX(x1)}
            y2={GY(y1)}
            stroke="rgba(226,167,62,0.6)"
            strokeDasharray="3 3"
          />
          <line
            x1={GX(1)}
            y1={GY(1)}
            x2={GX(x2)}
            y2={GY(y2)}
            stroke="rgba(226,167,62,0.6)"
            strokeDasharray="3 3"
          />
          <path d={path} fill="none" stroke="var(--beam)" strokeWidth="2.6" />
          <circle cx={GX(0)} cy={GY(0)} r="4" fill="var(--paper)" />
          <circle cx={GX(1)} cy={GY(1)} r="4" fill="var(--paper)" />
        </svg>
        {[0, 1].map((which) => (
          <button
            key={which}
            type="button"
            className="ce-handle"
            style={{
              left: `${(GX(curve[which * 2]) / 340) * 100}%`,
              top: `${(GY(curve[which * 2 + 1]) / 240) * 100}%`,
            }}
            aria-label={`Control handle ${which + 1}: x ${curve[which * 2].toFixed(
              2
            )}, y ${curve[which * 2 + 1].toFixed(2)}. Arrow keys to bend the ease.`}
            onPointerDown={startDrag(which)}
            onPointerMove={moveDrag(which)}
            onPointerUp={endDrag(which)}
            onPointerCancel={endDrag(which)}
            onKeyDown={keyNudge(which)}
          />
        ))}
      </div>
      <div className="ce-preview" aria-hidden="true">
        <span className="ce-preview-track" />
        <span className="ce-puck" ref={puckRef} />
        <span className="ce-onion">
          {onion.map((v, i) => (
            <i
              key={i}
              style={{
                left: `calc(5px + ${(v * 100).toFixed(2)}% - ${(v * 10).toFixed(2)}px)`,
                opacity: 0.25 + (i / 8) * 0.75,
              }}
            />
          ))}
        </span>
      </div>
      <div className="ce-presets" role="group" aria-label="Ease presets">
        {CURVE_PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            className="chip"
            aria-pressed={activePreset?.id === p.id}
            onClick={() => {
              onCurveChange(p.v.slice(), true);
              announce(p.v);
            }}
          >
            {p.name}
          </button>
        ))}
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- code panel */

function CodePanel({ curve, codeRef }) {
  const bz = `cubic-bezier(${curve.map((v) => v.toFixed(2)).join(", ")})`;
  const lines = [
    <span key="0" className="tok-c">{`/* meridian · export — hero-entrance.css */`}</span>,
    <span key="1"><span className="tok-s">.hero</span> {"{"}</span>,
    <span key="2">
      {"  "}<span className="tok-k">animation</span>: <span className="tok-s">hero-rise 900ms</span>
    </span>,
    <span key="2b">
      {"    "}<span className="tok-b">{bz}</span> <span className="tok-s">both</span>;
    </span>,
    <span key="3">{"}"}</span>,
    <span key="4"><span className="tok-k">@keyframes</span> <span className="tok-s">hero-rise</span> {"{"}</span>,
    <span key="5">
      {"  "}<span className="tok-s">from</span> {"{"} <span className="tok-k">translate</span>:{" "}
      <span className="tok-n">0 28px</span>; <span className="tok-k">opacity</span>:{" "}
      <span className="tok-n">0</span>; {"}"}
    </span>,
    <span key="6">
      {"  "}<span className="tok-s">to</span> {"  {"} <span className="tok-k">translate</span>:{" "}
      <span className="tok-n">0 0</span>; {"  "}<span className="tok-k">opacity</span>:{" "}
      <span className="tok-n">1</span>; {"}"}
    </span>,
    <span key="7">{"}"}</span>,
    <span key="8">{" "}</span>,
    <span key="9" className="tok-c">{`/* or straight to the Web Animations API */`}</span>,
    <span key="10">
      <span className="tok-s">el</span>.<span className="tok-k">animate</span>(rise, {"{"}
    </span>,
    <span key="11">
      {"  "}<span className="tok-k">duration</span>: <span className="tok-n">900</span>,
    </span>,
    <span key="12">
      {"  "}<span className="tok-k">easing</span>: <span className="tok-b">"{bz}"</span>,
    </span>,
    <span key="13">{"});"}</span>,
  ];
  return (
    <div className="code panel aside">
      <div className="code-head">compiled output — no runtime attached</div>
      <pre>
        <code ref={codeRef}>
          {lines.map((l, i) => (
            <span className="cl" key={i}>
              {l}
            </span>
          ))}
        </code>
      </pre>
    </div>
  );
}

/* ---------------------------------------------------------------- the acts */

export function Acts({
  sectionRef,
  headingRef,
  curve,
  onCurveChange,
  puckRef,
  liveRef,
  codeRef,
  statRefs,
  onSeek,
  onPlayFromStart,
}) {
  const ch = CHAPTERS;
  const eb = (i) => (
    <p className="t-eyebrow">
      <span>
        {ch[i].num} · {ch[i].name}
      </span>
      <span className="tc">{fmtTC(ch[i].start)}</span>
    </p>
  );

  return (
    <main id="main" className="acts">
      {/* 00 — overture */}
      <section
        id="act-overture"
        className="act act-overture"
        ref={sectionRef(0)}
        aria-labelledby="h-overture"
      >
        <div className="act-inner">
          <p className="t-eyebrow" data-reveal style={{ transitionDelay: "0.1s" }}>
            <span>Meridian</span>
            <span className="tc">motion editor for the web · early access</span>
          </p>
          <h1 className="t-display" id="h-overture" tabIndex={-1} ref={headingRef(0)} data-reveal style={{ transitionDelay: "0.22s" }}>
            Direct <em>time.</em>
          </h1>
          <p className="t-body lede" data-reveal style={{ transitionDelay: "0.36s" }}>
            Meridian is a timeline editor for interface motion. Compose on real tracks,
            sculpt easing by hand, and ship the result as the code you already write.
          </p>
          <div className="hero-cta" data-reveal style={{ transitionDelay: "0.5s" }}>
            <a className="btn btn-primary" href="mailto:hello@meridian.tools?subject=Meridian%20early%20access">
              Get early access
            </a>
            <button type="button" className="btn btn-ghost live-only" onClick={onPlayFromStart}>
              Press play
            </button>
          </div>
          <p className="hint" data-reveal style={{ transitionDelay: "0.64s" }}>
            scroll to scrub · <kbd>space</kbd> to play
          </p>
        </div>
      </section>

      {/* 01 — the curve */}
      <section
        id="act-curve"
        className="act act-curve"
        ref={sectionRef(1)}
        aria-labelledby="h-curve"
      >
        <div className="act-inner act-grid">
          <div className="copy">
            {eb(1)}
            <h2 className="t-h2" id="h-curve" tabIndex={-1} ref={headingRef(1)}>
              Easing you can <em>hold.</em>
            </h2>
            <p className="t-body">
              Every motion in Meridian is a curve with handles. Pull one — the world behind
              this panel takes your ease <strong>immediately</strong>, and keeps it for the
              rest of this page.
            </p>
          </div>
          <CurveEditor
            curve={curve}
            onCurveChange={onCurveChange}
            puckRef={puckRef}
            liveRef={liveRef}
          />
        </div>
      </section>

      {/* 02 — the timeline */}
      <section
        id="act-timeline"
        className="act act-timeline"
        ref={sectionRef(2)}
        aria-labelledby="h-timeline"
      >
        <div className="act-inner act-grid">
          <div className="copy panel">
            {eb(2)}
            <h2 className="t-h2" id="h-timeline" tabIndex={-1} ref={headingRef(2)}>
              You&rsquo;re inside <em>one now.</em>
            </h2>
            <p className="t-body">
              This page is a Meridian composition. The lanes around you are its real tracks —
              the camera you&rsquo;re riding, the copy you&rsquo;re reading, the world itself —
              and the brass blade is the playhead you&rsquo;ve been scrubbing.
            </p>
            <p className="t-mono-line" style={{ marginTop: "18px" }}>
              {TRACKS.length} tracks · {KEY_COUNT} keyframes · 60 seconds
            </p>
          </div>
        </div>
      </section>

      {/* 03 — the export */}
      <section
        id="act-export"
        className="act act-export"
        ref={sectionRef(3)}
        aria-labelledby="h-export"
      >
        <div className="act-inner act-grid">
          <div className="copy">
            {eb(3)}
            <h2 className="t-h2" id="h-export" tabIndex={-1} ref={headingRef(3)}>
              Ship the curve, <em>not a runtime.</em>
            </h2>
            <p className="t-body">
              Meridian compiles compositions to plain CSS and the Web Animations API.
              The file beside this line is <strong>your curve from act 01</strong> —
              exact values, zero dependencies.
            </p>
          </div>
          <CodePanel curve={curve} codeRef={codeRef} />
        </div>
      </section>

      {/* 04 — the budget */}
      <section
        id="act-budget"
        className="act act-budget"
        ref={sectionRef(4)}
        aria-labelledby="h-budget"
      >
        <div className="act-inner">
          {eb(4)}
          <h2 className="t-h2" id="h-budget" tabIndex={-1} ref={headingRef(4)}>
            Sixty frames, <em>honestly.</em>
          </h2>
          <p className="t-body">
            The line behind this copy is this page&rsquo;s own render loop, plotted live.
            Motion you ship from Meridian runs on the platform&rsquo;s compositor,
            so the budget stays yours.
          </p>
          <div className="stats" role="group" aria-label="Live render statistics">
            <div className="stat">
              <div className="v"><span ref={statRefs.fps}>—</span></div>
              <div className="l">frames / second</div>
            </div>
            <div className="stat">
              <div className="v"><span ref={statRefs.ms}>—</span><em> ms</em></div>
              <div className="l">frame time</div>
            </div>
            <div className="stat">
              <div className="v"><span ref={statRefs.draws}>—</span></div>
              <div className="l">draw calls</div>
            </div>
            <div className="stat">
              <div className="v"><span ref={statRefs.count}>—</span></div>
              <div className="l">particles</div>
            </div>
          </div>
          <p className="t-mono-line" style={{ marginTop: "22px" }}>
            measured on your machine, right now — not ours
          </p>
        </div>
      </section>

      {/* 05 — begin */}
      <section
        id="act-begin"
        className="act act-begin"
        ref={sectionRef(5)}
        aria-labelledby="h-begin"
      >
        <div className="act-inner">
          {eb(5)}
          <h2 className="t-h2" id="h-begin" tabIndex={-1} ref={headingRef(5)}>
            Your first composition <em>is empty.</em>
          </h2>
          <p className="t-body" style={{ margin: "0 auto", maxWidth: "32rem" }}>
            Early access opens this fall. Bring the motion you can see
            but can&rsquo;t type.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary" href="mailto:hello@meridian.tools?subject=Meridian%20early%20access">
              Get early access
            </a>
            <button type="button" className="btn btn-ghost live-only" onClick={() => onSeek(0, true)}>
              Watch again
            </button>
          </div>
          <footer className="footer-line">
            <span>© 2026 Meridian Systems</span>
            <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>
            <span>
              this page is a meridian composition — {TRACKS.length} tracks, {KEY_COUNT} keys
            </span>
          </footer>
        </div>
      </section>
    </main>
  );
}
