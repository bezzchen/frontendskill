"use client";

import { memo } from "react";
import { CHAPTERS, DUR, TRACKS, fmtTC } from "@/lib/composition";

const pct = (t) => `${((t / DUR) * 100).toFixed(3)}%`;

function Ruler() {
  const items = [];
  for (let s = 0; s <= DUR; s++) {
    const major = s % 5 === 0;
    items.push(
      <span
        key={`t${s}`}
        className={`dock-tick${major ? " major" : ""}`}
        style={{ left: pct(s) }}
      />
    );
    if (major && s < DUR) {
      items.push(
        <span
          key={`l${s}`}
          className={`dock-tick-label${s % 15 === 0 ? " q" : ""}`}
          style={{ left: pct(s) }}
        >
          {fmtTC(s).slice(0, 5)}
        </span>
      );
    }
  }
  return (
    <div className="dock-ruler" aria-hidden="true">
      {items}
    </div>
  );
}

export const Dock = memo(function Dock({
  chapter,
  playing,
  onPlayToggle,
  onChapter,
  onScrubInput,
  onScrubStart,
  onScrubEnd,
  tcRef,
  playheadRef,
  scrubRef,
  fpsRef,
}) {
  return (
    <div className="dock" data-reveal role="region" aria-label="Composition timeline">
      <div className="dock-transport">
        <button
          type="button"
          className="dock-play"
          onClick={onPlayToggle}
          aria-label={playing ? "Pause playback" : "Play the composition"}
        >
          {playing ? (
            <svg width="12" height="14" viewBox="0 0 12 14" aria-hidden="true">
              <rect x="1" y="1" width="3.4" height="12" fill="currentColor" />
              <rect x="7.6" y="1" width="3.4" height="12" fill="currentColor" />
            </svg>
          ) : (
            <svg width="13" height="14" viewBox="0 0 13 14" aria-hidden="true">
              <path d="M1.5 1.2 L12 7 L1.5 12.8 Z" fill="currentColor" />
            </svg>
          )}
        </button>
        <div className="dock-tc">
          <span ref={tcRef}>00:00:00</span>
          <span className="dur">/ {fmtTC(DUR)} · 24 fps ruler</span>
        </div>
        <div className="dock-scene" aria-hidden="true">
          {CHAPTERS[chapter].num} · {CHAPTERS[chapter].name}
        </div>
      </div>

      <div className="dock-body">
        <div className="dock-fps" ref={fpsRef} aria-hidden="true" />
        <Ruler />
        <div className="dock-lanes">
          <div className="dock-lane dock-lane-scenes" role="group" aria-label="Scenes">
            <span className="dock-lane-name" aria-hidden="true">
              scenes
            </span>
            {CHAPTERS.map((c, i) => (
              <button
                key={c.id}
                type="button"
                className="dock-clip"
                style={{
                  left: pct(c.start),
                  width: `calc(${(((c.end - c.start) / DUR) * 100).toFixed(3)}% - 3px)`,
                }}
                aria-current={i === chapter ? "true" : undefined}
                aria-label={`${c.num} — ${c.name}, ${fmtTC(c.start)}`}
                onClick={() => onChapter(i)}
              >
                <span className="num">{c.num}</span>
                <span className="full">{c.name}</span>
              </button>
            ))}
          </div>
          {TRACKS.slice(1).map((track) => (
            <div key={track.id} className="dock-lane dock-lane-mini" aria-hidden="true">
              <span className="dock-lane-name">{track.name}</span>
              {track.clips.map((cl, j) => (
                <i
                  key={`c${j}`}
                  className="dock-mini-clip"
                  style={{
                    left: pct(cl.t0),
                    width: `calc(${(((cl.t1 - cl.t0) / DUR) * 100).toFixed(3)}% - 2px)`,
                  }}
                />
              ))}
              {track.keys.map((t, j) => (
                <i key={`k${j}`} className="dock-key" style={{ left: pct(t) }} />
              ))}
            </div>
          ))}
        </div>
        <div className="dock-playhead" ref={playheadRef} style={{ left: 0 }} aria-hidden="true" />
        <span className="dock-loop" title="Loop point — 01:00:00" aria-hidden="true" />
        <input
          ref={scrubRef}
          className="dock-scrub"
          type="range"
          min="0"
          max={DUR}
          step="0.5"
          defaultValue="0"
          aria-label="Playhead — scrub the composition"
          onPointerDown={onScrubStart}
          onPointerUp={onScrubEnd}
          onInput={(e) => onScrubInput(parseFloat(e.currentTarget.value))}
        />
      </div>
    </div>
  );
});
