export default function SiteHeader() {
  return (
    <header className="site-header">
      <a className="wordmark" href="#act-1">Meridian</a>
      <a className="header-cta" href="#access">Get early access</a>
    </header>
  );
}
