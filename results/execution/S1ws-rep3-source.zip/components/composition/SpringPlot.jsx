"use client";

import { springResponse } from "./lib/easing";

// The curve view of the spring: how the visitor's spring settles over time.
// In reduced-motion mode this is the primary way the spring is shown.
export default function SpringPlot({ params }) {
  const T = Math.max(0.6, Math.min(params.settle * 1.05, 4));
  const N = 160;
  const points = [];
  for (let i = 0; i <= N; i++) {
    const t = (i / N) * T;
    const x = springResponse(t, params);
    points.push(`${((i / N) * 100).toFixed(2)},${(52 - x * 38).toFixed(2)}`);
  }
  const description =
    params.overshoot > 0.005
      ? `settles in ${params.settle.toFixed(2)} seconds and overshoots by ${Math.round(params.overshoot * 100)} percent`
      : `settles in ${params.settle.toFixed(2)} seconds without overshooting`;
  return (
    <figure className="spring-plot">
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        role="img"
        aria-label={`Spring response over ${T.toFixed(1)} seconds: ${description}.`}
      >
        <line className="spring-plot__axis" x1="0" y1="52" x2="100" y2="52" />
        <line className="spring-plot__axis" x1="0" y1="14" x2="100" y2="14" strokeDasharray="1 2" />
        <polyline className="spring-plot__line" points={points.join(" ")} />
      </svg>
      <figcaption>
        <span>0 s</span>
        <span>{T.toFixed(1)} s</span>
      </figcaption>
    </figure>
  );
}
