"use client";

import { useRef } from "react";
import { useStore, setState, getState } from "./store";
import { clamp } from "./lib/easing";

const Y_MIN = -0.3;
const Y_MAX = 1.3;

export default function EasingEditor() {
  const easing = useStore((s) => s.easing);
  const plotRef = useRef(null);
  const [x1, y1, x2, y2] = easing;
  const hx1 = x1 * 100;
  const hy1 = (1 - y1) * 100;
  const hx2 = x2 * 100;
  const hy2 = (1 - y2) * 100;
  const path = `M 0 100 C ${hx1} ${hy1}, ${hx2} ${hy2}, 100 0`;

  const startDrag = (i) => (e) => {
    const plot = plotRef.current;
    if (!plot || e.button !== 0) return;
    e.preventDefault();
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);
    const move = (ev) => {
      const r = plot.getBoundingClientRect();
      const x = clamp((ev.clientX - r.left) / r.width, 0, 1);
      const y = clamp(1 - (ev.clientY - r.top) / r.height, Y_MIN, Y_MAX);
      const cur = getState().easing.slice();
      cur[i * 2] = x;
      cur[i * 2 + 1] = y;
      setState({ easing: cur });
    };
    const end = () => {
      target.removeEventListener("pointermove", move);
      target.removeEventListener("pointerup", end);
      target.removeEventListener("pointercancel", end);
    };
    target.addEventListener("pointermove", move);
    target.addEventListener("pointerup", end);
    target.addEventListener("pointercancel", end);
  };

  const onKey = (i) => (e) => {
    const step = e.shiftKey ? 0.1 : 0.02;
    let dx = 0;
    let dy = 0;
    if (e.key === "ArrowLeft") dx = -step;
    else if (e.key === "ArrowRight") dx = step;
    else if (e.key === "ArrowUp") dy = step;
    else if (e.key === "ArrowDown") dy = -step;
    else return;
    e.preventDefault();
    const cur = getState().easing.slice();
    cur[i * 2] = clamp(cur[i * 2] + dx, 0, 1);
    cur[i * 2 + 1] = clamp(cur[i * 2 + 1] + dy, Y_MIN, Y_MAX);
    setState({ easing: cur });
  };

  const label = (n, x, y) =>
    `Control point ${n}: x ${x.toFixed(2)}, y ${y.toFixed(2)}. Arrow keys move it, hold Shift for larger steps.`;

  return (
    <div className="editor">
      <div className="editor__plot" data-anchor="2" ref={plotRef}>
        <svg className="editor__svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
          <g className="editor__grid">
            {[25, 50, 75].map((v) => (
              <line key={`v${v}`} x1={v} y1={0} x2={v} y2={100} />
            ))}
            {[25, 50, 75].map((v) => (
              <line key={`h${v}`} x1={0} y1={v} x2={100} y2={v} />
            ))}
          </g>
          <rect className="editor__frame" x={0} y={0} width={100} height={100} />
          <line className="editor__linear" x1={0} y1={100} x2={100} y2={0} />
          <line className="editor__arm" x1={0} y1={100} x2={hx1} y2={hy1} />
          <line className="editor__arm" x1={100} y1={0} x2={hx2} y2={hy2} />
          <path className="editor__curve" d={path} />
        </svg>
        <button
          type="button"
          className="editor__handle"
          style={{ left: `${hx1}%`, top: `${hy1}%` }}
          onPointerDown={startDrag(0)}
          onKeyDown={onKey(0)}
          aria-label={label(1, x1, y1)}
        />
        <button
          type="button"
          className="editor__handle"
          style={{ left: `${hx2}%`, top: `${hy2}%` }}
          onPointerDown={startDrag(1)}
          onKeyDown={onKey(1)}
          aria-label={label(2, x2, y2)}
        />
      </div>
    </div>
  );
}
