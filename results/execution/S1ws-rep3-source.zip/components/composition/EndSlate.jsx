"use client";

import { useStore } from "./store";
import { formatBezier } from "./lib/easing";

export default function EndSlate() {
  const easing = useStore((s) => s.easing);
  const spring = useStore((s) => s.spring);
  const count = useStore((s) => s.particleCount);
  const renderer = useStore((s) => s.renderer);
  return (
    <footer className="end-slate">
      <div className="end-slate__inner">
        <p className="wordmark wordmark--large">Meridian</p>
        <dl className="facts">
          <div>
            <dt>Runtime</dt>
            <dd>00:00:48:00</dd>
          </div>
          <div>
            <dt>Acts</dt>
            <dd>5</dd>
          </div>
          <div>
            <dt>Points in the field</dt>
            <dd>{renderer === "none" ? "vector fallback" : count ? count.toLocaleString("en-US") : "measuring"}</dd>
          </div>
          <div>
            <dt>Your curve</dt>
            <dd>{formatBezier(easing)}</dd>
          </div>
          <div>
            <dt>Your spring</dt>
            <dd>stiffness {spring.stiffness}, damping {spring.damping}</dd>
          </div>
        </dl>
        <p className="muted">Rendered live in your browser. Nothing on this page was pre-recorded.</p>
        <p>
          <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>
        </p>
      </div>
    </footer>
  );
}
