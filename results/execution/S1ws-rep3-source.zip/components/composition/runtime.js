// DOM handles the render loop writes to directly (timecode, playhead, markers),
// so the HUD never re-renders at frame rate.
export const hud = {
  tc: null,
  range: null,
  head: null,
  markers: [],
  actTimes: [],
  scrubbing: false,
};

export function registerHud(refs) {
  Object.assign(hud, refs);
}
