import { createProgram, uniformLocations, perspective, translation, multiply } from "./gl";
import { VERT, FRAG } from "./shaders";

const FOV = (50 * Math.PI) / 180;
// Camera distance such that the z=0 plane spans y in [-1, 1].
export const CAM_DIST = 1 / Math.tan(FOV / 2);

const UNIFORMS = [
  "uVP", "uTime", "uDpr", "uPointScale", "uAlpha", "uCamDist", "uA", "uB", "uMix", "uIntro",
  "uRect[0]", "uEase", "uSpring", "uPluck", "uHold", "uPointer", "uGlobe", "uHeroPlayhead",
  "uGrid", "uAmbient", "uIce", "uAmber",
];

export const ICE = [0.62, 0.85, 1.0];
export const AMBER = [1.0, 0.7, 0.36];

// Deterministic seeds so every visitor sees the same field.
function mulberry32(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Field {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext("webgl2", {
      alpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      preserveDrawingBuffer: false,
      powerPreference: "high-performance",
    });
    if (!gl) throw new Error("WebGL2 unavailable");
    this.gl = gl;
    this.program = createProgram(gl, VERT, FRAG);
    this.u = uniformLocations(gl, this.program, UNIFORMS);
    this.vao = gl.createVertexArray();
    this.buffer = gl.createBuffer();
    this.count = 0;
    this.grid = [8, 8];
    this.alpha = 0.3;
    this.width = 1;
    this.height = 1;
    this.dpr = 1;
    this.aspect = 1;
    this.vp = new Float32Array(16);
    this.lost = false;
    this.onLost = (e) => {
      e.preventDefault();
      this.lost = true;
    };
    canvas.addEventListener("webglcontextlost", this.onLost);
    gl.disable(gl.DEPTH_TEST);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE);
    gl.clearColor(0, 0, 0, 0);
    gl.useProgram(this.program);
    gl.uniform3fv(this.u.uIce, ICE);
    gl.uniform3fv(this.u.uAmber, AMBER);
    gl.uniform1f(this.u.uCamDist, CAM_DIST);
  }

  setCount(n) {
    const gl = this.gl;
    const seeds = new Float32Array(n * 4);
    const rnd = mulberry32(0x9e3779b9);
    for (let i = 0; i < seeds.length; i++) seeds[i] = rnd();
    gl.bindVertexArray(this.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferData(gl.ARRAY_BUFFER, seeds, gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(this.program, "aSeed");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    this.count = n;
    // Lattice: about twenty particles per node so nodes read as glowing points; node grid ~5:4.
    const nodes = Math.max(64, Math.floor(n / 20));
    const cols = Math.max(2, Math.round(Math.sqrt(nodes * 1.25)));
    const rows = Math.max(2, Math.round(nodes / cols));
    this.grid = [cols, rows];
    // Per-particle alpha falls with density so brightness stays constant across tiers.
    this.alpha = Math.min(0.9, 0.36 * Math.sqrt(24000 / n));
  }

  resize(width, height, dpr) {
    const w = Math.max(1, Math.round(width * dpr));
    const h = Math.max(1, Math.round(height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    this.width = width;
    this.height = height;
    this.dpr = dpr;
    this.aspect = width / height;
    this.gl.viewport(0, 0, w, h);
    const P = perspective(FOV, this.aspect, 0.1, 20);
    const V = translation(0, 0, -CAM_DIST);
    this.vp.set(multiply(P, V));
  }

  render(f) {
    if (this.lost) return;
    const gl = this.gl;
    const u = this.u;
    gl.useProgram(this.program);
    gl.uniformMatrix4fv(u.uVP, false, this.vp);
    gl.uniform1f(u.uTime, f.time);
    gl.uniform1f(u.uDpr, this.dpr);
    gl.uniform1f(u.uPointScale, f.pointScale);
    gl.uniform1f(u.uAlpha, this.alpha);
    gl.uniform1i(u.uA, f.a);
    gl.uniform1i(u.uB, f.b);
    gl.uniform1f(u.uMix, f.mix);
    gl.uniform1f(u.uIntro, f.intro);
    gl.uniform4fv(u["uRect[0]"], f.rects);
    gl.uniform4fv(u.uEase, f.ease);
    gl.uniform4fv(u.uSpring, f.spring);
    gl.uniform4fv(u.uPluck, f.pluck);
    gl.uniform1f(u.uHold, f.hold);
    gl.uniform4fv(u.uPointer, f.pointer);
    gl.uniform2fv(u.uGlobe, f.globe);
    gl.uniform1f(u.uHeroPlayhead, f.heroPlayhead);
    gl.uniform2fv(u.uGrid, this.grid);
    gl.uniform1f(u.uAmbient, f.ambient);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.POINTS, 0, this.count);
    gl.bindVertexArray(null);
  }

  dispose() {
    const gl = this.gl;
    this.canvas.removeEventListener("webglcontextlost", this.onLost);
    gl.deleteBuffer(this.buffer);
    gl.deleteVertexArray(this.vao);
    gl.deleteProgram(this.program);
    const ext = gl.getExtension("WEBGL_lose_context");
    if (ext) ext.loseContext();
  }
}
