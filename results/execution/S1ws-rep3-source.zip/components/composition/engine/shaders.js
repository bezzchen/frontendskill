// One vertex shader computes every formation procedurally from a 4-float seed
// (plus gl_VertexID for the lattice), then blends between the two formations
// that scroll is currently between. Formation k is expressed in a local
// [-1, 1] square and mapped into the world rect of the DOM element it belongs
// to, so the field literally forms *on* the instrument in the document.

export const VERT = /* glsl */ `#version 300 es
precision highp float;
precision highp int;

in vec4 aSeed;

uniform mat4 uVP;
uniform float uTime;
uniform float uDpr;
uniform float uPointScale;
uniform float uAlpha;
uniform float uCamDist;
uniform int uA;
uniform int uB;
uniform float uMix;
uniform float uIntro;
uniform vec4 uRect[6];      // cx, cy, halfW, halfH in world units
uniform vec4 uEase;         // cubic-bezier x1 y1 x2 y2
uniform vec4 uSpring;       // omega0, zeta, releaseTime, strength
uniform vec4 uPluck;        // px, py (local), vx, vy (local displacement)
uniform float uHold;
uniform vec4 uPointer;      // wx, wy, strength, radius
uniform vec2 uGlobe;        // rotY, rotX
uniform float uHeroPlayhead;
uniform vec2 uGrid;         // lattice cols, rows
uniform float uAmbient;
uniform vec3 uIce;
uniform vec3 uAmber;

out vec3 vColor;
out float vAlpha;

const float PI = 3.14159265;
const float TAU = 6.2831853;

float hash1(float n) { return fract(sin(n * 127.1 + 0.37) * 43758.5453); }

vec2 bez(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t) {
  float u = 1.0 - t;
  return u * u * u * p0 + 3.0 * u * u * t * p1 + 3.0 * u * t * t * p2 + t * t * t * p3;
}
vec2 bezD(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t) {
  float u = 1.0 - t;
  return 3.0 * u * u * (p1 - p0) + 6.0 * u * t * (p2 - p1) + 3.0 * t * t * (p3 - p2);
}

// CSS cubic-bezier(x1,y1,x2,y2) evaluated as y(x). Same solve as lib/easing.js.
float easeBez(float x, vec4 e) {
  x = clamp(x, 0.0, 1.0);
  float cx = 3.0 * e.x, bx = 3.0 * (e.z - e.x) - cx, ax = 1.0 - cx - bx;
  float cy = 3.0 * e.y, by = 3.0 * (e.w - e.y) - cy, ay = 1.0 - cy - by;
  float t = x;
  for (int i = 0; i < 6; i++) {
    float xt = ((ax * t + bx) * t + cx) * t - x;
    float dx = (3.0 * ax * t + 2.0 * bx) * t + cx;
    if (abs(dx) < 1e-4) break;
    t = clamp(t - xt / dx, 0.0, 1.0);
  }
  return ((ay * t + by) * t + cy) * t;
}

vec3 toWorld(vec3 l, vec4 r) {
  return vec3(r.xy + l.xy * r.zw, l.z * min(r.z, r.w));
}

// 0 — unauthored motion: a drifting cloud filling the viewport.
vec3 fChaos(vec4 s, float t) {
  vec3 p = s.xyz * 2.0 - 1.0;
  p.x += 0.12 * sin(t * 0.23 + s.w * TAU);
  p.y += 0.12 * cos(t * 0.19 + s.z * TAU);
  p.z *= 0.9;
  return p;
}

// 1 — the timeline ruler: baseline, ticks, a playhead that follows the pointer, a haze above.
vec3 fRuler(vec4 s, float t, float ph, out float size, out float a, out float heat) {
  float role = s.y;
  vec3 p = vec3(s.x * 2.0 - 1.0, 0.0, 0.0);
  size = 1.0; a = 1.0; heat = 0.0;
  if (role < 0.48) {
    p.y = (s.z - 0.5) * 0.05;
  } else if (role < 0.80) {
    float n = 72.0;
    float i = floor(s.x * n);
    p.x = (i + 0.5) / n * 2.0 - 1.0 + (s.w - 0.5) * 0.004;
    float major = 1.0 - step(0.5, mod(i, 6.0));
    p.y = s.z * mix(0.28, 0.72, major);
    size = mix(0.9, 1.15, major);
  } else if (role < 0.86) {
    p.x = ph * 2.0 - 1.0 + (s.z - 0.5) * 0.012;
    p.y = mix(-0.45, 1.25, s.x);
    heat = 1.0; size = 1.35;
  } else {
    p.y = 0.55 + s.z * 1.1 + 0.06 * sin(t * 0.7 + s.w * TAU);
    p.x += 0.04 * sin(t * 0.4 + s.z * TAU);
    p.z = (s.w - 0.5) * 0.5;
    size = 1.8; a = 0.4;
  }
  return p;
}

// 2 — the visitor's easing curve, its grid, its handles, and a soft trace around it.
vec3 fCurve(vec4 s, vec4 e, out float size, out float a, out float heat) {
  float role = s.y;
  size = 1.0; a = 1.0; heat = 0.0;
  vec2 p0 = vec2(-1.0), p3 = vec2(1.0);
  vec2 p1 = -1.0 + 2.0 * e.xy;
  vec2 p2 = -1.0 + 2.0 * e.zw;
  if (role < 0.62 || role >= 0.80) {
    bool trace = role >= 0.80;
    float tt = s.x;
    vec2 b = bez(p0, p1, p2, p3, tt);
    vec2 d = normalize(bezD(p0, p1, p2, p3, tt) + vec2(1e-4, 0.0));
    vec2 nrm = vec2(-d.y, d.x);
    float w = (s.z - 0.5) * (trace ? 0.5 : 0.09) * (0.4 + s.w * s.w);
    heat = trace ? 0.0 : 0.35 * s.w;
    a = trace ? 0.16 : 1.0;
    size = trace ? 1.5 : 1.0;
    return vec3(b + nrm * w, (s.w - 0.5) * (trace ? 0.3 : 0.06));
  } else if (role < 0.74) {
    float gx = (floor(s.x * 12.0) + 0.5) / 12.0 * 2.0 - 1.0;
    float gy = (floor(s.z * 12.0) + 0.5) / 12.0 * 2.0 - 1.0;
    a = 0.35; size = 0.8;
    return vec3(gx + (s.w - 0.5) * 0.012, gy + (hash1(s.w * 91.0) - 0.5) * 0.012, 0.0);
  } else {
    vec2 h = role < 0.77 ? p1 : p2;
    float ang = s.x * TAU;
    float r = 0.06 * sqrt(s.z);
    heat = 0.85; size = 1.2;
    return vec3(h + r * vec2(cos(ang), sin(ang)), 0.0);
  }
}

// Spring released from unit displacement at rest; overdamped branch included.
float springX(float tt, float w0, float z) {
  if (tt <= 0.0) return 1.0;
  if (z < 0.999) {
    float wd = w0 * sqrt(1.0 - z * z);
    return exp(-z * w0 * tt) * (cos(wd * tt) + (z * w0 / wd) * sin(wd * tt));
  }
  if (z < 1.001) return exp(-w0 * tt) * (1.0 + w0 * tt);
  float root = sqrt(z * z - 1.0);
  float s1 = -w0 * (z - root), s2 = -w0 * (z + root);
  float A = -s2 / (s1 - s2), B = s1 / (s1 - s2);
  return A * exp(s1 * tt) + B * exp(s2 * tt);
}

// 3 — a lattice of spring nodes that carries the visitor's pluck outward as a wave.
vec3 fLattice(int id, vec4 s, float t, out float size, out float a, out float heat) {
  float cols = uGrid.x, rows = uGrid.y;
  float total = cols * rows;
  float k = mod(float(id), total);
  float col = mod(k, cols), row = floor(k / cols);
  vec2 p = vec2(col / max(cols - 1.0, 1.0), row / max(rows - 1.0, 1.0)) * 2.0 - 1.0;
  p += (s.zw - 0.5) * 0.02;
  vec2 d = p - uPluck.xy;
  float dist = length(d);
  float fall = exp(-dist * dist * 1.3);
  float disp;
  if (uHold > 0.0) {
    disp = fall * uHold;
  } else {
    float tt = t - uSpring.z - dist * 0.10;
    disp = tt > 0.0 ? springX(tt, uSpring.x, uSpring.y) * fall : 0.0;
  }
  vec2 off = uPluck.zw * disp * uSpring.w;
  heat = clamp(abs(disp) * uSpring.w * 2.2, 0.0, 1.0);
  size = 1.0; a = 0.45;
  return vec3(p + off, disp * 0.6 * uSpring.w);
}

// 4 — lines of code, typed in top to bottom (stagger follows the reading order).
vec3 fCode(vec4 s, out float size, out float a, out float heat, out float order) {
  float rows = 20.0;
  float r = floor(s.y * rows);
  float hr = hash1(r + 3.7);
  float blockPos = mod(r, 5.0);
  float lvl = blockPos < 0.5 ? 0.0 : (blockPos > 3.5 ? 0.0 : 1.0 + step(0.55, hash1(r * 2.1)));
  float indent = lvl * 0.11;
  float len = blockPos < 0.5 || blockPos > 3.5 ? 0.42 + 0.2 * hr : 0.45 + 0.5 * fract(hr * 7.31);
  float u = s.x;
  float span = (2.0 - indent) * len;
  float x = -1.0 + indent + u * span + (s.w - 0.5) * 0.006;
  float y = 1.0 - (r + 0.5) / rows * 2.0 + (s.z - 0.5) * 0.035;
  float tok = u * 7.0 + hr * 3.0;
  float seg = floor(tok);
  float gap = step(0.84, fract(tok));
  float cls = mod(seg + floor(hr * 5.0), 3.0);
  heat = cls < 0.5 ? 0.9 : (cls < 1.5 ? 0.0 : 0.4);
  a = 0.5 * (1.0 - gap);
  size = 1.0;
  order = (r + u * 0.8) / rows;
  return vec3(x, y, 0.0);
}

// 5 — the Meridian mark: a globe of meridians, the prime one warm.
vec3 fGlobe(vec4 s, vec2 rot, out float size, out float a, out float heat) {
  float role = s.y;
  float lon, lat;
  size = 1.0; a = 0.9; heat = 0.0;
  if (role < 0.55) {
    float m = floor(s.x * 16.0);
    lon = (m + 0.5) / 16.0 * TAU;
    lat = (s.z - 0.5) * PI;
    heat = m < 0.5 ? 1.0 : 0.0;
  } else if (role < 0.78) {
    float m = floor(s.z * 7.0);
    lat = (m + 0.5) / 7.0 * PI - PI * 0.5;
    lon = s.x * TAU;
    a = 0.55;
  } else {
    lon = s.x * TAU;
    lat = asin(clamp(s.z * 2.0 - 1.0, -1.0, 1.0));
    a = 0.28; size = 1.3;
  }
  vec3 p = vec3(cos(lat) * sin(lon), sin(lat), cos(lat) * cos(lon)) * 0.85;
  float cy = cos(rot.x), sy = sin(rot.x);
  p = vec3(p.x * cy + p.z * sy, p.y, -p.x * sy + p.z * cy);
  float cx = cos(rot.y), sx = sin(rot.y);
  p = vec3(p.x, p.y * cx - p.z * sx, p.y * sx + p.z * cx);
  a *= mix(0.22, 1.0, smoothstep(-0.9, 0.6, p.z));
  return p;
}

vec3 formation(int k, vec4 s, float t, out float size, out float a, out float heat, out float order) {
  size = 1.0; a = 1.0; heat = 0.0; order = s.w;
  if (k == 0) return fChaos(s, t);
  if (k == 1) return fRuler(s, t, uHeroPlayhead, size, a, heat);
  if (k == 2) return fCurve(s, uEase, size, a, heat);
  if (k == 3) return fLattice(gl_VertexID, s, t, size, a, heat);
  if (k == 4) return fCode(s, size, a, heat, order);
  return fGlobe(s, uGlobe, size, a, heat);
}

void main() {
  vec4 s = aSeed;
  float t = uTime;
  float sa, aa, ha, oa, sb, ab, hb, ob;
  vec3 la = formation(uA, s, t, sa, aa, ha, oa);
  vec3 lb = formation(uB, s, t, sb, ab, hb, ob);
  vec3 wa = toWorld(la, uRect[uA]);
  vec3 wb = toWorld(lb, uRect[uB]);

  // Staggered keyframes: every particle runs the visitor's easing, offset by its seed.
  float st = (uB == 4) ? ob : s.w;
  float span = 0.5;
  float m = clamp((uMix - st * span) / (1.0 - span), 0.0, 1.0);
  float me = easeBez(m, uEase);
  vec3 p = mix(wa, wb, me);
  float flight = 4.0 * me * (1.0 - me);
  p.z += 0.35 * flight * (s.z - 0.35);
  float size = mix(sa, sb, me);
  float alpha = mix(aa, ab, me);
  float heat = mix(ha, hb, me) + flight * 0.9;

  // Opening title: chaos resolving into the ruler.
  vec3 c0 = toWorld(fChaos(s, t), uRect[0]);
  float mi = clamp((uIntro - s.w * 0.55) / 0.45, 0.0, 1.0);
  mi = easeBez(mi, uEase);
  p = mix(c0, p, mi);
  heat += 4.0 * mi * (1.0 - mi) * 0.7;
  alpha = mix(0.35, alpha, mi);
  size = mix(1.6, size, mi);

  p.xy += uAmbient * 0.003 * vec2(sin(t * 1.3 + s.x * TAU), cos(t * 1.1 + s.y * TAU));

  // Pointer lens: repulsion plus a little swirl, warming what it touches.
  vec2 d = p.xy - uPointer.xy;
  float r2 = dot(d, d);
  float lens = uPointer.z * exp(-r2 / (uPointer.w * uPointer.w));
  vec2 dir = d * inversesqrt(r2 + 1e-5);
  p.xy += (dir * 0.7 + vec2(-dir.y, dir.x) * 0.5) * lens * uPointer.w * 0.9;
  heat += lens * 1.3;

  vec4 clip = uVP * vec4(p, 1.0);
  gl_Position = clip;
  float depthScale = clamp(uCamDist / max(clip.w, 0.2), 0.3, 3.0);
  gl_PointSize = uPointScale * uDpr * size * depthScale;

  heat = clamp(heat, 0.0, 1.0);
  vec3 col = mix(uIce, uAmber, heat);
  col = mix(col, vec3(1.0), smoothstep(0.72, 1.0, heat) * 0.55);
  vColor = col;
  vAlpha = alpha * uAlpha;
}
`;

export const FRAG = /* glsl */ `#version 300 es
precision mediump float;
in vec3 vColor;
in float vAlpha;
out vec4 outColor;
void main() {
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c) * 2.0;
  float a = smoothstep(1.0, 0.15, d);
  a *= a * vAlpha;
  outColor = vec4(vColor * a, a);
}
`;
