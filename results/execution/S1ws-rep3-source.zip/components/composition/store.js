import { useSyncExternalStore } from "react";

// Discrete state (re-renders React when it changes).
let state = {
  easing: [0.32, 0, 0.18, 1],
  spring: { stiffness: 120, damping: 9 },
  motion: "full", // 'full' | 'reduced'
  motionSource: "system", // 'system' | 'user'
  tier: "high", // 'high' | 'low'
  renderer: "pending", // 'pending' | 'webgl2' | 'none'
  particleCount: 0,
  act: 0,
};

const listeners = new Set();

export function getState() {
  return state;
}

export function setState(partial) {
  state = { ...state, ...partial };
  listeners.forEach((l) => l());
}

export function subscribeStore(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useStore(selector) {
  return useSyncExternalStore(
    subscribeStore,
    () => selector(state),
    () => selector(state),
  );
}

// Per-frame mutable state. Written by input handlers and the render loop,
// read by the loop. Never observed by React, so the loop never re-renders.
export const frame = {
  time: 0,
  progress: 0,
  t: 1, // continuous formation time, 1..5
  smoothT: 1,
  intro: 0,
  pointer: { cx: -1e4, cy: -1e4, wx: 0, wy: 0, strength: 0, target: 0, radius: 0.24, lastX: 0, lastY: 0, lastT: 0 },
  heroPlayhead: 0.36,
  heroTarget: 0.36,
  pluck: { x: 0, y: 0, vx: 0.42, vy: 0.14, release: -1e9, strength: 0, hold: 0, holdStart: 0, nextAuto: 0 },
  globe: { rotY: 0.5, rotX: 0.32, vel: 0, dragging: false },
  markers: [0, 0, 0, 0, 0],
};

export const ACTS = [
  { id: "act-1", numeral: "I", name: "Overture" },
  { id: "act-2", numeral: "II", name: "Keyframes" },
  { id: "act-3", numeral: "III", name: "Springs" },
  { id: "act-4", numeral: "IV", name: "Export" },
  { id: "act-5", numeral: "V", name: "Release" },
];

const MOTION_KEY = "meridian:motion";
let motionInitialised = false;

// Resolve the motion mode once on the client: a stored visitor choice wins,
// otherwise follow prefers-reduced-motion (and keep following it if it changes).
export function initMotion() {
  if (motionInitialised || typeof window === "undefined") return;
  motionInitialised = true;
  const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
  let stored = null;
  try {
    stored = window.localStorage.getItem(MOTION_KEY);
  } catch {
    stored = null;
  }
  if (stored === "full" || stored === "reduced") {
    setState({ motion: stored, motionSource: "user" });
  } else {
    setState({ motion: mq.matches ? "reduced" : "full", motionSource: "system" });
  }
  mq.addEventListener("change", () => {
    if (getState().motionSource === "system") {
      setState({ motion: mq.matches ? "reduced" : "full" });
    }
  });
}

export function setMotion(mode) {
  setState({ motion: mode, motionSource: "user" });
  try {
    window.localStorage.setItem(MOTION_KEY, mode);
  } catch {
    // Storage may be unavailable; the choice still applies for this visit.
  }
}
