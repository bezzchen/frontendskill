"use client";

import { useEffect, useRef } from "react";
import { Field } from "./engine/field";
import { frame, getState, setState, subscribeStore, initMotion, ACTS } from "./store";
import { hud } from "./runtime";
import { springParams, timecode, clamp, RUNTIME_SECONDS } from "./lib/easing";

// Capability recipes. "low" keeps the identity (same formations, same palette)
// with a quarter of the particles, DPR 1 and no ambient jitter.
const RECIPES = {
  high: { count: 56000, dprCap: 1.5, pointScale: 2.0, ambient: 1 },
  low: { count: 16000, dprCap: 1, pointScale: 2.3, ambient: 0 },
};

const INTRO_SECONDS = 2.6;
const ARRIVE_FROM = 1.15; // next instrument's centre, in viewport heights, where the morph starts
const ARRIVE_TO = 0.55; // ... and where it has fully arrived

function detectTier() {
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const narrow = window.innerWidth < 900;
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory || 8;
  return coarse || narrow || cores <= 4 || mem <= 4 ? "low" : "high";
}

// Small deterministic sequence for the auto-pluck positions.
let pseudoSeed = 12345;
const pseudo = () => {
  pseudoSeed = (pseudoSeed * 1664525 + 1013904223) >>> 0;
  return pseudoSeed / 4294967296;
};

const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export default function Stage() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const root = document.documentElement;
    initMotion();

    // Without WebGL2 the vector fallbacks carry the identity; the timeline HUD still follows scroll.
    let field = null;
    try {
      field = new Field(canvas);
    } catch {
      field = null;
    }

    let tier = detectTier();
    let recipe = RECIPES[tier];
    if (field) {
      field.setCount(recipe.count);
      setState({ renderer: "webgl2", tier, particleCount: recipe.count });
      root.dataset.renderer = "webgl2";
      root.dataset.tier = tier;
    } else {
      setState({ renderer: "none", tier });
      root.dataset.renderer = "none";
    }
    root.dataset.motion = getState().motion;

    const anchorEls = [];
    document.querySelectorAll("[data-anchor]").forEach((el) => {
      anchorEls[Number(el.dataset.anchor)] = el;
    });
    const sectionEls = ACTS.map((a) => document.getElementById(a.id));
    const arriveCache = new Array(6).fill(-1);
    const markerCache = new Array(5).fill(-1);
    let lastTimecode = "";
    let lastValueText = "";

    const rects = new Float32Array(24);
    const centres = new Float32Array(6);
    let viewport = { W: 1, H: 1, aspect: 1, left: 0, top: 0 };

    const stats = { frames: 0, ema: 16, governed: false, lastResize: 0 };
    let running = false;
    let rafId = 0;
    let last = 0;
    let visible = document.visibilityState === "visible";
    let intersecting = true;
    let pendingStatic = 0;

    function resize() {
      const cr = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, recipe.dprCap);
      if (field) field.resize(cr.width || 1, cr.height || 1, dpr);
    }

    function measure() {
      const cr = canvas.getBoundingClientRect();
      const W = cr.width || 1;
      const H = cr.height || 1;
      const aspect = W / H;
      viewport = { W, H, aspect, left: cr.left, top: cr.top };
      rects[0] = 0;
      rects[1] = 0;
      rects[2] = aspect;
      rects[3] = 1;
      const vh = window.innerHeight || H;
      const scrollY = window.scrollY;
      const maxScroll = Math.max(1, root.scrollHeight - vh);
      for (let k = 1; k <= 5; k++) {
        const el = anchorEls[k];
        if (!el) continue;
        const r = el.getBoundingClientRect();
        const cx = ((r.left + r.width / 2 - cr.left) / W) * 2 - 1;
        const cy = 1 - ((r.top + r.height / 2 - cr.top) / H) * 2;
        rects[k * 4] = cx * aspect;
        rects[k * 4 + 1] = cy;
        rects[k * 4 + 2] = (r.width / W) * aspect;
        rects[k * 4 + 3] = r.height / H;
        centres[k] = (r.top + r.height / 2) / vh;
        // Scroll position at which this act becomes current (its instrument centre at 80% of the viewport).
        frame.markers[k - 1] = k === 1 ? 0 : clamp((r.top + r.height / 2 + scrollY - 0.8 * vh) / maxScroll, 0, 1);
        if (k === 1) {
          const p = frame.pointer;
          if (p.cx > -1e3) frame.heroTarget = clamp((p.cx - r.left) / Math.max(1, r.width), 0.02, 0.98);
        }
      }
      // Continuous formation time: the field flows to whichever instrument is arriving.
      let t = 1;
      for (let k = 2; k <= 5; k++) {
        const arr = clamp((ARRIVE_FROM - centres[k]) / (ARRIVE_FROM - ARRIVE_TO), 0, 1);
        if (arr <= 0) break;
        t = k - 1 + arr;
      }
      frame.t = t;
      frame.progress = clamp(scrollY / maxScroll, 0, 1);
    }

    function writeHud() {
      const seconds = frame.progress * RUNTIME_SECONDS;
      const tc = timecode(seconds);
      if (hud.tc && tc !== lastTimecode) {
        hud.tc.textContent = tc;
        lastTimecode = tc;
      }
      if (hud.range && !hud.scrubbing) {
        hud.range.value = String(seconds);
        const act = ACTS[getState().act];
        const vt = `${tc}, Act ${act.numeral}: ${act.name}`;
        if (vt !== lastValueText) {
          hud.range.setAttribute("aria-valuetext", vt);
          lastValueText = vt;
        }
      }
      if (hud.head) hud.head.style.left = `${frame.progress * 100}%`;
      for (let k = 0; k < 5; k++) {
        const m = frame.markers[k];
        if (Math.abs(m - markerCache[k]) > 0.0005) {
          markerCache[k] = m;
          if (hud.markers[k]) hud.markers[k].style.left = `${m * 100}%`;
          if (hud.actTimes[k]) hud.actTimes[k].textContent = timecode(m * RUNTIME_SECONDS);
        }
      }
    }

    function writeArrival(a, b, mix, reduced) {
      for (let k = 1; k <= 5; k++) {
        let v;
        if (reduced) v = 1;
        else if (k === b) v = smoothstep(0.55, 1, mix);
        else if (k === a) v = 1 - smoothstep(0, 0.45, mix);
        else v = 0;
        if (b === a && k === a) v = 1;
        if (Math.abs(v - arriveCache[k]) > 0.005) {
          arriveCache[k] = v;
          const el = sectionEls[k - 1];
          if (el) el.style.setProperty("--arrive", v.toFixed(3));
        }
      }
    }

    function updateAct(t) {
      const act = clamp(Math.round(t) - 1, 0, 4);
      if (act !== getState().act) setState({ act });
    }

    function draw(mode) {
      if (!field) return;
      const S = getState();
      const reduced = mode === "reduced";
      const tt = reduced ? Math.round(frame.t) : frame.smoothT;
      const a = clamp(Math.floor(tt), 1, 5);
      const b = Math.min(5, a + 1);
      const mix = clamp(tt - a, 0, 1);
      const sp = springParams(S.spring);
      const p = frame.pointer;
      const pk = frame.pluck;
      const g = frame.globe;
      const wx = ((p.cx - viewport.left) / viewport.W) * 2 - 1;
      const wy = 1 - ((p.cy - viewport.top) / viewport.H) * 2;
      field.render({
        time: frame.time,
        a,
        b,
        mix,
        intro: reduced ? 1 : frame.intro,
        rects,
        ease: S.easing,
        spring: [sp.omega0, sp.zeta, pk.release, reduced ? 0 : pk.strength],
        pluck: [pk.x, pk.y, pk.vx, pk.vy],
        hold: reduced || !pk.hold ? 0 : Math.min(1, (frame.time - (pk.holdStart ?? frame.time)) / 0.35),
        pointer: [wx * viewport.aspect, wy, reduced ? 0 : p.strength, p.radius],
        globe: reduced ? [0.5, 0.32] : [g.rotY, g.rotX],
        heroPlayhead: reduced ? 0.36 : frame.heroPlayhead,
        ambient: reduced ? 0 : recipe.ambient,
        pointScale: recipe.pointScale,
      });
      writeArrival(a, b, mix, reduced);
    }

    function step(dt) {
      measure();
      frame.smoothT += (frame.t - frame.smoothT) * (1 - Math.exp(-dt * 10));
      if (frame.intro < 1) frame.intro = Math.min(1, frame.intro + dt / INTRO_SECONDS);
      const p = frame.pointer;
      p.strength += (p.target - p.strength) * (1 - Math.exp(-dt * 12));
      p.target *= Math.exp(-dt * 2.5);
      frame.heroPlayhead += (frame.heroTarget - frame.heroPlayhead) * (1 - Math.exp(-dt * 8));
      const g = frame.globe;
      if (!g.dragging) {
        g.rotY += (0.12 + g.vel) * dt;
        g.vel *= Math.exp(-dt * 1.8);
      }
      const pk = frame.pluck;
      // Springs act: while the visitor is here and not pulling the field themselves, pluck it
      // on arrival and about every 3.5 s, so the current stiffness and damping stay visible.
      if (getState().act === 2) {
        if (!pk.hold && frame.time > pk.nextAuto) {
          pk.nextAuto = frame.time + 3.0;
          const r1 = pseudo(), r2 = pseudo(), r3 = pseudo();
          Object.assign(pk, {
            x: (r1 - 0.5) * 1.2, y: (r2 - 0.5) * 1.0,
            vx: 0.4 + 0.3 * r3, vy: (r2 - 0.5) * 0.5,
            hold: 1, holdStart: frame.time, holdUntil: frame.time + 0.4, strength: 1,
          });
        }
      } else {
        pk.nextAuto = 0;
      }
      if (pk.hold && pk.holdUntil !== undefined && frame.time > pk.holdUntil) {
        pk.hold = 0;
        pk.holdUntil = undefined;
        pk.release = frame.time;
        pk.strength = 1;
      }
      updateAct(frame.smoothT);
    }

    function govern(dtMs) {
      stats.ema = stats.ema * 0.9 + dtMs * 0.1;
      if (field && !stats.governed && stats.frames > 150 && stats.ema > 24 && field.count > 20000) {
        stats.governed = true;
        tier = "low";
        recipe = { ...RECIPES.low, count: Math.floor(field.count / 2) };
        field.setCount(recipe.count);
        resize();
        setState({ tier, particleCount: recipe.count });
        root.dataset.tier = "low";
        root.dataset.governed = "true";
      }
    }

    function tick(now) {
      if (!running) return;
      rafId = requestAnimationFrame(tick);
      const dtMs = last ? Math.min(50, now - last) : 16;
      last = now;
      const dt = dtMs / 1000;
      frame.time += dt;
      step(dt);
      draw("full");
      writeHud();
      stats.frames++;
      if (frame.intro >= 1) govern(dtMs);
    }

    // No loop running (reduced mode, no renderer, or the stage scrolled offscreen): one
    // measurement per discrete change keeps the HUD honest, and reduced mode re-plates the field.
    function renderStatic() {
      if (pendingStatic) return;
      pendingStatic = requestAnimationFrame(() => {
        pendingStatic = 0;
        measure();
        const reduced = getState().motion === "reduced";
        frame.smoothT = reduced ? Math.round(frame.t) : frame.t;
        updateAct(frame.t);
        if (field && reduced) {
          draw("reduced");
          stats.frames++;
        }
        writeHud();
      });
    }

    function updateRunning() {
      const S = getState();
      const should = visible && intersecting && S.motion === "full" && !!field && !field.lost;
      if (should && !running) {
        running = true;
        last = 0;
        rafId = requestAnimationFrame(tick);
        canvas.dataset.render = "running";
      } else if (!should && running) {
        running = false;
        cancelAnimationFrame(rafId);
        canvas.dataset.render = S.motion === "reduced" ? "static" : "paused";
      } else if (!should) {
        canvas.dataset.render = S.motion === "reduced" ? "static" : "paused";
      }
      if (!field) canvas.dataset.render = "none";
      if ((S.motion === "reduced" || !field) && visible) renderStatic();
    }

    // Offscreen means no visible pixels: an edge-adjacent box (the sticky stage parked exactly
    // above the viewport once the end slate takes over) must count as offscreen, so both the
    // observer and the scroll handler test the canvas rect for a non-empty intersection.
    const canvasOnScreen = () => {
      const r = canvas.getBoundingClientRect();
      // A sub-pixel sliver left over from fractional layout does not count as on screen.
      return r.bottom > 1 && r.top < window.innerHeight - 1 && r.right > 1 && r.left < window.innerWidth - 1;
    };
    const io = new IntersectionObserver(
      () => {
        intersecting = canvasOnScreen();
        updateRunning();
      },
      { threshold: 0, rootMargin: "-1px" },
    );
    io.observe(canvas);

    const onVisibility = () => {
      visible = document.visibilityState === "visible";
      updateRunning();
    };
    document.addEventListener("visibilitychange", onVisibility);

    const onPointerMove = (e) => {
      const p = frame.pointer;
      const now = performance.now();
      if (p.lastT) {
        const dtp = Math.max(1, now - p.lastT);
        const speed = Math.hypot(e.clientX - p.lastX, e.clientY - p.lastY) / dtp; // px per ms
        p.target = Math.max(p.target, Math.min(1, speed * 1.1));
      }
      p.lastX = e.clientX;
      p.lastY = e.clientY;
      p.lastT = now;
      p.cx = e.clientX;
      p.cy = e.clientY;
    };
    const onPointerLeave = () => {
      frame.pointer.target = 0;
      frame.pointer.cx = -1e4;
      frame.pointer.cy = -1e4;
    };
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    document.addEventListener("pointerleave", onPointerLeave);

    const onScroll = () => {
      const on = canvasOnScreen();
      if (on !== intersecting) {
        intersecting = on;
        updateRunning();
      }
      if (!running) renderStatic();
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    const ro = new ResizeObserver(() => {
      resize();
      if (!running) renderStatic();
    });
    ro.observe(canvas);
    resize();

    let prevMotion = getState().motion;
    const unsubscribe = subscribeStore(() => {
      const S = getState();
      if (S.motion !== prevMotion) {
        prevMotion = S.motion;
        root.dataset.motion = S.motion;
        if (S.motion === "full" && S.act > 0) frame.intro = 1;
        updateRunning();
      } else if (S.motion === "reduced") {
        renderStatic(); // an edit to the curve or the spring re-plates the field
      }
    });

    updateRunning();
    canvas.dataset.ready = "true";

    window.__meridian = {
      get frames() { return stats.frames; },
      get running() { return running; },
      get frameMs() { return stats.ema; },
      get count() { return field ? field.count : 0; },
      get dpr() { return field ? field.dpr : 0; },
      get time() { return frame.time; },
      get pluck() { return { ...frame.pluck }; },
      get tier() { return tier; },
      get motion() { return getState().motion; },
      get t() { return frame.smoothT; },
      get intersecting() { return intersecting; },
      get visible() { return visible; },
      get governed() { return stats.governed; },
    };

    return () => {
      running = false;
      cancelAnimationFrame(rafId);
      cancelAnimationFrame(pendingStatic);
      io.disconnect();
      ro.disconnect();
      unsubscribe();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pointermove", onPointerMove);
      document.removeEventListener("pointerleave", onPointerLeave);
      window.removeEventListener("scroll", onScroll);
      if (field) field.dispose();
      delete window.__meridian;
    };
  }, []);

  return <canvas ref={canvasRef} className="stage__canvas" aria-hidden="true" />;
}
