"use client";

import Stage from "./Stage";
import Hud from "./Hud";
import SiteHeader from "./SiteHeader";
import EndSlate from "./EndSlate";
import Overture from "./acts/Overture";
import Keyframes from "./acts/Keyframes";
import Springs from "./acts/Springs";
import Export from "./acts/Export";
import Release from "./acts/Release";

// The stage is sticky for the length of the five acts, then scrolls away with
// them so the end slate can take the screen (and the render loop can pause).
export default function Composition() {
  return (
    <>
      <SiteHeader />
      <div className="composition">
        <div className="stage">
          <Stage />
        </div>
        <main id="main" className="acts">
          <Overture />
          <Keyframes />
          <Springs />
          <Export />
          <Release />
        </main>
      </div>
      <EndSlate />
      <Hud />
    </>
  );
}
