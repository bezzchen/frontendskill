"use client";

import { useEffect, useRef } from "react";
import { useStore, ACTS, frame, getState, setMotion } from "./store";
import { registerHud, hud } from "./runtime";
import { RUNTIME_SECONDS } from "./lib/easing";

function scrollToProgress(p, smooth) {
  const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  window.scrollTo({ top: p * max, behavior: smooth && getState().motion === "full" ? "smooth" : "auto" });
}

export default function Hud() {
  const act = useStore((s) => s.act);
  const motion = useStore((s) => s.motion);
  const tcRef = useRef(null);
  const rangeRef = useRef(null);
  const headRef = useRef(null);
  const markerRefs = useRef([]);

  useEffect(() => {
    registerHud({ tc: tcRef.current, range: rangeRef.current, head: headRef.current, markers: markerRefs.current });
    return () => registerHud({ tc: null, range: null, head: null, markers: [] });
  }, []);

  const current = ACTS[act];

  return (
    <nav className="hud" aria-label="Composition timeline">
      <div className="hud__time">
        <span className="hud__tc" ref={tcRef}>00:00:00:00</span>
        <span className="hud__act">
          Act {current.numeral}
          <span className="hud__act-name"> {current.name}</span>
        </span>
      </div>

      <div className="hud__ruler">
        <input
          ref={rangeRef}
          className="hud__range"
          type="range"
          min={0}
          max={RUNTIME_SECONDS}
          step={0.5}
          defaultValue={0}
          aria-label="Playhead"
          aria-valuetext="00:00:00:00, Act I: Overture"
          onInput={(e) => scrollToProgress(Number(e.currentTarget.value) / RUNTIME_SECONDS, false)}
          onPointerDown={() => { hud.scrubbing = true; }}
          onPointerUp={() => { hud.scrubbing = false; }}
          onPointerCancel={() => { hud.scrubbing = false; }}
          onBlur={() => { hud.scrubbing = false; }}
        />
        <span className="hud__head" ref={headRef} aria-hidden="true" />
        <ol className="hud__markers" aria-label="Keyframes">
          {ACTS.map((a, i) => (
            <li
              key={a.id}
              ref={(el) => { markerRefs.current[i] = el; }}
              className="hud__marker"
              style={{ left: `${(i / 4) * 100}%` }}
              data-current={i === act ? "true" : undefined}
            >
              <button
                type="button"
                className="hud__marker-button"
                aria-label={`Jump to Act ${a.numeral}: ${a.name}`}
                aria-current={i === act ? "true" : undefined}
                onClick={() => scrollToProgress(frame.markers[i], true)}
              >
                <span className="hud__marker-name">{a.name}</span>
              </button>
            </li>
          ))}
        </ol>
      </div>

      <button
        type="button"
        className="hud__motion"
        aria-describedby="motion-hint"
        onClick={() => setMotion(motion === "full" ? "reduced" : "full")}
      >
        Motion: {motion === "full" ? "full" : "reduced"}
      </button>
      <span id="motion-hint" className="sr-only">
        Switches between the full-motion and reduced-motion versions of this page. Both contain the same content.
      </span>
    </nav>
  );
}
