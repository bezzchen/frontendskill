"use client";

import { useEffect, useRef } from "react";
import { ACTS, useStore } from "./store";
import { hud } from "./runtime";

// "Act II 00:00:10:12" — the act's position on the composition's timeline.
// The timecode is filled by the render loop once the layout is measured.
export default function ActMarker({ index }) {
  const act = useStore((s) => s.act);
  const timeRef = useRef(null);
  useEffect(() => {
    hud.actTimes[index] = timeRef.current;
    return () => { hud.actTimes[index] = null; };
  }, [index]);
  const a = ACTS[index];
  return (
    <p className="act__marker" aria-current={act === index ? "step" : undefined}>
      <span className="act__numeral">Act {a.numeral}</span>
      <span className="act__time" ref={timeRef}>{index === 0 ? "00:00:00:00" : ""}</span>
    </p>
  );
}
