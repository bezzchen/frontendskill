"use client";

import { useState } from "react";
import ActMarker from "../ActMarker";
import { useStore } from "../store";
import { formatBezier, springParams } from "../lib/easing";

export default function Export() {
  const easing = useStore((s) => s.easing);
  const spring = useStore((s) => s.spring);
  const [copied, setCopied] = useState(false);
  const params = springParams(spring);
  const bezier = formatBezier(easing);
  const settle = params.settle.toFixed(2);

  const plain = [
    ".card {",
    `  transition: transform 720ms ${bezier};`,
    "}",
    "",
    "@media (prefers-reduced-motion: reduce) {",
    "  .card { transition-duration: 0ms; }",
    "}",
    "",
    'import { spring } from "@meridian/motion";',
    "",
    "export const settle = spring({",
    `  stiffness: ${spring.stiffness},`,
    `  damping: ${spring.damping},`,
    "  mass: 1,",
    `}); // settles in ${settle}s`,
  ].join("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(plain);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section id="act-4" className="act act--export" aria-labelledby="h-act-4">
      <div className="act__text">
        <ActMarker index={3} />
        <h2 id="h-act-4" className="display">Ship it as code, not a video.</h2>
        <p>
          What you designed above, exported the way it ships: plain CSS and JavaScript with your
          curve and your spring, and no runtime to install. The reduced-motion variant is written
          for you.
        </p>
        <p className="muted">Every highlighted value updates as you edit Acts II and III.</p>
      </div>
      <div className="instrument instrument--code" data-anchor="4">
        <div className="code">
          <div className="code__bar">
            <span className="code__file">motion.css</span>
            <button type="button" className="chip chip--small" onClick={copy}>
              {copied ? "Copied" : "Copy code"}
            </button>
          </div>
          <pre className="code__pre" tabIndex={0}>
            <code>
              <span className="tok-sel">.card</span> {"{"}{"\n"}
              {"  "}<span className="tok-prop">transition</span>: <span className="tok-val">transform 720ms</span>{" "}
              <span className="tok-live">{bezier}</span>;{"\n"}
              {"}"}{"\n\n"}
              <span className="tok-at">@media</span> <span className="tok-val">(prefers-reduced-motion: reduce)</span> {"{"}{"\n"}
              {"  "}<span className="tok-sel">.card</span> {"{"} <span className="tok-prop">transition-duration</span>:{" "}
              <span className="tok-val">0ms</span>; {"}"}{"\n"}
              {"}"}
            </code>
          </pre>
          <div className="code__bar">
            <span className="code__file">motion.js</span>
          </div>
          <pre className="code__pre" tabIndex={0}>
            <code>
              <span className="tok-at">import</span> {"{ "}<span className="tok-val">spring</span>{" }"}{" "}
              <span className="tok-at">from</span> <span className="tok-str">"@meridian/motion"</span>;{"\n\n"}
              <span className="tok-at">export const</span> <span className="tok-val">settle</span> = <span className="tok-fn">spring</span>({"{"}{"\n"}
              {"  "}<span className="tok-prop">stiffness</span>: <span className="tok-live">{spring.stiffness}</span>,{"\n"}
              {"  "}<span className="tok-prop">damping</span>: <span className="tok-live">{spring.damping}</span>,{"\n"}
              {"  "}<span className="tok-prop">mass</span>: <span className="tok-val">1</span>,{"\n"}
              {"}"}); <span className="tok-cm">{`// settles in ${settle}s`}</span>
            </code>
          </pre>
        </div>
        <span className="sr-only" aria-live="polite">{copied ? "Code copied to clipboard." : ""}</span>
      </div>
    </section>
  );
}
