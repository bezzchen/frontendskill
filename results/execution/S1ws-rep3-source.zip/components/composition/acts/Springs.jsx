"use client";

import { useRef } from "react";
import ActMarker from "../ActMarker";
import SpringPlot from "../SpringPlot";
import { useStore, setState, getState, frame } from "../store";
import { springParams, SPRING_LIMITS } from "../lib/easing";

export default function Springs() {
  const spring = useStore((s) => s.spring);
  const motion = useStore((s) => s.motion);
  const renderer = useStore((s) => s.renderer);
  const params = springParams(spring);
  const panelRef = useRef(null);
  const canPluck = motion === "full" && renderer === "webgl2";

  const update = (key) => (e) => setState({ spring: { ...getState().spring, [key]: Number(e.target.value) } });

  const pluckAt = (x, y, vx, vy) => {
    Object.assign(frame.pluck, { x, y, vx, vy, hold: 0, holdUntil: undefined, release: frame.time, strength: 1, nextAuto: frame.time + 4 });
  };

  // Pull the lattice with the pointer, let go, and the spring carries it back.
  const onPointerDown = (e) => {
    if (getState().motion !== "full" || e.button !== 0) return;
    const panel = panelRef.current;
    const r = panel.getBoundingClientRect();
    e.preventDefault();
    panel.setPointerCapture(e.pointerId);
    const lx = ((e.clientX - r.left) / r.width) * 2 - 1;
    const ly = 1 - ((e.clientY - r.top) / r.height) * 2;
    Object.assign(frame.pluck, { x: lx, y: ly, vx: 0, vy: 0, hold: 1, holdStart: frame.time, holdUntil: undefined, strength: 1, nextAuto: frame.time + 8 });
    const startX = e.clientX;
    const startY = e.clientY;
    const move = (ev) => {
      let dx = ((ev.clientX - startX) / r.width) * 2;
      let dy = -((ev.clientY - startY) / r.height) * 2;
      const len = Math.hypot(dx, dy);
      if (len > 0.6) { dx *= 0.6 / len; dy *= 0.6 / len; }
      frame.pluck.vx = dx;
      frame.pluck.vy = dy;
    };
    const cleanup = () => {
      panel.removeEventListener("pointermove", move);
      panel.removeEventListener("pointerup", up);
      panel.removeEventListener("pointercancel", cancel);
    };
    const up = () => {
      const pk = frame.pluck;
      if (Math.hypot(pk.vx, pk.vy) < 0.04) { pk.vx = 0.5; pk.vy = 0.15; } // a tap plucks too
      pk.hold = 0;
      pk.release = frame.time;
      pk.strength = 1;
      pk.nextAuto = frame.time + 4;
      cleanup();
    };
    const cancel = () => {
      frame.pluck.hold = 0;
      frame.pluck.strength = 0;
      cleanup();
    };
    panel.addEventListener("pointermove", move);
    panel.addEventListener("pointerup", up);
    panel.addEventListener("pointercancel", cancel);
  };

  return (
    <section id="act-3" className="act act--hold" aria-labelledby="h-act-3">
      <div className="act__text">
        <ActMarker index={2} />
        <h2 id="h-act-3" className="display">Springs, not stopwatches.</h2>
        <p>
          Motion that ends on a clock feels dead. Set stiffness and damping, then pull the field and
          let it go.
        </p>
        <div className="controls">
          <label className="slider">
            <span className="slider__name">Stiffness</span>
            <input
              type="range"
              min={SPRING_LIMITS.stiffness.min}
              max={SPRING_LIMITS.stiffness.max}
              step={SPRING_LIMITS.stiffness.step}
              value={spring.stiffness}
              onChange={update("stiffness")}
            />
            <output className="slider__value">{spring.stiffness}</output>
          </label>
          <label className="slider">
            <span className="slider__name">Damping</span>
            <input
              type="range"
              min={SPRING_LIMITS.damping.min}
              max={SPRING_LIMITS.damping.max}
              step={SPRING_LIMITS.damping.step}
              value={spring.damping}
              onChange={update("damping")}
            />
            <output className="slider__value">{spring.damping}</output>
          </label>
          {canPluck && (
            <button type="button" className="chip chip--action" onClick={() => pluckAt(0, 0, 0.55, 0.16)}>
              Pluck the field
            </button>
          )}
        </div>
        <p className="readout">
          Settles in {params.settle.toFixed(2)} s
          {params.overshoot > 0.005 ? `, overshoots by ${Math.round(params.overshoot * 100)}%` : ", no overshoot"}
        </p>
        <SpringPlot params={params} />
      </div>
      <div
        className="instrument instrument--lattice"
        data-anchor="3"
        ref={panelRef}
        onPointerDown={onPointerDown}
        aria-hidden="true"
      />
    </section>
  );
}
