"use client";

import { useRef } from "react";
import ActMarker from "../ActMarker";
import { frame, getState } from "../store";

export default function Release() {
  const panelRef = useRef(null);

  // Turn the mark under the pointer; it keeps spinning with inertia after release.
  const onPointerDown = (e) => {
    if (getState().motion !== "full" || e.button !== 0 || e.pointerType === "touch") return;
    const panel = panelRef.current;
    e.preventDefault();
    panel.setPointerCapture(e.pointerId);
    const g = frame.globe;
    g.dragging = true;
    let lastX = e.clientX;
    let lastT = performance.now();
    const move = (ev) => {
      const now = performance.now();
      const dx = ev.clientX - lastX;
      const dt = Math.max(1, now - lastT);
      g.rotY += dx * 0.008;
      g.vel = (dx / dt) * 6;
      lastX = ev.clientX;
      lastT = now;
    };
    const end = () => {
      g.dragging = false;
      panel.removeEventListener("pointermove", move);
      panel.removeEventListener("pointerup", end);
      panel.removeEventListener("pointercancel", end);
    };
    panel.addEventListener("pointermove", move);
    panel.addEventListener("pointerup", end);
    panel.addEventListener("pointercancel", end);
  };

  return (
    <section id="act-5" className="act act--release" aria-labelledby="h-act-5">
      <div className="act__text">
        <ActMarker index={4} />
        <h2 id="h-act-5" className="display">Meridian is in private beta.</h2>
        <p>
          We're onboarding small teams who ship motion in production. Tell us what you're animating
          and which framework you ship with.
        </p>
        <p className="cta-row">
          <a id="access" className="cta" href="mailto:hello@meridian.tools?subject=Early%20access%20to%20Meridian">
            Request early access
          </a>
          <span className="muted">hello@meridian.tools</span>
        </p>
      </div>
      <div
        className="instrument instrument--globe"
        data-anchor="5"
        ref={panelRef}
        onPointerDown={onPointerDown}
        aria-hidden="true"
      >
        <svg className="fallback fallback--globe" viewBox="0 0 100 100" focusable="false">
          <circle cx="50" cy="50" r="42" />
          <ellipse cx="50" cy="50" rx="14" ry="42" />
          <ellipse cx="50" cy="50" rx="30" ry="42" />
          <ellipse cx="50" cy="50" rx="42" ry="14" />
          <ellipse cx="50" cy="50" rx="42" ry="30" />
          <ellipse className="fallback__prime" cx="50" cy="50" rx="4" ry="42" />
        </svg>
      </div>
    </section>
  );
}
