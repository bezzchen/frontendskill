"use client";

import ActMarker from "../ActMarker";
import EasingEditor from "../EasingEditor";
import { useStore, setState } from "../store";
import { EASING_PRESETS, formatBezier } from "../lib/easing";

const same = (a, b) => a.every((v, i) => Math.abs(v - b[i]) < 1e-6);

export default function Keyframes() {
  const easing = useStore((s) => s.easing);
  return (
    <section id="act-2" className="act act--hold" aria-labelledby="h-act-2">
      <div className="act__text">
        <ActMarker index={1} />
        <h2 id="h-act-2" className="display">Keyframes you can feel.</h2>
        <p>
          Drag the handles. Every particle on this page re-times itself to your curve, and so does
          the code you export in Act IV.
        </p>
        <div className="chips" role="group" aria-label="Easing presets">
          {EASING_PRESETS.map((p) => (
            <button
              key={p.name}
              type="button"
              className="chip"
              aria-pressed={same(p.value, easing)}
              onClick={() => setState({ easing: p.value })}
            >
              {p.name}
            </button>
          ))}
        </div>
        <p className="readout">
          <code>{formatBezier(easing)}</code>
        </p>
      </div>
      <EasingEditor />
    </section>
  );
}
