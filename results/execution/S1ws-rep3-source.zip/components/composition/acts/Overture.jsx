"use client";

import ActMarker from "../ActMarker";

export default function Overture() {
  return (
    <section id="act-1" className="act act--overture" aria-labelledby="h-act-1">
      <div className="act__text act__text--wide">
        <ActMarker index={0} />
        <h1 id="h-act-1" className="display display--xl">
          Design animation visually. Ship production code.
        </h1>
        <p className="lede">
          Meridian is a timeline editor for motion on the web. This page is a Meridian composition:
          scroll to move the playhead, or drag it in the timeline below.
        </p>
        <p className="hint">Move your cursor along the ruler.</p>
      </div>
      <div className="instrument instrument--ruler" data-anchor="1" aria-hidden="true">
        <svg className="fallback fallback--ruler" viewBox="0 0 1000 100" preserveAspectRatio="none" focusable="false">
          <defs>
            <pattern id="ticks" width="20" height="100" patternUnits="userSpaceOnUse">
              <line x1="0" y1="50" x2="0" y2="62" />
            </pattern>
            <pattern id="ticks-major" width="120" height="100" patternUnits="userSpaceOnUse">
              <line x1="0" y1="50" x2="0" y2="78" />
            </pattern>
          </defs>
          <line x1="0" y1="50" x2="1000" y2="50" />
          <rect width="1000" height="100" fill="url(#ticks)" />
          <rect width="1000" height="100" fill="url(#ticks-major)" />
          <line className="fallback__head" x1="360" y1="20" x2="360" y2="90" />
        </svg>
      </div>
    </section>
  );
}
