import Composition from "@/components/composition/Composition";

export default function Home() {
  return <Composition />;
}
