import "./globals.css";

export const metadata = {
  title: "Meridian",
  description:
    "Meridian is a timeline-based motion editor for the web. Design animation visually, ship production code.",
  openGraph: {
    title: "Meridian",
    description: "Design animation visually. Ship production code.",
    type: "website",
  },
};

export const viewport = {
  themeColor: "#0b1020",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
