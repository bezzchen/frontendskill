export default function AccessAct() {
  return (
    <div className="copy copy-access">
      <h2 className="headline">Meridian is in private beta.</h2>
      <p className="lede">
        We are onboarding a few teams at a time and shipping weekly. Tell us what you animate
        today and we will send an invitation when your seat is ready.
      </p>
      <p className="cta-row">
        <a className="cta" href="mailto:hello@meridian.tools?subject=Early%20access%20to%20Meridian">
          Request early access
        </a>
        <a className="quiet-link" href="#meridian">
          Back to the start
        </a>
      </p>
    </div>
  );
}
