"use client";
import { useCallback, useRef, useState } from "react";
import { TRACKS, norm, denorm, clamp01, formatValue } from "@/lib/document";
import { useStore } from "@/lib/store";

const PAD = 0.18; // matches the shader's lane padding

function KeyHandle({ track, which, doc, setDoc, laneRef, rowIndex, reduced }) {
  const key = doc.keys[track.id][which];
  const other = doc.keys[track.id][1 - which];
  const n = clamp01(norm(track, key.v));
  const [active, setActive] = useState(false);
  const drag = useRef(null);

  const commit = useCallback(
    (t, v) => {
      setDoc((d) => {
        const keys = { ...d.keys };
        const pair = keys[track.id].map((k) => ({ ...k }));
        pair[which] = { t, v };
        keys[track.id] = pair;
        return { ...d, keys };
      });
    },
    [setDoc, track.id, which]
  );

  const clampT = (t) => (which === 0 ? Math.min(t, other.t - 0.06) : Math.max(t, other.t + 0.06));

  const onPointerDown = (e) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { id: e.pointerId };
    setActive(true);
  };
  const onPointerMove = (e) => {
    if (!drag.current || !laneRef.current) return;
    const lane = laneRef.current.getBoundingClientRect();
    const rowH = lane.height / TRACKS.length;
    const rowTop = lane.top + rowH * rowIndex;
    const t = clamp01((e.clientX - lane.left) / lane.width);
    const yFrac = (e.clientY - rowTop) / rowH;
    const nv = clamp01(1 - (yFrac - PAD) / (1 - 2 * PAD));
    commit(clamp01(clampT(t)), denorm(track, nv));
  };
  const onPointerUp = (e) => {
    if (!drag.current) return;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}
    drag.current = null;
    setActive(false);
  };
  const onKeyDown = (e) => {
    const big = e.shiftKey ? 5 : 1;
    let t = key.t;
    let nv = n;
    if (e.key === "ArrowLeft") t -= 0.02 * big;
    else if (e.key === "ArrowRight") t += 0.02 * big;
    else if (e.key === "ArrowUp") nv += 0.05 * big;
    else if (e.key === "ArrowDown") nv -= 0.05 * big;
    else if (e.key === "Home") t = which === 0 ? 0 : other.t + 0.06;
    else if (e.key === "End") t = which === 0 ? other.t - 0.06 : 1;
    else return;
    e.preventDefault();
    commit(clamp01(clampT(t)), denorm(track, clamp01(nv)));
  };

  const seconds = (key.t * doc.duration).toFixed(2);
  const label = `${track.name} ${which === 0 ? "start" : "end"} keyframe`;
  return (
    <button
      type="button"
      className={"key" + (active ? " is-active" : "")}
      style={{ left: `${key.t * 100}%`, top: `${(PAD + (1 - n) * (1 - 2 * PAD)) * 100}%` }}
      role="slider"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(key.t * 100)}
      aria-valuetext={`at ${seconds} seconds, ${formatValue(track, key.v)}. Left and right move time, up and down change the value.`}
      aria-orientation="horizontal"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onKeyDown={onKeyDown}
      data-reduced={reduced ? "" : undefined}
    >
      <span className="key-readout" aria-hidden="true">
        <b>{seconds} s</b>
        <span>{formatValue(track, key.v)}</span>
      </span>
    </button>
  );
}

export default function TimelineAct({ store, reduced }) {
  const doc = useStore(store);
  const laneRef = useRef(null);
  const setDoc = store.set;
  return (
    <>
      <div className="copy">
        <h2 className="headline">Every property is a track.</h2>
        <p className="lede">
          Position, opacity, scale, rotation: each one springs from a start keyframe to an end
          keyframe. Drag a diamond. The field is not a picture of the timeline, it is the
          timeline, rendered live.
        </p>
        <p className="hint">Drag a keyframe, or focus one and use the arrow keys.</p>
      </div>
      <div
        className="lane lane-tracks"
        ref={laneRef}
        role="group"
        aria-label="Keyframe editor: four tracks with a start and an end keyframe each"
      >
        {TRACKS.map((track, i) => (
          <div className="lane-row" key={track.id} style={{ top: `${i * 25}%` }}>
            <span className="lane-label">{track.name}</span>
            <span className="lane-range" aria-hidden="true">
              {formatValue(track, track.max)}
              <br />
              {formatValue(track, track.min)}
            </span>
            {[0, 1].map((which) => (
              <KeyHandle
                key={which}
                track={track}
                which={which}
                doc={doc}
                setDoc={setDoc}
                laneRef={laneRef}
                rowIndex={i}
                reduced={reduced}
              />
            ))}
          </div>
        ))}
      </div>
    </>
  );
}
