export default function Hero({ coarse }) {
  return (
    <div className="copy copy-hero">
      <h1 className="display">
        Design animation visually.
        <br />
        Ship production code.
      </h1>
      <p className="lede">
        Meridian is a timeline editor for interface motion. This page is one of its documents:
        twenty-four seconds, five acts, one field of light. The scroll bar is the playhead.
      </p>
      <p className="hint" aria-hidden="true">
        {coarse ? "Scroll to scrub the timeline." : "Scroll to scrub the timeline, or press Space to play."}
      </p>
    </div>
  );
}
