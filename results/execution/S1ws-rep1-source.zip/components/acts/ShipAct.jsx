"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useStore } from "@/lib/store";
import { toCSS, toJS } from "@/lib/document";

export default function ShipAct({ store, frames }) {
  const doc = useStore(store);
  const [tab, setTab] = useState("css");
  const [copied, setCopied] = useState("");
  const [runs, setRuns] = useState(0);
  const timer = useRef(null);
  const css = useMemo(() => toCSS(doc), [doc]);
  const js = useMemo(() => toJS(doc), [doc]);
  const code = tab === "css" ? css : js;

  useEffect(() => () => clearTimeout(timer.current), []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied("Copied");
    } catch {
      setCopied("Select the code and copy it");
    }
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setCopied(""), 2200);
  };

  return (
    <>
      <div className="copy copy-ship">
        <h2 className="headline">Export what you made.</h2>
        <p className="lede">
          The strip above is your document, frame by frame. The code beside it is generated from
          the same keyframes and the same spring: plain CSS or plain JavaScript, nothing to
          install, nothing to depend on.
        </p>
      </div>
      <div className="film-labels" aria-hidden="true" style={{ "--n": frames }}>
        {Array.from({ length: frames }, (_, i) => (
          <span key={i}>{String(i + 1).padStart(2, "0")}</span>
        ))}
      </div>
      <section className="export" aria-label="Exported code">
        <div className="export-bar">
          <div role="tablist" aria-label="Export format" className="tabs">
            {[
              ["css", "CSS"],
              ["js", "JavaScript"],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                id={`tab-${id}`}
                aria-selected={tab === id}
                aria-controls="export-code"
                tabIndex={tab === id ? 0 : -1}
                className={"tab" + (tab === id ? " is-on" : "")}
                onClick={() => setTab(id)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                    e.preventDefault();
                    setTab(tab === "css" ? "js" : "css");
                    requestAnimationFrame(() => document.getElementById(`tab-${tab === "css" ? "js" : "css"}`)?.focus());
                  }
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="export-actions">
            <button type="button" className="ghost" onClick={() => setRuns((r) => r + 1)}>
              Play preview
            </button>
            <button type="button" className="ghost" onClick={copy}>
              Copy code
            </button>
            <span className="sr-only" role="status">
              {copied}
            </span>
            {copied && (
              <span className="copied" aria-hidden="true">
                {copied}
              </span>
            )}
          </div>
        </div>
        <div className="export-body">
          <pre id="export-code" role="tabpanel" aria-labelledby={`tab-${tab}`} tabIndex={0}>
            <code>{code}</code>
          </pre>
          <div className="preview" aria-hidden="true">
            <style>{css}</style>
            {runs > 0 && (
              <div key={runs} className={`preview-card ${doc.name}`}>
                <span />
                <span />
              </div>
            )}
            {runs === 0 && <div className="preview-card is-idle" />}
          </div>
        </div>
      </section>
    </>
  );
}
