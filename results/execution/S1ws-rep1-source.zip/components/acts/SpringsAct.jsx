"use client";
import { useStore } from "@/lib/store";
import { springParams, describeDamping, settleTime } from "@/lib/spring";

export default function SpringsAct({ store, ringRef, coarse }) {
  const doc = useStore(store);
  const { zeta, omega } = springParams(doc.spring);
  const setSpring = (patch) => store.set((d) => ({ ...d, spring: { ...d.spring, ...patch } }));
  return (
    <>
      <div className="copy">
        <h2 className="headline">Springs you can feel.</h2>
        <p className="lede">
          Meridian animates with physics, not bezier guesses. Two numbers describe the whole
          motion, and the same two numbers drive every curve in this document, including the
          keyframes you just moved.
        </p>
        <div className="controls">
          <label className="control">
            <span className="control-name">Stiffness</span>
            <input
              type="range"
              min="30"
              max="400"
              step="1"
              value={doc.spring.stiffness}
              onChange={(e) => setSpring({ stiffness: Number(e.target.value) })}
            />
            <output className="control-value">{doc.spring.stiffness}</output>
          </label>
          <label className="control">
            <span className="control-name">Damping</span>
            <input
              type="range"
              min="2"
              max="44"
              step="0.5"
              value={doc.spring.damping}
              onChange={(e) => setSpring({ damping: Number(e.target.value) })}
            />
            <output className="control-value">{doc.spring.damping}</output>
          </label>
          <p className="control-note" role="status">
            Damping ratio {zeta.toFixed(2)}, {describeDamping(zeta)}. Settles in about{" "}
            {settleTime(zeta, omega).toFixed(2)} s.
          </p>
        </div>
        <p className="hint" aria-hidden="true">
          {coarse ? "Tap the field to launch it." : "Flick the pointer across the field to add velocity."}
        </p>
      </div>
      <div className="ring" ref={ringRef} aria-hidden="true" />
    </>
  );
}
