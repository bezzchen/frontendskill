"use client";

// Meridian ships reduced-motion variants of every animation, so the page offers its own.
export default function MotionToggle({ pref, reduced, onChange, system }) {
  const value = pref === "auto" ? (system ? "reduced" : "full") : pref;
  return (
    <fieldset className="motion" aria-describedby="motion-help">
      <legend className="motion-legend">Motion</legend>
      <div className="motion-options">
        {[
          ["full", "Full"],
          ["reduced", "Reduced"],
        ].map(([v, label]) => (
          <label key={v} className={"motion-option" + (value === v ? " is-on" : "")}>
            <input
              type="radio"
              name="motion"
              value={v}
              checked={value === v}
              onChange={() => onChange(v)}
            />
            <span>{label}</span>
          </label>
        ))}
      </div>
      <span id="motion-help" className="sr-only">
        {reduced
          ? "Reduced motion: the field still follows your scroll, without ambient or pointer motion."
          : "Full motion: ambient rotation, pointer physics and spring transitions."}
      </span>
    </fieldset>
  );
}
