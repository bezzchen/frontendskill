import { GLSL_SPRING } from "@/lib/spring";

// One point cloud, five layouts. Every vertex evaluates the layout it is leaving and the one
// it is entering and springs between them with its own delay. Nothing here is a texture or a
// baked animation: keyframes, spring constants, pointer and playhead are uniforms, so a drag
// in the DOM is a new shape on the next frame.
export const VERT = /* glsl */ `
precision highp float;

attribute float aId;
attribute vec3 aRand;

uniform float uCount;
uniform float uAspect;
uniform float uDpr;
uniform float uTime;
uniform float uReduced;
uniform float uIntro;
uniform int   uFrom;
uniform int   uTo;
uniform float uMorph;
uniform float uLocalA;
uniform float uLocalB;
uniform vec4  uLaneA;
uniform vec4  uLaneB;
uniform vec3  uGlobe;
uniform float uLineX;
uniform vec2  uPointer;
uniform vec2  uPointerVel;
uniform float uPointerOn;
uniform vec4  uKeyT0;
uniform vec4  uKeyT1;
uniform vec4  uKeyV0;
uniform vec4  uKeyV1;
uniform vec2  uSpring;
uniform float uDuration;
uniform float uImpulse;
uniform float uFrames;
uniform float uPointSize;

varying float vAlpha;
varying float vBrass;

const float PI = 3.141592653589793;
const float TAU = 6.283185307179586;

${GLSL_SPRING}

float gBrass = 0.0;

float pick(vec4 v, int i) {
  return i == 0 ? v.x : (i == 1 ? v.y : (i == 2 ? v.z : v.w));
}

// Track k of the document at normalized time x, as a normalized value 0..1.
float trackValue(int k, float x) {
  float t0 = pick(uKeyT0, k);
  float t1 = pick(uKeyT1, k);
  float v0 = pick(uKeyV0, k);
  float v1 = pick(uKeyV1, k);
  if (x <= t0) return v0;
  float seg = max(t1 - t0, 0.02);
  float tau = (x - t0) / seg * uDuration;
  return v1 + (v0 - v1) * springResponse(tau, uSpring.x, uSpring.y, 1.0, 0.0);
}

vec2 rot2(vec2 p, float a) {
  float c = cos(a), s = sin(a);
  return vec2(c * p.x - s * p.y, s * p.x + c * p.y);
}

// Act I: a globe drawn only with meridians. Scroll turns it; the pointer tilts it.
vec4 layoutGlobe(float u, vec3 r, float local) {
  const float M = 72.0;
  float m = floor(u * M);
  float s = fract(u * M);
  float lon = (m / M) * PI;
  float lat = s * TAU + r.x * (TAU * M / uCount);
  float live = 1.0 - uReduced;
  float yaw = live * uTime * 0.06 + local * 2.4 + uPointer.x * 0.12 * uPointerOn * live;
  float pitch = 0.42 - uPointer.y * 0.08 * uPointerOn * live;
  vec3 p = vec3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon));
  p = vec3(cos(yaw) * p.x + sin(yaw) * p.z, p.y, -sin(yaw) * p.x + cos(yaw) * p.z);
  p = vec3(p.x, cos(pitch) * p.y - sin(pitch) * p.z, sin(pitch) * p.y + cos(pitch) * p.z);
  float camZ = 3.2;
  float persp = camZ / (camZ - p.z);
  vec2 xy = uGlobe.xy + p.xy * uGlobe.z * persp;
  float depth = (p.z + 1.0) * 0.5;
  float w = mix(0.14, 1.0, depth * depth);
  // Every meridian meets at the poles; thin them there so the caps do not burn out.
  w *= 1.0 - 0.8 * smoothstep(0.72, 1.0, abs(sin(lat)));
  // The meridian facing the viewer is the prime one: brass.
  float facing = smoothstep(0.985, 1.0, p.z);
  gBrass = facing;
  return vec4(xy, mix(0.7, 1.3, depth), w);
}

// Act II: four property tracks, each a spring between two keyframes the visitor can drag.
vec4 layoutTracks(float u, vec3 r, float local, vec4 lane) {
  const float T = 4.0;
  float k = floor(u * T);
  float x = fract(u * T);
  x = clamp(x + (r.x - 0.5) * (T / uCount) * 2.0, 0.0, 1.0);
  int ki = int(k + 0.5);
  float v = trackValue(ki, x);
  float dv = trackValue(ki, min(x + 0.006, 1.0)) - v;
  float laneH = (lane.w - lane.y) / T;
  float yTop = lane.w - laneH * k;
  float pad = laneH * 0.18;
  float y = (yTop - laneH) + pad + v * (laneH - 2.0 * pad);
  float spread = 0.0035 + abs(dv) * 0.9;
  y += (r.y + r.z - 1.0) * spread;
  float X = mix(lane.x, lane.z, x);
  float head = local * 1.12;
  float reveal = 1.0 - smoothstep(head - 0.05, head + 0.01, x);
  float w = mix(0.22, 1.0, reveal);
  float t0 = pick(uKeyT0, ki), t1 = pick(uKeyT1, ki);
  gBrass = max(smoothstep(0.006, 0.0, abs(x - t0)), smoothstep(0.006, 0.0, abs(x - t1)));
  gBrass = max(gBrass, smoothstep(0.03, 0.0, abs(x - head)) * step(head, 1.0));
  return vec4(X, y, 1.0, w);
}

// Act III: a bundle of spring responses with different launch velocities. Sliders change the
// spring; a flick of the pointer adds velocity and fans the bundle open.
vec4 layoutSprings(float u, vec3 r, float local, vec4 lane) {
  const float C = 96.0;
  float c = floor(u * C);
  float s = fract(u * C);
  s = clamp(s + (r.x - 0.5) * (C / uCount) * 2.0, 0.0, 1.0);
  float f = (c / (C - 1.0)) * 2.0 - 1.0;
  f = sign(f) * pow(abs(f), 1.6);
  float v0 = f * (1.1 + 2.6 * uImpulse) * uSpring.y;
  float tau = s * uDuration * 1.5;
  float y = springResponse(tau, uSpring.x, uSpring.y, 1.0, v0);
  float Y = mix(lane.y, lane.w, 0.5 + y * 0.3);
  float X = mix(lane.x, lane.z, s);
  float head = local * 1.1;
  float reveal = 1.0 - smoothstep(head - 0.06, head + 0.01, s);
  float w = mix(0.18, 1.0, reveal) * (0.4 + 0.6 * (1.0 - abs(f)));
  gBrass = smoothstep(0.08, 0.0, abs(f)) * 0.9;
  return vec4(X, Y, 1.0, w);
}

// Act IV: the same document as a filmstrip. Each frame draws the element at that instant.
vec4 layoutFilm(float u, vec3 r, float local, vec4 lane) {
  float F = uFrames;
  float fi = floor(u * F);
  float p = fract(u * F);
  float tau = fi / max(F - 1.0, 1.0);
  float cellW = (lane.z - lane.x) / F;
  float cellH = (lane.w - lane.y);
  float cx = lane.x + cellW * (fi + 0.5);
  float cy = (lane.y + lane.w) * 0.5;
  float sz = min(cellW, cellH) * 0.5;
  float shown = smoothstep(fi / F - 0.04, fi / F + 0.01, local * 1.15);
  if (r.z > 0.84) {
    // The cell itself: a thin rectangle, like a frame on a strip.
    float per = fract(p * 7.0 + r.y);
    vec2 hs = vec2(cellW * 0.47, cellH * 0.47);
    float L = 2.0 * (hs.x + hs.y);
    float d = per * L;
    vec2 q;
    if (d < hs.x * 2.0) q = vec2(-hs.x + d, hs.y);
    else if (d < hs.x * 2.0 + hs.y * 2.0) q = vec2(hs.x, hs.y - (d - hs.x * 2.0));
    else if (d < hs.x * 4.0 + hs.y * 2.0) q = vec2(hs.x - (d - hs.x * 2.0 - hs.y * 2.0), -hs.y);
    else q = vec2(-hs.x, -hs.y + (d - hs.x * 4.0 - hs.y * 2.0));
    gBrass = 0.0;
    return vec4(cx + q.x, cy + q.y, 0.8, mix(0.08, 0.2, shown));
  }
  float a = p * TAU;
  vec2 sq = vec2(sign(cos(a)) * pow(abs(cos(a)), 0.4), sign(sin(a)) * pow(abs(sin(a)), 0.4));
  float interior = step(r.y, 0.3);
  float fill = mix(1.0, sqrt(r.x), interior);
  vec2 q = sq * vec2(0.62, 0.42) * fill;
  float ty = (trackValue(0, tau) - 0.5) * 2.0;
  float op = trackValue(1, tau);
  float sc = mix(0.8, 1.1, trackValue(2, tau));
  float rot = (trackValue(3, tau) - 0.5) * 2.0 * 0.14;
  q = rot2(q * sc, rot);
  q.y -= ty * 0.3;
  vec2 xy = vec2(cx, cy) + q * sz;
  float w = mix(0.2, 1.0, shown) * mix(0.12, 1.0, clamp(op, 0.0, 1.0)) * mix(1.0, 0.4, interior);
  gBrass = smoothstep(0.03, 0.0, abs(tau - clamp(local * 1.15, 0.0, 1.0))) * 0.9;
  return vec4(xy, 1.0, w);
}

// Act V and the opening: everything is one line again, the meridian, the playhead.
vec4 layoutLine(float u, vec3 r, float local) {
  float y = mix(-1.05, 1.05, u);
  float g = (r.y + r.z - 1.0);
  float spread = mix(0.06, 0.006, smoothstep(0.0, 0.6, local));
  float breathe = 1.0 + 0.5 * (1.0 - uReduced) * sin(uTime * 0.7 + y * 3.0 + r.x);
  float x = uLineX + g * spread * breathe;
  // Thousands of points share one column: keep the sum brass, not white.
  float w = (0.3 + 0.7 * (1.0 - abs(g))) * 0.07;
  gBrass = 1.0;
  return vec4(x, y, 1.0, w);
}

vec4 layoutFor(int act, float u, vec3 r, float local, vec4 lane) {
  if (act == 0) return layoutGlobe(u, r, local);
  if (act == 1) return layoutTracks(u, r, local, lane);
  if (act == 2) return layoutSprings(u, r, local, lane);
  if (act == 3) return layoutFilm(u, r, local, lane);
  return layoutLine(u, r, local);
}

void main() {
  float u = (aId + 0.5) / uCount;
  vec3 r = aRand;

  vec4 A = layoutFor(uFrom, u, r, uLocalA, uLaneA);
  float bA = gBrass;
  vec4 B = A;
  float bB = bA;
  float e = 0.0;
  if (uTo != uFrom) {
    B = layoutFor(uTo, u, r, uLocalB, uLaneB);
    bB = gBrass;
    float stag = r.z * 0.4;
    e = clamp((uMorph - stag) / 0.6, 0.0, 1.0);
    e = uReduced > 0.5
      ? smoothstep(0.0, 1.0, e)
      : 1.0 - springResponse(e * 1.15, 0.62, 12.0, 1.0, 0.0) * (1.0 - e * e * e);
  }
  vec4 P = mix(A, B, e);
  float brass = mix(bA, bB, e);

  // Points take an arc between layouts instead of a straight line.
  vec2 dir = B.xy - A.xy;
  P.xy += vec2(-dir.y, dir.x) * (r.x - 0.5) * 0.35 * sin(PI * e) * (1.0 - uReduced);

  // Opening: the field springs out of the meridian line.
  if (uIntro < 1.0) {
    vec4 L = layoutLine(u, r, 1.0);
    float ie = clamp(uIntro * 1.4 - r.y * 0.4, 0.0, 1.0);
    ie = 1.0 - springResponse(ie * 1.2, 0.55, 11.0, 1.0, 0.0) * (1.0 - ie * ie * ie);
    P.xy = mix(L.xy, P.xy, ie);
    P.w = mix(L.w, P.w, ie);
    brass = mix(1.0, brass, ie);
  }

  // The pointer is a lens: points nearby get pushed, and dragged by its velocity.
  vec2 d = P.xy - uPointer;
  float dist = length(d);
  float infl = uPointerOn * (1.0 - uReduced) * smoothstep(0.42, 0.0, dist);
  P.xy += (d / max(dist, 1e-3)) * infl * 0.1;
  P.xy += uPointerVel * infl * 0.35;
  brass = max(brass, infl * 0.85);

  float tw = 1.0 - 0.25 * (1.0 - uReduced) * (0.5 + 0.5 * sin(uTime * (1.5 + r.x * 2.0) + r.y * TAU));
  vAlpha = P.w * tw * (1.0 - 0.35 * sin(PI * e) * (1.0 - uReduced));
  vBrass = brass;

  gl_Position = vec4(P.x / uAspect, P.y, 0.0, 1.0);
  float size = uPointSize * uDpr * (0.75 + 0.5 * r.x) * P.z;
  gl_PointSize = clamp(size, 1.0, 7.0 * uDpr);
}
`;

export const FRAG = /* glsl */ `
precision mediump float;

uniform vec3 uIvory;
uniform vec3 uBrass;
uniform float uAlpha;

varying float vAlpha;
varying float vBrass;

void main() {
  vec2 c = gl_PointCoord - 0.5;
  float d = dot(c, c) * 4.0;
  float a = 1.0 - smoothstep(0.1, 1.0, d);
  a *= vAlpha * uAlpha;
  vec3 col = mix(uIvory, uBrass, vBrass);
  gl_FragColor = vec4(col * a, a);
}
`;
