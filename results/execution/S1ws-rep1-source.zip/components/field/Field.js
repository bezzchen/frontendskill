// The field: one WebGL point cloud driven entirely by uniforms. OGL is used as a thin
// substrate (context, program, VAO, uniform upload); every visual decision is in shaders.js.
import { Renderer } from "ogl/src/core/Renderer.js";
import { Program } from "ogl/src/core/Program.js";
import { Geometry } from "ogl/src/core/Geometry.js";
import { Mesh } from "ogl/src/core/Mesh.js";
import { VERT, FRAG } from "./shaders";

// Quality tiers, from a fast laptop down to an old phone. Only ever stepped down at runtime.
export const TIERS = [
  { dpr: 2, count: 65536, label: "full" },
  { dpr: 1.5, count: 65536, label: "high" },
  { dpr: 1.5, count: 40960, label: "medium" },
  { dpr: 1.5, count: 24576, label: "mobile" },
  { dpr: 1, count: 16384, label: "light" },
];

export function probeWebGL() {
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return false;
    const lose = gl.getExtension("WEBGL_lose_context");
    if (lose) lose.loseContext();
    return true;
  } catch {
    return false;
  }
}

export function pickTier({ width, coarse, memory, cores, reduced }) {
  if (width <= 767 || coarse) return 3;
  if ((memory && memory <= 4) || (cores && cores <= 4)) return 1;
  return reduced ? 1 : 0;
}

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255);

export class Field {
  constructor(canvas, { tier = 0, maxDpr = 2, palette }) {
    this.canvas = canvas;
    this.tier = tier;
    this.maxDpr = maxDpr;
    this.palette = palette;
    this.frames = 0;
    this.w = 1;
    this.h = 1;
    this.lost = false;
    this.onContextLost = null;

    this.renderer = new Renderer({
      canvas,
      dpr: Math.min(TIERS[tier].dpr, maxDpr),
      alpha: false,
      depth: false,
      stencil: false,
      antialias: false,
      premultipliedAlpha: false,
      powerPreference: "high-performance",
      autoClear: true,
      webgl: 2,
    });
    const gl = (this.gl = this.renderer.gl);
    const bg = hex(palette.bg);
    gl.clearColor(bg[0], bg[1], bg[2], 1);

    const f4 = () => new Float32Array(4);
    this.uniforms = {
      uCount: { value: 1 },
      uAspect: { value: 1 },
      uDpr: { value: this.renderer.dpr },
      uTime: { value: 0 },
      uReduced: { value: 0 },
      uIntro: { value: 0 },
      uFrom: { value: 0 },
      uTo: { value: 0 },
      uMorph: { value: 0 },
      uLocalA: { value: 0 },
      uLocalB: { value: 0 },
      uLaneA: { value: f4() },
      uLaneB: { value: f4() },
      uGlobe: { value: new Float32Array([0, 0, 0.7]) },
      uLineX: { value: 0 },
      uPointer: { value: new Float32Array([9, 9]) },
      uPointerVel: { value: new Float32Array(2) },
      uPointerOn: { value: 0 },
      uKeyT0: { value: f4() },
      uKeyT1: { value: f4() },
      uKeyV0: { value: f4() },
      uKeyV1: { value: f4() },
      uSpring: { value: new Float32Array([0.6, 13]) },
      uDuration: { value: 1.2 },
      uImpulse: { value: 0 },
      uFrames: { value: 24 },
      uPointSize: { value: 1.5 },
      uIvory: { value: new Float32Array(hex(palette.ivory)) },
      uBrass: { value: new Float32Array(hex(palette.brass)) },
      uAlpha: { value: 0.34 },
    };

    this.buildProgram();
    this.setCount(TIERS[tier].count);

    this._onLost = (e) => {
      e.preventDefault();
      this.lost = true;
      this.onContextLost?.();
    };
    this._onRestored = () => {
      this.lost = false;
      this.renderer.state.uniformLocations = new Map();
      this.renderer.state.currentProgram = null;
      this.renderer.currentGeometry = null;
      this.buildProgram();
      this.setCount(TIERS[this.tier].count);
      const bg2 = hex(this.palette.bg);
      this.gl.clearColor(bg2[0], bg2[1], bg2[2], 1);
      this.onContextRestored?.();
    };
    canvas.addEventListener("webglcontextlost", this._onLost);
    canvas.addEventListener("webglcontextrestored", this._onRestored);
  }

  buildProgram() {
    const gl = this.gl;
    this.program = new Program(gl, {
      vertex: VERT,
      fragment: FRAG,
      uniforms: this.uniforms,
      transparent: true,
      depthTest: false,
      depthWrite: false,
      cullFace: false,
    });
    this.program.setBlendFunc(gl.ONE, gl.ONE);
  }

  setCount(n) {
    const gl = this.gl;
    if (this.geometry) this.geometry.remove?.();
    const rand = mulberry32(1903);
    const ids = new Float32Array(n);
    const rnd = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      ids[i] = i;
      rnd[i * 3] = rand();
      rnd[i * 3 + 1] = rand();
      rnd[i * 3 + 2] = rand();
    }
    this.geometry = new Geometry(gl, {
      aId: { size: 1, data: ids },
      aRand: { size: 3, data: rnd },
    });
    this.mesh = new Mesh(gl, { geometry: this.geometry, program: this.program, mode: gl.POINTS, frustumCulled: false });
    this.count = n;
    this.uniforms.uCount.value = n;
    this.uniforms.uAlpha.value = Math.min(0.8, Math.max(0.3, 0.34 * Math.sqrt(65536 / n)));
  }

  setSize(w, h) {
    this.w = Math.max(1, Math.round(w));
    this.h = Math.max(1, Math.round(h));
    this.renderer.setSize(this.w, this.h);
    this.uniforms.uAspect.value = this.w / this.h;
  }

  applyTier(tier) {
    this.tier = Math.min(TIERS.length - 1, Math.max(0, tier));
    const t = TIERS[this.tier];
    const dpr = Math.min(t.dpr, this.maxDpr);
    if (dpr !== this.renderer.dpr) {
      this.renderer.dpr = dpr;
      this.uniforms.uDpr.value = dpr;
      this.renderer.setSize(this.w, this.h);
    }
    if (t.count !== this.count) this.setCount(t.count);
  }

  degrade() {
    if (this.tier >= TIERS.length - 1) return false;
    this.applyTier(this.tier + 1);
    return true;
  }

  get info() {
    return { tier: this.tier, label: TIERS[this.tier].label, count: this.count, dpr: this.renderer.dpr };
  }

  render() {
    if (this.lost) return;
    this.renderer.render({ scene: this.mesh, sort: false, frustumCull: false });
    this.frames++;
  }

  dispose() {
    this.canvas.removeEventListener("webglcontextlost", this._onLost);
    this.canvas.removeEventListener("webglcontextrestored", this._onRestored);
    try {
      this.geometry?.remove?.();
      this.program?.remove?.();
      const ext = this.gl.getExtension("WEBGL_lose_context");
      ext?.loseContext();
    } catch {}
  }
}
