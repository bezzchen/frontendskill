"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { createStore } from "@/lib/store";
import { DEFAULT_DOC, TRACKS, norm, timecode, DOC_SECONDS, clamp01 } from "@/lib/document";
import {
  ACTS,
  BOUNDS,
  SCROLL_VH,
  GEOMETRY,
  resolve,
  laneForAct,
  rectToStage,
  geoFor,
  geometryCSS,
} from "@/lib/acts";
import { springParams, SpringValue } from "@/lib/spring";
import { useMotionPreference } from "@/lib/motion";
import { Field, probeWebGL, pickTier } from "@/components/field/Field";
import Ruler from "@/components/Ruler";
import MotionToggle from "@/components/MotionToggle";
import StaticFallback from "@/components/StaticFallback";
import Hero from "@/components/acts/Hero";
import TimelineAct from "@/components/acts/TimelineAct";
import SpringsAct from "@/components/acts/SpringsAct";
import ShipAct from "@/components/acts/ShipAct";
import AccessAct from "@/components/acts/AccessAct";

const PALETTE = { bg: "#0b1020", ivory: "#f1ece1", brass: "#e6b455" };
const GEO_CSS = geometryCSS();
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

function makeRuntime() {
  return {
    field: null,
    running: false,
    rafId: 0,
    visible: true,
    intersecting: true,
    lost: false,
    reduced: false,
    wrapTop: 0,
    wrapH: 1,
    viewW: 1,
    viewH: 1,
    aspect: 1,
    scrollRange: 1,
    vhFrac: 0.11,
    geo: GEOMETRY.desktop,
    scrollT: 0,
    t: 0,
    playhead: new SpringValue(0, { stiffness: 140, damping: 24 }),
    lastTs: 0,
    time: 0,
    intro: 0,
    frameNo: 0,
    pointer: { x: 9, y: 9, vx: 0, vy: 0, lastMove: -1e9, lastTime: 0, px: 0, py: 0 },
    pointerOn: new SpringValue(0, { stiffness: 60, damping: 15 }),
    impulse: 0,
    keySprings: Array.from({ length: 16 }, () => new SpringValue(0, { stiffness: 260, damping: 26 })),
    lastDoc: null,
    playing: false,
    scrubbing: false,
    ema: 16,
    slow: 0,
    lastInput: 0,
    lastTc: "",
    currentIndex: 0,
    res: null,
    ring: [new SpringValue(0), new SpringValue(0)],
  };
}

export default function Stage() {
  const storeRef = useRef(null);
  if (!storeRef.current) storeRef.current = createStore(DEFAULT_DOC);
  const store = storeRef.current;

  const motion = useMotionPreference();
  const reduced = motion.reduced;

  const [webgl, setWebgl] = useState(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [coarse, setCoarse] = useState(false);
  const [info, setInfo] = useState(null);
  const [frames, setFrames] = useState(GEOMETRY.desktop.frames);

  const wrapRef = useRef(null);
  const viewRef = useRef(null);
  const canvasRef = useRef(null);
  const timecodeRef = useRef(null);
  const playheadRef = useRef(null);
  const inputRef = useRef(null);
  const ringRef = useRef(null);
  const rtRef = useRef(null);
  if (!rtRef.current) rtRef.current = makeRuntime();

  useEffect(() => {
    const rt = rtRef.current;
    const was = rt.reduced;
    rt.reduced = reduced;
    if (reduced) {
      rt.playhead.snap(rt.scrollT);
      rt.intro = 1;
      if (rt.playing) setPlayingState(false);
    } else if (was && !reduced) {
      rt.playhead.snap(rt.scrollT);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced]);

  const readScroll = useCallback(() => {
    const rt = rtRef.current;
    rt.scrollT = clamp01((window.scrollY - rt.wrapTop) / rt.scrollRange);
  }, []);

  const scrollToT = useCallback((t01, smooth) => {
    const rt = rtRef.current;
    window.scrollTo({ top: rt.wrapTop + clamp01(t01) * rt.scrollRange, behavior: smooth ? "smooth" : "auto" });
  }, []);

  const setPlayingState = useCallback(
    (v) => {
      const rt = rtRef.current;
      rt.playing = v;
      setPlaying(v);
      if (v && rt.scrollT >= 0.999) scrollToT(0, false);
    },
    [scrollToT]
  );

  const jump = useCallback(
    (dir) => {
      const rt = rtRef.current;
      const next = clamp(rt.currentIndex + dir, 0, ACTS.length - 1);
      scrollToT(BOUNDS[next].start + 0.0015, !rt.reduced);
    },
    [scrollToT]
  );

  const togglePlay = useCallback(() => {
    const rt = rtRef.current;
    rt.lastInput = performance.now();
    if (rt.reduced) jump(1);
    else setPlayingState(!rt.playing);
  }, [jump, setPlayingState]);

  const onScrub = useCallback(
    (v) => {
      const rt = rtRef.current;
      rt.lastInput = performance.now();
      if (rt.playing) setPlayingState(false);
      scrollToT(v, false);
    },
    [scrollToT, setPlayingState]
  );

  // Mount the field once the motion preference is known, so a reduced-motion visitor never
  // sees the opening sequence.
  useEffect(() => {
    if (!motion.ready) return;
    const rt = rtRef.current;
    const view = viewRef.current;
    const canvas = canvasRef.current;
    if (!view || !canvas) return;

    const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
    setCoarse(coarsePointer);

    if (!probeWebGL()) {
      setWebgl(false);
      return;
    }
    let field;
    try {
      const tier = pickTier({
        width: window.innerWidth,
        coarse: coarsePointer,
        memory: navigator.deviceMemory,
        cores: navigator.hardwareConcurrency,
        reduced: rt.reduced,
      });
      field = new Field(canvas, { tier, maxDpr: Math.min(window.devicePixelRatio || 1, 2), palette: PALETTE });
    } catch (err) {
      console.warn("Meridian: WebGL field unavailable, using the static variant.", err);
      setWebgl(false);
      return;
    }
    rt.field = field;
    rt.intro = rt.reduced ? 1 : 0;
    setWebgl(true);
    setInfo(field.info);

    const measure = () => {
      const wrap = wrapRef.current;
      if (!wrap) return;
      const r = wrap.getBoundingClientRect();
      rt.wrapTop = r.top + window.scrollY;
      rt.wrapH = wrap.offsetHeight;
      rt.viewW = Math.max(1, view.clientWidth);
      rt.viewH = Math.max(1, view.clientHeight);
      rt.aspect = rt.viewW / rt.viewH;
      rt.scrollRange = Math.max(1, rt.wrapH - rt.viewH);
      rt.vhFrac = rt.viewH / rt.scrollRange;
      rt.geo = geoFor(window.innerWidth);
      setFrames(rt.geo.frames);
      field.setSize(rt.viewW, rt.viewH);
      const U = field.uniforms;
      U.uGlobe.value[0] = (rt.geo.globe.cx * 2 - 1) * rt.aspect;
      U.uGlobe.value[1] = -(rt.geo.globe.cy * 2 - 1);
      U.uGlobe.value[2] = rt.geo.globe.r * 2;
      U.uLineX.value = (rt.geo.lineX * 2 - 1) * rt.aspect;
      U.uFrames.value = rt.geo.frames;
      U.uPointSize.value = 1.5 * Math.pow(65536 / field.count, 0.25);
      readScroll();
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(view);
    window.addEventListener("resize", measure);

    const updateRunning = () => {
      const should = rt.visible && rt.intersecting && !rt.lost;
      if (should && !rt.running) {
        rt.running = true;
        rt.lastTs = 0;
        rt.rafId = requestAnimationFrame(tick);
      } else if (!should && rt.running) {
        rt.running = false;
        cancelAnimationFrame(rt.rafId);
      }
    };

    field.onContextLost = () => {
      rt.lost = true;
      updateRunning();
    };
    field.onContextRestored = () => {
      rt.lost = false;
      measure();
      updateRunning();
    };

    const onVisibility = () => {
      rt.visible = document.visibilityState === "visible";
      updateRunning();
    };
    document.addEventListener("visibilitychange", onVisibility);
    // At the end of the page the sticky view sits exactly one viewport above the fold, and an
    // edge-adjacent, zero-area intersection still counts as intersecting. Inset the root by a
    // pixel so "fully scrolled away" is unambiguous.
    const io = new IntersectionObserver(
      (entries) => {
        rt.intersecting = entries[0].isIntersecting;
        updateRunning();
      },
      { threshold: 0, rootMargin: "-1px 0px -1px 0px" }
    );
    io.observe(canvas);

    const onScroll = () => {
      readScroll();
      rt.lastInput = performance.now();
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    const stopOnUserInput = () => {
      if (rt.playing) setPlayingState(false);
    };
    window.addEventListener("wheel", stopOnUserInput, { passive: true });
    window.addEventListener("touchstart", stopOnUserInput, { passive: true });

    const toStage = (cx, cy) => [((cx / rt.viewW) * 2 - 1) * rt.aspect, -((cy / rt.viewH) * 2 - 1)];
    const onPointerMove = (e) => {
      const p = rt.pointer;
      const now = performance.now();
      const [x, y] = toStage(e.clientX, e.clientY);
      if (p.lastTime) {
        const dt = Math.max(1e-3, (now - p.lastTime) / 1000);
        const vx = (x - p.x) / dt;
        const vy = (y - p.y) / dt;
        p.vx = p.vx * 0.5 + vx * 0.5;
        p.vy = p.vy * 0.5 + vy * 0.5;
        const speed = Math.hypot(vx, vy);
        rt.impulse = Math.min(1, rt.impulse + Math.max(0, speed - 2.5) * Math.min(dt, 0.05) * 0.25);
      }
      p.x = x;
      p.y = y;
      p.px = e.clientX;
      p.py = e.clientY;
      p.lastTime = now;
      p.lastMove = now;
      rt.lastInput = now;
    };
    const onPointerDown = (e) => {
      const p = rt.pointer;
      const [x, y] = toStage(e.clientX, e.clientY);
      p.x = x;
      p.y = y;
      p.px = e.clientX;
      p.py = e.clientY;
      p.lastMove = performance.now();
      rt.lastInput = p.lastMove;
      if (e.pointerType === "touch") rt.impulse = Math.min(1, rt.impulse + 0.55);
    };
    const onPointerGone = () => {
      rt.pointer.lastMove = -1e9;
      rt.pointer.lastTime = 0;
    };
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("pointerdown", onPointerDown, { passive: true });
    document.documentElement.addEventListener("pointerleave", onPointerGone);
    window.addEventListener("blur", onPointerGone);

    const onKey = (e) => {
      rt.lastInput = performance.now();
      const el = e.target;
      const onBody = el === document.body || el === document.documentElement || el === document.getElementById("main");
      const isSpace = e.code === "Space" || e.key === " " || e.key === "Spacebar";
      if (isSpace && onBody && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        togglePlay();
        return;
      }
      if (rt.playing && (e.key.startsWith("Arrow") || e.key.startsWith("Page") || e.key === "Home" || e.key === "End")) {
        setPlayingState(false);
      }
    };
    window.addEventListener("keydown", onKey);

    const input = inputRef.current;
    const scrubOn = () => (rt.scrubbing = true);
    const scrubOff = () => (rt.scrubbing = false);
    let scrubTimer = 0;
    const scrubKey = () => {
      rt.scrubbing = true;
      clearTimeout(scrubTimer);
      scrubTimer = setTimeout(scrubOff, 500);
    };
    input?.addEventListener("pointerdown", scrubOn);
    input?.addEventListener("pointerup", scrubOff);
    input?.addEventListener("pointercancel", scrubOff);
    input?.addEventListener("keydown", scrubKey);

    // Keyframe uniforms follow the document through small springs, so a drag settles the
    // field instead of teleporting it. Reduced motion snaps.
    const retarget = (doc, snap) => {
      TRACKS.forEach((track, k) => {
        const [k0, k1] = doc.keys[track.id];
        const vals = [k0.t, k1.t, norm(track, k0.v), norm(track, k1.v)];
        vals.forEach((v, j) => {
          const s = rt.keySprings[k * 4 + j];
          s.target = v;
          if (snap) s.snap(v);
        });
      });
    };
    retarget(store.get(), true);
    rt.lastDoc = store.get();

    const laneA = new Float32Array(4);
    const laneB = new Float32Array(4);

    const tick = (ts) => {
      if (!rt.running) return;
      rt.rafId = requestAnimationFrame(tick);
      const dt = rt.lastTs ? Math.min(0.05, (ts - rt.lastTs) / 1000) : 1 / 60;
      rt.lastTs = ts;
      rt.time += dt;
      const isReduced = rt.reduced;

      if (rt.playing) {
        window.scrollBy(0, (rt.scrollRange / DOC_SECONDS) * dt);
        readScroll();
        if (rt.scrollT >= 0.9995) setPlayingState(false);
      }

      rt.playhead.target = rt.scrollT;
      let t;
      if (isReduced) {
        rt.playhead.snap(rt.scrollT);
        t = rt.scrollT;
      } else {
        t = clamp01(rt.playhead.step(dt));
        if (Math.abs(t - rt.scrollT) < 2e-5) rt.playhead.snap(rt.scrollT), (t = rt.scrollT);
      }
      rt.t = t;
      const res = resolve(t, rt.vhFrac);
      rt.res = res;

      rt.intro = isReduced ? 1 : Math.min(1, rt.intro + dt / 1.7);

      const p = rt.pointer;
      rt.pointerOn.target = ts - p.lastMove < 1600 ? 1 : 0;
      rt.pointerOn.step(dt);
      const decay = Math.exp(-dt * 7);
      p.vx *= decay;
      p.vy *= decay;
      rt.impulse *= Math.exp(-dt / 0.75);

      const doc = store.get();
      if (doc !== rt.lastDoc) {
        retarget(doc, isReduced);
        rt.lastDoc = doc;
      }
      for (const s of rt.keySprings) {
        if (isReduced) s.snap(s.target);
        else s.step(dt);
      }
      const { zeta, omega } = springParams(doc.spring);

      const U = field.uniforms;
      U.uTime.value = rt.time;
      U.uReduced.value = isReduced ? 1 : 0;
      U.uIntro.value = rt.intro;
      U.uFrom.value = res.from;
      U.uTo.value = res.to;
      U.uMorph.value = res.morph;
      U.uLocalA.value = res.localFrom;
      U.uLocalB.value = res.localTo;
      const la = rectToStage(laneForAct(rt.geo, res.from), rt.aspect);
      const lb = rectToStage(laneForAct(rt.geo, res.to), rt.aspect);
      laneA.set(la);
      laneB.set(lb);
      U.uLaneA.value = laneA;
      U.uLaneB.value = laneB;
      U.uPointer.value[0] = p.x;
      U.uPointer.value[1] = p.y;
      U.uPointerVel.value[0] = clamp(p.vx * 0.02, -0.3, 0.3);
      U.uPointerVel.value[1] = clamp(p.vy * 0.02, -0.3, 0.3);
      U.uPointerOn.value = clamp01(rt.pointerOn.x);
      for (let k = 0; k < 4; k++) {
        U.uKeyT0.value[k] = rt.keySprings[k * 4].x;
        U.uKeyT1.value[k] = rt.keySprings[k * 4 + 1].x;
        U.uKeyV0.value[k] = rt.keySprings[k * 4 + 2].x;
        U.uKeyV1.value[k] = rt.keySprings[k * 4 + 3].x;
      }
      U.uSpring.value[0] = zeta;
      U.uSpring.value[1] = omega;
      U.uDuration.value = doc.duration;
      U.uImpulse.value = rt.impulse;

      // Idle: nothing moving but ambient drift, so draw every other frame.
      const idle =
        ts - rt.lastInput > 3000 && !rt.playing && rt.pointerOn.x < 0.01 && Math.abs(rt.t - rt.scrollT) < 1e-4 && rt.intro >= 1;
      rt.frameNo++;
      if (!idle || rt.frameNo % 2 === 0) field.render();

      if (!idle) {
        rt.ema = rt.ema * 0.9 + dt * 1000 * 0.1;
        if (rt.ema > 24) {
          if (++rt.slow > 90) {
            if (field.degrade()) {
              U.uPointSize.value = 1.5 * Math.pow(65536 / field.count, 0.25);
              setInfo(field.info);
            }
            rt.slow = 0;
            rt.ema = 16;
          }
        } else if (rt.slow > 0) rt.slow--;
      }

      const tc = timecode(t);
      if (tc !== rt.lastTc) {
        rt.lastTc = tc;
        if (timecodeRef.current) timecodeRef.current.textContent = tc;
        inputRef.current?.setAttribute("aria-valuetext", `${tc}, ${ACTS[res.current].name}`);
      }
      if (!rt.scrubbing && inputRef.current) inputRef.current.value = String(t);
      if (playheadRef.current) playheadRef.current.style.left = `${t * 100}%`;
      if (res.current !== rt.currentIndex) {
        rt.currentIndex = res.current;
        setIndex(res.current);
      }

      const ring = ringRef.current;
      if (ring) {
        const inSprings = res.from === 2 || res.to === 2;
        const show = inSprings && !isReduced && rt.pointerOn.x > 0.02 && !coarsePointer;
        if (show) {
          rt.ring[0].set(doc.spring);
          rt.ring[1].set(doc.spring);
          rt.ring[0].target = p.px;
          rt.ring[1].target = p.py;
          const rx = rt.ring[0].step(dt);
          const ry = rt.ring[1].step(dt);
          ring.style.opacity = String(clamp01(rt.pointerOn.x));
          ring.style.transform = `translate(${rx.toFixed(1)}px, ${ry.toFixed(1)}px)`;
        } else if (ring.style.opacity !== "0") {
          ring.style.opacity = "0";
          rt.ring[0].snap(p.px);
          rt.ring[1].snap(p.py);
        }
      }
    };

    rt.visible = document.visibilityState === "visible";
    updateRunning();

    window.__meridianStats = {
      get frames() {
        return field.frames;
      },
      get running() {
        return rt.running;
      },
      get info() {
        return field.info;
      },
      get t() {
        return rt.t;
      },
      get ema() {
        return rt.ema;
      },
    };

    return () => {
      rt.running = false;
      cancelAnimationFrame(rt.rafId);
      ro.disconnect();
      io.disconnect();
      window.removeEventListener("resize", measure);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("wheel", stopOnUserInput);
      window.removeEventListener("touchstart", stopOnUserInput);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerdown", onPointerDown);
      document.documentElement.removeEventListener("pointerleave", onPointerGone);
      window.removeEventListener("blur", onPointerGone);
      window.removeEventListener("keydown", onKey);
      input?.removeEventListener("pointerdown", scrubOn);
      input?.removeEventListener("pointerup", scrubOff);
      input?.removeEventListener("pointercancel", scrubOff);
      input?.removeEventListener("keydown", scrubKey);
      field.dispose();
      rt.field = null;
      delete window.__meridianStats;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [motion.ready]);

  const content = (i) => {
    switch (i) {
      case 0:
        return <Hero coarse={coarse} />;
      case 1:
        return <TimelineAct store={store} reduced={reduced} />;
      case 2:
        return <SpringsAct store={store} ringRef={ringRef} coarse={coarse} />;
      case 3:
        return <ShipAct store={store} frames={frames} />;
      default:
        return <AccessAct />;
    }
  };

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: GEO_CSS }} />
      <a className="skip" href="#main">
        Skip to content
      </a>
      <header className="top">
        <a className="brand" href="#meridian">
          <i aria-hidden="true" />
          Meridian
        </a>
        <nav className="top-nav" aria-label="Page">
          <MotionToggle pref={motion.pref} reduced={reduced} system={motion.system} onChange={motion.set} />
          <a className="top-link" href="#access">
            Request access
          </a>
        </nav>
      </header>

      <div className="stage" ref={wrapRef}>
        <div className={"view" + (webgl === null ? " is-hidden" : "")} ref={viewRef} aria-hidden="true">
          {webgl !== false ? <canvas ref={canvasRef} /> : <StaticFallback />}
        </div>
        <main id="main" className="acts">
          {ACTS.map((a, i) => (
            <section
              key={a.id}
              id={a.id}
              className={`act act-${a.id}`}
              style={{
                height:
                  i === ACTS.length - 1
                    ? `calc(${(a.span * SCROLL_VH).toFixed(2)}vh + var(--vh))`
                    : `${(a.span * SCROLL_VH).toFixed(2)}vh`,
              }}
            >
              <div className="pin">{content(i)}</div>
            </section>
          ))}
        </main>
      </div>

      <footer className="foot">
        <div>
          <p>
            <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>
          </p>
          <p>
            Meridian is made by a small team of motion designers and engineers. The editor is in
            private beta. The code it exports is already yours.
          </p>
        </div>
        <div>
          <p className="stat">
            {info
              ? `This visit drew ${info.count.toLocaleString()} points at ${info.dpr}x device pixels (${info.label} tier). The field stops drawing when it is offscreen or the tab is hidden.`
              : "The field is drawn with WebGL when it is available, and stands still as a drawing when it is not."}
          </p>
          <p className="stat">Document length: 24 seconds at 24 frames per second, five acts.</p>
        </div>
      </footer>

      <Ruler
        index={index}
        playing={playing}
        reduced={reduced}
        onTogglePlay={togglePlay}
        onScrub={onScrub}
        onJump={jump}
        timecodeRef={timecodeRef}
        playheadRef={playheadRef}
        inputRef={inputRef}
      />
    </>
  );
}
