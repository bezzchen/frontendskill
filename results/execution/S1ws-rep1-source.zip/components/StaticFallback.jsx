// Shown only when WebGL is unavailable: the globe of meridians as an SVG, so the page keeps its
// identity and every act's content still reads.
export default function StaticFallback() {
  const rings = Array.from({ length: 12 }, (_, i) => i);
  return (
    <div className="fallback" aria-hidden="true">
      <svg viewBox="-110 -110 220 220" className="fallback-globe">
        <g fill="none" stroke="currentColor" strokeWidth="0.6">
          {rings.map((i) => {
            const rx = Math.abs(Math.cos((i / 12) * Math.PI)) * 100;
            return <ellipse key={i} cx="0" cy="0" rx={Math.max(rx, 0.5)} ry="100" opacity={0.25 + 0.5 * (rx / 100)} />;
          })}
          <line x1="0" y1="-108" x2="0" y2="108" stroke="var(--brass)" strokeWidth="1.2" />
        </g>
      </svg>
    </div>
  );
}
