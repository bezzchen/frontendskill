"use client";
import { ACTS, BOUNDS } from "@/lib/acts";

// The timeline chrome: timecode, transport, clip regions, chapter markers, playhead.
// The scrubber is a real range input; the loop writes its value and valuetext directly.
export default function Ruler({
  index,
  playing,
  reduced,
  onTogglePlay,
  onScrub,
  onJump,
  timecodeRef,
  playheadRef,
  inputRef,
}) {
  const onKeyDown = (e) => {
    if (e.key === "PageDown" || e.key === "PageUp") {
      e.preventDefault();
      onJump(e.key === "PageDown" ? 1 : -1);
    }
  };
  return (
    <div className="ruler" role="region" aria-label="Timeline">
      <output className="tc" ref={timecodeRef} aria-live="off" aria-label="Timecode">
        00:00:00:00
      </output>
      <button
        type="button"
        className="transport"
        onClick={onTogglePlay}
        aria-pressed={playing}
        aria-label={reduced ? "Next act" : playing ? "Pause" : "Play"}
        title={reduced ? "Next act" : playing ? "Pause (Space)" : "Play (Space)"}
      >
        <svg viewBox="0 0 12 12" width="12" height="12" aria-hidden="true" focusable="false">
          {reduced ? (
            <path d="M2 1.5v9l5-4.5zM8.5 1.5h1.5v9H8.5z" fill="currentColor" />
          ) : playing ? (
            <path d="M2 1.5h3v9H2zM7 1.5h3v9H7z" fill="currentColor" />
          ) : (
            <path d="M2.5 1.2v9.6l8-4.8z" fill="currentColor" />
          )}
        </svg>
        <span className="transport-label">{reduced ? "Next" : playing ? "Pause" : "Play"}</span>
      </button>
      <div className="track">
        <div className="regions" aria-hidden="true">
          {ACTS.map((a, i) => (
            <div
              key={a.id}
              className={"region" + (i === index ? " is-current" : "")}
              style={{ left: `${BOUNDS[i].start * 100}%`, width: `${(BOUNDS[i].end - BOUNDS[i].start) * 100}%` }}
            >
              <i className="marker" />
              <span className="region-name">{a.name}</span>
            </div>
          ))}
        </div>
        <div className="playhead" ref={playheadRef} aria-hidden="true" />
        <input
          ref={inputRef}
          className="scrub"
          type="range"
          min="0"
          max="1"
          step="0.0005"
          defaultValue="0"
          aria-label="Timeline position"
          aria-valuetext="00:00:00:00, Meridian"
          onInput={(e) => onScrub(parseFloat(e.currentTarget.value))}
          onKeyDown={onKeyDown}
        />
      </div>
    </div>
  );
}
