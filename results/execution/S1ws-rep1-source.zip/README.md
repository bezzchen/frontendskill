# meridian-launch

Launch page for Meridian, a timeline-based motion editor for the web.

The page is itself a Meridian document: a 24-second timeline at 24 fps in five acts. Scroll
position is the playhead; one WebGL point cloud (up to 65,536 points, one draw call) is the
globe of meridians, the four property tracks, the spring bundle, the filmstrip and the closing
line in turn. Keyframes dragged in act II and spring constants set in act III change the field
on the next frame and are printed as plain CSS and JavaScript in act IV.

Built with Next.js, React, Tailwind CSS and OGL (a thin WebGL wrapper; all visuals live in
`components/field/shaders.js`).

## Layout

- `app/` — layout, page, global stylesheet (palette, type, ruler, lanes, reduced-motion rules)
- `components/Stage.jsx` — scroll-to-playhead mapping, render loop with pause guards
  (IntersectionObserver + `visibilitychange`), pointer physics, adaptive quality tiers
- `components/field/` — `Field.js` (OGL renderer, tiers, context loss) and `shaders.js`
- `components/acts/` — the five acts' content and controls (keyframe editor, spring sliders,
  code export)
- `components/Ruler.jsx` — timecode, transport, act regions, range-input scrubber
- `lib/` — the shared spring solution (JS and GLSL), the document model and exporters, act
  spans and screen geometry, a tiny store, the motion-preference hook

## Development

```bash
npm install
npm run dev
```

`npm run build && npm start` for the production server.

## Behaviour notes

- Full motion: opening sequence, ambient globe rotation, pointer lens and velocity, spring
  transitions between acts, smoothed playhead, Space plays the timeline.
- Reduced motion (OS setting or the page's own toggle): the same acts and controls, the field
  follows scroll 1:1, cross-dissolve transitions, no ambient or pointer motion, the transport
  steps between acts instead of playing.
- The loop stops when the canvas is scrolled out of view or the document is hidden, draws at
  half rate when idle, and steps down device-pixel ratio and point count if frames run long.
- Without WebGL the globe is drawn as an SVG and every act's content and controls remain.
