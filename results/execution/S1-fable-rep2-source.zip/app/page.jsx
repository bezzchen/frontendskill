import Experience from "./experience.jsx";

export default function Home() {
  return <Experience />;
}
