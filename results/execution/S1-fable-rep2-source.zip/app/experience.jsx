"use client";

// The page is a Meridian project file. This component renders the five acts
// (all real, server-rendered semantic HTML) plus the stage canvas and the
// transport, then hands the DOM to the director, which drives everything
// from one deterministic master clock.

import { useEffect, useRef } from "react";
import { createDirector } from "../lib/director.js";

const TRACKS = ["opacity", "translate y", "scale", "rotate", "blur", "hue", "mask", "spring"];
const CLIPS = [
  ["I", "first keyframe"],
  ["II", "the graph"],
  ["III", "tracks"],
  ["IV", "export"],
  ["V", "premiere"],
];
const PRESET_CHIPS = [
  ["gentle", "0.62,0.05,0.18,1"],
  ["snap", "0.9,0.02,0.16,1"],
  ["anticipate", "0.68,-0.28,0.32,1"],
  ["overshoot", "0.34,0.02,0.24,1.32"],
];

const DEFAULT_CSS = `.scene [data-clip] {
  animation: enter 900ms cubic-bezier(0.62, 0.05, 0.18, 1.00) both;
  animation-delay: calc(var(--i) * 120ms);
}

@keyframes enter {
  from { opacity: 0; translate: 0 28px; scale: 0.98; }
  to   { opacity: 1; translate: 0 0;    scale: 1; }
}`;
const DEFAULT_WAAPI = `el.animate(frames, {
  duration: 900,
  delay: i * 120,
  easing: "cubic-bezier(0.62, 0.05, 0.18, 1.00)",
  fill: "both",
});`;

export default function Experience() {
  const rootRef = useRef(null);

  useEffect(() => {
    if (!rootRef.current) return;
    return createDirector(rootRef.current);
  }, []);

  return (
    <div ref={rootRef} className="mrd">
      <a className="skip" href="#content">Skip to content</a>

      <canvas id="stage-canvas" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />
      <div className="letterbox lb-top" aria-hidden="true" />
      <div className="letterbox lb-bot" aria-hidden="true" />

      <header className="masthead">
        <a className="wordmark" href="#act-0" aria-label="Meridian — back to the start">
          MERID<span className="mline" aria-hidden="true" />IAN
        </a>
        <p className="mast-tag">a motion editor for the web</p>
        <a className="ghost-cta" href="mailto:hello@meridian.tools?subject=Early%20access">
          Early access
        </a>
      </header>

      <main id="content" tabIndex={-1}>
        <p className="sr-only">
          The background canvas is a decorative real-time visualization driven by the page
          timeline; every piece of information is present in the text. Scroll position acts
          as a playhead across five acts on one 48-second timeline.
        </p>
        <noscript>
          <p className="noscript">
            JavaScript is off, so you are reading the printed edition. With it, this page is
            one scrubbable 48-second timeline.
          </p>
        </noscript>

        {/* ACT I ------------------------------------------------------------ */}
        <section className="act" id="act-0" data-act="0" aria-labelledby="t-act0">
          <div className="pin center">
            <div className="hero">
              <p className="eyebrow plain" data-fx="rise" data-in="0.005">
                project: launch.mrd — 00:48.0 · 5 acts
              </p>
              <h1 className="serif" id="t-act0" data-fx="rise" data-in="0.03">
                Motion, directed.
              </h1>
              <p className="lede" data-fx="rise" data-in="0.06">
                Meridian is a timeline-based motion editor for the web. Design animation on a
                real timeline — and ship it as the exact code you’d write by hand.
              </p>
              <p className="hint" data-fx="rise" data-in="0.1" data-out="0.82">
                this page is a Meridian project · <kbd>scroll</kbd> to scrub it ·{" "}
                <kbd>space</kbd> to play
              </p>
            </div>
            <p className="kchip k1" data-fx="none" data-in="0.17" aria-hidden="true">
              ◆ K1 · 00:00.0 · set
            </p>
            <p className="kchip k2" data-fx="none" data-in="0.55" aria-hidden="true">
              ◆ K2 · 00:08.4 · set
            </p>
          </div>
        </section>

        {/* ACT II ----------------------------------------------------------- */}
        <section className="act" id="act-1" data-act="1" aria-labelledby="t-act1">
          <div className="pin">
            <div className="duo">
              <figure className="card editor-card" data-fx="rise" data-in="0.08">
                <figcaption className="card-head">
                  <span className="dot t" />easing — enter.curve
                </figcaption>
                <svg
                  id="curve-editor"
                  viewBox="-18 -40 136 180"
                  role="group"
                  aria-label="Cubic bezier easing editor. Two draggable control points shape the curve every particle on screen follows."
                >
                  {[0, 25, 50, 75, 100].map((v) => (
                    <g key={v}>
                      <line className="grid-line" x1={v} y1={0} x2={v} y2={100} />
                      <line className="grid-line" x1={0} y1={v} x2={100} y2={v} />
                    </g>
                  ))}
                  <line className="diag" x1={0} y1={100} x2={100} y2={0} />
                  <path id="curve-path" className="curve" d="M 0 100 C 62 95, 18 0, 100 0" />
                  <line id="h-line-1" className="h-line" x1={0} y1={100} x2={62} y2={95} />
                  <line id="h-line-2" className="h-line" x1={100} y1={0} x2={18} y2={0} />
                  <rect className="anchor" x={-3.2} y={96.8} width={6.4} height={6.4} transform="rotate(45 0 100)" />
                  <rect className="anchor" x={96.8} y={-3.2} width={6.4} height={6.4} transform="rotate(45 100 0)" />
                  <circle
                    id="h-1" className="handle" cx={62} cy={95} r={5.2}
                    tabIndex={0} role="slider" aria-label="Ease-in control point"
                    aria-valuemin={0} aria-valuemax={1} aria-valuenow={0.62}
                    aria-valuetext="control point 1: x 0.62, y 0.05"
                  />
                  <circle
                    id="h-2" className="handle" cx={18} cy={0} r={5.2}
                    tabIndex={0} role="slider" aria-label="Ease-out control point"
                    aria-valuemin={0} aria-valuemax={1} aria-valuenow={0.18}
                    aria-valuetext="control point 2: x 0.18, y 1.00"
                  />
                </svg>
                <p className="readout">
                  <code id="bez-readout">cubic-bezier(0.62, 0.05, 0.18, 1.00)</code>
                </p>
                <div className="presets" role="group" aria-label="Easing presets">
                  {PRESET_CHIPS.map(([name, bez]) => (
                    <button key={name} type="button" className="preset-chip" data-bez={bez} aria-pressed={name === "gentle"}>
                      {name}
                    </button>
                  ))}
                </div>
              </figure>
              <div className="copy">
                <p className="eyebrow" data-fx="rise" data-in="0.05">act ii · easing</p>
                <h2 className="serif" id="t-act1" data-fx="rise" data-in="0.07">Feel your curves.</h2>
                <p data-fx="rise" data-in="0.1">
                  Grab the amber handles. Every frame in the field behind this card re-times
                  itself to your ease, live — the way your users will feel it, not a preview
                  of it.
                </p>
                <p className="hint" data-fx="rise" data-in="0.14">
                  drag a handle — or focus one and steer with the arrow keys
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ACT III ---------------------------------------------------------- */}
        <section className="act" id="act-2" data-act="2" aria-labelledby="t-act2">
          <div className="pin">
            <div className="duo rev">
              <div className="copy">
                <p className="eyebrow" data-fx="rise" data-in="0.05">act iii · tracks</p>
                <h2 className="serif" id="t-act2" data-fx="rise" data-in="0.07">Choreography, layered.</h2>
                <p data-fx="rise" data-in="0.1">
                  Eight properties, one timeline. Slide the stagger and the whole cascade
                  re-conducts itself — offset is the difference between moving and music.
                </p>
                <p className="hint" data-fx="rise" data-in="0.14">
                  the stage lanes fire in the same order, with your offset
                </p>
              </div>
              <figure className="card tracks-card" data-fx="rise" data-in="0.08">
                <figcaption className="card-head">
                  <span className="dot t" />timeline — 8 tracks
                </figcaption>
                <ul className="tracks">
                  {TRACKS.map((n, i) => (
                    <li key={n}>
                      <span className="tname">{String(i + 1).padStart(2, "0")} {n}</span>
                      <span className="trow"><span className="tclip" style={{ left: `${i * 3.6}%` }} /></span>
                    </li>
                  ))}
                </ul>
                <div className="stagger-row">
                  <label htmlFor="stagger">stagger</label>
                  <input id="stagger" type="range" min="0" max="320" step="10" defaultValue="120" />
                  <output id="stagger-val" htmlFor="stagger">120ms</output>
                </div>
              </figure>
            </div>
          </div>
        </section>

        {/* ACT IV ----------------------------------------------------------- */}
        <section className="act" id="act-3" data-act="3" aria-labelledby="t-act3">
          <div className="pin">
            <div className="duo">
              <figure className="card code-card" id="code-panel" data-fx="rise" data-in="0.08">
                <figcaption className="card-head">
                  <span className="dot a" />meridian → export
                  <button id="copy-btn" className="copy-btn" type="button">Copy</button>
                </figcaption>
                <pre className="code css" aria-label="Exported CSS"><code id="code-css">{DEFAULT_CSS}</code></pre>
                <pre className="code waapi" aria-label="Exported Web Animations API code"><code id="code-waapi">{DEFAULT_WAAPI}</code></pre>
                <p className="compiled-note">
                  compiled live from <em>your</em> curve and <em>your</em> stagger
                </p>
              </figure>
              <div className="copy">
                <p className="eyebrow" data-fx="rise" data-in="0.05">act iv · export</p>
                <h2 className="serif" id="t-act3" data-fx="rise" data-in="0.07">Now it’s code.</h2>
                <p data-fx="rise" data-in="0.1">
                  Nothing here was hand-waved. The ease you shaped and the stagger you set
                  compile to production CSS and Web Animations — copy them straight into your
                  build. No runtime, no lock-in.
                </p>
                <p className="hint" data-fx="rise" data-in="0.14">
                  the playhead is typing exactly what you designed
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ACT V ------------------------------------------------------------ */}
        <section className="act" id="act-4" data-act="4" aria-labelledby="t-act4">
          <div className="pin center">
            <div className="finale">
              <p className="eyebrow" data-fx="rise" data-in="0.05">act v · premiere</p>
              <h2 className="serif" id="t-act4" data-fx="rise" data-in="0.08">
                Roll credits. Then roll your own.
              </h2>
              <p className="lede" data-fx="rise" data-in="0.12">
                You just scrubbed a five-act film on one deterministic timeline — every frame
                addressable, every scrub identical. That’s Meridian. Imagine what you’ll
                direct.
              </p>
              <div className="cta-row" data-fx="rise" data-in="0.16">
                <a className="btn solid" href="mailto:hello@meridian.tools?subject=Early%20access">
                  Request early access
                </a>
                <button className="btn ghost" id="replay-btn" type="button">
                  ↺ Replay the film
                </button>
              </div>
            </div>
          </div>
          <footer className="foot">
            <p>meridian © 2026 · <a href="mailto:hello@meridian.tools">hello@meridian.tools</a></p>
            <p>cut, scrubbed &amp; shipped on one timeline</p>
            <p>honors <code>prefers-reduced-motion</code> with onion-skin stills</p>
          </footer>
        </section>
      </main>

      {/* transport ---------------------------------------------------------- */}
      <div className="transport" role="group" aria-label="Timeline transport">
        <button id="play-btn" type="button" aria-pressed="false" aria-label="Play the timeline" title="Play (Space)">
          <span className="ico" aria-hidden="true">▶</span>
        </button>
        <p className="tc">
          <span id="tc-now">00:00.0</span>
          <span className="tc-sep" aria-hidden="true">/</span>
          <span className="tc-dur">00:48.0</span>
        </p>
        <div
          id="rail" role="slider" tabIndex={0}
          aria-label="Timeline scrubber"
          aria-valuemin={0} aria-valuemax={48} aria-valuenow={0}
          aria-valuetext="00:00.0 — Act I · First Keyframe"
        >
          <div className="clips" aria-hidden="true">
            {CLIPS.map(([num, name], i) => (
              <span className={i === 0 ? "clip now" : "clip"} key={num}>
                {num}<i>{name}</i>
              </span>
            ))}
          </div>
          <div id="rail-played" aria-hidden="true" />
          {[20, 40, 60, 80].map((p) => (
            <span className="kf" key={p} style={{ left: `${p}%` }} aria-hidden="true" />
          ))}
          <div id="playhead" aria-hidden="true"><span className="ph-diamond" /></div>
        </div>
        <p id="act-label" className="act-label" aria-hidden="true">ACT I · FIRST KEYFRAME</p>
        <p id="meter" className="meter" aria-hidden="true">— fps</p>
        <details id="keys" className="keys">
          <summary aria-label="Keyboard shortcuts">?</summary>
          <div className="keys-pop">
            <p><kbd>space</kbd> play / pause</p>
            <p><kbd>j</kbd> <kbd>k</kbd> <kbd>l</kbd> shuttle</p>
            <p><kbd>←</kbd> <kbd>→</kbd> step ±1s</p>
            <p><kbd>1</kbd>–<kbd>5</kbd> jump to act</p>
            <p><kbd>m</kbd> motion mode</p>
          </div>
        </details>
        <button id="motion-btn" type="button" className="motion-btn" aria-pressed="false">
          motion · full
        </button>
      </div>
      <p className="onion-note" role="status">
        Reduced motion — showing onion-skin stills. The curve and stagger still re-render
        their plates.
      </p>
    </div>
  );
}
