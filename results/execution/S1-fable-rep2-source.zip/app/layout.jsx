import "./globals.css";

export const metadata = {
  title: "Meridian — Design motion. Ship code.",
  description:
    "Meridian is a timeline-based motion editor for the web. Its launch page is itself a Meridian project: scroll to scrub a 48-second, five-act timeline, or press space to play it.",
};

export const viewport = {
  themeColor: "#0A0D12",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          precedence="default"
          href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:ital,wght@0,400;0,500;0,700;1,400&display=swap"
        />
        {children}
      </body>
    </html>
  );
}
