import TimelineChrome from "@/components/TimelineChrome";
import Stage from "@/components/Stage";
import SyncPanel from "@/components/SyncPanel";
import SystemCards from "@/components/SystemCards";
import Marquee from "@/components/Marquee";
import RevealInit from "@/components/RevealInit";
import PlayCta from "@/components/PlayCta";

export default function Home() {
  return (
    <>
      <a className="skip-link" href="#scene-open">Skip to content</a>
      <TimelineChrome />
      <RevealInit />

      <main>
        {/* SCENE 01 — OPEN */}
        <section
          className="scene scene-open"
          data-scene="open"
          id="scene-open"
          aria-labelledby="h-open"
        >
          <div className="reg-marks" aria-hidden="true"><i /><i /><i /><i /></div>
          <div className="hero-grid">
            <div className="hero-copy">
              <p className="mono-label reveal">
                Scene 01 · Open — a timeline motion editor for the web
              </p>
              <h1 className="h-display reveal" id="h-open" style={{ "--reveal-delay": "60ms" }}>
                Motion,<br /><em className="accent-i">composed.</em>
              </h1>
              <p className="lede reveal" style={{ "--reveal-delay": "120ms" }}>
                Meridian puts your interface on a real timeline. Keyframe it like film,
                tune it like an instrument — then ship the exact motion you designed
                as production code. No handoff. No redlines.
              </p>
              <div className="hero-ctas reveal" style={{ "--reveal-delay": "180ms" }}>
                <a className="btn btn-primary" href="#get-access">Get early access</a>
                <PlayCta />
              </div>
            </div>
            <Stage />
          </div>
        </section>

        {/* SCENE 02 — SYNC */}
        <section className="scene scene-mid" data-scene="sync" id="scene-sync" aria-labelledby="h-sync">
          <div className="scene-inner">
            <div className="scene-head reveal">
              <span className="mono-label">Scene 02 · Sync</span>
              <span className="rule" aria-hidden="true" />
              <span className="mono-label">The claim</span>
            </div>
            <h2 className="h-scene reveal" id="h-sync">
              Scrub here. <em className="accent-i">Ship there.</em>
            </h2>
            <p className="lede reveal" style={{ margin: "26px 0 48px", "--reveal-delay": "80ms" }}>
              The inspector and the export are the same document. Set a keyframe and it
              exists in code that instant — scrub this page’s timeline and watch both
              surfaces move in lockstep. What you feel in the editor is what ships,
              to the frame.
            </p>
            <SyncPanel />
          </div>
        </section>

        {/* SCENE 03 — SYSTEM */}
        <section className="scene scene-mid" data-scene="system" id="scene-system" aria-labelledby="h-system">
          <Marquee />
          <div className="scene-inner" style={{ paddingTop: "72px" }}>
            <div className="scene-head reveal">
              <span className="mono-label">Scene 03 · System</span>
              <span className="rule" aria-hidden="true" />
              <span className="mono-label">The instrument</span>
            </div>
            <h2 className="h-scene reveal" id="h-system">
              Built like an <em className="accent-i">instrument.</em>
            </h2>
            <p className="lede reveal" style={{ margin: "26px 0 48px", "--reveal-delay": "80ms" }}>
              Every control is tactile, every value is inspectable, and nothing hides
              behind a render button. These three panels are being driven by the same
              playhead you are scrolling right now.
            </p>
            <SystemCards />
          </div>
        </section>

        {/* SCENE 04 — SHIP */}
        <div className="scene scene-ship" data-scene="ship" id="scene-ship">
          <section className="ship-inner" aria-labelledby="h-ship">
            <div className="scene-head reveal">
              <span className="mono-label">Scene 04 · Ship</span>
              <span className="rule" aria-hidden="true" />
              <span className="mono-label">TC 00:00:24:00</span>
            </div>
            <h2 className="h-display reveal" id="h-ship">
              Ship <em className="accent-i">the cut.</em>
            </h2>
            <p className="lede reveal" style={{ "--reveal-delay": "80ms" }}>
              Meridian opens this fall to a first crew of motion designers and the
              engineers who ship their work. Bring a timeline. Leave with production code.
            </p>
            <div className="hero-ctas reveal" id="get-access" style={{ "--reveal-delay": "140ms" }}>
              <a className="btn btn-primary" href="mailto:hello@meridian.tools?subject=Early%20access">
                Get early access
              </a>
              <a className="btn btn-ghost" href="mailto:hello@meridian.tools">hello@meridian.tools</a>
            </div>
            <p className="ship-note reveal" style={{ "--reveal-delay": "200ms" }}>
              Free during the beta · no card · your exports are yours forever
            </p>
          </section>
          <footer className="site-foot">
            <div className="foot-grid">
              <span>MERIDIAN © 2026 — drawn to a 24-second timeline</span>
              <span>
                This page is itself a Meridian composition.<br />
                Press play, or scrub the bar below.
              </span>
              <span>
                Set in Instrument Serif, Instrument Sans &amp; IBM Plex Mono<br />
                No cookies, no trackers · motion rests when you look away
              </span>
            </div>
          </footer>
        </div>
      </main>
    </>
  );
}
