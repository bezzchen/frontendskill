"use client";

import { useEffect, useRef } from "react";
import { engine } from "@/lib/timeline";

const WORDS = ["Keyframe", "Curve", "Spring", "Stagger", "Sequence", "Export"];
const SOLID = new Set(["Spring", "Export"]);

function Seq() {
  return (
    <span className="seq">
      {WORDS.map((w) => (
        <span key={w} className={SOLID.has(w) ? "solid" : undefined}>
          {w}
          <span className="sep" aria-hidden="true">◆</span>
        </span>
      ))}
    </span>
  );
}

export default function Marquee() {
  const trackRef = useRef(null);
  const seqWRef = useRef(1);
  const visibleRef = useRef(false);
  const rootRef = useRef(null);

  useEffect(() => {
    engine.init();
    if (engine.reducedMotion()) return; // static strip under reduced motion

    const measure = () => {
      const seq = trackRef.current && trackRef.current.firstElementChild;
      seqWRef.current = seq ? Math.max(1, seq.offsetWidth) : 1;
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (trackRef.current) ro.observe(trackRef.current);

    const io = new IntersectionObserver(
      ([en]) => { visibleRef.current = en.isIntersecting; },
      { threshold: 0 }
    );
    if (rootRef.current) io.observe(rootRef.current);

    // Strictly scroll-position-driven: no ticker exists to pause.
    const off = engine.subscribe((p) => {
      if (!visibleRef.current || !trackRef.current) return;
      const shift = p.t * seqWRef.current * 2.2;
      trackRef.current.style.transform = `translate3d(${(-(shift % seqWRef.current)).toFixed(2)}px,0,0)`;
    });

    return () => { off(); ro.disconnect(); io.disconnect(); };
  }, []);

  return (
    <div className="marquee" aria-hidden="true" ref={rootRef}>
      <div className="marquee-track" ref={trackRef}>
        <Seq />
        <Seq />
        <Seq />
      </div>
    </div>
  );
}
