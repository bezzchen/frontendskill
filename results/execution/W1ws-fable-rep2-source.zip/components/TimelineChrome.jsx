"use client";

import { useEffect, useRef, useState } from "react";
import { engine, formatTimecode, FILM_SECONDS } from "@/lib/timeline";

export const SCENES = [
  { id: "open", num: "01", name: "Open" },
  { id: "sync", num: "02", name: "Sync" },
  { id: "system", num: "03", name: "System" },
  { id: "ship", num: "04", name: "Ship" },
];

const TICKS = Array.from({ length: FILM_SECONDS + 1 }, (_, s) => s);

export default function TimelineChrome() {
  const tcRef = useRef(null);
  const trackRef = useRef(null);
  const playheadRef = useRef(null);
  const sliderRef = useRef(null);
  const endKeyRef = useRef(null);
  const blockRefs = useRef({});
  const fillRefs = useRef({});
  const keyRefs = useRef({});
  const widthRef = useRef(0);
  const mvRef = useRef(-1);
  const scenesRef = useRef([]);
  const draggingRef = useRef(false);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    engine.init();
    const offPlay = engine.onPlayState(setPlaying);

    const track = trackRef.current;
    const measureTrack = () => {
      widthRef.current = track ? track.clientWidth : 0;
    };
    measureTrack();
    const ro = new ResizeObserver(measureTrack);
    if (track) ro.observe(track);

    const off = engine.subscribe((p) => {
      scenesRef.current = p.scenes;
      if (tcRef.current) tcRef.current.textContent = formatTimecode(p.seconds);
      if (playheadRef.current) {
        const phx = Math.max(1, Math.min(widthRef.current - 1, p.t * widthRef.current));
        playheadRef.current.style.transform = `translate3d(${phx.toFixed(2)}px,0,0)`;
      }
      if (p.mv !== mvRef.current) {
        mvRef.current = p.mv;
        for (const sc of p.scenes) {
          const el = blockRefs.current[sc.id];
          if (el) el.style.flex = `0 0 ${((sc.endT - sc.startT) * 100).toFixed(3)}%`;
          const key = keyRefs.current[sc.id];
          if (key) key.style.left = `${(sc.startT * 100).toFixed(3)}%`;
        }
      }
      for (const sc of p.scenes) {
        const fill = fillRefs.current[sc.id];
        if (fill) fill.style.width = `${(engine.sceneProgress(sc.id, p.t) * 100).toFixed(2)}%`;
        const key = keyRefs.current[sc.id];
        if (key) key.classList.toggle("lit", p.t >= sc.startT - 1e-6);
      }
      if (endKeyRef.current) endKeyRef.current.classList.toggle("lit", p.t > 0.999);
      const slider = sliderRef.current;
      if (slider) {
        if (document.activeElement !== slider) slider.value = p.seconds.toFixed(1);
        const cur = p.scenes.find((s) => p.t >= s.startT && p.t <= s.endT);
        const meta = SCENES.find((s) => s.id === (cur && cur.id));
        slider.setAttribute(
          "aria-valuetext",
          `${p.seconds.toFixed(1)} of ${FILM_SECONDS} seconds${meta ? ` — scene ${meta.num}, ${meta.name}` : ""}`
        );
      }
    });

    // Space toggles play/pause anywhere outside interactive elements.
    const onKey = (e) => {
      if (e.code !== "Space" || e.defaultPrevented) return;
      const t = e.target;
      if (t && t.closest && t.closest("input, textarea, select, button, a, [contenteditable=true]")) return;
      e.preventDefault();
      engine.toggle();
    };
    window.addEventListener("keydown", onKey);

    return () => {
      off();
      offPlay();
      ro.disconnect();
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const seekFromEvent = (e) => {
    const track = trackRef.current;
    if (!track) return;
    const r = track.getBoundingClientRect();
    const t = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    engine.pause("scrub");
    engine.seekT(t, false);
  };

  const onPointerDown = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    draggingRef.current = true;
    e.currentTarget.setPointerCapture(e.pointerId);
    document.documentElement.classList.add("scrubbing");
    seekFromEvent(e);
  };
  const onPointerMove = (e) => {
    if (draggingRef.current) seekFromEvent(e);
  };
  const endDrag = () => {
    draggingRef.current = false;
    document.documentElement.classList.remove("scrubbing");
  };

  const onBlockClick = (e, id) => {
    if (e.detail > 0) return; // mouse clicks are handled by the pointer scrub
    const sc = scenesRef.current.find((s) => s.id === id);
    if (sc) engine.seekT(sc.startT + 0.0005, true);
  };

  return (
    <>
      <header className="topbar">
        <a className="wordmark" href="#scene-open">
          <span className="dia" aria-hidden="true">◆</span>MERIDIAN
        </a>
        <span className="mono-label top-meta" aria-hidden="true">
          launch_film.mer · 24.0s · 60fps
        </span>
        <span className="top-tc" aria-hidden="true">
          TC <span className="tc-live" ref={tcRef}>00:00:00:00</span>
        </span>
        <button
          type="button"
          className="btn-play"
          aria-pressed={playing}
          onClick={() => engine.toggle()}
        >
          <span aria-hidden="true">{playing ? "❚❚" : "▸"}</span>
          <span className="lbl">{playing ? "Pause" : "Play"}</span>
        </button>
        <a className="btn-top-cta" href="#get-access">Get access</a>
      </header>

      <div
        className="tl-bar"
        role="group"
        aria-label="Film timeline — the page is a 24 second composition"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        <div className="tl-track" ref={trackRef}>
          <div className="tl-ruler" aria-hidden="true">
            {TICKS.map((s) => (
              <span key={s}>
                <i
                  className={`tl-tick${s % 4 === 0 ? " major" : ""}`}
                  style={{ left: `${(s / FILM_SECONDS) * 100}%` }}
                />
                {s % 4 === 0 && s < FILM_SECONDS && (
                  <i className="tl-tick-label" style={{ left: `${(s / FILM_SECONDS) * 100}%` }}>
                    {s}s
                  </i>
                )}
              </span>
            ))}
          </div>
          <div className="tl-scenes">
            {SCENES.map((sc) => (
              <button
                key={sc.id}
                type="button"
                className="tl-block"
                ref={(el) => { blockRefs.current[sc.id] = el; }}
                onClick={(e) => onBlockClick(e, sc.id)}
                aria-label={`Jump to scene ${sc.num}, ${sc.name}`}
              >
                <i className="fill" ref={(el) => { fillRefs.current[sc.id] = el; }} aria-hidden="true" />
                <span className="num">SC {sc.num}</span>
                <span className="name">{sc.name}</span>
              </button>
            ))}
          </div>
          {SCENES.map((sc) => (
            <i
              key={sc.id}
              className="tl-key"
              ref={(el) => { keyRefs.current[sc.id] = el; }}
              aria-hidden="true"
            />
          ))}
          <i className="tl-key" style={{ left: "100%" }} ref={endKeyRef} aria-hidden="true" />
          <div className="tl-playhead" ref={playheadRef} aria-hidden="true">
            <i className="line" />
            <i className="head" />
          </div>
          <input
            ref={sliderRef}
            className="tl-slider"
            type="range"
            min="0"
            max={FILM_SECONDS}
            step="0.1"
            defaultValue="0"
            aria-label="Playhead position"
            onInput={(e) => engine.seekSeconds(parseFloat(e.target.value), false)}
            onPointerDown={(e) => e.stopPropagation()}
          />
          <i className="tl-focus-ring" aria-hidden="true" />
        </div>
      </div>
    </>
  );
}
