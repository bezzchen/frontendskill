"use client";

import { useEffect, useRef } from "react";
import { engine, formatTimecode, easeInOutCubic } from "@/lib/timeline";

const lerp = (a, b, t) => a + (b - a) * t;
const CODE_LINES = 12;

export default function SyncPanel() {
  const rootRef = useRef(null);
  const visibleRef = useRef(true);
  const ins = useRef({});
  const bars = useRef({});
  const code = useRef({});
  const hlRef = useRef(null);

  useEffect(() => {
    engine.init();

    const io = new IntersectionObserver(
      ([en]) => { visibleRef.current = en.isIntersecting; },
      { threshold: 0.05 }
    );
    if (rootRef.current) io.observe(rootRef.current);

    const off = engine.subscribe((p) => {
      if (!visibleRef.current) return;
      const e = easeInOutCubic(engine.sceneProgress("sync", p.t));
      const x = lerp(-96, 288, e);
      const y = lerp(140, -48, e);
      const r = lerp(-6, 14, e);
      const s = lerp(0.86, 1.12, e);

      const iv = ins.current;
      if (iv.x) iv.x.textContent = `${x.toFixed(1)} px`;
      if (iv.y) iv.y.textContent = `${y.toFixed(1)} px`;
      if (iv.r) iv.r.textContent = `${r.toFixed(1)} deg`;
      if (iv.s) iv.s.textContent = `× ${s.toFixed(2)}`;

      const bv = bars.current;
      if (bv.x) bv.x.style.transform = `scaleX(${((x + 96) / 384).toFixed(4)})`;
      if (bv.y) bv.y.style.transform = `scaleX(${((140 - y) / 188).toFixed(4)})`;
      if (bv.r) bv.r.style.transform = `scaleX(${((r + 6) / 20).toFixed(4)})`;
      if (bv.s) bv.s.style.transform = `scaleX(${((s - 0.86) / 0.26).toFixed(4)})`;

      const cv = code.current;
      if (cv.tc) cv.tc.textContent = formatTimecode(p.seconds);
      if (cv.x) cv.x.textContent = `${x.toFixed(1)}px`;
      if (cv.y) cv.y.textContent = `${y.toFixed(1)}px`;
      if (cv.r) cv.r.textContent = `${r.toFixed(1)}deg`;
      if (cv.s) cv.s.textContent = s.toFixed(2);

      if (hlRef.current) {
        const line = Math.round(e * (CODE_LINES - 1));
        hlRef.current.style.transform = `translateY(${(line * 1.75).toFixed(2)}em)`;
      }
    });

    return () => { off(); io.disconnect(); };
  }, []);

  const R = (key, refset) => (el) => { refset.current[key] = el; };

  return (
    <div className="sync-grid" ref={rootRef}>
      <section className="panel reveal" aria-label="Inspector panel — live property values">
        <div className="panel-head">
          <span className="mono-label">inspector · track “badge”</span>
          <span className="mono-label">4 props</span>
        </div>
        <div className="inspector-rows">
          <div className="ins-row">
            <span className="k">Position X</span>
            <span className="v" ref={R("x", ins)}>-96.0 px</span>
            <span className="ins-bar" aria-hidden="true"><i ref={R("x", bars)} /></span>
          </div>
          <div className="ins-row">
            <span className="k">Position Y</span>
            <span className="v" ref={R("y", ins)}>140.0 px</span>
            <span className="ins-bar" aria-hidden="true"><i ref={R("y", bars)} /></span>
          </div>
          <div className="ins-row">
            <span className="k">Rotate</span>
            <span className="v" ref={R("r", ins)}>-6.0 deg</span>
            <span className="ins-bar" aria-hidden="true"><i ref={R("r", bars)} /></span>
          </div>
          <div className="ins-row">
            <span className="k">Scale</span>
            <span className="v" ref={R("s", ins)}>× 0.86</span>
            <span className="ins-bar" aria-hidden="true"><i ref={R("s", bars)} /></span>
          </div>
          <div className="ins-row">
            <span className="k">Ease</span>
            <span className="v">cubic-bezier(0.22, 1, 0.36, 1)</span>
          </div>
        </div>
      </section>

      <section className="panel code-panel reveal" aria-label="Export panel — the same values as production CSS" style={{ "--reveal-delay": "110ms" }}>
        <div className="panel-head">
          <span className="mono-label">export · css</span>
          <span className="mono-label">css · waapi · react</span>
        </div>
        <pre className="code-body"><i className="code-hl" ref={hlRef} aria-hidden="true" /><code>
<span className="tok-c">{"/* meridian · export/css — launch_film.css */"}</span>{"\n"}
<span className="tok-c">{"/* track “badge” · scene 02 · one source of truth */"}</span>{"\n"}
<span className="tok-k">@keyframes</span> <span className="tok-n">badge-flight</span> {"{"}{"\n"}
{"  0%   { transform: translate(-96px, 140px) rotate(-6deg) scale(0.86); }"}{"\n"}
{"  100% { transform: translate(288px, -48px) rotate(14deg) scale(1.12); }"}{"\n"}
{"}"}{"\n"}
<span className="tok-n">.badge</span> {"{"}{"\n"}
{"  animation: badge-flight 6s cubic-bezier(0.22, 1, 0.36, 1) both;"}{"\n"}
{"}"}{"\n"}
<span className="tok-c">{"/* playhead sample · tc "}<span ref={R("tc", code)}>00:00:00:00</span>{" */"}</span>{"\n"}
{"transform: translate("}<span className="tok-live" ref={R("x", code)}>-96.0px</span>{", "}<span className="tok-live" ref={R("y", code)}>140.0px</span>{")"}{"\n"}
{"           rotate("}<span className="tok-live" ref={R("r", code)}>-6.0deg</span>{") scale("}<span className="tok-live" ref={R("s", code)}>0.86</span>{");"}
</code></pre>
      </section>
    </div>
  );
}
