"use client";

import { engine } from "@/lib/timeline";

export default function PlayCta() {
  return (
    <>
      <button type="button" className="btn play-cta" onClick={() => engine.play()}>
        <span className="tri" aria-hidden="true">▸</span> Play this page
      </button>
      <span className="hint-space">or press <kbd>space</kbd></span>
    </>
  );
}
