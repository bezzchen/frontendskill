"use client";

import { useEffect, useRef } from "react";
import { engine, easeInOutCubic } from "@/lib/timeline";

const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

// unit-space -> svg-space for the curve card
const CX = (u) => 30 + u * 260;
const CY = (v) => 190 - v * 160;
const CA = { c1: [0.85, 0.12], c2: [0.9, 0.45] };   // hard ease-in
const CB = { c1: [0.22, 0.9], c2: [0.42, 1.0] };    // confident ease-out

// damped spring trace, precomputed (deterministic, SSR-safe)
const springY = (u) => 110 - 74 * Math.exp(-3.4 * u) * Math.cos(Math.PI * 2 * 2.6 * u);
const SX = (u) => 20 + u * 280;
const SPRING_D =
  "M " +
  Array.from({ length: 61 }, (_, i) => {
    const u = i / 60;
    return `${SX(u).toFixed(1)} ${springY(u).toFixed(1)}`;
  }).join(" L ");

export default function SystemCards() {
  const rootRef = useRef(null);
  const visibleRef = useRef(true);
  const r = useRef({});

  useEffect(() => {
    engine.init();
    const io = new IntersectionObserver(
      ([en]) => { visibleRef.current = en.isIntersecting; },
      { threshold: 0.05 }
    );
    if (rootRef.current) io.observe(rootRef.current);

    const off = engine.subscribe((p) => {
      if (!visibleRef.current) return;
      const ss = engine.sceneProgress("system", p.t);
      const el = r.current;

      // curve morph
      const e = easeInOutCubic(clamp01(ss * 1.5));
      const c1 = [lerp(CA.c1[0], CB.c1[0], e), lerp(CA.c1[1], CB.c1[1], e)];
      const c2 = [lerp(CA.c2[0], CB.c2[0], e), lerp(CA.c2[1], CB.c2[1], e)];
      if (el.curve) {
        el.curve.setAttribute(
          "d",
          `M 30 190 C ${CX(c1[0]).toFixed(1)} ${CY(c1[1]).toFixed(1)}, ${CX(c2[0]).toFixed(1)} ${CY(c2[1]).toFixed(1)}, 290 30`
        );
      }
      if (el.h1) { el.h1.setAttribute("x2", CX(c1[0]).toFixed(1)); el.h1.setAttribute("y2", CY(c1[1]).toFixed(1)); }
      if (el.h2) { el.h2.setAttribute("x2", CX(c2[0]).toFixed(1)); el.h2.setAttribute("y2", CY(c2[1]).toFixed(1)); }
      if (el.d1) { el.d1.setAttribute("cx", CX(c1[0]).toFixed(1)); el.d1.setAttribute("cy", CY(c1[1]).toFixed(1)); }
      if (el.d2) { el.d2.setAttribute("cx", CX(c2[0]).toFixed(1)); el.d2.setAttribute("cy", CY(c2[1]).toFixed(1)); }
      if (el.bezLabel) {
        el.bezLabel.textContent = `cubic-bezier(${c1[0].toFixed(2)}, ${c1[1].toFixed(2)}, ${c2[0].toFixed(2)}, ${c2[1].toFixed(2)})`;
      }

      // spring rider
      const u = clamp01(ss * 1.2);
      if (el.rider) {
        el.rider.setAttribute("cx", SX(u).toFixed(1));
        el.rider.setAttribute("cy", springY(u).toFixed(1));
      }
      if (el.springLabel) {
        el.springLabel.textContent = `t = ${(u * 1.4).toFixed(2)}s · Δ ${(110 - springY(u)).toFixed(1)}px`;
      }
    });

    return () => { off(); io.disconnect(); };
  }, []);

  const R = (key) => (el) => { r.current[key] = el; };

  return (
    <div className="cards" ref={rootRef}>
      <article className="card reveal">
        <div className="card-viz">
          <svg className="viz-curve" viewBox="0 0 320 220" role="img" aria-label="Easing curve editor with draggable bezier handles">
            <line className="axis" x1="30" y1="190" x2="290" y2="190" />
            <line className="axis" x1="30" y1="190" x2="30" y2="30" />
            <line className="handle-line" ref={R("h1")} x1="30" y1="190" x2="251" y2="171" />
            <line className="handle-line" ref={R("h2")} x1="290" y1="30" x2="264" y2="118" />
            <path className="curve" ref={R("curve")} d="M 30 190 C 251 171, 264 118, 290 30" />
            <circle className="end-dot" cx="30" cy="190" r="4" />
            <circle className="end-dot" cx="290" cy="30" r="4" />
            <circle className="handle-dot" ref={R("d1")} cx="251" cy="171" r="6" />
            <circle className="handle-dot" ref={R("d2")} cx="264" cy="118" r="6" />
          </svg>
        </div>
        <div className="card-body">
          <h3>Easing you can hold</h3>
          <p>A full-size curve editor, not a dropdown. Drag the handles, compare against presets, copy the bezier straight out.</p>
          <span className="card-read" ref={R("bezLabel")}>cubic-bezier(0.85, 0.12, 0.90, 0.45)</span>
        </div>
      </article>

      <article className="card reveal" style={{ "--reveal-delay": "90ms" }}>
        <div className="card-viz">
          <svg className="viz-spring" viewBox="0 0 320 220" role="img" aria-label="A damped spring settling toward its rest position">
            <line className="rest" x1="20" y1="110" x2="300" y2="110" />
            <path className="wave" d={SPRING_D} />
            <circle className="rider" ref={R("rider")} cx="20" cy="36" r="7" />
          </svg>
        </div>
        <div className="card-body">
          <h3>Physics, not guesswork</h3>
          <p>Stiffness, damping, mass — felt live in the preview. Export a real spring, or a baked track for engines that can’t.</p>
          <span className="card-read" ref={R("springLabel")}>t = 0.00s · Δ -74.0px</span>
        </div>
      </article>

      <article className="card reveal" style={{ "--reveal-delay": "180ms" }}>
        <div className="chips" aria-label="Export targets">
          <span className="chip">CSS</span>
          <span className="chip">WAAPI</span>
          <span className="chip">FRAMER MOTION</span>
          <span className="chip">LOTTIE</span>
          <span className="chip hot">1 : 1</span>
        </div>
        <div className="card-body">
          <h3>Code that matches</h3>
          <p>CSS, Web Animations, React, Lottie — same curves, same timing, reproducible to the frame. No runtime lock-in.</p>
          <span className="card-read">byte-identical curves · your code, forever</span>
        </div>
      </article>
    </div>
  );
}
