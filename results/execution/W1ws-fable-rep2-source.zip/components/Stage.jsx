"use client";

import { useEffect, useRef } from "react";
import { engine, easeInOutCubic } from "@/lib/timeline";

const P0 = [64, 316];
const P1 = [150, 90];
const P2 = [470, 60];
const P3 = [566, 170];

function bez(t) {
  const u = 1 - t;
  const x = u * u * u * P0[0] + 3 * u * u * t * P1[0] + 3 * u * t * t * P2[0] + t * t * t * P3[0];
  const y = u * u * u * P0[1] + 3 * u * u * t * P1[1] + 3 * u * t * t * P2[1] + t * t * t * P3[1];
  return [x, y];
}

const KF = [0, 0.35, 0.7, 1];
const KF_PTS = KF.map(bez);
const GRID_X = [64, 128, 192, 256, 320, 384, 448, 512, 576];
const GRID_Y = [64, 128, 192, 256, 336];
const PATH_D = `M ${P0[0]} ${P0[1]} C ${P1[0]} ${P1[1]}, ${P2[0]} ${P2[1]}, ${P3[0]} ${P3[1]}`;

export default function Stage() {
  const rootRef = useRef(null);
  const actorRef = useRef(null);
  const kfRefs = useRef([]);
  const vRefs = useRef({});
  const kcountRef = useRef(null);
  const footRef = useRef(null);
  const visibleRef = useRef(false);

  useEffect(() => {
    engine.init();
    const rm = engine.reducedMotion();

    const draw = (raw, now, bobOn) => {
      const e = easeInOutCubic(raw);
      const [x, y] = bez(e);
      const bob = bobOn ? Math.sin(now * 2.2) * 4 : 0;
      const wob = bobOn ? Math.sin(now * 1.55 + 1) * 1.4 : 0;
      const rot = -20 + 120 * e + wob;
      const sc = 0.8 + 0.35 * e;
      if (actorRef.current) {
        actorRef.current.setAttribute(
          "transform",
          `translate(${x.toFixed(2)} ${(y + bob).toFixed(2)}) rotate(${rot.toFixed(2)}) scale(${sc.toFixed(3)})`
        );
        engine.countStageWrite();
      }
      const v = vRefs.current;
      if (v.x) v.x.textContent = x.toFixed(1);
      if (v.y) v.y.textContent = y.toFixed(1);
      if (v.r) v.r.textContent = `${rot.toFixed(1)}°`;
      if (v.s) v.s.textContent = `×${sc.toFixed(2)}`;
      let passed = 0;
      KF.forEach((k, i) => {
        const lit = e >= k - 0.001;
        if (lit) passed++;
        const el = kfRefs.current[i];
        if (el) el.classList.toggle("lit", lit);
      });
      if (kcountRef.current) kcountRef.current.textContent = `K ${passed}/4`;
    };

    if (rm) {
      // Reduced motion: park the preview on the finished pose. All data intact.
      draw(1, 0, false);
      if (footRef.current) footRef.current.textContent = "preview parked · reduced motion";
      return;
    }

    const io = new IntersectionObserver(
      ([en]) => {
        visibleRef.current = en.isIntersecting;
        // The idle preview loop is ambient: it may only keep the rAF loop
        // alive while the stage is actually on screen.
        engine.setAmbient("stage", en.isIntersecting);
      },
      { threshold: 0.12 }
    );
    if (rootRef.current) io.observe(rootRef.current);

    const off = engine.subscribe((p) => {
      if (!visibleRef.current) return;
      draw(engine.sceneProgress("open", p.t), p.now, true);
    });

    return () => {
      off();
      io.disconnect();
      engine.setAmbient("stage", false);
    };
  }, []);

  return (
    <figure className="stage reveal" ref={rootRef} style={{ margin: 0, "--reveal-delay": "120ms" }}>
      <div className="stage-head">
        <span className="stage-dots" aria-hidden="true"><i /><i /><i /></span>
        <span className="mono-label">viewport · launch_film.mer</span>
        <span className="mono-label" ref={kcountRef}>K 0/4</span>
      </div>
      <svg
        className="stage-canvas"
        viewBox="0 0 640 400"
        role="img"
        aria-label="Editor viewport: a vermilion marker travels a keyframed motion path as the page timeline is scrubbed"
      >
        {GRID_X.map((x) => (
          <line key={`x${x}`} className="grid-line" x1={x} y1="0" x2={x} y2="400" />
        ))}
        {GRID_Y.map((y) => (
          <line key={`y${y}`} className="grid-line" x1="0" y1={y} x2="640" y2={y} />
        ))}
        <path className="mpath" d={PATH_D} />
        {KF_PTS.map(([x, y], i) => (
          <rect
            key={i}
            className="kf"
            x="-6.5"
            y="-6.5"
            width="13"
            height="13"
            transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(45)`}
            ref={(el) => { kfRefs.current[i] = el; }}
          />
        ))}
        <g ref={actorRef} transform={`translate(${P0[0]} ${P0[1]}) rotate(-20) scale(0.8)`}>
          <g transform="rotate(45)">
            <rect className="actor-shape" x="-15" y="-15" width="30" height="30" rx="2" />
          </g>
          <circle className="actor-core" r="3.5" />
        </g>
      </svg>
      <dl className="stage-readout">
        <div><dt>pos x</dt><dd ref={(el) => { vRefs.current.x = el; }}>64.0</dd></div>
        <div><dt>pos y</dt><dd ref={(el) => { vRefs.current.y = el; }}>316.0</dd></div>
        <div><dt>rotate</dt><dd ref={(el) => { vRefs.current.r = el; }}>-20.0°</dd></div>
        <div><dt>scale</dt><dd ref={(el) => { vRefs.current.s = el; }}>×0.80</dd></div>
      </dl>
      <figcaption className="stage-foot">
        <span className="mono-label">scene 01 · track “badge”</span>
        <span className="mono-label" ref={footRef}>ease · in-out cubic</span>
      </figcaption>
    </figure>
  );
}
