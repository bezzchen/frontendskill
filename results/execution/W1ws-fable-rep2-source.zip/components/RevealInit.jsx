"use client";

import { useEffect } from "react";
import { engine } from "@/lib/timeline";

export default function RevealInit() {
  useEffect(() => {
    engine.init();
    const els = Array.from(document.querySelectorAll(".reveal"));
    if (engine.reducedMotion() || !("IntersectionObserver" in window)) {
      els.forEach((el) => el.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) {
            en.target.classList.add("is-in");
            io.unobserve(en.target);
          }
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -6% 0px" }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
  return null;
}
