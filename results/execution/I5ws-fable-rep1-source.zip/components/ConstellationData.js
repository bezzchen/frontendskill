// Experience-constellation dataset: 500 artifacts from a decade of work.
// Deterministic (seeded) so the server-rendered list and the client canvas
// always agree — no Math.random at module scope.

function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const CATEGORIES = [
  {
    id: "engineering",
    label: "Engineering",
    // Okabe–Ito-derived hues, brightened for the dark plate. CVD-safe set.
    color: "#f5a524",
    blurb: "Systems, tools, and infrastructure that shipped.",
  },
  {
    id: "research",
    label: "Research",
    color: "#56b4e9",
    blurb: "Papers read, replicated, and annotated.",
  },
  {
    id: "design",
    label: "Design",
    color: "#e183b8",
    blurb: "Interfaces, specimens, and interaction studies.",
  },
  {
    id: "math",
    label: "Math",
    color: "#34c99a",
    blurb: "Proof sketches and computational explorations.",
  },
];

export const CATEGORY_IDS = CATEGORIES.map((c) => c.id);
export const categoryById = Object.fromEntries(CATEGORIES.map((c) => [c.id, c]));

const POOLS = {
  engineering: {
    a: ["Consensus", "Queue", "Shader", "Build", "Trace", "Schema", "Packet", "Replica", "Cache", "Lexer", "Vector", "Stream", "Kernel", "Socket", "Batch", "Cluster", "Signal", "Ledger"],
    b: ["visualizer", "profiler", "pipeline", "compiler", "sandbox", "router", "planner", "emulator", "inspector", "allocator", "scheduler", "runtime", "monitor", "harness"],
  },
  research: {
    a: ["Attention scaling", "Sparse retrieval", "Program synthesis", "Diffusion sampling", "Graph pruning", "Speculative decoding", "Curriculum learning", "Neural rendering", "Causal tracing", "Vector quantization", "Active sampling", "Grokking dynamics", "Feature circuits", "Long-context memory", "Reward shaping", "Data curation", "Sim-to-real transfer", "Uncertainty calibration"],
    b: ["notes", "replication", "survey", "ablations", "benchmark", "critique", "reading", "digest", "walkthrough", "annotations", "experiments", "review", "summary", "questions"],
  },
  design: {
    a: ["Terrain", "Ledger", "Signal", "Archive", "Meridian", "Tessera", "Halftone", "Waypoint", "Sediment", "Aperture", "Isogram", "Palimpsest", "Modulor", "Cursor", "Gnomon", "Fathom", "Umbra", "Verso"],
    b: ["type specimen", "interface study", "motion sketch", "icon set", "grid system", "color study", "poster series", "wireframe kit", "map style", "chart language", "cursor set", "form patterns", "layout etude", "identity draft"],
  },
  math: {
    a: ["Ramsey bounds", "Random walks", "Knot invariants", "Prime gaps", "Voronoi duals", "Markov mixing", "Braid groups", "Penrose tilings", "Elliptic curves", "Group actions", "Fourier tails", "Lattice packing", "Percolation", "Zeta zeros", "Convex hulls", "Chaos maps", "Spectral gaps", "Coin flips"],
    b: ["proof sketch", "exploration", "counterexample", "visual proof", "conjecture", "computation", "lecture notes", "puzzle", "estimate", "simulation", "derivation", "worked example", "toy model", "heuristic"],
  },
};

function titleCase(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function buildItems() {
  const rand = mulberry32(0xc0ffee);
  const used = new Set();
  const items = [];
  for (let index = 0; index < 500; index += 1) {
    // Preserve the original dataset's index -> category mapping.
    const category = CATEGORY_IDS[index % 4];
    const pool = POOLS[category];
    let label = "";
    for (let attempt = 0; attempt < 24; attempt += 1) {
      const a = pool.a[Math.floor(rand() * pool.a.length)];
      const b = pool.b[Math.floor(rand() * pool.b.length)];
      const candidate = `${a} ${b}`;
      if (!used.has(candidate)) {
        label = candidate;
        break;
      }
    }
    if (!label) {
      label = `${pool.a[index % pool.a.length]} ${pool.b[index % pool.b.length]} ${Math.floor(index / 4) + 1}`;
    }
    used.add(label);
    const year = 2016 + Math.floor(Math.pow(rand(), 0.62) * 11); // 2016..2026, weighted recent
    items.push({
      id: index,
      label: titleCase(label),
      category,
      year: Math.min(year, 2026),
      glyph: label.charAt(0).toUpperCase(),
      shade: Math.floor(rand() * 3), // per-item badge shade variant (0..2)
    });
  }
  return items;
}

export const constellationItems = buildItems();

export const categoryCounts = constellationItems.reduce((acc, item) => {
  acc[item.category] = (acc[item.category] || 0) + 1;
  return acc;
}, {});
