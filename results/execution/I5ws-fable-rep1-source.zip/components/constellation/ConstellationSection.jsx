"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  CATEGORIES,
  categoryById,
  categoryCounts,
  constellationItems,
} from "../ConstellationData";
import { ConstellationEngine } from "./engine";

const itemById = new Map(constellationItems.map((item) => [item.id, item]));
const itemsByCategory = CATEGORIES.map((cat) => ({
  ...cat,
  items: constellationItems.filter((item) => item.category === cat.id),
}));
const TOTAL = constellationItems.length;

export function ConstellationSection() {
  const hostRef = useRef(null);
  const tooltipRef = useRef(null);
  const engineRef = useRef(null);
  const uiRef = useRef({ filter: null, grouped: false, selectedId: null });

  const [filter, setFilter] = useState(null);
  const [grouped, setGrouped] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [hoverItem, setHoverItem] = useState(null);
  const [clusters, setClusters] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | live | idle | fallback
  const [mode, setMode] = useState(null);
  const [fps, setFps] = useState(null);
  const [announce, setAnnounce] = useState("");
  const [listOpen, setListOpen] = useState(false);

  useEffect(() => {
    uiRef.current = { filter, grouped, selectedId };
  }, [filter, grouped, selectedId]);

  const selectItem = useCallback((id) => {
    setSelectedId(id);
    engineRef.current?.select(id);
    if (id == null) {
      setAnnounce("Selection cleared.");
    } else {
      const item = itemById.get(id);
      setAnnounce(`${item.label} selected. ${categoryById[item.category].label}, ${item.year}.`);
    }
  }, []);

  const applyFilter = useCallback((f) => {
    setFilter(f);
    engineRef.current?.setFilter(f);
    setAnnounce(
      f
        ? `Showing ${categoryCounts[f]} ${categoryById[f].label.toLowerCase()} works of ${TOTAL}.`
        : `Showing all ${TOTAL} works.`
    );
  }, []);

  const applyGrouped = useCallback((g) => {
    setGrouped(g);
    engineRef.current?.setGrouped(g);
    setAnnounce(g ? "Grouped by discipline." : "Ungrouped: one field.");
  }, []);

  // Engine lifecycle. Pixi (and its chunk) loads lazily when the section
  // approaches the viewport; everything is torn down on unmount.
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;
    let engine = null;

    const lowPower =
      window.matchMedia("(pointer: coarse)").matches ||
      navigator.maxTouchPoints > 1 ||
      window.innerWidth < 768;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const io = new IntersectionObserver(
      (entries) => {
        if (!entries[0]?.isIntersecting || engine) return;
        io.disconnect();
        engine = new ConstellationEngine({
          host,
          items: constellationItems,
          categories: CATEGORIES,
          lowPower,
          reducedMotion,
          getInitialState: () => uiRef.current,
          callbacks: {
            onReady: () => {
              const e = engine;
              if (e) setMode({ low: e.lowPower, reduced: e.reducedMotion });
            },
            onSelect: (item) => {
              // Canvas tap/click: toggle off when re-picking the current node,
              // clear when picking empty sky.
              if (!item) selectItem(null);
              else selectItem(uiRef.current.selectedId === item.id ? null : item.id);
            },
            onHover: (item) => {
              setHoverItem(item);
              if (!item && tooltipRef.current) tooltipRef.current.style.opacity = "0";
            },
            onHoverMove: (x, y) => {
              const el = tooltipRef.current;
              if (!el) return;
              el.style.opacity = "1";
              el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -100%)`;
            },
            onClusters: (c) => setClusters(c),
            onRunState: (running) => setStatus(running ? "live" : "idle"),
            onStats: ({ fps: value }) => setFps(value),
          },
        });
        engineRef.current = engine;
        engine.init().catch((err) => {
          console.error("Constellation could not start WebGL:", err);
          setStatus("fallback");
          setListOpen(true);
          engine?.destroy();
          engine = null;
          engineRef.current = null;
        });
      },
      { rootMargin: "600px" }
    );
    io.observe(host);

    return () => {
      io.disconnect();
      engineRef.current = null;
      engine?.destroy();
      engine = null;
    };
  }, [selectItem]);

  const selectedItem = selectedId == null ? null : itemById.get(selectedId);
  const visibleGroups = filter ? itemsByCategory.filter((g) => g.id === filter) : itemsByCategory;
  const readout = [
    `n=${TOTAL}`,
    status === "fallback" ? "no gpu" : status,
    status === "live" && fps ? `${fps}fps` : null,
    mode?.low ? "touch mode" : null,
    mode?.reduced ? "reduced motion" : null,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <section aria-labelledby="constellation-title" className="space-y-6">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[var(--muted)]">
          Fig. 01 · Experience constellation
        </p>
        <p aria-hidden="true" className="font-mono text-[11px] tabular-nums tracking-[0.14em] text-[var(--muted)]">
          {readout}
        </p>
      </div>

      <div className="max-w-3xl space-y-3">
        <h2 id="constellation-title" className="text-3xl font-semibold tracking-tight">
          A decade of work, as a sky
        </h2>
        <p className="text-[var(--muted)] leading-7">
          Five hundred artifacts — shipped systems, annotated papers, design studies, and proof
          sketches — drawn as one field. Filter a discipline, group the sky, or pick any point to
          inspect it. Every point here is also in the list below the map.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by discipline">
        <button
          type="button"
          aria-pressed={filter === null}
          onClick={() => applyFilter(null)}
          className={`rounded-full border px-3 py-1.5 text-sm transition-colors motion-reduce:transition-none ${
            filter === null
              ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
              : "border-[var(--line)] bg-[var(--surface)] hover:border-[var(--muted)]"
          }`}
        >
          All · {TOTAL}
        </button>
        {CATEGORIES.map((cat) => {
          const active = filter === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              aria-pressed={active}
              onClick={() => applyFilter(active ? null : cat.id)}
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition-colors motion-reduce:transition-none ${
                active
                  ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                  : "border-[var(--line)] bg-[var(--surface)] hover:border-[var(--muted)]"
              }`}
            >
              <span
                aria-hidden="true"
                className="h-2.5 w-2.5 rounded-full"
                style={{ backgroundColor: cat.color }}
              />
              {cat.label} · {categoryCounts[cat.id]}
            </button>
          );
        })}
        <span aria-hidden="true" className="mx-1 hidden h-5 w-px bg-[var(--line)] sm:block" />
        <button
          type="button"
          aria-pressed={grouped}
          onClick={() => applyGrouped(!grouped)}
          className={`rounded-full border px-3 py-1.5 text-sm transition-colors motion-reduce:transition-none ${
            grouped
              ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
              : "border-[var(--line)] bg-[var(--surface)] hover:border-[var(--muted)]"
          }`}
        >
          Group by discipline
        </button>
      </div>

      <figure className="m-0 space-y-2">
        <div
          className="constellation-plate h-[clamp(380px,58vh,620px)] overflow-hidden rounded-xl"
          role="img"
          aria-label={`Map of ${TOTAL} works drawn as coloured points that drift, cluster, and respond to the pointer. The same works are available as buttons in the list titled “Browse all ${TOTAL} works as a list”.`}
        >
          <span aria-hidden="true" className="plate-ticks" />
          {/* Engine-owned mount point: React renders nothing inside it. */}
          <div ref={hostRef} className="constellation-host" />

          {status === "loading" && (
            <p
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 z-[2] grid place-items-center font-mono text-xs tracking-[0.2em] text-slate-500"
            >
              PLOTTING FIELD…
            </p>
          )}
          {status === "fallback" && (
            <p className="pointer-events-none absolute inset-0 z-[2] grid place-items-center px-6 text-center text-sm text-slate-400">
              This browser could not start the canvas. Every work is still available in the list
              below.
            </p>
          )}

          {/* Cluster labels (decorative: chips + list carry the semantics) */}
          {clusters?.map((c) => (
            <span
              key={c.id}
              aria-hidden="true"
              className="pointer-events-none absolute z-[2] -translate-x-1/2 font-mono text-[10px] uppercase"
              style={{
                left: c.x,
                top: Math.max(4, c.y - c.r - 18),
                color: categoryById[c.id].color,
                letterSpacing: "0.22em",
              }}
            >
              {categoryById[c.id].label} · {c.count}
            </span>
          ))}

          {/* Hover tooltip; position driven directly by the engine, no re-render */}
          <div
            ref={tooltipRef}
            aria-hidden="true"
            className="pointer-events-none absolute left-0 top-0 z-[3] whitespace-nowrap rounded-md border border-slate-700 bg-[#10141c]/95 px-2.5 py-1.5 font-mono text-[11px] text-slate-200 opacity-0"
          >
            {hoverItem ? (
              <>
                <span className="font-semibold text-white">{hoverItem.label}</span>
                <span className="text-slate-400">
                  {" "}
                  · {categoryById[hoverItem.category].label} · {hoverItem.year}
                </span>
              </>
            ) : null}
          </div>
        </div>
        <figcaption className="font-mono text-[11px] tracking-[0.06em] text-[var(--muted)]">
          Each point is one work; colour and silhouette encode its discipline. The field idles when
          it leaves the viewport.
        </figcaption>
      </figure>

      <div className="flex min-h-12 flex-wrap items-center gap-3 rounded-lg border border-[var(--line)] bg-[var(--surface)] px-4 py-3">
        {selectedItem ? (
          <>
            <span
              aria-hidden="true"
              className="h-3 w-3 shrink-0 rounded-full"
              style={{ backgroundColor: categoryById[selectedItem.category].color }}
            />
            <p className="m-0">
              <strong>{selectedItem.label}</strong>{" "}
              <span className="font-mono text-sm text-[var(--muted)]">
                {categoryById[selectedItem.category].label} · {selectedItem.year} · №
                {String(selectedItem.id + 1).padStart(3, "0")}
              </span>
            </p>
            <button
              type="button"
              onClick={() => selectItem(null)}
              className="ml-auto rounded-md border border-[var(--line)] px-3 py-1 text-sm hover:border-[var(--muted)]"
            >
              Clear selection
            </button>
          </>
        ) : (
          <p className="m-0 text-sm text-[var(--muted)]">
            Nothing selected — hover to preview, click a point to pin it, or use the list below.
          </p>
        )}
      </div>

      <p role="status" aria-live="polite" className="sr-only">
        {announce}
      </p>

      <details
        open={listOpen}
        onToggle={(e) => setListOpen(e.currentTarget.open)}
        className="rounded-lg border border-[var(--line)] bg-[var(--surface)]"
      >
        <summary className="cursor-pointer select-none px-4 py-3 font-medium">
          Browse all {TOTAL} works as a list
        </summary>
        <div className="grid gap-6 border-t border-[var(--line)] p-4 sm:grid-cols-2 lg:grid-cols-4">
          {visibleGroups.map((group) => (
            <section key={group.id} aria-labelledby={`constellation-cat-${group.id}`}>
              <h3
                id={`constellation-cat-${group.id}`}
                className="mb-1 flex items-center gap-2 text-sm font-semibold"
              >
                <span
                  aria-hidden="true"
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: group.color }}
                />
                {group.label} <span className="font-normal text-[var(--muted)]">({group.items.length})</span>
              </h3>
              <p className="mb-2 mt-0 text-xs text-[var(--muted)]">{group.blurb}</p>
              <ul className="m-0 max-h-72 list-none overflow-y-auto p-0 pr-1">
                {group.items.map((item) => {
                  const active = selectedId === item.id;
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        aria-pressed={active}
                        onClick={() => selectItem(active ? null : item.id)}
                        className={`flex w-full items-baseline justify-between gap-2 rounded px-2 py-1 text-left text-sm hover:bg-[color-mix(in_srgb,var(--foreground)_6%,transparent)] ${
                          active ? "bg-[color-mix(in_srgb,var(--foreground)_10%,transparent)] font-medium" : ""
                        }`}
                      >
                        <span>{item.label}</span>
                        <span className="shrink-0 font-mono text-xs text-[var(--muted)]">{item.year}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      </details>
    </section>
  );
}
