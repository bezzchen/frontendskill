// Bakes every badge glyph the constellation needs into ONE RenderTexture.
// ParticleContainer requires all particles to share a single texture source;
// baking (category shape x hue x letter) cells into one atlas keeps the whole
// 500-node field to a single batched draw call.

const INK = "#0c1016";

function hexToInt(hex) {
  return parseInt(hex.slice(1), 16);
}

function darken(hex, f) {
  const v = hexToInt(hex);
  const r = Math.round(((v >> 16) & 0xff) * f);
  const g = Math.round(((v >> 8) & 0xff) * f);
  const b = Math.round((v & 0xff) * f);
  return (r << 16) | (g << 8) | b;
}

function hexPoints(R) {
  const pts = [];
  for (let k = 0; k < 6; k += 1) {
    const a = -Math.PI / 2 + (k * Math.PI) / 3;
    pts.push(R * Math.cos(a), R * Math.sin(a));
  }
  return pts;
}

// Badge silhouette doubles as a category signal (redundant with hue, helps CVD).
const SHAPES = ["round", "circle", "squircle", "hex"];

function drawBadge(PIXI, shape, S, color) {
  const g = new PIXI.Graphics();
  const rim = darken(color, 0.55);
  if (shape === "round") g.roundRect(-S / 2, -S / 2, S, S, S * 0.2);
  else if (shape === "circle") g.circle(0, 0, S / 2);
  else if (shape === "squircle") g.roundRect(-S / 2, -S / 2, S, S, S * 0.44);
  else g.poly(hexPoints(S * 0.56));
  g.fill({ color: hexToInt(color) });
  g.stroke({ width: 3, color: rim, alpha: 1 });
  return g;
}

/**
 * Build the shared atlas.
 * @returns {{ rt: RenderTexture, frames: Map<string, Texture>, cell: number }}
 *   frames key: `${categoryId}:${glyphLetter}`
 */
export function buildAtlas(PIXI, renderer, items, categories, { resolution = 2, cell = 80 } = {}) {
  // Unique (category, letter) pairs actually used by the data.
  const keys = [];
  const seen = new Set();
  for (const item of items) {
    const key = `${item.category}:${item.glyph}`;
    if (!seen.has(key)) {
      seen.add(key);
      keys.push(key);
    }
  }

  const cols = 8;
  const rows = Math.ceil(keys.length / cols);
  const rt = PIXI.RenderTexture.create({
    width: cols * cell,
    height: rows * cell,
    resolution,
    antialias: true,
  });

  const catIndex = Object.fromEntries(categories.map((c, i) => [c.id, i]));
  const catColor = Object.fromEntries(categories.map((c) => [c.id, c.color]));

  const scene = new PIXI.Container();
  const S = cell * 0.76;
  keys.forEach((key, i) => {
    const [cat, letter] = key.split(":");
    const badge = new PIXI.Container();
    badge.position.set((i % cols) * cell + cell / 2, Math.floor(i / cols) * cell + cell / 2);
    badge.addChild(drawBadge(PIXI, SHAPES[catIndex[cat] % SHAPES.length], S, catColor[cat]));
    const mark = new PIXI.Text({
      text: letter,
      style: {
        fontFamily: 'ui-monospace, "SF Mono", Menlo, Consolas, monospace',
        fontSize: S * 0.56,
        fontWeight: "700",
        fill: INK,
      },
      resolution,
    });
    mark.anchor.set(0.5);
    mark.position.set(0, 1);
    badge.addChild(mark);
    scene.addChild(badge);
  });

  renderer.render({ container: scene, target: rt });
  // The bake scene (Graphics contexts, Text canvases) is no longer needed.
  scene.destroy({ children: true, texture: true, textureSource: true });

  const frames = new Map();
  keys.forEach((key, i) => {
    frames.set(
      key,
      new PIXI.Texture({
        source: rt.source, // one shared source -> ParticleContainer stays one batch
        frame: new PIXI.Rectangle((i % cols) * cell, Math.floor(i / cols) * cell, cell, cell),
        label: `constellation-${key}`,
      })
    );
  });

  return { rt, frames, cell };
}
