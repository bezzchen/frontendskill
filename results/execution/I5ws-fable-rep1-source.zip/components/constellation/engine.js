// ConstellationEngine — owns the Pixi application, the single render loop, all
// canvas-side interaction, and every GPU resource. React never touches Pixi:
// the section component calls the small public API below and receives events
// through callbacks.
//
// Render-loop ownership rules implemented here:
//  * exactly ONE ticker runs (app.ticker); Pixi's shared ticker is stopped and
//    the EventSystem's Ticker.system listener is detached (we use native
//    pointer events instead of Pixi's event system);
//  * the loop pauses when the section is offscreen (IntersectionObserver),
//    when the tab is hidden (visibilitychange), and when the simulation has
//    settled with nothing animating (auto-sleep — this is how the canvas idles
//    at zero cost under prefers-reduced-motion).
//
// pixi.js is imported dynamically inside init() so it never runs during SSR
// and stays out of the initial JS bundle.

import { computeTargets, hash01 } from "./layouts";
import { buildAtlas } from "./atlas";

const PLATE_INK = 0x0b0e14;
const DIM_ALPHA = 0.1;
const DIM_SCALE = 0.78;
const SETTLE_FRAMES = 45;
const SETTLE_EPS = 0.035;

let liveInstances = 0;

export class ConstellationEngine {
  constructor({ host, items, categories, lowPower, reducedMotion, callbacks, getInitialState }) {
    this.host = host;
    this.items = items;
    this.categories = categories;
    this.categoryIds = categories.map((c) => c.id);
    this.lowPower = !!lowPower;
    this.reducedMotion = !!reducedMotion;
    this.cb = callbacks || {};
    this.getInitialState = getInitialState;

    this.n = items.length;
    this.destroyed = false;
    this.ready = false;
    this._counted = false;

    // UI state (mirrored from React via applyState/setters)
    this.filter = null;
    this.grouped = false;
    this.selectedIdx = -1;
    this.hoverIdx = -1;

    // run gates
    this.pageVisible = typeof document !== "undefined" ? !document.hidden : true;
    this.inView = false;
    this.sleeping = false;
    this._settled = 0;
    this._frames = 0;
    this._running = false;
    this._statFrames = 0;
    this._statMS = 0;
    this._timeS = 0;

    this.pointer = { x: 0, y: 0, inside: false, active: false, isTouch: false, downX: 0, downY: 0, downAt: 0 };
    this.viewW = 0;
    this.viewH = 0;

    this._listeners = [];
  }

  // ---------------------------------------------------------------- lifecycle

  async init() {
    const host = this.host;
    const PIXI = await import("pixi.js");
    if (this.destroyed) return false;
    this.PIXI = PIXI;

    // Rule: no library ticker may free-run besides the one we own.
    PIXI.Ticker.shared.autoStart = false;
    PIXI.Ticker.shared.stop();

    const dpr = Math.min(globalThis.devicePixelRatio || 1, this.lowPower ? 1.5 : 2);
    const app = new PIXI.Application();
    await app.init({
      width: Math.max(2, host.clientWidth),
      height: Math.max(2, host.clientHeight),
      background: PLATE_INK,
      antialias: !this.lowPower,
      resolution: dpr,
      autoDensity: true,
      preference: "webgl",
      powerPreference: this.lowPower ? "low-power" : "high-performance",
      // We never use Pixi's event system; disable its features outright.
      eventFeatures: { move: false, globalMove: false, click: false, wheel: false },
    });
    if (this.destroyed) {
      app.destroy({ removeView: true }, { children: true, texture: true, textureSource: true, context: true });
      return false;
    }
    this.app = app;

    // Detach Pixi's EventSystem entirely: removes its document/global pointer
    // listeners AND its interaction listener on the auto-starting Ticker.system.
    app.renderer.events.setTargetElement(null);
    app.stage.eventMode = "none";
    app.stage.interactiveChildren = false;

    // We own start/stop; nothing runs until the visibility gates allow it.
    app.stop();
    // v8's SchedulerSystem parks a permanent listener on the auto-starting
    // Ticker.system (it drives periodic GPU-resource GC). Gate it with the
    // same run gates as our loop: frozen here, started/stopped in
    // _updateRunState so GC still runs while the field is live.
    PIXI.Ticker.system.stop();
    if (this.lowPower) app.ticker.maxFPS = 30;

    this.viewW = app.renderer.width;
    this.viewH = app.renderer.height;

    const canvas = app.canvas;
    canvas.className = "constellation-canvas";
    canvas.setAttribute("aria-hidden", "true");
    host.appendChild(canvas);
    this.canvas = canvas;

    // --- atlas + particles -------------------------------------------------
    const atlas = buildAtlas(PIXI, app.renderer, this.items, this.categories, { resolution: dpr });
    this.atlas = atlas;
    // Small at rest (a sky, not confetti); hover/selection magnify to legibility.
    this.baseScale = this.lowPower ? 0.18 : 0.27;
    this.nodeRadius = (atlas.cell / 2) * this.baseScale;

    const n = this.n;
    this.x = new Float32Array(n);
    this.y = new Float32Array(n);
    this.vx = new Float32Array(n);
    this.vy = new Float32Array(n);
    this.s = new Float32Array(n);
    this.a = new Float32Array(n);
    this.jitter = new Float32Array(n);
    this.ph1 = new Float32Array(n);
    this.ph2 = new Float32Array(n);
    this.f1 = new Float32Array(n);
    this.f2 = new Float32Array(n);
    this.dimmed = new Uint8Array(n);
    this.idToIndex = new Map();

    const layout = this._layout();
    this.tx = layout.tx;
    this.ty = layout.ty;
    this.clusters = layout.clusters;

    const pc = new PIXI.ParticleContainer({
      // position: drift/regroup; vertex: hover/selection scaling; color: filter fades.
      // rotation and uvs never change -> static attributes.
      dynamicProperties: { position: true, vertex: true, color: true, rotation: false, uvs: false },
    });
    this.particleContainer = pc;
    this.particles = new Array(n);

    for (let i = 0; i < n; i += 1) {
      const item = this.items[i];
      this.idToIndex.set(item.id, i);
      const j = 0.9 + hash01(item.id * 7 + 3) * 0.24;
      this.jitter[i] = j;
      this.ph1[i] = hash01(item.id * 5 + 1) * Math.PI * 2;
      this.ph2[i] = hash01(item.id * 5 + 2) * Math.PI * 2;
      this.f1[i] = 0.22 + hash01(item.id * 5 + 4) * 0.3; // rad/s — slow
      this.f2[i] = 0.18 + hash01(item.id * 5 + 5) * 0.28;
      this.x[i] = this.tx[i];
      this.y[i] = this.ty[i];
      this.s[i] = this.baseScale * j;
      this.a[i] = this.reducedMotion ? 1 : 0; // gentle fade-in unless PRM
      const particle = new PIXI.Particle({
        texture: atlas.frames.get(`${item.category}:${item.glyph}`),
        x: this.x[i],
        y: this.y[i],
        anchorX: 0.5,
        anchorY: 0.5,
        scaleX: this.s[i],
        scaleY: this.s[i],
        alpha: this.a[i],
      });
      this.particles[i] = particle;
      pc.addParticle(particle);
    }
    app.stage.addChild(pc);

    // --- selection / hover rings (2 Graphics, ordinary container) ----------
    this.overlay = new PIXI.Container();
    this.hoverRing = new PIXI.Graphics();
    this.selRing = new PIXI.Graphics();
    this.hoverRing.visible = false;
    this.selRing.visible = false;
    this.overlay.addChild(this.hoverRing, this.selRing);
    app.stage.addChild(this.overlay);
    this._drawHoverRing();

    // --- listeners / observers ---------------------------------------------
    this._bindDom();

    // --- loop ----------------------------------------------------------------
    this._tick = this._tick.bind(this);
    app.ticker.add(this._tick);

    this.ready = true;
    liveInstances += 1;
    this._counted = true;
    this._exposeDebug();

    // Adopt whatever the UI already shows (filter may have been set while lazy-loading).
    const initial = this.getInitialState ? this.getInitialState() : null;
    if (initial) this.applyState(initial, { animate: false });

    app.render(); // guarantee a first paint even if gates keep the loop off
    this._updateRunState();
    this.cb.onReady?.();
    return true;
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.cb = {};

    for (const [target, type, fn, opts] of this._listeners) target.removeEventListener(type, fn, opts);
    this._listeners = [];
    this._io?.disconnect();
    this._io = null;
    this._ro?.disconnect();
    this._ro = null;

    if (this.app) {
      this.app.ticker.remove(this._tick);
      // Destroys renderer + context, stage children (ParticleContainer,
      // overlay Graphics), their textures and texture sources, and removes
      // the canvas from the DOM.
      this.app.destroy(
        { removeView: true },
        { children: true, texture: true, textureSource: true, context: true }
      );
      this.app = null;
    }
    if (this.atlas) {
      // Frames wrap the shared render texture; make sure both are released
      // even if the stage destroy above missed them (guarded internally).
      for (const tex of this.atlas.frames.values()) if (!tex.destroyed) tex.destroy(false);
      if (!this.atlas.rt.destroyed) this.atlas.rt.destroy(true);
      this.atlas = null;
    }
    this.particles = null;
    this.particleContainer = null;
    this.canvas = null;

    if (this._counted) {
      liveInstances -= 1;
      this._counted = false;
    }
    if (typeof window !== "undefined" && window.__constellation?.engine === this) {
      delete window.__constellation;
    }
  }

  // ---------------------------------------------------------------- public UI

  applyState({ filter = null, grouped = false, selectedId = null }, { animate = true } = {}) {
    if (!this.ready) return;
    this.filter = filter;
    this.grouped = grouped;
    this._applyDim();
    this._relayout(animate);
    this.select(selectedId, { silent: true });
    this._wake();
  }

  setFilter(filter) {
    if (!this.ready) return;
    this.filter = filter;
    this._applyDim();
    this._relayout(true);
    this._wake();
  }

  setGrouped(grouped) {
    if (!this.ready) return;
    this.grouped = grouped;
    this._relayout(true);
    this._wake();
  }

  select(id, { silent = false } = {}) {
    if (!this.ready) return;
    const idx = id == null ? -1 : this.idToIndex.get(id) ?? -1;
    this.selectedIdx = idx;
    this._drawSelRing();
    this._wake();
  }

  // ---------------------------------------------------------------- internals

  _layout() {
    return computeTargets({
      items: this.items,
      categoryIds: this.categoryIds,
      w: this.viewW,
      h: this.viewH,
      grouped: this.grouped,
      filter: this.grouped ? null : this.filter,
    });
  }

  _relayout(animate) {
    const layout = this._layout();
    this.tx = layout.tx;
    this.ty = layout.ty;
    this.clusters = layout.clusters;
    if (!animate || this.reducedMotion) {
      for (let i = 0; i < this.n; i += 1) {
        this.x[i] = this.tx[i];
        this.y[i] = this.ty[i];
        this.vx[i] = 0;
        this.vy[i] = 0;
      }
    }
    this.cb.onClusters?.(this.grouped ? this.clusters : null);
  }

  _applyDim() {
    const f = this.filter;
    for (let i = 0; i < this.n; i += 1) {
      this.dimmed[i] = f && this.items[i].category !== f ? 1 : 0;
    }
  }

  _bindDom() {
    const on = (target, type, fn, opts) => {
      target.addEventListener(type, fn, opts);
      this._listeners.push([target, type, fn, opts]);
    };
    const canvas = this.canvas;

    on(canvas, "pointermove", (e) => {
      const p = this.pointer;
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      p.x = ((e.clientX - rect.left) / rect.width) * this.viewW;
      p.y = ((e.clientY - rect.top) / rect.height) * this.viewH;
      p.isTouch = e.pointerType !== "mouse";
      p.inside = !p.isTouch;
      this._wake();
    });
    on(canvas, "pointerdown", (e) => {
      const p = this.pointer;
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      p.x = ((e.clientX - rect.left) / rect.width) * this.viewW;
      p.y = ((e.clientY - rect.top) / rect.height) * this.viewH;
      p.isTouch = e.pointerType !== "mouse";
      p.active = true;
      p.downX = e.clientX;
      p.downY = e.clientY;
      p.downAt = performance.now();
      this._wake();
    });
    on(canvas, "pointerup", (e) => {
      const p = this.pointer;
      const moved = Math.hypot(e.clientX - p.downX, e.clientY - p.downY);
      const quick = performance.now() - p.downAt < 700;
      p.active = false;
      if (moved < 7 && quick) {
        const rect = canvas.getBoundingClientRect();
        if (rect.width && rect.height) {
          const px = ((e.clientX - rect.left) / rect.width) * this.viewW;
          const py = ((e.clientY - rect.top) / rect.height) * this.viewH;
          const idx = this._pick(px, py);
          this.cb.onSelect?.(idx === -1 ? null : this.items[idx]);
        }
      }
      this._wake();
    });
    const clearPointer = () => {
      this.pointer.inside = false;
      this.pointer.active = false;
      this._wake(); // one more pass so hover state clears, then it settles
    };
    on(canvas, "pointerleave", clearPointer);
    on(canvas, "pointercancel", clearPointer);

    on(document, "visibilitychange", () => {
      this.pageVisible = !document.hidden;
      this._updateRunState();
    });

    this._io = new IntersectionObserver(
      (entries) => {
        this.inView = entries[0]?.isIntersecting ?? false;
        if (this.inView) this._wake();
        else this._updateRunState();
      },
      { rootMargin: "80px", threshold: 0 }
    );
    this._io.observe(this.host);

    this._ro = new ResizeObserver(() => this._resize());
    this._ro.observe(this.host);

    this._mq = matchMedia("(prefers-reduced-motion: reduce)");
    const onMq = () => {
      this.reducedMotion = this._mq.matches;
      this._relayout(false);
      this._wake();
    };
    on(this._mq, "change", onMq);
  }

  _resize() {
    if (!this.ready || this.destroyed) return;
    const w = this.host.clientWidth;
    const h = this.host.clientHeight;
    if (!w || !h || (w === this.viewW && h === this.viewH)) return;
    this.app.renderer.resize(w, h);
    this.viewW = w;
    this.viewH = h;
    this._relayout(false); // resize is not a choreography moment: snap to the new map
    this._drawSelRing();
    this._wake();
  }

  _pick(px, py) {
    let best = -1;
    let bestD2 = Infinity;
    for (let i = 0; i < this.n; i += 1) {
      const dx = this.x[i] - px;
      const dy = this.y[i] - py;
      const d2 = dx * dx + dy * dy;
      const r = (this.atlas.cell / 2) * this.s[i] + 12;
      if (d2 < r * r && d2 < bestD2) {
        bestD2 = d2;
        best = i;
      }
    }
    return best;
  }

  // ------------------------------------------------------------------- loop

  _tick(ticker) {
    const dtF = Math.min(ticker.deltaTime, 3); // 60fps-normalised frames
    this._timeS += ticker.deltaMS / 1000;
    this._frames += 1;

    // fps readout, once per second
    this._statFrames += 1;
    this._statMS += ticker.deltaMS;
    if (this._statMS >= 1000) {
      this.cb.onStats?.({ fps: Math.round((this._statFrames * 1000) / this._statMS) });
      this._statFrames = 0;
      this._statMS = 0;
    }

    const n = this.n;
    const reduced = this.reducedMotion;
    const amp = reduced ? 0 : this.lowPower ? 2.0 : 3.2;
    const p = this.pointer;
    const forcesOn = !reduced && ((p.inside && !this.lowPower) || (p.isTouch && p.active));
    const trackPointer = p.inside || (p.isTouch && p.active);
    const magR = 90;
    const repR = this.lowPower ? 100 : 130;
    const damp = Math.pow(0.86, dtF);
    const K = 0.006 * dtF;
    const sel = this.selectedIdx;
    const t = this._timeS;

    // The node currently courted by the cursor (nearest within the magnify
    // radius, decided last frame) is exempt from repulsion — otherwise the
    // repel force pushes every node out of its own pick radius and hover can
    // never engage. The crowd parts; the courted node stays and magnifies.
    const cand = this._cand ?? -1;
    let nearest = -1;
    let nearestD2 = Infinity;
    let maxDelta = 0;

    for (let i = 0; i < n; i += 1) {
      // ambient drift target around the layout target
      let ax = this.tx[i];
      let ay = this.ty[i];
      if (amp > 0) {
        ax += amp * Math.sin(t * this.f1[i] + this.ph1[i]);
        ay += amp * Math.cos(t * this.f2[i] + this.ph2[i]);
      }

      let dx = 0;
      let dy = 0;
      let d2 = Infinity;
      if (trackPointer) {
        dx = this.x[i] - p.x;
        dy = this.y[i] - p.y;
        d2 = dx * dx + dy * dy;
        if (p.inside && d2 < nearestD2) {
          nearestD2 = d2;
          nearest = i;
        }
      }

      if (reduced) {
        // No ambient, no springs: nodes sit exactly on their targets.
        this.x[i] = ax;
        this.y[i] = ay;
        this.vx[i] = 0;
        this.vy[i] = 0;
      } else {
        let vx = this.vx[i] * damp + (ax - this.x[i]) * K;
        let vy = this.vy[i] * damp + (ay - this.y[i]) * K;
        if (forcesOn && i !== cand && d2 < repR * repR && d2 > 0.01) {
          const d = Math.sqrt(d2);
          const f = ((1 - d / repR) * (1 - d / repR) * 0.55 * dtF) / d;
          vx += dx * f;
          vy += dy * f;
        }
        this.vx[i] = vx;
        this.vy[i] = vy;
        this.x[i] += vx * dtF;
        this.y[i] += vy * dtF;
        const v = Math.abs(vx) + Math.abs(vy);
        if (v > maxDelta) maxDelta = v;
      }

      // scale target: base jitter, then selection/hover/dim/magnify modifiers
      let ts = this.baseScale * this.jitter[i];
      const isDim = this.dimmed[i] === 1 && i !== sel;
      if (isDim) ts *= DIM_SCALE;
      if (i === sel) ts *= 1.5;
      if (i === this.hoverIdx) ts *= 1.35;
      if (forcesOn && !p.isTouch && d2 < magR * magR) {
        const m = 1 - Math.sqrt(d2) / magR;
        ts *= 1 + 0.6 * m * m;
      }
      const ta = isDim ? DIM_ALPHA : 1;
      if (reduced) {
        this.s[i] = ts;
        this.a[i] = ta;
      } else {
        const ds = (ts - this.s[i]) * Math.min(1, 0.22 * dtF);
        const da = (ta - this.a[i]) * Math.min(1, 0.12 * dtF);
        this.s[i] += ds;
        this.a[i] += da;
        const m = Math.abs(ds) + Math.abs(da) * 24;
        if (m > maxDelta) maxDelta = m;
      }

      const particle = this.particles[i];
      particle.x = this.x[i];
      particle.y = this.y[i];
      particle.scaleX = this.s[i];
      particle.scaleY = this.s[i];
      particle.alpha = this.a[i];
    }

    // hover bookkeeping (mouse only): nearest within the magnify radius is
    // the candidate (repel-exempt next frame); within its own pick radius it
    // becomes the hovered node.
    let hover = -1;
    if (p.inside && nearest !== -1 && nearestD2 < magR * magR) {
      this._cand = nearest;
      const r = (this.atlas.cell / 2) * this.s[nearest] + 10;
      if (nearestD2 < r * r) hover = nearest;
    } else {
      this._cand = -1;
    }
    if (hover !== this.hoverIdx) {
      this.hoverIdx = hover;
      this.hoverRing.visible = hover !== -1;
      this.cb.onHover?.(hover === -1 ? null : this.items[hover]);
    }
    if (hover !== -1) {
      this.hoverRing.position.set(this.x[hover], this.y[hover]);
      const k = this.s[hover] / this.baseScale;
      this.hoverRing.scale.set(k);
      this.cb.onHoverMove?.(this.x[hover], this.y[hover] - this.nodeRadius * k - 6);
    }
    if (sel !== -1) {
      this.selRing.position.set(this.x[sel], this.y[sel]);
      this.selRing.scale.set(this.s[sel] / this.baseScale);
    }

    // auto-sleep: with ambient drift there is always work; under
    // prefers-reduced-motion the field settles and the loop stops itself.
    const busy = amp > 0 || trackPointer || p.active || maxDelta > SETTLE_EPS;
    this._settled = busy ? 0 : this._settled + 1;
    if (this._settled > SETTLE_FRAMES) this._sleep();
  }

  // ------------------------------------------------------------------ rings

  _drawHoverRing() {
    const r = this.nodeRadius + 5;
    this.hoverRing.clear();
    this.hoverRing.circle(0, 0, r).stroke({ width: 1.5, color: 0xffffff, alpha: 0.55 });
  }

  _drawSelRing() {
    const idx = this.selectedIdx;
    this.selRing.clear();
    if (idx === -1) {
      this.selRing.visible = false;
      return;
    }
    const color = parseInt(this.categories.find((c) => c.id === this.items[idx].category).color.slice(1), 16);
    const r = this.nodeRadius + 6;
    this.selRing.circle(0, 0, r).stroke({ width: 2, color, alpha: 0.95 });
    this.selRing.circle(0, 0, r + 5).stroke({ width: 1, color, alpha: 0.35 });
    this.selRing.visible = true;
    this.selRing.position.set(this.x[idx], this.y[idx]);
  }

  // ------------------------------------------------------------------ gates

  _updateRunState() {
    if (!this.ready || this.destroyed) return;
    const shouldRun = this.pageVisible && this.inView && !this.sleeping;
    if (shouldRun && !this._running) {
      this._running = true;
      this.app.start();
      this.PIXI.Ticker.system.start(); // resume Pixi's scheduler (GC) with us
    } else if (!shouldRun && this._running) {
      this._running = false;
      this.app.stop();
      this.PIXI.Ticker.system.stop(); // no rendering -> no background scheduler work
    }
    this.cb.onRunState?.(this._running);
  }

  _wake() {
    if (this.destroyed || !this.ready) return;
    this._settled = 0;
    if (this.sleeping) this.sleeping = false;
    this._updateRunState();
  }

  _sleep() {
    if (this.sleeping) return;
    this.sleeping = true;
    this._updateRunState();
  }

  // ------------------------------------------------------------------ debug

  _exposeDebug() {
    if (process.env.NODE_ENV === "production" || typeof window === "undefined") return;
    const engine = this;
    window.__constellation = {
      engine,
      get frames() {
        return engine._frames;
      },
      get running() {
        return engine._running;
      },
      get sleeping() {
        return engine.sleeping;
      },
      get inView() {
        return engine.inView;
      },
      get pageVisible() {
        return engine.pageVisible;
      },
      get nodeCount() {
        return engine.n;
      },
      get lowPower() {
        return engine.lowPower;
      },
      get reducedMotion() {
        return engine.reducedMotion;
      },
      get resolution() {
        return engine.app?.renderer.resolution;
      },
      get sharedTickerStarted() {
        return engine.PIXI.Ticker.shared.started;
      },
      get systemTickerListeners() {
        return engine.PIXI.Ticker.system.count;
      },
      get instances() {
        return liveInstances;
      },
    };
  }
}
