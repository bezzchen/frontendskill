// Pure, deterministic layout targets for the constellation.
// All functions are hash/seed based so server, client, and every re-render agree.

const GOLDEN = Math.PI * (3 - Math.sqrt(5)); // golden angle

function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hash01(n) {
  let x = (n + 0x9e3779b9) >>> 0;
  x = Math.imul(x ^ (x >>> 16), 0x21f0aaad) >>> 0;
  x = Math.imul(x ^ (x >>> 15), 0x735a2d97) >>> 0;
  return ((x ^ (x >>> 15)) >>> 0) / 4294967296;
}

/** Evenly scattered "sky": jittered grid with a seeded permutation so categories interleave. */
function scatterInto(tx, ty, items, w, h, pad) {
  const n = items.length;
  const iw = Math.max(1, w - pad * 2);
  const ih = Math.max(1, h - pad * 2);
  const cols = Math.max(1, Math.round(Math.sqrt(n * (iw / ih))));
  const rows = Math.ceil(n / cols);
  const cellW = iw / cols;
  const cellH = ih / rows;
  const cellCount = cols * rows;

  // Seeded Fisher-Yates permutation of grid cells.
  const perm = new Uint32Array(cellCount);
  for (let i = 0; i < cellCount; i += 1) perm[i] = i;
  const rand = mulberry32(0x5eed);
  for (let i = cellCount - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    const t = perm[i];
    perm[i] = perm[j];
    perm[j] = t;
  }

  for (let i = 0; i < n; i += 1) {
    const cell = perm[i];
    const cx = cell % cols;
    const cy = Math.floor(cell / cols);
    const id = items[i].id;
    const jx = (hash01(id * 2 + 1) - 0.5) * cellW * 0.92;
    const jy = (hash01(id * 2 + 2) - 0.5) * cellH * 0.92;
    tx[i] = pad + (cx + 0.5) * cellW + jx;
    ty[i] = pad + (cy + 0.5) * cellH + jy;
  }
}

/** Phyllotaxis disc: the j-th of `count` points in a disc of radius R at (cx, cy). */
function phyllotaxis(j, count, cx, cy, R, angleSeed) {
  const r = R * Math.sqrt((j + 0.5) / count);
  const theta = j * GOLDEN + angleSeed;
  return [cx + r * Math.cos(theta), cy + r * Math.sin(theta)];
}

function clusterGrid(categoryIds, w, h, pad) {
  const k = categoryIds.length;
  const iw = w - pad * 2;
  const ih = h - pad * 2;
  const wide = iw / ih > 2.1;
  const cols = wide ? k : Math.ceil(Math.sqrt(k));
  const rows = Math.ceil(k / cols);
  const cellW = iw / cols;
  const cellH = ih / rows;
  const R = Math.min(cellW, cellH) * 0.46;
  return categoryIds.map((id, i) => ({
    id,
    x: pad + ((i % cols) + 0.5) * cellW,
    y: pad + (Math.floor(i / cols) + 0.5) * cellH,
    r: R,
  }));
}

/**
 * Compute target positions for every node.
 * @returns {{ tx: Float32Array, ty: Float32Array, clusters: Array|null }}
 */
export function computeTargets({ items, categoryIds, w, h, grouped, filter }) {
  const n = items.length;
  const tx = new Float32Array(n);
  const ty = new Float32Array(n);
  const pad = Math.max(26, Math.min(w, h) * 0.07);
  let clusters = null;

  if (grouped) {
    const centers = clusterGrid(categoryIds, w, h, pad);
    const byCat = Object.fromEntries(centers.map((c) => [c.id, c]));
    const counts = {};
    const seen = {};
    for (let i = 0; i < n; i += 1) counts[items[i].category] = (counts[items[i].category] || 0) + 1;
    for (let i = 0; i < n; i += 1) {
      const cat = items[i].category;
      const c = byCat[cat];
      const j = (seen[cat] = (seen[cat] || 0) + 1) - 1;
      const catIndex = categoryIds.indexOf(cat);
      const [x, y] = phyllotaxis(j, counts[cat], c.x, c.y, c.r, catIndex * 1.7);
      tx[i] = x;
      ty[i] = y;
    }
    clusters = centers.map((c) => ({ ...c, count: counts[c.id] || 0 }));
  } else {
    scatterInto(tx, ty, items, w, h, pad);
    if (filter) {
      // Filtered discipline gathers into a centre disc; the rest stay scattered, dimmed by the engine.
      let count = 0;
      for (let i = 0; i < n; i += 1) if (items[i].category === filter) count += 1;
      const R = Math.min(w, h) * 0.42 - pad * 0.4;
      let j = 0;
      for (let i = 0; i < n; i += 1) {
        if (items[i].category !== filter) continue;
        const [x, y] = phyllotaxis(j, count, w / 2, h / 2, Math.max(40, R), 0.9);
        tx[i] = x;
        ty[i] = y;
        j += 1;
      }
    }
  }

  return { tx, ty, clusters };
}
