// Shared, deterministic dataset for the experience constellation.
// Imported by both the server-rendered semantic list and the client-side
// Pixi engine, so everything here must be pure and stable across runs
// (no Date.now, no Math.random).

export const CATEGORIES = {
  engineering: {
    label: "Engineering",
    // Hue used for canvas tiles; css used for DOM accents (chips, legend, list dots).
    hue: 215,
    css: "#5b8def",
  },
  research: {
    label: "Research",
    hue: 36,
    css: "#e0a43c",
  },
  design: {
    label: "Design",
    hue: 330,
    css: "#e06ca8",
  },
  math: {
    label: "Math",
    hue: 160,
    css: "#3fbf9a",
  },
};

export const CATEGORY_IDS = Object.keys(CATEGORIES);

const NAME_POOLS = {
  engineering: {
    a: ["Raft", "Anvil", "Socket", "Beacon", "Ledger", "Foundry", "Gantry", "Piston", "Quill", "Crank"],
    b: ["Compiler", "Scheduler", "Cache", "Pipeline", "Runtime", "Allocator", "Router", "Debugger", "Emulator", "Cluster", "Daemon", "Kernel", "Queue"],
  },
  research: {
    a: ["Spectral", "Latent", "Neural", "Bayesian", "Markov", "Sparse", "Convex", "Stochastic", "Causal", "Quantized"],
    b: ["Fields", "Priors", "Embeddings", "Dynamics", "Inference", "Sampling", "Attention", "Manifolds", "Kernels", "Gradients", "Bandits", "Encoders", "Entropy"],
  },
  design: {
    a: ["Grain", "Umbra", "Facet", "Cadence", "Vellum", "Prism", "Contour", "Halftone", "Marrow", "Gossamer"],
    b: ["Grid", "Type", "Poster", "Palette", "Motion", "Layout", "Glyphs", "Icons", "Slides", "Textures", "Frames", "System", "Study"],
  },
  math: {
    a: ["Euler", "Gauss", "Fermat", "Noether", "Hilbert", "Riemann", "Poincare", "Galois", "Ramanujan", "Erdos"],
    b: ["Orbits", "Lattices", "Primes", "Knots", "Graphs", "Tilings", "Series", "Groups", "Curves", "Flows", "Proofs", "Sets", "Forms"],
  },
};

const KINDS = ["project", "prototype", "paper", "talk", "tool", "study"];

// mulberry32: tiny deterministic PRNG (integer math via Math.imul, so it is
// stable between Node SSR and every browser engine).
function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(0x5eed);

export const constellationItems = Array.from({ length: 500 }, (_, index) => {
  // Preserve the original id -> category mapping from the seed dataset.
  const category = CATEGORY_IDS[index % 4];
  const ordinal = Math.floor(index / 4); // 0..124 within the category
  const pool = NAME_POOLS[category];
  const label = `${pool.a[ordinal % pool.a.length]} ${pool.b[Math.floor(ordinal / pool.a.length) % pool.b.length]}`;
  const r1 = rand();
  const r2 = rand();
  const r3 = rand();
  const r4 = rand();
  return {
    id: index,
    label,
    category,
    monogram: label.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase(),
    kind: KINDS[Math.floor(r1 * KINDS.length)],
    year: 2014 + Math.floor(r2 * 13),
    // Seeds consumed by the canvas tile painter and the drift simulation.
    seed: r3,
    phase: r4 * Math.PI * 2,
  };
});

export const itemsByCategory = CATEGORY_IDS.reduce((acc, cat) => {
  acc[cat] = constellationItems.filter((item) => item.category === cat);
  return acc;
}, {});
