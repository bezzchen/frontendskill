// Pixi v8 engine for the experience constellation.
//
// Architecture notes (why it is shaped this way):
// - One Pixi Application with a DEDICATED ticker (sharedTicker: false,
//   autoStart: false). The single ticker callback owns simulation + render;
//   nothing else schedules frames. Pausing = app.stop(), so no library
//   ticker keeps running behind our back.
// - All 500 node tiles + the ring/glow utility tiles live on ONE
//   canvas-painted atlas (a single TextureSource), so the whole scene
//   batches into ~3 draw calls (additive glow layer / nodes / ring).
// - React never touches per-frame state. The component talks to this module
//   through the returned handle (setFilter/setLayout/select/...), and the
//   engine reports back through onSelect/onHover callbacks.
// - Reduced motion: nothing is ever animated; state changes snap and we
//   render exactly one frame on demand. The ticker never runs.
//
// This module is client-only. It must only be imported dynamically from a
// browser effect.

import { Application, Container, Sprite, Texture, Rectangle } from "pixi.js";
import { CATEGORIES, CATEGORY_IDS } from "@/components/ConstellationData";

const TILE = 88; // atlas cell size (px), content drawn inside with padding
const TILE_PAD = 6;
const ATLAS_COLS = 25;
const GOLDEN = Math.PI * (3 - Math.sqrt(5));

// ---------------------------------------------------------------------------
// Atlas painting: every node gets a small procedural "logo" tile (shape +
// category-hued gradient + monogram). Painted once, uploaded once.
// ---------------------------------------------------------------------------

function paintTile(ctx, cx, cy, item) {
  const { hue } = CATEGORIES[item.category];
  const s = item.seed;
  const inner = TILE - TILE_PAD * 2;
  const half = inner / 2;
  const h = hue + (s - 0.5) * 26;
  const light = 46 + s * 14;
  const grad = ctx.createLinearGradient(cx - half, cy - half, cx + half, cy + half);
  grad.addColorStop(0, `hsl(${h} 72% ${light + 12}%)`);
  grad.addColorStop(1, `hsl(${h + 14} 68% ${light - 10}%)`);
  ctx.fillStyle = grad;

  const shape = Math.floor(s * 4.999) % 5;
  ctx.beginPath();
  if (shape === 0) {
    // rounded square
    ctx.roundRect(cx - half, cy - half, inner, inner, inner * 0.28);
  } else if (shape === 1) {
    ctx.arc(cx, cy, half, 0, Math.PI * 2);
  } else if (shape === 2) {
    // hexagon
    for (let i = 0; i < 6; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 3;
      const px = cx + Math.cos(a) * half;
      const py = cy + Math.sin(a) * half;
      i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (shape === 3) {
    // diamond (rotated rounded square)
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(Math.PI / 4);
    ctx.roundRect(-half * 0.78, -half * 0.78, inner * 0.78, inner * 0.78, inner * 0.16);
    ctx.restore();
  } else {
    // squircle-ish blob
    ctx.roundRect(cx - half, cy - half * 0.92, inner, inner * 0.92, inner * 0.46);
  }
  ctx.fill();

  // top sheen
  ctx.save();
  ctx.clip();
  const sheen = ctx.createLinearGradient(cx, cy - half, cx, cy);
  sheen.addColorStop(0, "rgba(255,255,255,0.28)");
  sheen.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = sheen;
  ctx.fillRect(cx - half, cy - half, inner, half);
  ctx.restore();

  // monogram
  ctx.fillStyle = "rgba(255,255,255,0.94)";
  ctx.font = `600 ${Math.round(inner * 0.42)}px Arial, Helvetica, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(item.monogram, cx, cy + 1);
}

function buildAtlas(items) {
  const count = items.length + 2; // + ring + glow utility tiles
  const rows = Math.ceil(count / ATLAS_COLS);
  const canvas = document.createElement("canvas");
  canvas.width = ATLAS_COLS * TILE;
  canvas.height = rows * TILE;
  const ctx = canvas.getContext("2d");

  items.forEach((item, i) => {
    const cx = (i % ATLAS_COLS) * TILE + TILE / 2;
    const cy = Math.floor(i / ATLAS_COLS) * TILE + TILE / 2;
    paintTile(ctx, cx, cy, item);
  });

  // ring tile (white; tinted at runtime)
  const ringIndex = items.length;
  {
    const cx = (ringIndex % ATLAS_COLS) * TILE + TILE / 2;
    const cy = Math.floor(ringIndex / ATLAS_COLS) * TILE + TILE / 2;
    ctx.strokeStyle = "rgba(255,255,255,1)";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(cx, cy, (TILE - TILE_PAD * 2) / 2 - 3, 0, Math.PI * 2);
    ctx.stroke();
  }
  // glow tile (soft radial disc; tinted + additive at runtime)
  const glowIndex = items.length + 1;
  {
    const cx = (glowIndex % ATLAS_COLS) * TILE + TILE / 2;
    const cy = Math.floor(glowIndex / ATLAS_COLS) * TILE + TILE / 2;
    const r = (TILE - TILE_PAD) / 2;
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, "rgba(255,255,255,0.85)");
    g.addColorStop(0.45, "rgba(255,255,255,0.25)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const base = Texture.from(canvas);
  // Nodes render well below atlas size most of the time; mipmaps kill the
  // minification shimmer during drift.
  base.source.autoGenerateMipmaps = true;
  base.source.update();

  const frameFor = (i) =>
    new Texture({
      source: base.source,
      frame: new Rectangle(
        (i % ATLAS_COLS) * TILE + TILE_PAD,
        Math.floor(i / ATLAS_COLS) * TILE + TILE_PAD,
        TILE - TILE_PAD * 2,
        TILE - TILE_PAD * 2
      ),
    });

  return {
    base,
    nodeTextures: items.map((_, i) => frameFor(i)),
    ringTexture: frameFor(ringIndex),
    glowTexture: frameFor(glowIndex),
  };
}

// ---------------------------------------------------------------------------
// Layouts: pure functions from (visible nodes, w, h) -> target positions.
// ---------------------------------------------------------------------------

function hash01(n) {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

function computeLayout(mode, nodes, w, h) {
  const visible = nodes.filter((n) => n.inFilter);
  const cats = CATEGORY_IDS.filter((c) => visible.some((n) => n.item.category === c));
  const cx = w / 2;
  const cy = h / 2;
  const margin = Math.min(w, h) * 0.08 + 18;

  if (mode === "clusters") {
    const rx = w * 0.5 - margin - Math.min(w, h) * 0.16;
    const ry = h * 0.5 - margin - Math.min(w, h) * 0.16;
    cats.forEach((cat, ci) => {
      const catNodes = visible.filter((n) => n.item.category === cat);
      const angle = -Math.PI / 2 + (ci * Math.PI * 2) / cats.length;
      const ccx = cats.length === 1 ? cx : cx + Math.cos(angle) * rx * 0.62;
      const ccy = cats.length === 1 ? cy : cy + Math.sin(angle) * ry * 0.62;
      const clusterR =
        Math.min(w, h) * (cats.length === 1 ? 0.4 : 0.24) * Math.sqrt(Math.max(catNodes.length, 8) / 125);
      catNodes.forEach((n, k) => {
        const r = clusterR * Math.sqrt((k + 0.5) / catNodes.length);
        const a = k * GOLDEN + angle;
        n.tx = ccx + Math.cos(a) * r + (n.item.seed - 0.5) * 10;
        n.ty = ccy + Math.sin(a) * r + (hash01(n.item.id) - 0.5) * 10;
      });
    });
  } else if (mode === "grid") {
    const sorted = [...visible].sort(
      (a, b) =>
        CATEGORY_IDS.indexOf(a.item.category) - CATEGORY_IDS.indexOf(b.item.category) || a.item.id - b.item.id
    );
    const n = sorted.length;
    const cols = Math.max(4, Math.round(Math.sqrt((n * (w - margin * 2)) / (h - margin * 2))));
    const rows = Math.ceil(n / cols);
    const cellX = (w - margin * 2) / cols;
    const cellY = (h - margin * 2) / rows;
    sorted.forEach((node, i) => {
      const gx = i % cols;
      const gy = Math.floor(i / cols);
      const rowCount = gy === rows - 1 ? n - (rows - 1) * cols : cols;
      const xOffset = gy === rows - 1 ? ((cols - rowCount) * cellX) / 2 : 0;
      node.tx = margin + xOffset + gx * cellX + cellX / 2;
      node.ty = margin + gy * cellY + cellY / 2;
    });
  } else if (mode === "rings") {
    const maxR = Math.min(w, h) / 2 - margin;
    cats.forEach((cat, ci) => {
      const catNodes = visible.filter((n) => n.item.category === cat);
      const r0 = maxR * (0.3 + (0.68 * ci) / Math.max(cats.length - 1, 1));
      catNodes.forEach((n, k) => {
        const a = (k * Math.PI * 2) / catNodes.length + ci * 0.5;
        const r = r0 + (n.item.seed - 0.5) * maxR * 0.07;
        n.tx = cx + Math.cos(a) * r * (w > h ? Math.min(w / h, 1.6) : 1);
        n.ty = cy + Math.sin(a) * r * (h > w ? Math.min(h / w, 1.4) : 1);
      });
    });
  } else {
    // "field": seeded uniform scatter
    visible.forEach((n) => {
      n.tx = margin + n.item.seed * (w - margin * 2);
      n.ty = margin + hash01(n.item.id * 7 + 13) * (h - margin * 2);
    });
  }
  // Nodes outside the filter keep their last target and just dim in place.
}

// ---------------------------------------------------------------------------
// Engine
// ---------------------------------------------------------------------------

export async function createConstellation({
  host,
  items,
  lite = false,
  nodeCap = Infinity,
  reducedMotion = false,
  onSelect = () => {},
  onHover = () => {},
  onStateChange = () => {},
}) {
  // Rendered subset for the mobile cap. Categories round-robin over ids
  // (id % 4), so we subsample whole QUARTETS of consecutive ids — a naive
  // `i % stride` would keep only even ids and silently drop the two
  // odd-id categories.
  const groups = CATEGORY_IDS.length;
  const stride = items.length > nodeCap ? Math.ceil(items.length / nodeCap) : 1;
  const rendered =
    stride === 1 ? items : items.filter((_, i) => Math.floor(i / groups) % stride === 0);

  const app = new Application();
  await app.init({
    preference: "webgl",
    antialias: false, // tiles are pre-antialiased raster; MSAA buys nothing
    backgroundAlpha: 0,
    resolution: Math.min(globalThis.devicePixelRatio || 1, lite ? 1.5 : 2),
    autoDensity: true,
    width: Math.max(host.clientWidth, 2),
    height: Math.max(host.clientHeight, 2),
    autoStart: false, // we own start/stop; nothing runs until setActive(true)
    sharedTicker: false, // dedicated ticker; app.stop() truly stops our work
    powerPreference: lite ? "low-power" : "high-performance",
  });
  if (lite) app.ticker.maxFPS = 30;

  host.appendChild(app.canvas);
  app.canvas.style.width = "100%";
  app.canvas.style.height = "100%";
  app.canvas.style.display = "block";

  const atlas = buildAtlas(rendered);

  // Scene graph: glow layer (additive) -> nodes -> selection ring.
  const glowLayer = new Container();
  const nodeLayer = new Container();
  const fxLayer = new Container();
  app.stage.addChild(glowLayer, nodeLayer, fxLayer);

  // Dim background starfield (static decor, same atlas -> same batch).
  const starCount = lite ? 50 : 130;
  const stars = [];
  for (let i = 0; i < starCount; i++) {
    const star = new Sprite({ texture: atlas.glowTexture, anchor: 0.5 });
    star.alpha = 0.04 + hash01(i * 3.7) * 0.08;
    star.scale.set(0.05 + hash01(i * 9.1) * 0.1);
    glowLayer.addChild(star);
    stars.push(star);
  }

  const nodes = rendered.map((item, i) => {
    const sprite = new Sprite({ texture: atlas.nodeTextures[i], anchor: 0.5 });
    nodeLayer.addChild(sprite);
    return {
      item,
      sprite,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      tx: 0,
      ty: 0,
      pushX: 0,
      pushY: 0,
      sizeJitter: 0.85 + item.seed * 0.3,
      scale: 0.001,
      targetScaleMul: 1,
      alpha: 0,
      targetAlpha: 1,
      inFilter: true,
    };
  });
  const nodeById = new Map(nodes.map((n) => [n.item.id, n]));

  const hoverRing = new Sprite({ texture: atlas.ringTexture, anchor: 0.5, alpha: 0 });
  const selGlow = new Sprite({ texture: atlas.glowTexture, anchor: 0.5, alpha: 0 });
  selGlow.blendMode = "add";
  const selRing = new Sprite({ texture: atlas.ringTexture, anchor: 0.5, alpha: 0 });
  glowLayer.addChild(selGlow);
  fxLayer.addChild(hoverRing, selRing);

  // ---- state ---------------------------------------------------------------
  const state = {
    layout: "clusters",
    activeCats: new Set(CATEGORY_IDS),
    selectedId: null,
    hoverId: null,
    reducedMotion,
    active: false, // section visible AND document visible
    destroyed: false,
    pointer: { x: -1e4, y: -1e4, inside: false },
    time: 0,
    baseSize: 24,
    w: app.screen.width,
    h: app.screen.height,
  };

  let renderQueued = 0; // rAF id for reduced-motion render-on-demand
  const debug = { frames: 0 };
  if (typeof window !== "undefined") {
    window.__constellation = {
      get running() {
        return app.ticker.started;
      },
      get frames() {
        return debug.frames;
      },
      get rendered() {
        return rendered.length;
      },
    };
  }

  function announceState() {
    host.dataset.animState = state.destroyed
      ? "destroyed"
      : !state.active
        ? "paused"
        : state.reducedMotion
          ? "static"
          : "running";
    onStateChange(host.dataset.animState);
  }

  function computeBaseSize() {
    const visibleCount = Math.max(nodes.filter((n) => n.inFilter).length, 40);
    state.baseSize = Math.max(13, Math.min(36, Math.sqrt((state.w * state.h) / visibleCount) * 0.46));
  }

  function scatterStars() {
    stars.forEach((star, i) => {
      star.position.set(hash01(i * 13.3) * state.w, hash01(i * 31.7) * state.h);
    });
  }

  function relayout() {
    computeLayout(state.layout, nodes, state.w, state.h);
    computeBaseSize();
  }

  function snapAll() {
    for (const n of nodes) {
      n.x = n.tx;
      n.y = n.ty;
      n.vx = 0;
      n.vy = 0;
      n.alpha = n.targetAlpha;
      n.scale = ((state.baseSize * n.sizeJitter) / (TILE - TILE_PAD * 2)) * n.targetScaleMul;
      applySprite(n);
    }
    positionFx();
  }

  function applySprite(n) {
    n.sprite.position.set(n.x, n.y);
    n.sprite.scale.set(n.scale);
    n.sprite.alpha = n.alpha;
  }

  function positionFx() {
    const sel = state.selectedId != null ? nodeById.get(state.selectedId) : null;
    if (sel) {
      const catColor = CATEGORIES[sel.item.category].css;
      const s = sel.scale * 1.45;
      selRing.position.set(sel.x, sel.y);
      selRing.scale.set(s);
      selRing.tint = catColor;
      selRing.alpha = 0.95;
      selGlow.position.set(sel.x, sel.y);
      selGlow.scale.set(s * 2.4);
      selGlow.tint = catColor;
      selGlow.alpha = 0.5;
    } else {
      selRing.alpha = 0;
      selGlow.alpha = 0;
    }
    const hov = state.hoverId != null && state.hoverId !== state.selectedId ? nodeById.get(state.hoverId) : null;
    if (hov) {
      hoverRing.position.set(hov.x, hov.y);
      hoverRing.scale.set(hov.scale * 1.35);
      hoverRing.alpha = 0.55;
    } else {
      hoverRing.alpha = 0;
    }
  }

  // Render exactly one frame (reduced motion / paused refresh). Coalesced
  // through rAF so bursts of events cost one render.
  function renderOnce() {
    if (state.destroyed || renderQueued) return;
    renderQueued = requestAnimationFrame(() => {
      renderQueued = 0;
      if (!state.destroyed && state.active) {
        app.render();
        debug.frames += 1;
      }
    });
  }

  function afterChange() {
    if (state.reducedMotion) {
      snapAll();
      renderOnce();
    }
    // In animated mode the running ticker picks the new targets up and
    // springs there; if paused (offscreen), targets are ready for return.
  }

  // ---- simulation ----------------------------------------------------------
  const SPRING_K = 46;
  const DAMP = 6.2;
  const driftAmp = lite ? 2.2 : 3.6;
  const pointerRadius = 120;

  function tick(ticker) {
    const dt = Math.min(ticker.deltaMS, 50) / 1000;
    state.time += dt;
    debug.frames += 1;

    const { pointer } = state;
    const usePointer = pointer.inside && !lite;
    let nearest = null;
    let nearestD2 = Infinity;

    for (const n of nodes) {
      // pointer proximity: gentle radial push + swell
      let push = 0;
      if (usePointer && n.inFilter) {
        const pdx = n.x - pointer.x;
        const pdy = n.y - pointer.y;
        const d2 = pdx * pdx + pdy * pdy;
        if (d2 < pointerRadius * pointerRadius) {
          const d = Math.sqrt(d2) || 1;
          const f = 1 - d / pointerRadius;
          push = f * f;
          n.pushX = (pdx / d) * push * 30;
          n.pushY = (pdy / d) * push * 30;
          if (d2 < nearestD2) {
            nearestD2 = d2;
            nearest = n;
          }
        } else {
          n.pushX *= 0.86;
          n.pushY *= 0.86;
        }
      } else {
        n.pushX *= 0.86;
        n.pushY *= 0.86;
      }

      // ambient drift (skipped entirely under reduced motion; tick doesn't run)
      const s = n.item.seed;
      const driftX = driftAmp * Math.sin(state.time * (0.28 + s * 0.34) + n.item.phase);
      const driftY = driftAmp * Math.cos(state.time * (0.22 + s * 0.42) + n.item.phase * 1.7);

      const gx = n.tx + driftX + n.pushX;
      const gy = n.ty + driftY + n.pushY;
      n.vx += (gx - n.x) * SPRING_K * dt;
      n.vy += (gy - n.y) * SPRING_K * dt;
      const damp = Math.exp(-DAMP * dt);
      n.vx *= damp;
      n.vy *= damp;
      n.x += n.vx * dt;
      n.y += n.vy * dt;

      // eased scale/alpha
      const targetScale =
        ((state.baseSize * n.sizeJitter) / (TILE - TILE_PAD * 2)) * n.targetScaleMul * (1 + push * 0.5);
      const ease = Math.min(1, dt * 9);
      n.scale += (targetScale - n.scale) * ease;
      n.alpha += (n.targetAlpha - n.alpha) * ease;
      applySprite(n);
    }

    // hover resolution (fine pointer only)
    const hoverThreshold = Math.max(26, state.baseSize * 0.9);
    const newHover = nearest && nearestD2 < hoverThreshold * hoverThreshold ? nearest.item.id : null;
    if (newHover !== state.hoverId) {
      state.hoverId = newHover;
      app.canvas.style.cursor = newHover != null ? "pointer" : "default";
      const n = newHover != null ? nodeById.get(newHover) : null;
      onHover(n ? n.item : null, n ? n.x : 0, n ? n.y - state.baseSize : 0);
    } else if (state.hoverId != null) {
      const n = nodeById.get(state.hoverId);
      onHover(n.item, n.x, n.y - state.baseSize);
    }

    positionFx();
  }

  app.ticker.add(tick);

  // ---- input (DOM listeners on our canvas; Pixi's event system stays off,
  // proximity + picking are already O(n) in the sim loop) --------------------
  const canvas = app.canvas;

  function toLocal(e) {
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  function onPointerMove(e) {
    const p = toLocal(e);
    state.pointer.x = p.x;
    state.pointer.y = p.y;
    state.pointer.inside = true;
    if (state.reducedMotion) {
      // No proximity physics; still resolve hover discretely + render once.
      resolveHoverStatic();
    }
  }

  function onPointerLeave() {
    state.pointer.inside = false;
    if (state.hoverId != null) {
      state.hoverId = null;
      canvas.style.cursor = "default";
      onHover(null, 0, 0);
      if (state.reducedMotion) {
        positionFx();
        renderOnce();
      }
    }
  }

  function resolveHoverStatic() {
    const hit = pick(state.pointer.x, state.pointer.y);
    const id = hit ? hit.item.id : null;
    if (id !== state.hoverId) {
      state.hoverId = id;
      canvas.style.cursor = id != null ? "pointer" : "default";
      onHover(hit ? hit.item : null, hit ? hit.x : 0, hit ? hit.y - state.baseSize : 0);
      positionFx();
      renderOnce();
    }
  }

  function pick(x, y) {
    let best = null;
    let bestD2 = Infinity;
    const r = Math.max(24, state.baseSize);
    for (const n of nodes) {
      if (!n.inFilter && n.item.id !== state.selectedId) continue;
      const dx = n.x - x;
      const dy = n.y - y;
      const d2 = dx * dx + dy * dy;
      if (d2 < bestD2 && d2 < r * r) {
        bestD2 = d2;
        best = n;
      }
    }
    return best;
  }

  let downAt = null;
  function onPointerDown(e) {
    downAt = { x: e.clientX, y: e.clientY, t: performance.now() };
  }
  function onPointerUp(e) {
    if (!downAt) return;
    const moved = Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y);
    const elapsed = performance.now() - downAt.t;
    downAt = null;
    if (moved > 8 || elapsed > 600) return; // drag/long-press, not a tap
    const p = toLocal(e);
    const hit = pick(p.x, p.y);
    api.select(hit ? hit.item.id : null);
    // Only canvas-originated picks notify React; list/panel picks already
    // originate there (prevents feedback loops).
    onSelect(hit ? hit.item : null, { source: "canvas" });
  }

  canvas.addEventListener("pointermove", onPointerMove, { passive: true });
  canvas.addEventListener("pointerleave", onPointerLeave, { passive: true });
  canvas.addEventListener("pointerdown", onPointerDown, { passive: true });
  canvas.addEventListener("pointerup", onPointerUp, { passive: true });

  // ---- initial placement ----------------------------------------------------
  relayout();
  scatterStars();
  // Nodes are born at their first target (slightly pulled to center for a
  // subtle bloom-in when animated).
  for (const n of nodes) {
    if (state.reducedMotion) {
      n.x = n.tx;
      n.y = n.ty;
    } else {
      n.x = state.w / 2 + (n.tx - state.w / 2) * 0.72;
      n.y = state.h / 2 + (n.ty - state.h / 2) * 0.72;
    }
    n.alpha = state.reducedMotion ? 1 : 0;
    n.scale = ((state.baseSize * n.sizeJitter) / (TILE - TILE_PAD * 2)) * (state.reducedMotion ? 1 : 0.4);
  }
  if (state.reducedMotion) snapAll();

  // ---- public API ------------------------------------------------------------
  const api = {
    get renderedCount() {
      return rendered.length;
    },

    setLayout(mode) {
      if (state.destroyed || state.layout === mode) return;
      state.layout = mode;
      relayout();
      afterChange();
    },

    setFilter(activeCats) {
      if (state.destroyed) return;
      state.activeCats = new Set(activeCats);
      for (const n of nodes) {
        n.inFilter = state.activeCats.has(n.item.category);
        n.targetAlpha = n.inFilter ? 1 : 0.06;
        n.targetScaleMul = n.inFilter ? 1 : 0.55;
      }
      relayout();
      afterChange();
    },

    // Returns true when the node is part of the rendered canvas subset.
    select(id) {
      if (state.destroyed) return false;
      state.selectedId = id;
      const n = id != null ? nodeById.get(id) : null;
      if (n) n.targetScaleMul = Math.max(n.targetScaleMul, n.inFilter ? 1.25 : 0.9);
      for (const other of nodes) {
        if (other !== n) other.targetScaleMul = other.inFilter ? 1 : 0.55;
      }
      if (state.reducedMotion) {
        snapAll();
        renderOnce();
      } else {
        positionFx();
      }
      return id == null ? true : Boolean(n);
    },

    setReducedMotion(rm) {
      if (state.destroyed || state.reducedMotion === rm) return;
      state.reducedMotion = rm;
      if (rm) {
        app.stop();
        snapAll();
        renderOnce();
      } else if (state.active) {
        app.start();
      }
      announceState();
    },

    // active = section intersecting viewport AND document not hidden
    setActive(active) {
      if (state.destroyed || state.active === active) return;
      state.active = active;
      if (!active) {
        app.stop(); // dedicated ticker halts; zero rAF work while away
        if (renderQueued) {
          cancelAnimationFrame(renderQueued);
          renderQueued = 0;
        }
      } else if (state.reducedMotion) {
        snapAll();
        renderOnce(); // static mode: exactly one frame on re-entry
      } else {
        app.start();
      }
      announceState();
    },

    resize(w, h) {
      if (state.destroyed || w < 4 || h < 4) return;
      app.renderer.resize(w, h);
      state.w = w;
      state.h = h;
      relayout();
      scatterStars();
      if (state.reducedMotion) {
        snapAll();
        renderOnce();
      }
    },

    destroy() {
      if (state.destroyed) return;
      state.destroyed = true;
      if (renderQueued) cancelAnimationFrame(renderQueued);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerleave", onPointerLeave);
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointerup", onPointerUp);
      app.ticker.remove(tick);
      // Full teardown: children, textures, the shared atlas TextureSource,
      // the WebGL context, and the canvas element itself.
      app.destroy(
        { removeView: true },
        { children: true, texture: true, textureSource: true, context: true }
      );
      if (typeof window !== "undefined" && window.__constellation) delete window.__constellation;
      delete host.dataset.animState;
    },
  };

  announceState();
  return api;
}
