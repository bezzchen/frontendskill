"use client";

import { memo, useEffect, useMemo, useRef, useState } from "react";
import {
  CATEGORIES,
  CATEGORY_IDS,
  constellationItems,
  itemsByCategory,
} from "@/components/ConstellationData";

const LAYOUTS = [
  { id: "clusters", label: "Category clusters" },
  { id: "rings", label: "Orbits" },
  { id: "grid", label: "Grid" },
  { id: "field", label: "Open field" },
];

const itemById = new Map(constellationItems.map((item) => [item.id, item]));

// Memoized per-category list group so a selection change re-renders at most
// two groups instead of all 500 rows.
const CategoryGroup = memo(function CategoryGroup({ cat, active, selectedId, onPick }) {
  const meta = CATEGORIES[cat];
  const items = itemsByCategory[cat];
  return (
    <details className="rounded-lg border border-[var(--line)] bg-[var(--surface)]">
      <summary className="flex cursor-pointer items-center gap-2 px-4 py-3 text-sm font-semibold">
        <span
          aria-hidden="true"
          className="inline-block h-2.5 w-2.5 rounded-full"
          style={{ background: meta.css }}
        />
        {meta.label}
        <span className="font-normal text-[var(--muted)]">({items.length})</span>
        {!active && (
          <span className="ml-auto rounded-full border border-[var(--line)] px-2 py-0.5 text-xs font-normal text-[var(--muted)]">
            dimmed by filter
          </span>
        )}
      </summary>
      <ul
        className="c-index max-h-72 overflow-y-auto px-2 pb-2"
        onClick={(event) => {
          const button = event.target.closest("button[data-id]");
          if (button) onPick(Number(button.dataset.id));
        }}
      >
        {items.map((item) => (
          <li key={item.id}>
            <button type="button" data-id={item.id} aria-pressed={selectedId === item.id}>
              <b>{item.label}</b>
              <span>
                {item.kind} · {item.year}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </details>
  );
});

export function Constellation() {
  const hostRef = useRef(null);
  const tooltipRef = useRef(null);
  const engineRef = useRef(null);

  const [layout, setLayout] = useState("clusters");
  const [activeCats, setActiveCats] = useState(() => [...CATEGORY_IDS]);
  const [selectedId, setSelectedId] = useState(null);
  const [engineFailed, setEngineFailed] = useState(false);
  const [renderedCount, setRenderedCount] = useState(null);
  const [staticMode, setStaticMode] = useState(false);

  const selected = selectedId != null ? itemById.get(selectedId) : null;
  const shownCount = useMemo(
    () => activeCats.reduce((sum, cat) => sum + itemsByCategory[cat].length, 0),
    [activeCats]
  );

  // ---- engine lifecycle -----------------------------------------------------
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;

    let disposed = false;
    let engine = null;
    let io = null;
    let ro = null;
    let resizeTimer = 0;
    let ioVisible = false;
    const rmQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const lite = coarse || window.innerWidth < 700;

    const updateActive = () => {
      engine?.setActive(ioVisible && !document.hidden);
    };
    const onVisibility = () => updateActive();
    const onRmChange = () => {
      engine?.setReducedMotion(rmQuery.matches);
      setStaticMode(rmQuery.matches);
    };

    setStaticMode(rmQuery.matches);

    (async () => {
      try {
        const { createConstellation } = await import("./engine");
        if (disposed) return;
        engine = await createConstellation({
          host,
          items: constellationItems,
          lite,
          nodeCap: lite && window.innerWidth < 560 ? 250 : Infinity,
          reducedMotion: rmQuery.matches,
          onSelect: (item) => {
            // canvas-originated picks only
            if (!disposed) setSelectedId(item ? item.id : null);
          },
          onHover: (item, x, y) => {
            const tip = tooltipRef.current;
            if (!tip) return;
            if (!item) {
              tip.dataset.show = "false";
              return;
            }
            tip.dataset.show = "true";
            tip.style.transform = `translate(-50%, -100%) translate(${Math.round(x)}px, ${Math.round(y - 6)}px)`;
            tip.textContent = `${item.label} — ${CATEGORIES[item.category].label}`;
          },
        });
        if (disposed) {
          engine.destroy();
          engine = null;
          return;
        }
        engineRef.current = engine;
        setRenderedCount(engine.renderedCount);

        io = new IntersectionObserver(
          ([entry]) => {
            ioVisible = entry.isIntersecting;
            updateActive();
          },
          { rootMargin: "64px", threshold: 0 }
        );
        io.observe(host);

        ro = new ResizeObserver(() => {
          window.clearTimeout(resizeTimer);
          resizeTimer = window.setTimeout(() => {
            if (!disposed && engine) engine.resize(host.clientWidth, host.clientHeight);
          }, 120);
        });
        ro.observe(host);

        document.addEventListener("visibilitychange", onVisibility);
        rmQuery.addEventListener("change", onRmChange);
      } catch (error) {
        console.error("[constellation] WebGL init failed; DOM index remains available.", error);
        if (!disposed) setEngineFailed(true);
      }
    })();

    return () => {
      disposed = true;
      window.clearTimeout(resizeTimer);
      io?.disconnect();
      ro?.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
      rmQuery.removeEventListener("change", onRmChange);
      engineRef.current = null;
      engine?.destroy();
      engine = null;
    };
  }, []);

  // ---- state -> engine ------------------------------------------------------
  useEffect(() => {
    engineRef.current?.setLayout(layout);
  }, [layout]);
  useEffect(() => {
    engineRef.current?.setFilter(activeCats);
  }, [activeCats]);

  const pick = (id) => {
    const next = id === selectedId ? null : id;
    setSelectedId(next);
    engineRef.current?.select(next);
  };

  const toggleCat = (cat) => {
    setActiveCats((prev) => {
      const set = new Set(prev);
      set.has(cat) ? set.delete(cat) : set.add(cat);
      return CATEGORY_IDS.filter((c) => set.has(c));
    });
  };

  const statusText = [
    `${shownCount} of ${constellationItems.length} experiences in focus`,
    LAYOUTS.find((l) => l.id === layout)?.label,
    selected
      ? `selected: ${selected.label} (${CATEGORIES[selected.category].label} ${selected.kind}, ${selected.year})`
      : null,
    renderedCount != null && renderedCount < constellationItems.length
      ? `${renderedCount} drawn in the low-power field; the full index is listed below`
      : null,
    staticMode ? "motion minimized per your system setting" : null,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <section aria-labelledby="constellation-title" className="space-y-6">
      <header className="max-w-3xl space-y-3">
        <h2 id="constellation-title" className="text-3xl font-semibold">
          Experience constellation
        </h2>
        <p className="text-[var(--muted)]">
          Twelve years of projects, papers, tools, and studies — all {constellationItems.length} of
          them — drawn as one field. Filter by discipline, regroup the sky, or pick any point to
          inspect it. The same index is available as a plain list below the field.
        </p>
      </header>

      {/* Controls: real DOM, fully keyboard operable */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
        <div role="group" aria-label="Filter by discipline" className="flex flex-wrap gap-2">
          {CATEGORY_IDS.map((cat) => {
            const on = activeCats.includes(cat);
            return (
              <button
                key={cat}
                type="button"
                aria-pressed={on}
                onClick={() => toggleCat(cat)}
                className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition-colors ${
                  on
                    ? "border-transparent bg-[var(--foreground)] text-[var(--background)]"
                    : "border-[var(--line)] bg-[var(--surface)] text-[var(--muted)]"
                }`}
              >
                <span
                  aria-hidden="true"
                  className="inline-block h-2 w-2 rounded-full"
                  style={{ background: CATEGORIES[cat].css, opacity: on ? 1 : 0.45 }}
                />
                {CATEGORIES[cat].label}
              </button>
            );
          })}
        </div>

        <fieldset className="flex flex-wrap items-center gap-2 border-0 p-0">
          <legend className="sr-only">Arrange the constellation</legend>
          {LAYOUTS.map((l) => (
            <label
              key={l.id}
              className={`cursor-pointer rounded-md border px-3 py-1.5 text-sm ${
                layout === l.id
                  ? "border-[var(--foreground)] bg-[var(--surface)] font-medium"
                  : "border-[var(--line)] bg-[var(--surface)] text-[var(--muted)]"
              }`}
            >
              <input
                type="radio"
                name="constellation-layout"
                value={l.id}
                checked={layout === l.id}
                onChange={() => setLayout(l.id)}
                className="sr-only"
              />
              {l.label}
            </label>
          ))}
        </fieldset>
      </div>

      {/* Live status: one polite announcer for filter/layout/selection changes */}
      <p aria-live="polite" className="text-sm text-[var(--muted)]">
        {statusText}
      </p>

      {/* The bounded canvas stage */}
      <div className="relative overflow-hidden rounded-2xl border border-[var(--line)] bg-[#0b0e14] [background-image:radial-gradient(120%_90%_at_50%_0%,#141a26_0%,#0b0e14_60%)]">
        <div
          ref={hostRef}
          role="img"
          aria-label={`Animated constellation of ${constellationItems.length} experience tiles across engineering, research, design, and math. Decorative view of the index below; use the filters, list, and detail panel to explore the same items.`}
          className="h-[62vh] max-h-[640px] min-h-[380px] w-full touch-pan-y"
        />
        {engineFailed && (
          <div className="absolute inset-0 flex items-center justify-center p-8 text-center text-sm text-[#8b93a7]">
            This browser could not start the WebGL field. Every item is still available in the
            index below.
          </div>
        )}
        <div
          ref={tooltipRef}
          aria-hidden="true"
          data-show="false"
          className="c-tooltip pointer-events-none absolute left-0 top-0 z-10 max-w-56 rounded-md bg-black/80 px-2.5 py-1.5 text-xs text-white opacity-0 shadow-lg transition-opacity duration-100 data-[show=true]:opacity-100"
        />

        {/* Selection detail card, anchored inside the stage */}
        {selected && (
          <div className="absolute bottom-4 left-4 right-4 z-10 flex max-w-md items-start gap-3 rounded-xl border border-white/10 bg-[#131826] p-4 text-white sm:right-auto">
            <span
              aria-hidden="true"
              className="mt-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold"
              style={{ background: CATEGORIES[selected.category].css }}
            >
              {selected.monogram}
            </span>
            <div className="min-w-0 text-sm">
              <p className="font-semibold">{selected.label}</p>
              <p className="text-white/65">
                {CATEGORIES[selected.category].label} · {selected.kind} · {selected.year}
              </p>
              {renderedCount != null &&
                renderedCount < constellationItems.length &&
                !isRendered(selected.id, renderedCount) && (
                  <p className="mt-1 text-xs text-white/45">
                    Not drawn in the reduced mobile field — it is still part of the index.
                  </p>
                )}
            </div>
            <button
              type="button"
              onClick={() => pick(selected.id)}
              className="ml-auto rounded-md border border-white/15 px-2 py-1 text-xs text-white/80"
            >
              Clear
            </button>
          </div>
        )}
      </div>

      {/* Semantic twin: every item as real, focusable DOM */}
      <div aria-label="Experience index" role="group" className="space-y-2">
        <h3 className="text-sm font-semibold uppercase tracking-[0.14em] text-[var(--muted)]">
          Full index
        </h3>
        <div className="grid gap-2 md:grid-cols-2">
          {CATEGORY_IDS.map((cat) => (
            <CategoryGroup
              key={cat}
              cat={cat}
              active={activeCats.includes(cat)}
              selectedId={selected?.category === cat ? selected.id : null}
              onPick={pick}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

// Mirrors the engine's quartet subsampling so the card can say honestly
// whether a list-selected item is drawn in the reduced mobile field.
function isRendered(id, renderedCount) {
  const stride = Math.round(constellationItems.length / renderedCount);
  if (stride <= 1) return true;
  return Math.floor(id / CATEGORY_IDS.length) % stride === 0;
}
