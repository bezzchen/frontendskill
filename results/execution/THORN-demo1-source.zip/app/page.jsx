import Distillery from "./experience/Distillery";
import MotionToggle from "./experience/MotionToggle";
import BotanicalLedger from "./experience/BotanicalLedger";
import LedgerForm from "./experience/LedgerForm";
import { BOTANICALS } from "./experience/botanicals";

// Act scroll ranges (fractions of the 900vh stage; travel = 800vh):
// a1 .10–.36 · a2 .36–.50 · a3 .50–.70 · a4 .70–.86 · a5 .86–1
const ACT_STYLE = {
  a1: { top: "80vh", height: "308vh" },
  a2: { top: "288vh", height: "212vh" },
  a3: { top: "400vh", height: "260vh" },
  a4: { top: "560vh", height: "228vh" },
  a5: { top: "688vh", height: "212vh" },
};

export default function Home() {
  return (
    <>
      <a className="skip-link" href="#serve">
        Skip past the visual journey
      </a>

      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Thornmere — back to top">
          <span className="thorn">Thorn</span>mere
        </a>
        <div className="header-meta">
          <span className="batch">Batch № 03 · London Dry</span>
          <MotionToggle />
        </div>
      </header>

      <main id="top">
        <h1 className="sr-only">Thornmere — London Dry Gin</h1>

        <Distillery>
          {/* Act 0 — arrival (overlays the sticky stage) */}
          <div className="arrival-overlay">
            <div className="arrival-copy" data-arrival>
              <p className="kicker">London · Small batch · Est. MMXXIV</p>
              <p className="arrival-title font-display" aria-hidden="true">
                Thornmere
              </p>
              <p className="arrival-sub">
                A London dry gin of five botanicals, distilled once in copper.
                What follows is the run itself — from plate, to vapour, to glass.
              </p>
              <span className="scroll-cue" aria-hidden="true">
                Scroll — the run begins
              </span>
            </div>
          </div>

          {/* Act I — the five */}
          <section className="act" style={ACT_STYLE.a1} aria-label="Act one — the five botanicals">
            <div className="act-pin">
              <div className="act-copy copy-panel" data-act-for="a1">
                <p className="act-kicker">Act I · The Five</p>
                <h2 className="headline" style={{ fontSize: "1.9rem" }}>
                  Nothing that doesn&apos;t earn its place.
                </h2>
                <BotanicalLedger />
              </div>
            </div>
          </section>

          {/* Reduced-motion / no-JS folio: the plates themselves */}
          <div className="folio-plates" aria-label="The five botanical plates">
            {BOTANICALS.map((b) => (
              <figure className="folio-plate" key={b.id}>
                <img src={b.file} alt={b.alt} loading="lazy" width="460" height="590" />
                <figcaption>{b.name}</figcaption>
              </figure>
            ))}
          </div>

          {/* Act II — the copper */}
          <section className="act act--right" style={ACT_STYLE.a2} aria-label="Act two — the copper still">
            <div className="act-pin">
              <div className="act-copy copy-panel" data-act-for="a2">
                <p className="act-kicker">Act II · The Copper</p>
                <h2 className="headline" style={{ fontSize: "2.1rem" }}>
                  One still. One slow morning.
                </h2>
                <p className="prose-dim">
                  Batch № 03 was run on <em>Constance</em>, our 300-litre copper pot.
                  Copper isn&apos;t nostalgia: it holds back what the grain would rather
                  keep, and gives the spirit back its brightness. Twenty-four hours of
                  maceration. The fire is lit at five.
                </p>
              </div>
            </div>
          </section>

          {/* Act III — the vapour */}
          <section className="act" style={ACT_STYLE.a3} aria-label="Act three — the vapour">
            <div className="act-pin">
              <div className="act-copy copy-panel" data-act-for="a3">
                <p className="act-kicker">Act III · The Vapour</p>
                <h2 className="headline" style={{ fontSize: "2.1rem" }}>
                  We keep only the heart.
                </h2>
                <p className="prose-dim">
                  The run begins loud with heads and ends heavy with tails — both are
                  cut by taste, not by clock. Only what crosses the swan neck between
                  them will ever wear the name.
                </p>
                <p className="prose-dim vapour-hint" aria-hidden="true">
                  Move your cursor through the vapour.
                </p>
              </div>
            </div>
          </section>

          {/* Act IV — the spirit */}
          <section className="act act--right" style={ACT_STYLE.a4} aria-label="Act four — the spirit condenses">
            <div className="act-pin">
              <div className="act-copy copy-panel" data-act-for="a4">
                <p className="act-kicker">Act IV · The Spirit</p>
                <h2 className="headline" style={{ fontSize: "2.1rem" }}>
                  The colour stays behind. The character doesn&apos;t.
                </h2>
                <p className="prose-dim">
                  Vapour condenses to a spirit that runs perfectly clear, carrying
                  everything the five gave it. Cut to 43.1% with soft water, rested
                  fourteen days in glass, and never chill-filtered.
                </p>
              </div>
            </div>
          </section>

          {/* Act V — still life */}
          <section className="act" style={ACT_STYLE.a5} aria-label="Act five — the bottle">
            <div className="act-pin">
              <div className="act-copy copy-panel" data-act-for="a5">
                <p className="act-kicker">Batch № 03</p>
                <h2 className="headline" style={{ fontSize: "2.6rem" }}>
                  Four hundred bottles,
                  <br />
                  numbered by hand.
                </h2>
                <div className="cta-row">
                  <a className="btn" href="#stockists">
                    Find a stockist
                  </a>
                  <a className="btn btn--ghost" href="#serve">
                    The serve
                  </a>
                </div>
              </div>
            </div>
          </section>

        </Distillery>

        <div className="tail">
          <section id="serve" className="tail-section" aria-labelledby="serve-h">
            <p className="kicker">The Serve</p>
            <h2 id="serve-h" className="headline" style={{ fontSize: "2.4rem" }}>
              The Thornmere &amp; Tonic.
            </h2>
            <div className="serve-grid">
              <div className="serve-step">
                <span className="n" aria-hidden="true">1</span>
                <h3>Build it cold</h3>
                <p>A tall glass, ice to the rim. 50&nbsp;ml of Thornmere, poured over.</p>
              </div>
              <div className="serve-step">
                <span className="n" aria-hidden="true">2</span>
                <h3>Keep it bitter</h3>
                <p>100&nbsp;ml of a properly bitter tonic. One to two — never drown it.</p>
              </div>
              <div className="serve-step">
                <span className="n" aria-hidden="true">3</span>
                <h3>Peel, not juice</h3>
                <p>A long coil of lemon peel, oils over the top, and three juniper berries.</p>
              </div>
            </div>
            <p className="prose-dim" style={{ marginTop: "2rem" }}>
              Or stirred, cold and brief: ten parts Thornmere to one of dry vermouth,
              lemon oils over the top.
            </p>
          </section>

          <section id="stockists" className="tail-section" aria-labelledby="stockists-h">
            <p className="kicker">Stockists</p>
            <h2 id="stockists-h" className="headline" style={{ fontSize: "2.4rem" }}>
              Independent merchants, mostly.
            </h2>
            <p className="prose-dim">
              Batch № 03 is with independent wine and spirit merchants across London
              and the South East. For the batch list, or trade terms:{" "}
              <a className="underline" href="mailto:orders@thornmere.example">
                orders@thornmere.example
              </a>
            </p>
          </section>

          <section id="ledger" className="tail-section" aria-labelledby="ledger-h">
            <p className="kicker">The Ledger</p>
            <h2 id="ledger-h" className="headline" style={{ fontSize: "2.4rem" }}>
              First word of each batch.
            </h2>
            <LedgerForm />
          </section>

          <footer className="site-footer">
            <div className="cols">
              <div>
                <p className="wordmark" style={{ fontSize: "0.9rem" }}>
                  <span className="thorn">Thorn</span>mere
                </p>
                <p>
                  Thornmere is a fictional distillery, built as a design demonstration.
                  Please enjoy gin responsibly.
                </p>
              </div>
              <div>
                <h3>Provenance</h3>
                <p>
                  Botanical plates from Köhler&apos;s <em>Medizinal-Pflanzen</em> (1887),
                  public domain. Studio lighting environment by Poly Haven, CC0.
                </p>
              </div>
              <div>
                <h3>Thornmere Distillery</h3>
                <p>
                  Arch 9, Thornmere Yard
                  <br />
                  London E8 — by appointment
                  <br />
                  <a className="underline" href="mailto:orders@thornmere.example">
                    orders@thornmere.example
                  </a>
                </p>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </>
  );
}
