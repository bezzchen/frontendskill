// ————————————————————————————————————————————————————————————————
// Thornmere Experience — one imperative three.js scene, one RAF,
// one timeline. Rendering runs ONLY while the canvas is onscreen
// and the document is visible; reduced mode renders single frames
// on demand.
// ————————————————————————————————————————————————————————————————
import * as THREE from "three";
import { RGBELoader } from "three/addons/loaders/RGBELoader.js";
import {
  TL,
  LAYOUT,
  galleryPose,
  ringPose,
  wallPose,
  lerpPose,
} from "./timeline.js";
import {
  plateVert,
  plateFrag,
  pointsVert,
  pointsFrag,
  liquidVert,
  liquidFrag,
  floorVert,
  floorFrag,
  backVert,
  backFrag,
} from "./shaders.js";
import {
  sampleInk,
  inkToWorld,
  sampleBottleSurface,
  BOTTLE_PROFILE,
  LIQUID_PROFILE,
} from "./sampling.js";
import { BOTANICALS } from "./botanicals.js";
import { drawLabel } from "./label.js";

const BG = new THREE.Color(0x070b08);

function TLcamTgtAt(p) {
  return TL.camTgt(p);
}

export class Experience {
  constructor(canvas, { tier = "high", mode = "full", onProgress, onReady, onFail } = {}) {
    this.canvas = canvas;
    this.tier = tier;
    this.mode = mode;
    this.onProgress = onProgress || (() => {});
    this.onReady = onReady || (() => {});
    this.onFail = onFail || (() => {});

    this.p = 0;
    this.targetP = 0;
    this.time = 0;
    this.intro = 0;
    this.frames = 0;
    this.fps = 0;
    this.running = false;
    this.visible = true;
    this.onscreen = true;
    this.disposed = false;
    this.ready = false;
    this.raf = 0;

    this.pointerNdc = new THREE.Vector2(0, 0);
    this.pointerWorld = new THREE.Vector3(0, 0.8, 0);
    this.pointerTargetWorld = new THREE.Vector3(0, 0.8, 0);
    this.parallax = new THREE.Vector2(0, 0);
    this.highlight = { hover: -1, beat: -1 };
    this.glow = [0, 0, 0, 0, 0];
  }

  async init() {
    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: this.tier === "high",
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch (e) {
      this.onFail(e);
      return;
    }
    const r = this.renderer;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.05;
    r.setClearColor(BG, 1);

    this.canvas.addEventListener("webglcontextlost", (e) => {
      e.preventDefault();
      this.stopLoop();
      this.onFail(new Error("context lost"));
    });

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 60);
    this.scene.add(this.camera);
    this.camTarget = new THREE.Vector3();
    this.smoothTarget = new THREE.Vector3(0, 1.35, 0);

    this.resize();

    // ——— asset loading with coarse progress ———
    const total = 7;
    let done = 0;
    const step = () => this.onProgress(++done / total);

    try {
      const texLoader = new THREE.TextureLoader();
      const [env, ...plateTex] = await Promise.all([
        new RGBELoader().loadAsync("/env/studio_small_09_1k.hdr").then((t) => {
          step();
          return t;
        }),
        ...BOTANICALS.map((b) =>
          texLoader.loadAsync(b.file).then((t) => {
            step();
            return t;
          })
        ),
      ]);
      env.mapping = THREE.EquirectangularReflectionMapping;
      this.scene.environment = env;
      this.envTex = env;
      plateTex.forEach((t) => {
        t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = Math.min(4, r.capabilities.getMaxAnisotropy());
      });
      this.plateTex = plateTex;

      this.build();
      step();
      this.ready = true;
      this.visible = typeof document === "undefined" || document.visibilityState === "visible";
      this.onReady();
      this.applyMode();
      if (this.frames === 0) this.renderOnce();
    } catch (e) {
      this.onFail(e);
    }
  }

  // ————— scene construction —————
  build() {
    const s = this.scene;

    // backdrop + floor
    this.backMat = new THREE.ShaderMaterial({
      vertexShader: backVert,
      fragmentShader: backFrag,
      uniforms: {
        uBottom: { value: new THREE.Color(0x050705) },
        uTop: { value: new THREE.Color(0x0e1811) },
        uLight: { value: 1 },
      },
      depthWrite: false,
    });
    const back = new THREE.Mesh(new THREE.PlaneGeometry(70, 34), this.backMat);
    back.position.set(0, 6, -12);
    back.renderOrder = -2;
    s.add(back);

    this.floorMat = new THREE.ShaderMaterial({
      vertexShader: floorVert,
      fragmentShader: floorFrag,
      uniforms: {
        uBase: { value: new THREE.Color(0x0a120c) },
        uWarm: { value: new THREE.Color(0x2b2317) },
        uLight: { value: 1 },
      },
      transparent: true,
      depthWrite: false,
    });
    const floor = new THREE.Mesh(new THREE.CircleGeometry(10, 48), this.floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = LAYOUT.floorY - 0.001;
    floor.renderOrder = -1;
    s.add(floor);

    // ——— plates ———
    this.plates = [];
    const plateGeo = new THREE.PlaneGeometry(LAYOUT.plateW, LAYOUT.plateH, 12, 16);
    for (let i = 0; i < 5; i++) {
      const mat = new THREE.ShaderMaterial({
        vertexShader: plateVert,
        fragmentShader: plateFrag,
        uniforms: {
          uMap: { value: this.plateTex[i] },
          uTime: { value: 0 },
          uSway: { value: 1 },
          uPhase: { value: i * 1.7 },
          uErode: { value: 0 },
          uGlow: { value: 0 },
          uDim: { value: 1 },
          uFog: { value: BG.clone() },
        },
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(plateGeo, mat);
      mesh.renderOrder = 3;
      s.add(mesh);
      this.plates.push(mesh);
    }

    // ——— copper still (surface of revolution, like the bottle) ———
    const stillPts = [
      [0.001, 0], [0.55, 0], [0.78, 0.05], [0.92, 0.22], [1.02, 0.55],
      [1.0, 0.95], [0.86, 1.3], [0.62, 1.6], [0.42, 1.78], [0.3, 1.9],
      [0.26, 2.05], [0.3, 2.14], [0.31, 2.24], [0.26, 2.3], [0.001, 2.3],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    this.stillMat = new THREE.MeshStandardMaterial({
      color: 0x9c5a28,
      metalness: 1,
      roughness: 0.27,
      emissive: 0x501707,
      emissiveIntensity: 0,
      envMapIntensity: 1.0,
    });
    this.still = new THREE.Group();
    const pot = new THREE.Mesh(new THREE.LatheGeometry(stillPts, 56), this.stillMat);
    this.still.add(pot);
    // stub of a lyne arm — the rest is drawn by vapour
    const armCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0.05, 2.18, 0),
      new THREE.Vector3(0.3, 2.42, 0),
      new THREE.Vector3(0.62, 2.32, 0)
    );
    const arm = new THREE.Mesh(new THREE.TubeGeometry(armCurve, 12, 0.065, 10, false), this.stillMat);
    this.still.add(arm);
    this.still.position.set(LAYOUT.still.x, -6.4, 0);
    s.add(this.still);

    // ——— bottle (lathed), liquid, label, closure ———
    this.bottleGroup = new THREE.Group();
    this.bottleGroup.position.set(LAYOUT.bottle.x, LAYOUT.bottle.baseY, 0);
    s.add(this.bottleGroup);

    const bottlePts = BOTTLE_PROFILE.map(([x, y]) => new THREE.Vector2(x, y));
    const bottleGeo = new THREE.LatheGeometry(bottlePts, 64);
    if (this.tier === "high") {
      this.glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xf2f6f0,
        metalness: 0,
        roughness: 0.06,
        transmission: 1,
        thickness: 0.5,
        ior: 1.5,
        attenuationColor: 0xd9e6d2,
        attenuationDistance: 3.0,
        clearcoat: 0.5,
        clearcoatRoughness: 0.25,
        specularIntensity: 1,
        envMapIntensity: 0,
      });
    } else {
      this.glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xdfe8dd,
        metalness: 0,
        roughness: 0.08,
        transparent: true,
        opacity: 0.32,
        envMapIntensity: 0,
        depthWrite: false,
      });
    }
    const glass = new THREE.Mesh(bottleGeo, this.glassMat);
    glass.renderOrder = 5;
    this.bottleGroup.add(glass);

    const liquidPts = LIQUID_PROFILE.map(([x, y]) => new THREE.Vector2(x, y));
    this.liquidMat = new THREE.ShaderMaterial({
      vertexShader: liquidVert,
      fragmentShader: liquidFrag,
      uniforms: {
        uFill: { value: -3 },
        uOn: { value: 0 },
        uTint: { value: new THREE.Color(0x9db487) },
        uCam: { value: new THREE.Vector3() },
      },
      transparent: true,
      depthWrite: false,
    });
    const liquid = new THREE.Mesh(new THREE.LatheGeometry(liquidPts, 48), this.liquidMat);
    liquid.renderOrder = 4;
    this.bottleGroup.add(liquid);

    // label
    const labelCanvas = document.createElement("canvas");
    drawLabel(labelCanvas);
    this.labelTex = new THREE.CanvasTexture(labelCanvas);
    this.labelTex.colorSpace = THREE.SRGBColorSpace;
    this.labelTex.anisotropy = 4;
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => {
        if (this.disposed) return;
        drawLabel(labelCanvas);
        this.labelTex.needsUpdate = true;
        if (this.mode === "reduced") this.renderOnce();
      });
    }
    this.labelMat = new THREE.MeshStandardMaterial({
      map: this.labelTex,
      roughness: 0.85,
      metalness: 0,
      envMapIntensity: 0.3,
      transparent: true,
      opacity: 0,
    });
    const label = new THREE.Mesh(
      new THREE.CylinderGeometry(0.645, 0.645, 0.82, 48, 1, true, -0.82, 1.64),
      this.labelMat
    );
    label.position.y = 0.78;
    label.renderOrder = 6;
    this.bottleGroup.add(label);

    // closure: cork + copper cap band
    const corkMat = new THREE.MeshStandardMaterial({ color: 0x241812, roughness: 0.6, metalness: 0.05 });
    const cork = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.16, 0.3, 24), corkMat);
    cork.position.y = 3.28;
    this.bottleGroup.add(cork);
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(0.2, 0.2, 0.1, 24),
      new THREE.MeshStandardMaterial({ color: 0x9c5a28, metalness: 1, roughness: 0.35, envMapIntensity: 1 })
    );
    band.position.y = 3.2;
    this.bottleGroup.add(band);
    this.closure = [cork, band];

    // warm light that "finds" the bottle as the spirit condenses
    this.bottleLight = new THREE.PointLight(0xffdcb0, 0, 9, 2);
    this.bottleLight.position.set(LAYOUT.bottle.x + 1.4, 1.6, 2.4);
    s.add(this.bottleLight);
    // ember inside the still
    this.emberLight = new THREE.PointLight(0xff7a30, 0, 7, 2);
    this.emberLight.position.set(LAYOUT.still.x, -1.4, 0.6);
    s.add(this.emberLight);

    // ——— the distillate: ink-sampled particles ———
    const N = this.tier === "high" ? 30000 : 12000;
    const per = Math.floor(N / 5);
    const home = new Float32Array(N * 3);
    const color = new Float32Array(N * 3);
    for (let i = 0; i < 5; i++) {
      const { positions, colors } = sampleInk(this.plateTex[i].image, per);
      home.set(inkToWorld(positions, i), i * per * 3);
      color.set(colors, i * per * 3);
    }
    // any remainder duplicates plate 0 points
    for (let i = per * 5; i < N; i++) {
      home.copyWithin(i * 3, 0, 3);
      color.copyWithin(i * 3, 0, 3);
    }
    const bottleTargets = sampleBottleSurface(N);
    const seeds = new Float32Array(N * 4);
    for (let i = 0; i < N; i++) {
      seeds[i * 4] = Math.random();
      seeds[i * 4 + 1] = Math.random();
      seeds[i * 4 + 2] = Math.random();
      seeds[i * 4 + 3] = Math.random();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(home.slice(), 3)); // required by three
    geo.setAttribute("aHome", new THREE.BufferAttribute(home, 3));
    geo.setAttribute("aBottle", new THREE.BufferAttribute(bottleTargets, 3));
    geo.setAttribute("aColor", new THREE.BufferAttribute(color, 3));
    geo.setAttribute("aSeed", new THREE.BufferAttribute(seeds, 4));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0.5, 0), 14);
    const b = LAYOUT.bez;
    this.pointsMat = new THREE.ShaderMaterial({
      vertexShader: pointsVert,
      fragmentShader: pointsFrag,
      uniforms: {
        uTime: { value: 0 },
        uDissolve: { value: 0 },
        uTravel: { value: 0 },
        uCondense: { value: 0 },
        uAlpha: { value: 0 },
        uSize: { value: 0.045 },
        uScaleH: { value: 800 },
        uPointerK: { value: this.tier === "high" ? 0.55 : 0 },
        uPointer: { value: this.pointerWorld },
        uP0: { value: new THREE.Vector3(...b.p0) },
        uP1: { value: new THREE.Vector3(...b.p1) },
        uP2: { value: new THREE.Vector3(...b.p2) },
        uP3: { value: new THREE.Vector3(...b.p3) },
        uClear: { value: new THREE.Vector3(...LAYOUT.clearSpirit) },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.pointsMat);
    this.points.renderOrder = 7;
    this.points.visible = false;
    s.add(this.points);

    this.clock = new THREE.Clock(false);
  }

  // ————— per-frame state from the timeline —————
  applyProgress(dt) {
    const p = this.p;
    const t = this.time;

    // camera — lookAt on the camera itself (−Z convention), parallax composed after
    if (this.mode === "reduced") {
      // the folio still-life: bottle right of frame, copy space left
      this.camera.position.set(0.2, 0.05, 5.6);
      this.camera.lookAt(this.smoothTarget.set(2.65, -0.55, 0));
    } else {
      const cp = TL.camPos(p);
      const ct = TL.camTgt(p);
      const introBack = (1 - this.intro) * 3.2;
      this.camera.position.set(cp[0], cp[1], cp[2] + introBack);
      this.smoothTarget.lerp(this.camTarget.set(ct[0], ct[1], ct[2]), dt ? 1 - Math.exp(-dt * 5.5) : 1);
      this.camera.lookAt(this.smoothTarget);
      this.camera.rotateY(this.parallax.x);
      this.camera.rotateX(this.parallax.y);
    }

    // plates
    const ringMix = TL.ringMix(p);
    const wallMix = TL.wallMix(p);
    const erode = TL.erode(p);
    const sway = TL.sway(p);
    const dim = TL.plateDim(p);
    for (let i = 0; i < 5; i++) {
      let pose = lerpPose(galleryPose(i), ringPose(i), ringMix);
      if (wallMix > 0) pose = lerpPose(pose, wallPose(i), wallMix);
      const m = this.plates[i];
      const introDrift = (1 - this.intro) * (1.5 + i * 0.7);
      m.position.set(pose.pos[0], pose.pos[1], pose.pos[2] - introDrift);
      m.rotation.set(pose.rot[0], pose.rot[1], pose.rot[2]);
      m.scale.setScalar(pose.scale);
      const u = m.material.uniforms;
      u.uTime.value = t;
      u.uSway.value = sway;
      u.uErode.value = Math.max(0, erode - i * 0.045);
      u.uDim.value = wallMix > 0 ? dim : 1;
      // hover / beat glow
      const target = this.highlight.hover === i ? 1 : this.highlight.beat === i ? 0.45 : 0;
      this.glow[i] += (target - this.glow[i]) * (dt ? 1 - Math.exp(-dt * 8) : 1);
      u.uGlow.value = this.glow[i];
      m.visible = erode - i * 0.045 < 1.2 || wallMix > 0;
    }

    // still
    this.still.position.y = TL.stillRise(p);
    const heat = TL.heat(p);
    this.stillMat.emissiveIntensity = heat * 0.55;
    this.emberLight.intensity = heat * 2.6;

    // vapour
    const pu = this.pointsMat.uniforms;
    pu.uTime.value = t;
    pu.uDissolve.value = TL.dissolve(p);
    pu.uTravel.value = TL.travel(p);
    pu.uCondense.value = TL.condense(p);
    pu.uAlpha.value = TL.pointsAlpha(p);
    this.points.visible = pu.uAlpha.value > 0.003;

    // bottle — offstage until the vapour has somewhere to land
    this.bottleGroup.visible = p > 0.485;
    const light = TL.glassLight(p);
    this.glassMat.envMapIntensity = light;
    this.bottleLight.intensity = light * 2.2;
    this.labelMat.opacity = TL.labelFade(p);
    this.liquidMat.uniforms.uFill.value = TL.liquidFill(p);
    this.liquidMat.uniforms.uOn.value = TL.liquidOn(p);
    this.liquidMat.uniforms.uCam.value.setFromMatrixPosition(this.camera.matrixWorld);
    const closureOn = TL.labelFade(p);
    this.closure.forEach((c) => {
      c.visible = closureOn > 0.02;
      if (c.material.transparent) c.material.opacity = closureOn;
    });

    // ambience
    const stage = TL.stageLight(p);
    this.backMat.uniforms.uLight.value = stage;
    this.floorMat.uniforms.uLight.value = stage;
  }

  // ————— loop control —————
  updateRun() {
    const should =
      this.ready && !this.disposed && this.mode === "full" && this.visible && this.onscreen;
    if (should && !this.running) {
      this.running = true;
      this.clock.start();
      this.raf = requestAnimationFrame(this.tick);
    } else if (!should && this.running) {
      this.stopLoop();
    }
  }

  stopLoop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    if (this.clock) this.clock.stop();
  }

  tick = () => {
    if (!this.running) return;
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.time += dt;
    this.fps = this.fps * 0.95 + (dt > 0 ? 1 / dt : 60) * 0.05;

    if (this.intro < 1) this.intro = Math.min(1, this.intro + dt / 2.2);
    const e = 1 - Math.exp(-dt * 6.5);
    this.p += (this.targetP - this.p) * e;
    this.pointerWorld.lerp(this.pointerTargetWorld, 1 - Math.exp(-dt * 5));

    this.applyProgress(dt);
    this.renderer.render(this.scene, this.camera);
    this.frames++;
    this.raf = requestAnimationFrame(this.tick);
  };

  renderOnce() {
    if (!this.ready || this.disposed) return;
    this.applyProgress(0);
    this.renderer.render(this.scene, this.camera);
    this.frames++;
  }

  // ————— external API —————
  setProgress(p) {
    this.targetP = p;
  }

  // deterministic scrub + single frame (verification/debug)
  step(p) {
    this.intro = 1;
    this.targetP = p;
    this.p = p;
    this.smoothTarget.set(...([].concat(TLcamTgtAt(p))));
    this.renderOnce();
  }

  setPointer(ndcX, ndcY) {
    if (this.mode !== "full" || this.tier !== "high") return;
    this.pointerNdc.set(ndcX, ndcY);
    this.parallax.x += (-ndcX * 0.03 - this.parallax.x) * 0.5;
    this.parallax.y += (ndcY * 0.02 - this.parallax.y) * 0.5;
    // project onto the z=0 stage plane for vapour stirring
    const v = new THREE.Vector3(ndcX, ndcY, 0.5).unproject(this.camera);
    const o = new THREE.Vector3().setFromMatrixPosition(this.camera.matrixWorld);
    const d = v.sub(o).normalize();
    const tPlane = -o.z / (d.z || 1e-4);
    if (tPlane > 0 && tPlane < 40) this.pointerTargetWorld.copy(o).addScaledVector(d, tPlane);
  }

  setHighlight(hover, beat) {
    this.highlight.hover = hover;
    this.highlight.beat = beat;
  }

  setRunFlags({ visible, onscreen }) {
    if (visible !== undefined) this.visible = visible;
    if (onscreen !== undefined) this.onscreen = onscreen;
    this.updateRun();
  }

  setMode(mode) {
    this.mode = mode;
    this.applyMode();
  }

  applyMode() {
    if (!this.ready) return;
    if (this.mode === "reduced") {
      this.stopLoop();
      // the composed still-life: end of the run, no motion
      this.intro = 1;
      this.p = 1;
      this.targetP = 1;
      this.parallax.set(0, 0);
      this.renderOnce();
    } else {
      this.p = Math.min(this.p, this.targetP);
      this.updateRun();
      // paused at birth (hidden tab / offscreen): still paint one composed frame
      if (!this.running) this.renderOnce();
    }
  }

  resize() {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    const dprCap = this.tier === "high" ? 1.75 : 1.25;
    const dpr = Math.min(window.devicePixelRatio || 1, dprCap);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.pointsMat) {
      this.pointsMat.uniforms.uScaleH.value = (h * 0.5) / Math.tan((this.camera.fov * Math.PI) / 360);
    }
    if (this.ready && !this.running) this.renderOnce();
  }

  dispose() {
    this.disposed = true;
    this.stopLoop();
    if (this.renderer) this.renderer.dispose();
    if (this.scene) {
      this.scene.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          const mats = Array.isArray(o.material) ? o.material : [o.material];
          mats.forEach((m) => {
            for (const k in m) if (m[k] && m[k].isTexture) m[k].dispose();
            m.dispose();
          });
        }
      });
    }
  }
}
