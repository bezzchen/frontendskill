"use client";

import { useEffect, useState } from "react";
import { BOTANICALS } from "./botanicals";
import { setHover, subscribeBus, getBus } from "./bus";
import { initMotionStore, getMotion, subscribeMotion } from "./motionStore";

export default function BotanicalLedger() {
  const [active, setActive] = useState(-1);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    setReduced(initMotionStore() === "reduced");
    const un1 = subscribeMotion((m) => setReduced(m === "reduced"));
    const un2 = subscribeBus((s) => setActive(s.hover > -1 ? s.hover : s.beat));
    const b = getBus();
    setActive(b.hover > -1 ? b.hover : b.beat);
    return () => { un1(); un2(); };
  }, []);

  return (
    <ol className="botanical-list">
      {BOTANICALS.map((b, i) => {
        const inner = (
          <>
            <span className="num" aria-hidden="true">{String(i + 1).padStart(2, "0")}</span>
            <span>
              <span className="name">
                {b.name}
                <i className="latin">{b.latin}</i>
              </span>
              <span className="note">{b.note}</span>
            </span>
          </>
        );
        return (
          <li key={b.id}>
            {reduced ? (
              <div className="botanical-row is-active">{inner}</div>
            ) : (
              <button
                type="button"
                className={`botanical-row${active === i ? " is-active" : ""}`}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(-1)}
                onFocus={() => setHover(i)}
                onBlur={() => setHover(-1)}
                aria-label={`${b.name} — highlight its plate in the scene`}
              >
                {inner}
              </button>
            )}
          </li>
        );
      })}
    </ol>
  );
}
