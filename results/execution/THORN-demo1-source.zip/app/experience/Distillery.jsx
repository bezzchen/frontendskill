"use client";

import { useEffect, useRef, useState } from "react";
import { actFromP, beatFromP } from "./timeline.js";
import { initMotionStore, getMotion, subscribeMotion, lockReduced } from "./motionStore";
import { setBeat, getBus, subscribeBus } from "./bus";

export default function Distillery({ children }) {
  const wrapRef = useRef(null);
  const stickyRef = useRef(null);
  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const [pct, setPct] = useState(0);
  const [done, setDone] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let disposed = false;
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    initMotionStore();

    // capability recipe
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const small = window.innerWidth < 820;
    const lowMem = navigator.deviceMemory !== undefined && navigator.deviceMemory <= 4;
    const tier = coarse || small || lowMem ? "low" : "high";

    let engine = null;
    let cleanupFns = [];

    const applyAct = (act) => {
      wrap.dataset.act = act;
      const reduced = getMotion() === "reduced";
      wrap.querySelectorAll("[data-act-for]").forEach((el) => {
        const live = reduced || el.dataset.actFor === act;
        el.classList.toggle("is-live", live);
        el.querySelectorAll("a,button,input").forEach((f) => {
          f.tabIndex = live ? 0 : -1;
        });
      });
      const arrival = wrap.querySelector("[data-arrival]");
      if (arrival) arrival.classList.toggle("is-gone", !reduced && act !== "a0");
    };

    let lastAct = null;
    let lastBeat = -2;
    const onScroll = () => {
      const travel = Math.max(1, wrap.offsetHeight - window.innerHeight);
      const p = Math.min(1, Math.max(0, window.scrollY / travel));
      if (engine) engine.setProgress(p);
      const act = actFromP(p);
      if (act !== lastAct) {
        lastAct = act;
        applyAct(act);
      }
      const beat = beatFromP(p);
      if (beat !== lastBeat) {
        lastBeat = beat;
        setBeat(beat);
      }
    };

    const boot = async () => {
      const { Experience } = await import("./engine.js");
      if (disposed) return;
      engine = new Experience(canvas, {
        tier,
        mode: getMotion(),
        onProgress: (f) => setPct(Math.round(f * 100)),
        onReady: () => {
          setDone(true);
          onScroll();
          engine.updateRun();
        },
        onFail: () => {
          setFailed(true);
          setDone(true);
          lockReduced();
          wrap.dataset.canvas = "off";
        },
      });
      engineRef.current = engine;
      window.__thorn = {
        get frames() { return engine ? engine.frames : -1; },
        get running() { return engine ? engine.running : false; },
        get fps() { return engine ? Math.round(engine.fps) : 0; },
        get p() { return engine ? engine.p : 0; },
        get mode() { return engine ? engine.mode : "none"; },
        tier,
        step(p) { if (engine) engine.step(p); },
        // verification probes: mutate exactly one input, repaint one frame
        stir(x, y, z) {
          if (!engine) return;
          engine.pointerWorld.set(x, y, z);
          engine.pointerTargetWorld.set(x, y, z);
          engine.renderOnce();
        },
        glow(hover) {
          if (!engine) return;
          engine.setHighlight(hover, -1);
          engine.renderOnce();
        },
        snap() {
          return engine ? engine.canvas.toDataURL("image/png").length : 0;
        },
        hash() {
          if (!engine) return "none";
          const d = engine.canvas.toDataURL("image/png");
          let h = 0;
          for (let i = 0; i < d.length; i += 7) h = (h * 33 + d.charCodeAt(i)) >>> 0;
          return h.toString(16) + ":" + d.length;
        },
      };
      await engine.init();
      if (disposed) { engine.dispose(); return; }

      // scroll + resize
      window.addEventListener("scroll", onScroll, { passive: true });
      const onResize = () => { engine.resize(); onScroll(); };
      window.addEventListener("resize", onResize);
      cleanupFns.push(() => window.removeEventListener("scroll", onScroll));
      cleanupFns.push(() => window.removeEventListener("resize", onResize));

      // pause when the tab is hidden — the actual condition
      const onVis = () => engine.setRunFlags({ visible: document.visibilityState === "visible" });
      document.addEventListener("visibilitychange", onVis);
      cleanupFns.push(() => document.removeEventListener("visibilitychange", onVis));

      // pause when the stage scrolls offscreen — the actual condition
      const io = new IntersectionObserver(
        (entries) => engine.setRunFlags({ onscreen: entries[0].isIntersecting }),
        { threshold: 0 }
      );
      io.observe(stickyRef.current);
      cleanupFns.push(() => io.disconnect());

      // pointer (fine pointers only)
      if (window.matchMedia("(pointer: fine)").matches) {
        const onMove = (e) => {
          engine.setPointer((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
        };
        window.addEventListener("pointermove", onMove, { passive: true });
        cleanupFns.push(() => window.removeEventListener("pointermove", onMove));
      }

      // ledger hover / scroll beat → plate glow
      cleanupFns.push(
        subscribeBus((s) => engine.setHighlight(s.hover, s.beat))
      );

      // motion preference
      cleanupFns.push(
        subscribeMotion((m) => {
          engine.setMode(m);
          if (lastAct) applyAct(lastAct);
          onScroll();
        })
      );

      onScroll();
      applyAct(actFromP(0));
      onVis();
    };

    boot();
    return () => {
      disposed = true;
      cleanupFns.forEach((fn) => fn());
      if (engineRef.current) engineRef.current.dispose();
      engineRef.current = null;
    };
  }, []);

  return (
    <>
      <div className="loader" data-done={done} aria-hidden={done}>
        <span className="lm">Thornmere</span>
        <span className="bar" aria-hidden="true">
          <i style={{ transform: `scaleX(${pct / 100})` }} />
        </span>
        <span className="pct">{failed ? "folio edition" : `distilling ${pct}%`}</span>
      </div>

      <div className="stage-wrap" ref={wrapRef} data-act="a0">
        <div className="stage-sticky" ref={stickyRef}>
          <canvas className="stage-canvas" ref={canvasRef} aria-hidden="true" />
          <div className="stage-vignette" aria-hidden="true" />
        </div>
        {children}
      </div>
    </>
  );
}
