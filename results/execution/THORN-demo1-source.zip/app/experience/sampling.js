// CPU-side sampling: engraving ink → particle homes; lathe surface → condensation targets.
import { LAYOUT, ringPose } from "./timeline.js";

// Sample pigment pixels from a plate image. Returns {positions, colors} in
// plate-local units (plate width/height from LAYOUT), origin at plate centre.
export function sampleInk(image, count) {
  const w = image.naturalWidth || image.width;
  const h = image.naturalHeight || image.height;
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(image, 0, 0);
  const data = ctx.getImageData(0, 0, w, h).data;

  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  let placed = 0;
  let guard = 0;
  const maxTries = count * 80;
  while (placed < count && guard++ < maxTries) {
    const x = (Math.random() * w) | 0;
    const y = (Math.random() * h) | 0;
    const o = (y * w + x) * 4;
    const r = data[o] / 255;
    const g = data[o + 1] / 255;
    const b = data[o + 2] / 255;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    if (lum > 0.86) continue; // paper
    // keep denser ink more often so structure survives
    if (Math.random() > (1 - lum) * 1.4 + 0.08) continue;
    const px = (x / w - 0.5) * LAYOUT.plateW;
    const py = (0.5 - y / h) * LAYOUT.plateH;
    positions[placed * 3] = px;
    positions[placed * 3 + 1] = py;
    positions[placed * 3 + 2] = (Math.random() - 0.5) * 0.02;
    // slightly brightened, linearised for additive glow
    colors[placed * 3] = Math.pow(Math.min(1, r * 1.25 + 0.06), 2.0);
    colors[placed * 3 + 1] = Math.pow(Math.min(1, g * 1.25 + 0.06), 2.0);
    colors[placed * 3 + 2] = Math.pow(Math.min(1, b * 1.2 + 0.05), 2.0);
    placed++;
  }
  // fill any shortfall by duplicating placed points
  for (let i = placed; i < count; i++) {
    const j = (Math.random() * Math.max(1, placed)) | 0;
    positions.set(positions.subarray(j * 3, j * 3 + 3), i * 3);
    colors.set(colors.subarray(j * 3, j * 3 + 3), i * 3);
  }
  return { positions, colors };
}

// Transform plate-local ink points into world space at the converged-ring
// keyframe (the dissolve moment) — same constants the timeline uses.
export function inkToWorld(local, plateIndex) {
  const pose = ringPose(plateIndex);
  const [cx, cy, cz] = pose.pos;
  const rz = pose.rot[2];
  const s = pose.scale;
  const cos = Math.cos(rz);
  const sin = Math.sin(rz);
  const out = new Float32Array(local.length);
  for (let i = 0; i < local.length; i += 3) {
    const x = local[i] * s;
    const y = local[i + 1] * s;
    out[i] = cx + x * cos - y * sin;
    out[i + 1] = cy + x * sin + y * cos;
    out[i + 2] = cz + local[i + 2] * s;
  }
  return out;
}

// The bottle is a surface of revolution — this is its profile, reused by
// LatheGeometry (via toVector2s) and by the surface sampler below.
// [radius, height-above-base]
export const BOTTLE_PROFILE = [
  [0.001, 0.0],
  [0.3, 0.0],
  [0.55, 0.015],
  [0.615, 0.09],
  [0.63, 0.28],
  [0.63, 1.42],
  [0.605, 1.6],
  [0.5, 1.78],
  [0.335, 1.98],
  [0.215, 2.2],
  [0.172, 2.42],
  [0.165, 2.78],
  [0.168, 2.96],
  [0.19, 3.02],
  [0.195, 3.12],
  [0.17, 3.16],
];

// liquid: inset copy of the wetted part of the profile
export const LIQUID_PROFILE = BOTTLE_PROFILE.filter(([, y]) => y <= 2.45).map(([r, y]) => [
  Math.max(0.001, r - 0.05),
  y + 0.015,
]);

export function sampleBottleSurface(count) {
  const P = BOTTLE_PROFILE;
  const bx = LAYOUT.bottle.x;
  const by = LAYOUT.bottle.baseY;
  // cumulative lateral area per segment ≈ avg radius × segment length
  const cum = [];
  let total = 0;
  for (let i = 1; i < P.length; i++) {
    const [r0, y0] = P[i - 1];
    const [r1, y1] = P[i];
    const len = Math.hypot(r1 - r0, y1 - y0);
    total += ((r0 + r1) / 2) * len;
    cum.push(total);
  }
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const pick = Math.random() * total;
    let s = 0;
    while (s < cum.length - 1 && cum[s] < pick) s++;
    const [r0, y0] = P[s];
    const [r1, y1] = P[s + 1];
    const f = Math.random();
    const r = r0 + (r1 - r0) * f + (Math.random() - 0.5) * 0.012;
    const y = y0 + (y1 - y0) * f;
    const a = Math.random() * Math.PI * 2;
    out[i * 3] = bx + Math.cos(a) * r;
    out[i * 3 + 1] = by + y;
    out[i * 3 + 2] = Math.sin(a) * r;
  }
  return out;
}
