// ————————————————————————————————————————————————————————————————
// The single owner of the scene timeline. Scroll progress p ∈ [0,1]
// is evaluated through keyframe tracks; nothing else animates
// transforms. DOM copy reveals are CSS classes keyed off the same p.
// ————————————————————————————————————————————————————————————————

export const ACT_RANGES = [
  { id: "a0", from: 0.0, to: 0.1 },
  { id: "a1", from: 0.1, to: 0.36 },
  { id: "a2", from: 0.36, to: 0.5 },
  { id: "a3", from: 0.5, to: 0.7 },
  { id: "a4", from: 0.7, to: 0.86 },
  { id: "a5", from: 0.86, to: 1.0 },
];

export function actFromP(p) {
  for (const a of ACT_RANGES) if (p < a.to) return a.id;
  return "a5";
}

// Act I sub-beats: which botanical the camera is framing.
// camX(p) mirrors the camPos track's linear a1 segment.
export function beatFromP(p) {
  if (p < 0.1 || p > 0.352) return -1;
  const camX = -6.4 + ((p - 0.1) / 0.245) * 12.8;
  return Math.max(0, Math.min(4, Math.round((camX + 6.9) / 3)));
}

// ————— easing —————
const EASE = {
  lin: (t) => t,
  io: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  o: (t) => 1 - Math.pow(1 - t, 3),
  i: (t) => t * t * t,
};

// keys: [[t, value, ease?], ...] value = number | number[]
export function track(keys) {
  return (p) => {
    if (p <= keys[0][0]) return keys[0][1];
    for (let k = 1; k < keys.length; k++) {
      if (p <= keys[k][0]) {
        const [t0, v0] = keys[k - 1];
        const [t1, v1, e] = keys[k];
        const f = EASE[e || "io"]((p - t0) / (t1 - t0));
        if (Array.isArray(v0)) return v0.map((a, j) => a + (v1[j] - a) * f);
        return v0 + (v1 - v0) * f;
      }
    }
    return keys[keys.length - 1][1];
  };
}

// ————— world layout —————
export const LAYOUT = {
  plateW: 1.7,
  plateH: 2.17,
  floorY: -2.6,
  still: { x: -2.2, baseY: -2.6, mouth: [-2.2, -0.3, 0] },
  bottle: { x: 2.2, baseY: -2.6, height: 3.16 },
  // the swan neck, drawn in vapour: cubic bezier from still mouth to bottle mouth
  bez: {
    p0: [-2.2, -0.2, 0],
    p1: [-2.05, 2.55, 0],
    p2: [1.55, 2.8, 0.15],
    p3: [2.2, 0.72, 0],
  },
  clearSpirit: [0.82, 0.86, 0.8],
};

const GX = [-6, -3, 0, 3, 6];
const GY = [0.25, -0.12, 0.16, -0.2, 0.1];
const GZ = [-0.6, 0.5, -0.35, 0.6, -0.5];
const GR = [-0.03, 0.025, -0.02, 0.03, -0.025];

export function galleryPose(i) {
  return {
    pos: [GX[i], 1.45 + GY[i], GZ[i]],
    rot: [0, 0, GR[i]],
    scale: 1,
  };
}

// converged ring above the still mouth at the dissolve keyframe —
// the SAME constants feed the CPU particle-home sampler.
export function ringPose(i) {
  const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
  return {
    pos: [
      LAYOUT.still.x + Math.cos(a) * 0.78,
      0.62 + Math.sin(a) * 0.46,
      i % 2 ? 0.14 : -0.14,
    ],
    rot: [0, 0, Math.cos(a) * 0.22],
    scale: 0.3,
  };
}

// herbarium wall behind the finished bottle (Act V echo)
export function wallPose(i) {
  return {
    pos: [2.45 + (i - 2) * 1.16, 0.95, -3.6],
    rot: [0, 0, (i - 2) * 0.012],
    scale: 0.8,
  };
}

export function lerpPose(a, b, f) {
  return {
    pos: a.pos.map((v, j) => v + (b.pos[j] - v) * f),
    rot: a.rot.map((v, j) => v + (b.rot[j] - v) * f),
    scale: a.scale + (b.scale - a.scale) * f,
  };
}

// ————— tracks —————
export const TL = {
  camPos: track([
    [0.0, [0, 1.5, 12.0]],
    [0.1, [-6.4, 1.5, 4.8], "io"],
    [0.345, [6.4, 1.5, 4.6], "lin"],
    [0.42, [1.6, 0.9, 6.6], "io"],
    [0.5, [-0.9, 0.5, 5.6], "io"],
    [0.62, [0.1, 1.15, 7.4], "io"],
    [0.74, [1.35, 0.55, 5.6], "io"],
    [0.86, [2.2, -0.1, 4.0], "io"],
    [1.0, [0.95, 0.12, 5.3], "io"],
  ]),
  camTgt: track([
    [0.0, [0, 1.35, 0]],
    [0.1, [-6.95, 1.42, 0], "io"],
    [0.345, [5.05, 1.4, 0], "lin"],
    [0.42, [-1.2, 0.35, 0], "io"],
    [0.5, [-2.15, 0.45, 0], "io"],
    [0.62, [0.0, 1.0, 0], "io"],
    [0.74, [2.1, 0.15, 0], "io"],
    [0.86, [2.2, -0.7, 0], "io"],
    [1.0, [1.85, -0.62, 0], "io"],
  ]),
  ringMix: track([
    [0.355, 0],
    [0.5, 1, "io"],
  ]),
  wallMix: track([
    [0.875, 0],
    [0.975, 1, "io"],
  ]),
  erode: track([
    [0.495, 0],
    [0.615, 1.25, "o"],
    [0.875, 1.25],
    [0.955, 0, "io"],
  ]),
  plateDim: track([
    [0.86, 1],
    [0.97, 0.34, "io"],
  ]),
  sway: track([
    [0.34, 1],
    [0.48, 0, "io"],
  ]),
  stillRise: track([
    [0.335, -6.4],
    [0.46, -2.6, "o"],
    [0.87, -2.6],
    [0.97, -7.6, "io"],
  ]),
  heat: track([
    [0.4, 0],
    [0.56, 1, "io"],
    [0.68, 0.35, "io"],
    [0.8, 0.0, "io"],
  ]),
  dissolve: track([
    [0.495, 0],
    [0.62, 1, "io"],
  ]),
  travel: track([
    [0.52, 0],
    [0.75, 1, "lin"],
  ]),
  condense: track([
    [0.7, 0],
    [0.865, 1, "io"],
  ]),
  pointsAlpha: track([
    [0.49, 0],
    [0.56, 0.9, "o"],
    [0.845, 0.9],
    [0.9, 0, "io"],
  ]),
  glassLight: track([
    [0.72, 0],
    [0.88, 1.15, "io"],
  ]),
  labelFade: track([
    [0.885, 0],
    [0.945, 1, "io"],
  ]),
  liquidFill: track([
    [0.755, -2.75],
    [0.92, -1.38, "io"],
  ]),
  liquidOn: track([
    [0.74, 0],
    [0.8, 1, "io"],
  ]),
  stageLight: track([
    [0.0, 1],
    [0.36, 1],
    [0.5, 0.75, "io"],
    [0.7, 0.7, "io"],
    [0.88, 1, "io"],
  ]),
};
