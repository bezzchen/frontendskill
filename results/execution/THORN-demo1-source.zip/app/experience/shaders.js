// GLSL for the four custom materials. Everything else uses three's PBR.

const NOISE = /* glsl */ `
  float hash21(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
  }
  float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }
  vec3 swirl(vec3 p, float t) {
    return 0.5 * vec3(
      sin(p.y * 1.7 + t * 0.9) + sin(p.z * 2.3 + t * 0.7),
      sin(p.z * 1.9 + t * 0.8) + sin(p.x * 2.1 + t * 1.1),
      sin(p.x * 1.5 + t)       + sin(p.y * 2.7 + t * 0.6)
    );
  }
`;

// ————— botanical plate: white paper keyed away, pigment kept —————
export const plateVert = /* glsl */ `
  uniform float uTime;
  uniform float uSway;
  uniform float uPhase;
  varying vec2 vUv;
  varying float vDepth;
  void main() {
    vUv = uv;
    vec3 p = position;
    float sway = uSway * 0.05;
    p.z += sin(uv.y * 2.6 + uTime * 0.55 + uPhase) * sway;
    p.x += sin(uv.y * 1.4 + uTime * 0.4 + uPhase * 1.7) * sway * 0.55;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    vDepth = -mv.z;
    gl_Position = projectionMatrix * mv;
  }
`;

export const plateFrag = /* glsl */ `
  precision highp float;
  uniform sampler2D uMap;
  uniform float uErode;
  uniform float uGlow;
  uniform float uDim;
  uniform vec3 uFog;
  varying vec2 vUv;
  varying float vDepth;
  ${NOISE}
  void main() {
    vec4 tex = texture2D(uMap, vUv);
    float lum = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
    float alpha = 1.0 - smoothstep(0.80, 0.955, lum);
    float n = 0.62 * vnoise(vUv * 6.0) + 0.38 * vnoise(vUv * 15.0);
    alpha *= smoothstep(uErode - 0.22, uErode + 0.02, n + 0.12);
    if (alpha < 0.012) discard;
    vec3 col = tex.rgb;
    col = mix(col, col * vec3(1.04, 1.0, 0.92), 0.35);   // warm the pigment
    col *= (0.94 + uGlow * 0.55);
    col *= uDim;
    float fogF = 1.0 - exp(-vDepth * vDepth * 0.0016);
    col = mix(col, uFog, fogF * 0.85);
    gl_FragColor = vec4(col, alpha);
  }
`;

// ————— the distillate: ink-sampled particles —————
export const pointsVert = /* glsl */ `
  attribute vec3 aHome;
  attribute vec3 aBottle;
  attribute vec3 aColor;
  attribute vec4 aSeed;
  uniform float uTime;
  uniform float uDissolve;
  uniform float uTravel;
  uniform float uCondense;
  uniform float uSize;
  uniform float uScaleH;
  uniform float uPointerK;
  uniform vec3 uPointer;
  uniform vec3 uP0; uniform vec3 uP1; uniform vec3 uP2; uniform vec3 uP3;
  uniform vec3 uClear;
  varying vec3 vColor;
  varying float vFade;
  ${NOISE}
  vec3 bez(float t) {
    float s = 1.0 - t;
    return s*s*s*uP0 + 3.0*s*s*t*uP1 + 3.0*s*t*t*uP2 + t*t*t*uP3;
  }
  void main() {
    float sg = aSeed.x;
    // 1 — lift off the engraving
    float d = smoothstep(sg * 0.3, sg * 0.3 + 0.7, uDissolve);
    vec3 pos = aHome + swirl(aHome * 1.5 + sg * 6.0, uTime * 0.6) * 0.22 * d;
    // 2 — ride the invisible swan neck
    float tr = clamp(uTravel * (1.3 + aSeed.y * 0.35) - sg * 0.42, 0.0, 1.0);
    tr = tr * tr * (3.0 - 2.0 * tr);
    float spread = sin(tr * 3.14159) * (0.3 + aSeed.w * 0.55);
    vec3 vap = bez(tr) + swirl(vec3(aSeed.yw * 8.0, tr * 4.0), uTime * 0.45) * spread;
    pos = mix(pos, vap, smoothstep(0.015, 0.28, tr));
    // 3 — condense onto the bottle, bottom first
    float cn = smoothstep(sg * 0.45, sg * 0.45 + 0.55, uCondense);
    pos = mix(pos, aBottle, cn);
    // pointer stirs the vapour only
    float vaporness = smoothstep(0.04, 0.35, tr) * (1.0 - cn) * (1.0 - d * 0.0);
    vec3 dp = pos - uPointer;
    float dl2 = dot(dp, dp);
    pos += (dp / (sqrt(dl2) + 0.001)) * exp(-dl2 * 1.9) * uPointerK * vaporness;

    vColor = mix(aColor, uClear, cn * 0.88);
    vFade = (0.5 + 0.5 * aSeed.w) * mix(1.0, 0.8, cn);
    vec4 mv = modelViewMatrix * vec4(pos, 1.0);
    float size = uSize * (0.7 + aSeed.z) * (1.0 + spread * 0.7) * (1.0 - 0.5 * cn);
    gl_PointSize = clamp(size * uScaleH / -mv.z, 1.0, 26.0);
    gl_Position = projectionMatrix * mv;
  }
`;

export const pointsFrag = /* glsl */ `
  precision mediump float;
  uniform float uAlpha;
  varying vec3 vColor;
  varying float vFade;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float a = smoothstep(0.5, 0.06, length(c));
    gl_FragColor = vec4(vColor * (a * vFade * uAlpha), 1.0);
  }
`;

// ————— the spirit inside the glass —————
export const liquidVert = /* glsl */ `
  varying vec3 vWorld;
  varying vec3 vNormalW;
  void main() {
    vec4 w = modelMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    vNormalW = normalize(mat3(modelMatrix) * normal);
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;

export const liquidFrag = /* glsl */ `
  precision highp float;
  uniform float uFill;
  uniform float uOn;
  uniform vec3 uTint;
  uniform vec3 uCam;
  varying vec3 vWorld;
  varying vec3 vNormalW;
  void main() {
    if (vWorld.y > uFill || uOn < 0.003) discard;
    vec3 v = normalize(uCam - vWorld);
    float fres = pow(1.0 - abs(dot(normalize(vNormalW), v)), 2.4);
    float line = smoothstep(0.05, 0.0, abs(vWorld.y - uFill)) * 0.85;
    vec3 col = uTint * (0.2 + fres * 0.9) + vec3(0.95, 0.9, 0.74) * line;
    float alpha = clamp(fres * 0.42 + line * 0.85 + 0.09, 0.0, 1.0) * uOn;
    gl_FragColor = vec4(col, alpha);
  }
`;

// ————— floor: light pool + contact shadows —————
export const floorFrag = /* glsl */ `
  precision highp float;
  uniform vec3 uBase;
  uniform vec3 uWarm;
  uniform float uLight;
  varying vec3 vWorld;
  ${NOISE}
  void main() {
    float r2 = vWorld.x * vWorld.x * 0.55 + vWorld.z * vWorld.z;
    vec3 col = uBase + uWarm * exp(-r2 * 0.10) * 0.5 * uLight;
    vec2 ds = vWorld.xz - vec2(-2.2, 0.0);
    vec2 db = vWorld.xz - vec2(2.2, 0.0);
    col *= 1.0 - 0.55 * exp(-dot(ds, ds) * 1.35);
    col *= 1.0 - 0.55 * exp(-dot(db, db) * 1.9);
    col += (hash21(vWorld.xz * 41.7) - 0.5) * 0.012;
    float edge = 1.0 - smoothstep(4.5, 9.5, sqrt(r2));
    gl_FragColor = vec4(col, edge);
  }
`;

export const floorVert = /* glsl */ `
  varying vec3 vWorld;
  void main() {
    vec4 w = modelMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;

// ————— backdrop gradient, dithered —————
export const backVert = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

export const backFrag = /* glsl */ `
  precision highp float;
  uniform vec3 uBottom;
  uniform vec3 uTop;
  uniform float uLight;
  varying vec2 vUv;
  ${NOISE}
  void main() {
    float g = smoothstep(0.0, 0.85, vUv.y);
    vec2 c = vUv - vec2(0.5, 0.42);
    float halo = exp(-dot(c, c) * 5.5) * 0.5 * uLight;
    vec3 col = mix(uBottom, uTop, g * 0.8 + halo);
    col += (hash21(vUv * 913.7) - 0.5) * 0.012;
    gl_FragColor = vec4(col, 1.0);
  }
`;
