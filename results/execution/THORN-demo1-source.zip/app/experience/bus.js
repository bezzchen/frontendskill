// Tiny pubsub linking DOM copy (botanical ledger) and the WebGL scene.
const state = { hover: -1, beat: -1 };
const subs = new Set();

export function setHover(i) {
  if (state.hover === i) return;
  state.hover = i;
  subs.forEach((fn) => fn(state));
}
export function setBeat(i) {
  if (state.beat === i) return;
  state.beat = i;
  subs.forEach((fn) => fn(state));
}
export function getBus() {
  return state;
}
export function subscribeBus(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
