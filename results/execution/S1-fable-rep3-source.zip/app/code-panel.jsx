"use client";

import { useRef, useState, useSyncExternalStore } from "react";
import { curveStore, fmt } from "../lib/curve";

/*
 * Act 03: the export. Not a mockup — the values are live-bound to the
 * curve the visitor shaped in Act 02. Copy gives you real, runnable CSS.
 */

export default function CodePanel() {
  const c = useSyncExternalStore(curveStore.subscribe, curveStore.get, curveStore.get);
  const [copied, setCopied] = useState(false);
  const timer = useRef(0);

  const bezier = `cubic-bezier(${fmt(c.x1)}, ${fmt(c.y1)}, ${fmt(c.x2)}, ${fmt(c.y2)})`;

  // [cssClass, text] token pairs, one array per line
  const lines = [
    [["tok-c", "/* meridian export — seq 001 · curve 01 */"]],
    [["tok-sel", ".hero-card"], ["", " {"]],
    [["", "  "], ["tok-prop", "animation"], ["", ": "], ["tok-val", `rise 640ms ${bezier}`], ["", " "], ["tok-kw", "both"], ["", ";"]],
    [["", "}"]],
    [["", ""]],
    [["tok-kw", "@keyframes"], ["", " "], ["tok-sel", "rise"], ["", " {"]],
    [["", "  "], ["tok-prop", "from"], ["", " { "], ["tok-prop", "translate"], ["", ": "], ["tok-val", "0 28px"], ["", "; "], ["tok-prop", "opacity"], ["", ": "], ["tok-val", "0"], ["", "; }"]],
    [["", "  "], ["tok-prop", "to"], ["", "   { "], ["tok-prop", "translate"], ["", ": "], ["tok-val", "0 0"], ["", ";    "], ["tok-prop", "opacity"], ["", ": "], ["tok-val", "1"], ["", "; }"]],
    [["", "}"]],
    [["", ""]],
    [["tok-c", "/* reduced-motion variant, exported alongside */"]],
    [["tok-kw", "@media"], ["", " (prefers-reduced-motion: reduce) {"]],
    [["", "  "], ["tok-sel", ".hero-card"], ["", " { "], ["tok-prop", "animation"], ["", ": "], ["tok-val", "fade 240ms linear"], ["", " "], ["tok-kw", "both"], ["", "; }"]],
    [["", "}"]],
  ];

  const plain = lines
    .map((line) => line.map(([, text]) => text).join(""))
    .join("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(plain);
      setCopied(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setCopied(false), 1800);
    } catch {
      // clipboard unavailable — the code stays selectable by hand
    }
  };

  return (
    <div className="code-panel">
      <div className="cp-head">
        <span>Export · CSS + WAAPI</span>
        <button type="button" className="cp-copy" onClick={copy} data-copied={copied}>
          {copied ? "Copied" : "Copy CSS"}
        </button>
      </div>
      <pre tabIndex={0} aria-label="Generated CSS, live-bound to the easing curve from Act 02">
        <code>
          {lines.map((line, i) => (
            <span key={i}>
              {line.map(([cls, text], j) =>
                cls ? (
                  <span key={j} className={cls}>
                    {text}
                  </span>
                ) : (
                  <span key={j}>{text}</span>
                )
              )}
              {"\n"}
            </span>
          ))}
        </code>
      </pre>
    </div>
  );
}
