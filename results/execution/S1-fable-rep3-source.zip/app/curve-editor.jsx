"use client";

import { useCallback, useEffect, useRef, useSyncExternalStore } from "react";
import { curveStore, PRESETS, cssBezier, easeAt, fmt } from "../lib/curve";

/*
 * The Act 02 instrument: a real cubic-bezier editor.
 * Pointer-draggable, keyboard-adjustable (arrow keys, shift for fine steps),
 * announced politely to screen readers. Whatever it holds drives the WebGL
 * river behind it and the compiled export in Act 03.
 */

// plot geometry (SVG user units)
const W = 260;
const H = 300;
const PX0 = 26; // x for value 0
const PX1 = 234; // x for value 1
const PY0 = 252; // y for value 0
const PY1 = 108; // y for value 1  (headroom above for overshoot)

const toPx = (x, y) => [PX0 + x * (PX1 - PX0), PY0 + y * (PY1 - PY0)];
const fromPx = (px, py) => [(px - PX0) / (PX1 - PX0), (py - PY0) / (PY1 - PY0)];

export default function CurveEditor({ reducedMotion }) {
  const curve = useSyncExternalStore(curveStore.subscribe, curveStore.get, curveStore.get);
  const plotRef = useRef(null);
  const dotRef = useRef(null);
  const liveRef = useRef(null);
  const announceT = useRef(0);

  const [p1x, p1y] = toPx(curve.x1, curve.y1);
  const [p2x, p2y] = toPx(curve.x2, curve.y2);
  const [ax, ay] = toPx(0, 0);
  const [bx, by] = toPx(1, 1);

  const announce = useCallback((c) => {
    clearTimeout(announceT.current);
    announceT.current = setTimeout(() => {
      if (liveRef.current) liveRef.current.textContent = `Easing set to ${cssBezier(c)}`;
    }, 450);
  }, []);

  useEffect(() => () => clearTimeout(announceT.current), []);

  const dragHandle = useCallback(
    (which) => (e) => {
      e.preventDefault();
      const svg = plotRef.current?.querySelector("svg");
      if (!svg) return;
      const el = e.currentTarget;
      el.setPointerCapture(e.pointerId);
      const rect = svg.getBoundingClientRect();
      const scaleX = W / rect.width;
      const scaleY = H / rect.height;

      const move = (ev) => {
        const px = (ev.clientX - rect.left) * scaleX;
        const py = (ev.clientY - rect.top) * scaleY;
        const [x, y] = fromPx(px, py);
        const c = { ...curveStore.get() };
        if (which === 1) { c.x1 = x; c.y1 = y; } else { c.x2 = x; c.y2 = y; }
        curveStore.set(c);
      };
      const up = (ev) => {
        el.releasePointerCapture(ev.pointerId);
        el.removeEventListener("pointermove", move);
        el.removeEventListener("pointerup", up);
        el.removeEventListener("pointercancel", up);
        announce(curveStore.get());
      };
      el.addEventListener("pointermove", move);
      el.addEventListener("pointerup", up);
      el.addEventListener("pointercancel", up);
    },
    [announce]
  );

  const keyHandle = useCallback(
    (which) => (e) => {
      const step = e.shiftKey ? 0.005 : 0.02;
      let dx = 0;
      let dy = 0;
      if (e.key === "ArrowLeft") dx = -step;
      else if (e.key === "ArrowRight") dx = step;
      else if (e.key === "ArrowUp") dy = step;
      else if (e.key === "ArrowDown") dy = -step;
      else return;
      e.preventDefault();
      const c = { ...curveStore.get() };
      if (which === 1) { c.x1 += dx; c.y1 += dy; } else { c.x2 += dx; c.y2 += dy; }
      curveStore.set(c);
      announce(curveStore.get());
    },
    [announce]
  );

  const applyPreset = (p) => {
    curveStore.set({ ...p.v });
    announce(p.v);
  };

  const isPreset = (p) =>
    Math.abs(p.v.x1 - curve.x1) < 0.005 &&
    Math.abs(p.v.y1 - curve.y1) < 0.005 &&
    Math.abs(p.v.x2 - curve.x2) < 0.005 &&
    Math.abs(p.v.y2 - curve.y2) < 0.005;

  const preview = () => {
    const dot = dotRef.current;
    const track = dot?.parentElement;
    if (!dot || !track) return;
    const dist = track.clientWidth;
    if (reducedMotion) {
      // no travel animation: place the dot at the end; the ghost row already
      // plots the ease against time
      dot.style.transform = `translateX(${dist}px) rotate(45deg)`;
      return;
    }
    dot.style.transform = "translateX(0) rotate(45deg)";
    dot.animate(
      [
        { transform: "translateX(0) rotate(45deg)" },
        { transform: `translateX(${dist}px) rotate(45deg)` },
      ],
      { duration: 950, easing: cssBezier(curve), fill: "forwards" }
    );
  };

  // ghost row: the ease sampled at 9 timestamps — the still-life of the curve
  const ghosts = Array.from({ length: 9 }, (_, i) => {
    const t = i / 8;
    return { t, p: easeAt(t, curve) };
  });

  const pathD = `M ${ax} ${ay} C ${p1x} ${p1y}, ${p2x} ${p2y}, ${bx} ${by}`;

  return (
    <div className="curve-editor" role="group" aria-label="Easing curve editor">
      <div className="ce-head">
        <span>Ease · Curve 01</span>
        <output className="ce-readout" aria-live="off">{cssBezier(curve)}</output>
      </div>

      <div className="ce-plot" ref={plotRef}>
        <svg viewBox={`0 0 ${W} ${H}`} aria-hidden="true" focusable="false">
          {/* grid */}
          {[0.25, 0.5, 0.75].map((g) => (
            <line key={`v${g}`} className="ce-grid" x1={toPx(g, 0)[0]} y1={28} x2={toPx(g, 0)[0]} y2={PY0} />
          ))}
          {[0.25, 0.5, 0.75, 1.25].map((g) => (
            <line key={`h${g}`} className="ce-grid" x1={PX0} y1={toPx(0, g)[1]} x2={PX1} y2={toPx(0, g)[1]} />
          ))}
          <rect className="ce-frame" x={PX0} y={PY1} width={PX1 - PX0} height={PY0 - PY1} />
          {/* linear reference */}
          <line className="ce-linear" x1={ax} y1={ay} x2={bx} y2={by} />
          {/* control arms */}
          <line className="ce-arm" x1={ax} y1={ay} x2={p1x} y2={p1y} />
          <line className="ce-arm" x1={bx} y1={by} x2={p2x} y2={p2y} />
          {/* the curve */}
          <path className="ce-path" d={pathD} />
          <circle className="ce-end" cx={ax} cy={ay} r="4" />
          <circle className="ce-end" cx={bx} cy={by} r="4" />
        </svg>

        <button
          type="button"
          className="ce-handle"
          style={{ left: `${(p1x / W) * 100}%`, top: `${(p1y / H) * 100}%` }}
          aria-label={`Control point 1: ${fmt(curve.x1)}, ${fmt(curve.y1)}. Arrow keys to adjust, shift for fine steps.`}
          onPointerDown={dragHandle(1)}
          onKeyDown={keyHandle(1)}
        />
        <button
          type="button"
          className="ce-handle"
          style={{ left: `${(p2x / W) * 100}%`, top: `${(p2y / H) * 100}%` }}
          aria-label={`Control point 2: ${fmt(curve.x2)}, ${fmt(curve.y2)}. Arrow keys to adjust, shift for fine steps.`}
          onPointerDown={dragHandle(2)}
          onKeyDown={keyHandle(2)}
        />
      </div>

      <div className="ce-track" aria-hidden="true">
        {ghosts.map((g) => (
          <span
            key={g.t}
            className="ce-ghost"
            style={{ left: `${Math.min(Math.max(g.p, -0.1), 1.1) * 100}%`, opacity: 0.25 + g.t * 0.45 }}
          />
        ))}
        <span className="ce-dot" ref={dotRef} />
      </div>

      <div className="ce-actions">
        <div className="ce-presets" role="group" aria-label="Easing presets">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              className="ce-chip"
              aria-pressed={isPreset(p)}
              onClick={() => applyPreset(p)}
            >
              {p.label}
            </button>
          ))}
        </div>
        <button type="button" className="ce-play" onClick={preview}>
          Preview
        </button>
      </div>
      <p className="ce-note">Grey diamonds sample the ease at nine timestamps.</p>

      <p aria-live="polite" ref={liveRef} style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clipPath: "inset(50%)" }} />
    </div>
  );
}
