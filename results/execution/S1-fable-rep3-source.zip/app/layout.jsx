import "./globals.css";
import { Newsreader, Instrument_Sans, Fragment_Mono } from "next/font/google";

const newsreader = Newsreader({
  subsets: ["latin"],
  style: ["normal", "italic"],
  variable: "--font-newsreader",
  display: "swap",
});

const instrument = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-instrument",
  display: "swap",
});

const fragment = Fragment_Mono({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-fragment",
  display: "swap",
});

export const metadata = {
  title: "Meridian — the web's missing timeline",
  description:
    "Meridian is a timeline-based motion editor for the web. Sequence keyframes, sculpt easing you can hold, and ship the exact CSS and Web Animations code you'd have written by hand.",
  openGraph: {
    title: "Meridian — the web's missing timeline",
    description:
      "Design animation visually, ship production code. A timeline-based motion editor for the web.",
    type: "website",
  },
};

export const viewport = {
  themeColor: "#05070f",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${newsreader.variable} ${instrument.variable} ${fragment.variable}`}>
      <body>{children}</body>
    </html>
  );
}
