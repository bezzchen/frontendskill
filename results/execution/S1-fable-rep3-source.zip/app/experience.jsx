"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Field, supportsWebGL2 } from "../lib/engine";
import { curveStore } from "../lib/curve";
import CurveEditor from "./curve-editor";
import CodePanel from "./code-panel";

/*
 * The page is a Meridian file.
 * Your scrollbar is the playhead of an eight-hundred-frame sequence; the HUD
 * is the editor's chrome; the WebGL field of keyframe diamonds is the scene
 * being scrubbed. Five acts, one continuous timeline.
 */

const ACTS = [
  { id: "overture", num: "00", label: "First light" },
  { id: "tracks", num: "01", label: "Tracks" },
  { id: "ease", num: "02", label: "Ease" },
  { id: "ship", num: "03", label: "Ship" },
  { id: "zenith", num: "04", label: "Zenith" },
];

const TOTAL_FRAMES = 24 * 30; // a 24-second sequence at 30 fps

function timecode(t) {
  const f = Math.round(t * TOTAL_FRAMES);
  const ss = Math.floor(f / 30);
  const mm = Math.floor(ss / 60);
  const pad = (n) => String(n).padStart(2, "0");
  return `00:${pad(mm)}:${pad(ss % 60)}:${pad(f % 30)}`;
}

export default function Experience() {
  const canvasRef = useRef(null);
  const dawnRef = useRef(null);
  const playheadRef = useRef(null);
  const fillRef = useRef(null);
  const caretRef = useRef(null);
  const tcRef = useRef(null);
  const rulerRef = useRef(null);
  const sectionRefs = useRef({});
  const engineRef = useRef(null);
  const boundsRef = useRef([0, 0.2, 0.4, 0.6, 0.8]);
  const scrollableRef = useRef(1);
  const reducedRef = useRef(false);

  const [actIdx, setActIdx] = useState(0);
  const [marks, setMarks] = useState([0, 20, 40, 60, 80]);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const doc = document.documentElement;
    doc.classList.add("js");

    const qs = new URLSearchParams(window.location.search);
    const prmQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const fineQuery = window.matchMedia("(pointer: fine)");
    let rm = prmQuery.matches || qs.has("rm");
    reducedRef.current = rm;
    setReduced(rm);

    const noGL = qs.has("nogl") || !supportsWebGL2();
    let engine = null;

    if (noGL) {
      doc.classList.add("no-gl");
    } else {
      // capability recipe: same identity, lighter field on lighter machines
      const coarse = window.matchMedia("(pointer: coarse)").matches;
      const small = Math.min(window.innerWidth, window.innerHeight * 2) < 820;
      const lowMem = navigator.deviceMemory !== undefined && navigator.deviceMemory <= 4;
      let count = 12000;
      let dprCap = 2;
      let sizePx = 3.1;
      if (coarse || small) {
        count = 4200;
        dprCap = 1.5;
        sizePx = 2.5;
      }
      if (lowMem) count = Math.floor(count * 0.6);

      engine = new Field(canvasRef.current, {
        count,
        dprCap,
        sizePx,
        onContextLost: () => doc.classList.add("no-gl"),
      });
      if (engine.init()) {
        doc.classList.remove("no-gl");
      } else {
        doc.classList.add("no-gl");
        engine = null;
      }
      engineRef.current = engine;
    }

    // ——— master timeline geometry ———
    const measure = () => {
      const vh = window.innerHeight;
      const scrollable = Math.max(doc.scrollHeight - vh, 1);
      scrollableRef.current = scrollable;
      const b = ACTS.map((a) => {
        const el = sectionRefs.current[a.id];
        return el ? Math.min(el.offsetTop / scrollable, 0.999) : 0;
      });
      b[0] = 0;
      boundsRef.current = b;
      engine?.setBounds(b);
      setMarks(b.map((f) => f * 100));
    };

    // ——— scrub: scroll drives everything ———
    let raw = 0;
    let ticking = false;
    const apply = () => {
      ticking = false;
      const vw = window.innerWidth;
      if (playheadRef.current) playheadRef.current.style.transform = `translateX(${raw * vw}px)`;
      if (fillRef.current) fillRef.current.style.transform = `scaleX(${raw})`;
      if (caretRef.current) caretRef.current.style.transform = `translateX(${raw * (rulerRef.current?.clientWidth || vw)}px)`;
      if (tcRef.current) tcRef.current.textContent = timecode(raw);
      if (dawnRef.current) {
        const d = Math.max(0, (raw - 0.58) / 0.42);
        dawnRef.current.style.opacity = String(Math.pow(d, 1.4));
      }
      const b = boundsRef.current;
      let i = 0;
      for (let k = 1; k < b.length; k++) if (raw >= b[k] - 0.001) i = k;
      setActIdx((prev) => (prev === i ? prev : i));
    };
    const onScroll = () => {
      raw = Math.min(Math.max(window.scrollY / scrollableRef.current, 0), 1);
      engine?.setScroll(raw);
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(apply);
      }
    };

    // ——— pointer ripple (fine pointers, full-motion mode only) ———
    const onPointerMove = (e) => {
      if (!engine || engine.mode !== "flow") return;
      const a = window.innerWidth / window.innerHeight;
      engine.setPointer(
        (e.clientX / window.innerWidth) * 2 * a - a,
        -((e.clientY / window.innerHeight) * 2 - 1)
      );
    };

    // ——— lifecycle: never render for nobody ———
    const onVisibility = () => {
      if (!engine) return;
      if (document.hidden) engine.stop();
      else if (engine.mode === "flow") engine.start();
    };
    const io = new IntersectionObserver(
      (entries) => {
        if (!engine) return;
        for (const en of entries) {
          if (en.isIntersecting && engine.mode === "flow" && !document.hidden) engine.start();
          else if (!en.isIntersecting) engine.stop();
        }
      },
      { threshold: 0 }
    );
    if (canvasRef.current) io.observe(canvasRef.current);

    // ——— reveals ———
    const revealIO = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) {
            en.target.classList.add("in");
            revealIO.unobserve(en.target);
          }
        }
      },
      { threshold: 0.2 }
    );
    document.querySelectorAll(".reveal").forEach((el) => revealIO.observe(el));

    // ——— reduced motion: five still poses instead of a stream ———
    const applyMotionMode = () => {
      rm = prmQuery.matches || qs.has("rm");
      reducedRef.current = rm;
      setReduced(rm);
      if (!engine) return;
      if (rm) {
        engine.setMode("static");
      } else {
        engine.setMode("flow");
        if (!document.hidden) engine.start();
      }
    };

    const onResize = () => {
      engine?.resize();
      measure();
      onScroll();
    };

    const unsubscribeCurve = curveStore.subscribe((c) => {
      engine?.setCurve([c.x1, c.y1, c.x2, c.y2]);
    });
    const c0 = curveStore.get();
    engine?.setCurve([c0.x1, c0.y1, c0.x2, c0.y2]);

    measure();
    applyMotionMode();
    onScroll();
    apply();

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVisibility);
    if (fineQuery.matches) window.addEventListener("pointermove", onPointerMove, { passive: true });
    prmQuery.addEventListener("change", applyMotionMode);

    // fonts settle → offsets can shift
    const remeasure = setTimeout(measure, 600);

    return () => {
      clearTimeout(remeasure);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pointermove", onPointerMove);
      prmQuery.removeEventListener("change", applyMotionMode);
      io.disconnect();
      revealIO.disconnect();
      unsubscribeCurve();
      engine?.destroy();
      engineRef.current = null;
    };
  }, []);

  const seek = useCallback((i) => {
    window.scrollTo({
      top: boundsRef.current[i] * scrollableRef.current + 2,
      behavior: reducedRef.current ? "auto" : "smooth",
    });
  }, []);

  const rulerSeek = useCallback((e) => {
    if (e.target.closest("button")) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const frac = Math.min(Math.max((e.clientX - rect.left) / rect.width, 0), 1);
    window.scrollTo({
      top: frac * scrollableRef.current,
      behavior: reducedRef.current ? "auto" : "smooth",
    });
  }, []);

  const setSection = (id) => (el) => {
    sectionRefs.current[id] = el;
  };

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>

      {/* the stage */}
      <div className="sky" aria-hidden="true" />
      <div className="sky-dawn" aria-hidden="true" ref={dawnRef} />
      <canvas className="stagecanvas" ref={canvasRef} aria-hidden="true" />
      <Poster />
      <div className="grain" aria-hidden="true" />
      <div className="vignette" aria-hidden="true" />
      <div className="playhead" aria-hidden="true" ref={playheadRef} />

      {/* editor chrome */}
      <header className="hud-top">
        <span className="wordmark">
          <span className="kf" aria-hidden="true">
            ◆
          </span>
          Meridian
        </span>
        <div className="hud-meta">
          <span className="hud-seq">Seq 001 · Launch</span>
          <span className="hud-tc">
            TC <b ref={tcRef}>00:00:00:00</b>
          </span>
        </div>
      </header>

      <main id="main">
        {/* ACT 00 — FIRST LIGHT */}
        <section id="overture" className="act act-overture" aria-labelledby="overture-h" ref={setSection("overture")}>
          <div className="stage">
            <div className="block reveal">
              <p className="eyebrow">
                Meridian <span className="stamp">· motion editor for the web</span>
              </p>
              <h1 className="headline" id="overture-h">
                The web&rsquo;s <em>missing</em> timeline.
              </h1>
              <p className="lede">
                Interface motion deserves what film has had for a century: a real timeline.{" "}
                <strong>Meridian</strong> lets you sequence keyframes, sculpt easing, and ship the
                exact CSS and Web Animations code you would have written by hand.
              </p>
              <p className="scrollhint">
                <span className="kf" aria-hidden="true" />
                Scroll to scrub the sequence
              </p>
            </div>
          </div>
        </section>

        {/* ACT 01 — TRACKS */}
        <section id="tracks" className="act act-tracks" aria-labelledby="tracks-h" ref={setSection("tracks")}>
          <div className="stage">
            <div className="block block--right reveal">
              <p className="eyebrow">
                Act 01 · Tracks <span className="stamp">tc 00:00:06:00</span>
              </p>
              <h2 className="headline" id="tracks-h">
                Every element <em>on a track.</em>
              </h2>
              <p className="lede">
                The dope sheet, rebuilt for the DOM. Stack elements into tracks, spread properties
                into lanes, and cut springs, keyframes and gestures together the way editors cut
                film. The playhead sweeping the field behind this card is the same one you&rsquo;ll
                drive in Meridian.
              </p>
              <dl className="featrows">
                <div className="featrow">
                  <dt>Scrub</dt>
                  <dd>
                    <b>Frame-accurate playhead</b> — step by frame, snap to beats, audition in
                    place.
                  </dd>
                </div>
                <div className="featrow">
                  <dt>Lanes</dt>
                  <dd>
                    <b>A lane per property</b> — transform, opacity, filter, custom properties.
                  </dd>
                </div>
                <div className="featrow">
                  <dt>Nesting</dt>
                  <dd>
                    <b>Sequences inside sequences</b> — compose scenes from reusable clips.
                  </dd>
                </div>
              </dl>
            </div>
          </div>
        </section>

        {/* ACT 02 — EASE */}
        <section id="ease" className="act act-ease" aria-labelledby="ease-h" ref={setSection("ease")}>
          <div className="stage stage--split">
            <div className="block reveal">
              <p className="eyebrow">
                Act 02 · Ease <span className="stamp">tc 00:00:12:00</span>
              </p>
              <h2 className="headline" id="ease-h">
                Easing you can <em>hold.</em>
              </h2>
              <p className="lede">
                Curves aren&rsquo;t numbers you guess — they&rsquo;re shapes you grab. Drag the
                handles: the river of frames behind this card re-times instantly, and so does the
                code you&rsquo;ll ship in the next act. The dim blue stream is linear time; the gold
                one is yours.
              </p>
            </div>
            <div className="reveal">
              <CurveEditor reducedMotion={reduced} />
            </div>
          </div>
        </section>

        {/* ACT 03 — SHIP */}
        <section id="ship" className="act act-ship" aria-labelledby="ship-h" ref={setSection("ship")}>
          <div className="stage stage--split">
            <div className="block reveal">
              <p className="eyebrow">
                Act 03 · Ship <span className="stamp">tc 00:00:18:00</span>
              </p>
              <h2 className="headline" id="ship-h">
                Ship the code, <em>not a runtime.</em>
              </h2>
              <p className="lede">
                Meridian compiles your timeline to plain CSS and the Web Animations API. No player,
                no dependencies, no lock-in. The export beside this card is live — it&rsquo;s the
                curve you just shaped, and its reduced-motion variant ships with it.
              </p>
            </div>
            <div className="reveal">
              <CodePanel />
            </div>
          </div>
        </section>

        {/* ACT 04 — ZENITH */}
        <section id="zenith" className="act act-zenith" aria-labelledby="zenith-h" ref={setSection("zenith")}>
          <div className="stage">
            <div className="block block--center reveal">
              <p className="eyebrow">
                Act 04 · Zenith <span className="stamp">tc 00:00:24:00</span>
              </p>
              <h2 className="headline" id="zenith-h">
                Cross the <em>meridian.</em>
              </h2>
              <p className="lede">
                The private beta opens this autumn. Early seats go to teams shipping real interface
                motion — bring a project, leave with a timeline.
              </p>
              <div className="cta-row">
                <a className="btn-solar" href="mailto:hello@meridian.tools?subject=Early%20access">
                  Request early access
                </a>
                <a className="link-quiet" href="mailto:hello@meridian.tools">
                  hello@meridian.tools
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* the master timeline */}
      <nav className="hud-bottom" aria-label="Sequence timeline">
        <div className="tl-ruler" ref={rulerRef} onPointerDown={rulerSeek}>
          <div className="tl-fill" ref={fillRef} aria-hidden="true" />
          <div className="tl-caret" ref={caretRef} aria-hidden="true" />
          <div className="tl-marks">
            {ACTS.map((a, i) => (
              <button
                key={a.id}
                type="button"
                className="tl-mark"
                style={{ left: `${marks[i]}%` }}
                aria-current={i === actIdx ? "true" : undefined}
                onClick={() => seek(i)}
              >
                <span className="num">{a.num}</span>
                <span className="lbl">{a.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      <footer className="site-footer">
        <div className="footer-inner">
          <p className="colophon">
            <b>Colophon.</b> Set in Newsreader, Instrument Sans and Fragment Mono. The field behind
            this page is twelve thousand keyframe diamonds drawn in a single WebGL2 call, scrubbed
            by your scrollbar. It rests when the tab is hidden, travels lighter on smaller
            machines, and holds five still poses if you prefer reduced motion. Docs and changelog
            arrive with the beta.
          </p>
          <p className="footer-meta">
            Meridian Tools · MMXXVI
            <br />
            <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>
            <br />
            <span>Private beta · Autumn 2026</span>
          </p>
        </div>
      </footer>
    </>
  );
}

/* Static poster for machines without WebGL2 — the meridian arc, embroidered
   in SVG diamonds. Same identity, zero GPU. */
function Poster() {
  const diamonds = [];
  for (let i = 0; i < 72; i++) {
    const t = i / 71;
    const x = 4 + t * 92;
    const nx = t * 2 - 1;
    const y = 58 - 30 * (1 - nx * nx);
    const s = 0.5 + (1 - Math.abs(nx)) * 0.9;
    const o = 0.25 + (1 - Math.abs(nx)) * 0.75;
    diamonds.push(
      <rect
        key={i}
        x={-s / 2}
        y={-s / 2}
        width={s}
        height={s}
        fill={i % 9 === 0 ? "#efece3" : "#f5b845"}
        opacity={o}
        transform={`translate(${x} ${y}) rotate(45)`}
      />
    );
  }
  return (
    <div className="poster" aria-hidden="true">
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
        {diamonds}
        <line x1="0" y1="58" x2="100" y2="58" stroke="#f5b845" strokeOpacity="0.25" strokeWidth="0.15" />
      </svg>
    </div>
  );
}
