import "./globals.css";
import { Fraunces, Schibsted_Grotesk, Spline_Sans_Mono } from "next/font/google";

/*
 * Type carries the product's two voices:
 *   Fraunces        — display; "motion is craft"
 *   Schibsted Grotesk — body
 *   Spline Sans Mono  — timecode, tracks, code; "frames and code"
 * Loaded via next/font: self-hosted at build time, zero runtime requests.
 */
const fraunces = Fraunces({
  subsets: ["latin"],
  style: ["normal", "italic"],
  axes: ["opsz", "SOFT", "WONK"],
  variable: "--font-fraunces",
  display: "swap",
});
const schibsted = Schibsted_Grotesk({
  subsets: ["latin"],
  variable: "--font-schibsted",
  display: "swap",
});
const spline = Spline_Sans_Mono({
  subsets: ["latin"],
  variable: "--font-spline",
  display: "swap",
});

export const metadata = {
  metadataBase: new URL("https://meridian.tools"),
  title: "Meridian — the motion editor for the web",
  description:
    "Meridian is a timeline-based motion editor for the web. Design animation visually, ship production code.",
  openGraph: {
    title: "Meridian — the motion editor for the web",
    description:
      "Design animation on a real canvas — keyframes, curves, a playhead — then ship it as plain, production-ready code.",
    type: "website",
  },
};

export const viewport = {
  themeColor: "#edeee9",
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={`${fraunces.variable} ${schibsted.variable} ${spline.variable}`}
    >
      <body>{children}</body>
    </html>
  );
}
