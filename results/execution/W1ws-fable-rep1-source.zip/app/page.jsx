import Hero from "./components/Hero";
import Curves from "./components/Curves";
import TimecodeChip from "./components/TimecodeChip";
import RevealManager from "./components/RevealManager";

/* Hand-tokenized code sample — the "file" behind the hero. Keeping it as
   data avoids a syntax-highlighting dependency for 24 lines of code. */
const k = (text) => ({ cls: "tk-k", text });
const s = (text) => ({ cls: "tk-s", text });
const c = (text) => ({ cls: "tk-c", text });
const f = (text) => ({ cls: "tk-f", text });
const p = (text) => ({ cls: "tk-p", text });

const CODE_LINES = [
  [c("// hero.timeline.js — exported by Meridian 1.0")],
  [c("// The source of the hero above. Scrub it, then read it.")],
  [],
  [k("import"), p(" { "), f("timeline"), p(" } "), k("from"), p(" "), s('"@meridian/run"'), p(";  "), c("// 3.2 kB, zero deps")],
  [],
  [k("export const"), f(" hero "), p("= "), f("timeline"), p("({")],
  [p("  "), f("duration"), p(": "), s("6"), p(", "), f("fps"), p(": "), s("60"), p(",")],
  [p("  "), f("tracks"), p(": {")],
  [p("    "), s('"headline.line-1"'), p(": [")],
  [p("      { "), f("at"), p(": "), s("0.25"), p(", "), f("y"), p(": "), s("44"), p(", "), f("opacity"), p(": "), s("0"), p(", "), f("blur"), p(": "), s("7"), p(" },")],
  [p("      { "), f("at"), p(": "), s("1.35"), p(", "), f("y"), p(": "), s("0"), p(", "), f("opacity"), p(": "), s("1"), p(", "), f("ease"), p(": "), s('"outExpo"'), p(" },")],
  [p("    ],")],
  [p("    "), s('"selection.box"'), p(": [")],
  [p("      { "), f("at"), p(": "), s("1.70"), p(", "), f("draw"), p(": "), s("0"), p(" },")],
  [p("      { "), f("at"), p(": "), s("2.45"), p(", "), f("draw"), p(": "), s("1"), p(", "), f("ease"), p(": "), s('"inOutCubic"'), p(" },")],
  [p("    ],")],
  [p("    "), s('"layer-01.flight"'), p(": [")],
  [p("      { "), f("at"), p(": "), s("3.05"), p(", "), f("path"), p(": "), s("0"), p(" },")],
  [p("      { "), f("at"), p(": "), s("5.50"), p(", "), f("path"), p(": "), s("1"), p(", "), f("ease"), p(": "), s('"inOutCubic"'), p(" },")],
  [p("    ],")],
  [p("  },")],
  [p("});")],
  [],
  [f("hero"), p("."), f("play"), p("();  "), c("// or hero.seek(t) — the red playhead does")],
];

function Wordmark({ href, label }) {
  return (
    <a className="wordmark" href={href} aria-label={label}>
      <span aria-hidden="true">
        MER
        <span className="ph-i" />
        DIAN
      </span>
    </a>
  );
}

export default function Home() {
  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <RevealManager />

      <header className="appbar">
        <div className="wrap appbar-in">
          <Wordmark href="#top" label="Meridian home" />
          <nav aria-label="Primary">
            <a href="#product">Editor</a>
            <a href="#curves">Curves</a>
            <a href="#code">Export</a>
          </nav>
          <div className="appbar-right">
            <TimecodeChip />
            <a className="btn btn-primary btn-sm" href="#beta">
              Request beta access
            </a>
          </div>
        </div>
      </header>

      <main id="main">
        <span id="top" />
        <Hero />

        <section className="sec" id="product" aria-labelledby="h-product">
          <div className="wrap">
            <p className="eyebrow chrome-label" data-reveal>
              the editor · three panels
            </p>
            <h2 className="display" id="h-product" data-reveal>
              An editor, not another library.
            </h2>
            <p className="lede" data-reveal style={{ "--rv-delay": ".08s" }}>
              Motion libraries hand you an API and wish you luck. Meridian hands you a
              canvas, a timeline, and a playhead — and when you&rsquo;re done, the code
              walks out the door with you.
            </p>

            <div className="trackrows">
              <div className="trackrow" data-reveal>
                <div className="tr-rail mono">
                  <span className="tr-diamond" aria-hidden="true" />
                  <span>canvas</span>
                </div>
                <div>
                  <h3>Design where it ships</h3>
                  <p>
                    No preview pane. You select real DOM, nudge it into place, and
                    keyframe it on the element itself — what you scrub is exactly what
                    the browser renders, because it is the browser.
                  </p>
                </div>
              </div>
              <div className="trackrow" data-reveal style={{ "--rv-delay": ".06s" }}>
                <div className="tr-rail mono">
                  <span className="tr-diamond" aria-hidden="true" />
                  <span>timeline</span>
                </div>
                <div>
                  <h3>Frames, not vibes</h3>
                  <p>
                    A real playhead at 60 fps. Snap keyframes to frames, stagger tracks
                    against each other, and step through a move one frame at a time
                    until it lands.
                  </p>
                </div>
              </div>
              <div className="trackrow" data-reveal style={{ "--rv-delay": ".12s" }}>
                <div className="tr-rail mono">
                  <span className="tr-diamond" aria-hidden="true" />
                  <span>export</span>
                </div>
                <div>
                  <h3>Leave with the code</h3>
                  <p>
                    One export: plain Web Animations API or CSS, plus an optional 3.2 kB
                    scrubbable runtime. Your motion lives in your repo, not our SDK.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="sec sec-dark on-dark" id="curves" aria-labelledby="h-curves">
          <div className="wrap">
            <p className="eyebrow chrome-label" data-reveal>
              panel · curve editor
            </p>
            <h2 className="display" id="h-curves" data-reveal>
              Curves you can feel.
            </h2>
            <p className="lede" data-reveal style={{ "--rv-delay": ".06s" }}>
              Six of the presets that ship with Meridian. Select one — the plot redraws
              and the ball runs it once. In the editor, those blue handles are yours to
              pull.
            </p>
            <div data-reveal style={{ "--rv-delay": ".1s" }}>
              <Curves />
            </div>
          </div>
        </section>

        <section className="sec" id="code" aria-labelledby="h-code">
          <div className="wrap">
            <p className="eyebrow chrome-label" data-reveal>
              export · hero.timeline.js
            </p>
            <h2 className="display" id="h-code" data-reveal>
              The code walks out the door.
            </h2>
            <p className="lede" data-reveal style={{ "--rv-delay": ".06s" }}>
              Nothing to embed, nothing to license. Meridian compiles a timeline into
              code you&rsquo;d be glad to review — this page&rsquo;s hero included.
            </p>

            <div className="code-grid">
              <div className="codecard" data-reveal>
                <div className="codecard-top mono">
                  <span className="dots" aria-hidden="true">
                    <i />
                    <i />
                    <i />
                  </span>
                  hero.timeline.js
                </div>
                <pre tabIndex={0}>
                  <code>
                    {CODE_LINES.map((line, i) => (
                      <span key={i}>
                        {line.map((tk, j) => (
                          <span key={j} className={tk.cls}>
                            {tk.text}
                          </span>
                        ))}
                        {"\n"}
                      </span>
                    ))}
                  </code>
                </pre>
              </div>
              <ul className="export-list" data-reveal style={{ "--rv-delay": ".1s" }}>
                <li>
                  <span className="k">waapi</span>
                  <span className="v">Native Web Animations API — no wrapper, no lock-in</span>
                </li>
                <li>
                  <span className="k">css</span>
                  <span className="v">Pure @keyframes for the simple cases</span>
                </li>
                <li>
                  <span className="k">runtime</span>
                  <span className="v">
                    Optional 3.2 kB scrubbable runtime — the one this page runs on
                  </span>
                </li>
                <li>
                  <span className="k">reduced-motion</span>
                  <span className="v">A still variant generated with every export</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        <section className="sec sec-dark on-dark beta" id="beta" aria-labelledby="h-beta">
          <div className="wrap">
            <p className="eyebrow chrome-label" data-reveal>
              00:00:00:00 · start here
            </p>
            <h2 className="display" id="h-beta" data-reveal>
              Set your motion to <span className="it">Meridian&nbsp;time.</span>
            </h2>
            <div data-reveal style={{ "--rv-delay": ".08s" }}>
              <a
                className="btn btn-primary"
                href="mailto:hello@meridian.tools?subject=Beta%20access"
              >
                Request beta access
              </a>
              <p className="beta-note mono">
                PRIVATE BETA · INVITES WEEKLY · BRING A PROJECT, NOT A PROTOTYPE
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="site">
        <div className="wrap foot-in">
          <div>
            <Wordmark href="#top" label="Meridian — back to top" />
            <p className="foot-tag">The motion editor for the web.</p>
          </div>
          <div className="foot-links">
            <a href="#product">Editor</a>
            <a href="#curves">Curves</a>
            <a href="#code">Export</a>
            <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>
          </div>
        </div>
        <div className="wrap foot-line mono">
          © 2026 MERIDIAN · LONGITUDE 0° 0′ 0″ — EVERY FRAME MEASURED FROM HERE
        </div>
      </footer>
    </>
  );
}
