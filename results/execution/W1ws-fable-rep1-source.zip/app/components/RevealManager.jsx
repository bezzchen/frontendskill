"use client";

/*
 * One-shot scroll reveals. Progressive-enhancement rules:
 *  - content is fully visible by default (no JS, no problem)
 *  - hides an element only if JS is running, the element is still below
 *    the fold, and prefers-reduced-motion is NOT set
 *  - IntersectionObserver reveals once, then unobserves (no ambient work)
 */

import { useEffect } from "react";

export default function RevealManager() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const els = Array.from(document.querySelectorAll("[data-reveal]"));
    if (!els.length) return;

    const vh = window.innerHeight;
    const pending = els.filter((el) => {
      if (el.getBoundingClientRect().top > vh * 0.9) {
        el.classList.add("rv-pre");
        return true;
      }
      return false;
    });
    if (!pending.length) return;

    const io = new IntersectionObserver(
      (entries) => {
        for (const en of entries) {
          if (en.isIntersecting) {
            en.target.classList.add("rv-in");
            io.unobserve(en.target);
          }
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
    );
    pending.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return null;
}
