"use client";

/*
 * App-bar timecode chip. Watches the hero engine's clock bus and writes
 * text directly — zero React re-renders per frame. Decorative chrome
 * (aria-hidden): the timeline panel's slider is the accessible control.
 */

import { useEffect, useRef } from "react";
import { clock, smpte } from "../lib/engine";

export default function TimecodeChip() {
  const txt = useRef(null);
  const dot = useRef(null);

  useEffect(() => {
    return clock.subscribe((t, playing) => {
      if (txt.current) txt.current.textContent = smpte(t);
      if (dot.current) dot.current.dataset.live = playing ? "1" : "0";
    });
  }, []);

  return (
    <span className="tc-chip mono" aria-hidden="true">
      <span className="tc-dot" ref={dot} />
      <span ref={txt}>00:00:06:00</span>
    </span>
  );
}
