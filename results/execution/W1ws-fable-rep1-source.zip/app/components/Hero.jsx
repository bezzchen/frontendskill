"use client";

/*
 * The signature moment: the hero is a real Meridian composition.
 * A 6-second, 60 fps keyframe timeline drives the actual page hero —
 * play it, scrub it with the red playhead, or step it frame by frame.
 *
 * Behavior contract (verified in the browser, not assumed):
 *  - pauses when the document is hidden, resumes if it was playing
 *  - pauses when the hero scrolls out of view, resumes when it returns
 *  - never auto-plays under prefers-reduced-motion (final frame shown;
 *    the transport still works — motion only on explicit request)
 */

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { DUR, FPS, sample, smpte, clock } from "../lib/engine";

/* Keyframe channels for every element on the stage. */
const CH = {
  grid: { o: [{ t: 0, v: 0 }, { t: 0.7, v: 1, e: "outQuint" }] },
  line1: {
    y: [{ t: 0.25, v: 44 }, { t: 1.35, v: 0, e: "outExpo" }],
    o: [{ t: 0.25, v: 0 }, { t: 1.05, v: 1, e: "outQuint" }],
    b: [{ t: 0.25, v: 7 }, { t: 1.3, v: 0, e: "outQuint" }],
  },
  line2: {
    y: [{ t: 0.55, v: 44 }, { t: 1.7, v: 0, e: "outExpo" }],
    o: [{ t: 0.55, v: 0 }, { t: 1.35, v: 1, e: "outQuint" }],
    b: [{ t: 0.55, v: 7 }, { t: 1.65, v: 0, e: "outQuint" }],
  },
  selbox: {
    o: [{ t: 1.7, v: 0 }, { t: 1.95, v: 1, e: "outQuint" }],
    d: [{ t: 1.7, v: 0 }, { t: 2.45, v: 1, e: "inOutCubic" }],
    hs: [{ t: 2.3, v: 0 }, { t: 2.6, v: 1, e: "outBack" }],
  },
  badge: {
    o: [{ t: 1.85, v: 0 }, { t: 2.15, v: 1, e: "outQuint" }],
    y: [{ t: 1.85, v: 8 }, { t: 2.15, v: 0, e: "outQuint" }],
  },
  sub: {
    y: [{ t: 2.5, v: 18 }, { t: 3.2, v: 0, e: "outQuint" }],
    o: [{ t: 2.5, v: 0 }, { t: 3.1, v: 1, e: "outQuint" }],
  },
  cta: {
    y: [{ t: 2.8, v: 18 }, { t: 3.5, v: 0, e: "outQuint" }],
    o: [{ t: 2.8, v: 0 }, { t: 3.3, v: 1, e: "outQuint" }],
    s: [{ t: 2.8, v: 0.92 }, { t: 3.6, v: 1, e: "outBack" }],
  },
  flight: {
    o: [{ t: 3.05, v: 0 }, { t: 3.35, v: 1, e: "outQuint" }],
    d: [{ t: 3.05, v: 0 }, { t: 4.0, v: 1, e: "inOutCubic" }],
    p: [{ t: 3.9, v: 0 }, { t: 5.5, v: 1, e: "inOutCubic" }],
    r: [{ t: 3.9, v: -10 }, { t: 5.5, v: 8, e: "inOutCubic" }],
    co: [{ t: 3.75, v: 0 }, { t: 4.0, v: 1, e: "outQuint" }],
  },
  mer: {
    o: [
      { t: 0, v: 0 },
      { t: 0.12, v: 0.85 },
      { t: 5.55, v: 0.85 },
      { t: 5.95, v: 0 },
    ],
  },
};

/* What the timeline panel displays — same times the engine samples. */
const TRACKS = [
  { id: "canvas.grid", vno: "V1", kfs: [0, 0.7] },
  { id: "headline.line-1", vno: "V2", kfs: [0.25, 1.35] },
  { id: "headline.line-2", vno: "V3", kfs: [0.55, 1.7] },
  { id: "selection.box", vno: "V4", kfs: [1.7, 2.45, 2.6] },
  { id: "copy.rise", vno: "V5", kfs: [2.5, 3.2] },
  { id: "cta.spring", vno: "V6", kfs: [2.8, 3.6] },
  { id: "layer-01.flight", vno: "V7", kfs: [3.05, 4.0, 5.5] },
];

const FLIGHT_D =
  "M 26 36 C 170 -8 330 34 372 128 C 404 200 380 268 300 306 C 246 332 176 330 140 300";

const pct = (t) => `${(t / DUR) * 100}%`;

export default function Hero() {
  const heroEl = useRef(null);
  const stageEl = useRef(null);
  const dressEl = useRef(null);
  const merEl = useRef(null);
  const h1Wrap = useRef(null);
  const l1 = useRef(null);
  const l2 = useRef(null);
  const selSvg = useRef(null);
  const badgeEl = useRef(null);
  const subEl = useRef(null);
  const ctaEl = useRef(null);
  const flightSvg = useRef(null);
  const drawPath = useRef(null);
  const chipG = useRef(null);
  const pheadEl = useRef(null);
  const tcMain = useRef(null);
  const scrubEl = useRef(null);
  const lanesEl = useRef(null);

  const [playing, setPlaying] = useState(false);
  const [box, setBox] = useState({ w: 0, h: 0 });

  const S = useRef({
    t: DUR,
    playing: false,
    wasPlaying: false,
    inView: true,
    scrubbing: false,
    scrubWasPlaying: false,
    raf: 0,
    last: 0,
    pathLen: 0,
    stageW: 0,
    reduced: false,
    userTouched: false,
  }).current;

  /* ---- engine ------------------------------------------------- */

  const apply = (t) => {
    if (dressEl.current) dressEl.current.style.opacity = sample(CH.grid.o, t);

    const setLine = (el, ch) => {
      if (!el.current) return;
      const y = sample(ch.y, t);
      const o = sample(ch.o, t);
      const b = sample(ch.b, t);
      el.current.style.transform = `translate3d(0, ${y}px, 0)`;
      el.current.style.opacity = o;
      el.current.style.filter = b > 0.02 ? `blur(${b}px)` : "";
    };
    setLine(l1, CH.line1);
    setLine(l2, CH.line2);

    if (selSvg.current) {
      const el = selSvg.current;
      el.style.opacity = sample(CH.selbox.o, t);
      el.style.setProperty("--boxdash", String(1 - sample(CH.selbox.d, t)));
      el.style.setProperty("--hs", String(sample(CH.selbox.hs, t)));
    }
    if (badgeEl.current) {
      badgeEl.current.style.opacity = sample(CH.badge.o, t);
      badgeEl.current.style.transform = `translate3d(0, ${sample(CH.badge.y, t)}px, 0)`;
    }
    if (subEl.current) {
      subEl.current.style.opacity = sample(CH.sub.o, t);
      subEl.current.style.transform = `translate3d(0, ${sample(CH.sub.y, t)}px, 0)`;
    }
    if (ctaEl.current) {
      ctaEl.current.style.opacity = sample(CH.cta.o, t);
      ctaEl.current.style.transform = `translate3d(0, ${sample(CH.cta.y, t)}px, 0) scale(${sample(CH.cta.s, t)})`;
    }
    if (flightSvg.current) {
      const el = flightSvg.current;
      el.style.opacity = sample(CH.flight.o, t);
      el.style.setProperty("--pathdash", String(1 - sample(CH.flight.d, t)));
      if (chipG.current && drawPath.current && S.pathLen > 0) {
        const p = sample(CH.flight.p, t);
        const pt = drawPath.current.getPointAtLength(p * S.pathLen);
        chipG.current.setAttribute(
          "transform",
          `translate(${pt.x} ${pt.y}) rotate(${sample(CH.flight.r, t)})`
        );
        chipG.current.style.opacity = sample(CH.flight.co, t);
      }
    }
    if (merEl.current) {
      merEl.current.style.opacity = sample(CH.mer.o, t);
      merEl.current.style.transform = `translateX(${(t / DUR) * S.stageW}px)`;
    }
    if (pheadEl.current) pheadEl.current.style.left = pct(t);
    if (tcMain.current) tcMain.current.textContent = smpte(t);
    if (scrubEl.current) {
      const f = Math.round(t * FPS);
      scrubEl.current.value = String(f);
      scrubEl.current.setAttribute(
        "aria-valuetext",
        `${t.toFixed(2)} seconds of 6 — frame ${f} of 360`
      );
    }
    clock.publish(t, S.playing);
  };

  const tick = (now) => {
    if (!S.playing) return;
    const dt = Math.min((now - S.last) / 1000, 0.05);
    S.last = now;
    S.t = Math.min(S.t + dt, DUR);
    apply(S.t);
    if (S.t >= DUR) {
      S.playing = false;
      setPlaying(false);
      clock.publish(S.t, false);
    } else {
      S.raf = requestAnimationFrame(tick);
    }
  };

  const play = () => {
    if (S.playing) return;
    if (S.t >= DUR - 1e-6) S.t = 0;
    S.playing = true;
    setPlaying(true);
    S.last = performance.now();
    cancelAnimationFrame(S.raf);
    S.raf = requestAnimationFrame(tick);
    clock.publish(S.t, true);
  };

  const pause = () => {
    if (!S.playing) return;
    S.playing = false;
    setPlaying(false);
    cancelAnimationFrame(S.raf);
    clock.publish(S.t, false);
  };

  const seek = (t) => {
    S.t = Math.min(Math.max(t, 0), DUR);
    apply(S.t);
  };

  /* ---- measurement -------------------------------------------- */

  useLayoutEffect(() => {
    const measure = () => {
      if (selSvg.current) {
        // .selbox is a plain div (insets are reliable on non-replaced
        // elements); the svg inside just fills it
        setBox({
          w: selSvg.current.clientWidth,
          h: selSvg.current.clientHeight,
        });
      }
      if (stageEl.current) S.stageW = stageEl.current.clientWidth;
      try {
        S.pathLen = drawPath.current ? drawPath.current.getTotalLength() : 0;
      } catch {
        S.pathLen = 0;
      }
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (h1Wrap.current) ro.observe(h1Wrap.current);
    if (stageEl.current) ro.observe(stageEl.current);
    return () => ro.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---- mount: reduced motion, autoplay, visibility, exposure --- */

  useEffect(() => {
    const rmq = window.matchMedia("(prefers-reduced-motion: reduce)");
    S.reduced = rmq.matches;
    const onRM = (e) => {
      S.reduced = e.matches;
      if (e.matches) {
        pause();
        seek(DUR);
      }
    };
    rmq.addEventListener?.("change", onRM);

    apply(S.t); // paint the resting (final) frame deterministically

    let cancelled = false;
    let tm = 0;
    if (!S.reduced) {
      const kick = () => {
        if (cancelled || S.userTouched || S.reduced) return;
        if (document.hidden || !S.inView) return;
        seek(0);
        play();
      };
      tm = window.setTimeout(kick, 1200);
      document.fonts?.ready?.then(() => {
        if (cancelled) return;
        window.clearTimeout(tm);
        tm = window.setTimeout(kick, 130);
      });
    }

    const onVis = () => {
      if (document.hidden) {
        if (S.playing) {
          S.wasPlaying = true;
          pause();
        }
      } else if (S.wasPlaying && S.inView) {
        S.wasPlaying = false;
        play();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    const io = new IntersectionObserver(
      ([en]) => {
        S.inView = en.isIntersecting;
        if (!en.isIntersecting) {
          if (S.playing) {
            S.wasPlaying = true;
            pause();
          }
        } else if (S.wasPlaying && !document.hidden) {
          S.wasPlaying = false;
          play();
        }
      },
      { threshold: 0.08 }
    );
    if (heroEl.current) io.observe(heroEl.current);

    // Small verifiable handle (and a console toy for the curious).
    window.__meridian = {
      time: () => S.t,
      playing: () => S.playing,
      play,
      pause,
      seek: (t) => {
        S.userTouched = true;
        pause();
        seek(t);
      },
    };

    return () => {
      cancelled = true;
      window.clearTimeout(tm);
      rmq.removeEventListener?.("change", onRM);
      document.removeEventListener("visibilitychange", onVis);
      io.disconnect();
      cancelAnimationFrame(S.raf);
      delete window.__meridian;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---- transport + scrub handlers ------------------------------ */

  const onToggle = () => {
    S.userTouched = true;
    if (S.playing) pause();
    else play();
  };
  const onRestart = () => {
    S.userTouched = true;
    pause();
    seek(0);
  };

  const seekFromPointer = (e) => {
    const lanes = lanesEl.current;
    if (!lanes) return;
    const rect = lanes.getBoundingClientRect();
    const u = Math.min(Math.max((e.clientX - rect.left) / rect.width, 0), 1);
    seek(u * DUR);
  };
  const onPointerDown = (e) => {
    S.userTouched = true;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    lanesEl.current?.setPointerCapture(e.pointerId);
    S.scrubWasPlaying = S.playing;
    pause();
    S.scrubbing = true;
    seekFromPointer(e);
  };
  const onPointerMove = (e) => {
    if (S.scrubbing) seekFromPointer(e);
  };
  const onPointerUp = (e) => {
    if (!S.scrubbing) return;
    S.scrubbing = false;
    lanesEl.current?.releasePointerCapture?.(e.pointerId);
    if (S.scrubWasPlaying && S.t < DUR) play();
    S.scrubWasPlaying = false;
  };
  const onScrubInput = (e) => {
    S.userTouched = true;
    pause();
    seek(Number(e.target.value) / FPS);
  };

  /* ---- render --------------------------------------------------- */

  const handles =
    box.w > 4
      ? [
          [0, 0],
          [box.w / 2, 0],
          [box.w, 0],
          [box.w, box.h / 2],
          [box.w, box.h],
          [box.w / 2, box.h],
          [0, box.h],
          [0, box.h / 2],
        ]
      : [];

  return (
    <section className="hero" ref={heroEl} aria-label="Meridian introduction">
      <div className="stage" ref={stageEl}>
        <div className="stage-dress" ref={dressEl} aria-hidden="true">
          <div className="checker" />
          <div className="ruler-x">
            {Array.from({ length: 24 }, (_, i) => (
              <span key={i}>{i * 120}</span>
            ))}
          </div>
          <div className="ruler-y" />
          <div className="ruler-corner" />
        </div>

        <div className="stage-meridian" ref={merEl} aria-hidden="true" />

        <svg
          className="flight"
          ref={flightSvg}
          viewBox="0 0 440 400"
          aria-hidden="true"
          focusable="false"
        >
          <path className="guide" d={FLIGHT_D} pathLength="1" />
          <path className="draw" d={FLIGHT_D} pathLength="1" ref={drawPath} />
          <line className="pinline" x1="26" y1="36" x2="110" y2="12" />
          <circle className="pin" cx="26" cy="36" r="4" />
          <circle className="pin" cx="110" cy="12" r="3" />
          <line className="pinline" x1="140" y1="300" x2="188" y2="336" />
          <circle className="pin" cx="140" cy="300" r="4" />
          <circle className="pin" cx="188" cy="336" r="3" />
          <g ref={chipG} style={{ opacity: 0 }} transform="translate(26 36)">
            <rect className="chip-body" x="-16" y="-16" width="32" height="32" rx="6" />
            <rect className="chip-key" x="-4.5" y="-4.5" width="9" height="9" transform="rotate(45)" />
          </g>
        </svg>

        <div className="stage-inner wrap">
          <p className="layer-badge mono" ref={badgeEl}>
            <span className="lb-t" aria-hidden="true">
              T
            </span>
            hero.headline
            <span className="lb-sel">— selected</span>
          </p>

          <div className="h1wrap" ref={h1Wrap}>
            <h1 className="display">
              <span className="h1line" ref={l1}>
                Every frame,
              </span>
              <span className="h1line it" ref={l2}>
                on purpose.
              </span>
            </h1>
            <div className="selbox" ref={selSvg} aria-hidden="true">
              {/* svg fills the inset-positioned div; user units = CSS px */}
              <svg width="100%" height="100%" focusable="false">
                <rect
                  className="box"
                  x="0.75"
                  y="0.75"
                  width={Math.max(box.w - 1.5, 1)}
                  height={Math.max(box.h - 1.5, 1)}
                  pathLength="1"
                />
                {handles.map(([x, y], i) => (
                  <rect key={i} className="hnd" x={x - 3.5} y={y - 3.5} width="7" height="7" />
                ))}
              </svg>
            </div>
          </div>

          <p className="sub" ref={subEl}>
            Meridian is a timeline-based motion editor for the web. Set keyframes on a
            real canvas, shape the curves between them, then ship the result as{" "}
            <strong>plain, production-ready code</strong>.
          </p>

          <div className="cta-row" ref={ctaEl}>
            <a className="btn btn-primary" href="#beta">
              Request beta access
            </a>
            <a className="btn btn-ghost" href="#code">
              See what it ships
            </a>
            <p className="cta-note mono">
              PRIVATE BETA · EXPORTS WAAPI + CSS · RUNTIME 3.2 KB
            </p>
          </div>
        </div>
      </div>

      {/* ---- the timeline panel: this drives the hero above ---- */}
      <div
        className="tl-panel"
        role="group"
        aria-label="Timeline for the hero animation — the hero above follows the playhead"
      >
        <div className="tl-top">
          <div className="tl-transport">
            <button className="tl-btn" type="button" onClick={onRestart} aria-label="Back to start">
              <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true">
                <path d="M2.5 1.5v11" stroke="currentColor" strokeWidth="2" />
                <path d="M12.5 1.5 5 7l7.5 5.5z" fill="currentColor" />
              </svg>
            </button>
            <button
              className="tl-btn"
              type="button"
              onClick={onToggle}
              aria-label={playing ? "Pause" : "Play"}
            >
              {playing ? (
                <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true">
                  <rect x="2" y="1.5" width="3.4" height="11" fill="currentColor" />
                  <rect x="8.6" y="1.5" width="3.4" height="11" fill="currentColor" />
                </svg>
              ) : (
                <svg width="12" height="12" viewBox="0 0 14 14" aria-hidden="true">
                  <path d="M3 1.5 12.5 7 3 12.5z" fill="currentColor" />
                </svg>
              )}
            </button>
          </div>
          <div className="tl-tc mono" aria-hidden="true">
            <span ref={tcMain}>00:00:06:00</span>{" "}
            <span className="dim">/ 00:00:06:00 · 60 FPS</span>
          </div>
          <div className="tl-file mono">
            hero.mtl · 7 tracks · <span className="tl-hint">drag the red playhead</span>
          </div>
        </div>

        <div className="tl-body">
          <div className="tl-labels mono" aria-hidden="true">
            {TRACKS.map((tr) => (
              <div className="tl-lab" key={tr.id}>
                <span className="vno">{tr.vno}</span>
                {tr.id}
              </div>
            ))}
          </div>

          <div
            className="tl-lanes"
            ref={lanesEl}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
          >
            <div className="tl-ruler mono" aria-hidden="true">
              {Array.from({ length: 6 }, (_, i) => (
                <span key={i}>{i}s</span>
              ))}
            </div>

            {TRACKS.map((tr) => {
              const inT = tr.kfs[0];
              const outT = tr.kfs[tr.kfs.length - 1];
              return (
                <div className="tl-row" key={tr.id} aria-hidden="true">
                  <div
                    className="tl-bar"
                    style={{ left: pct(inT), width: `${((outT - inT) / DUR) * 100}%` }}
                  />
                  {tr.kfs.map((k) => (
                    <span className="tl-kf" key={k} style={{ left: pct(k) }} />
                  ))}
                </div>
              );
            })}

            <div className="tl-phead" ref={pheadEl} aria-hidden="true">
              <div className="tl-phead-flag" />
            </div>

            <input
              className="tl-scrub"
              ref={scrubEl}
              type="range"
              min="0"
              max="360"
              step="1"
              defaultValue="360"
              aria-label="Playhead — scrub the hero timeline"
              aria-describedby="scrub-help"
              onInput={onScrubInput}
            />
            <span id="scrub-help" className="sr-only">
              Left and right arrow keys step one frame at a time. The hero animation
              above follows the playhead.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
