"use client";

/*
 * The curve library — an interactive easing playground styled like
 * Meridian's curve editor. Selecting a preset redraws the bezier plot
 * (with grabbable-looking handles) and runs a single finite demo pass
 * on the runway below. Event-driven only: nothing loops, nothing runs
 * while unattended, and under prefers-reduced-motion the ball never
 * moves — the plot alone carries the meaning.
 */

import { useEffect, useRef, useState } from "react";
import { cubicBezier } from "../lib/engine";

const S = 260; // plot size in svg units

const PRESETS = [
  {
    id: "outQuint",
    bez: [0.22, 1, 0.36, 1],
    blurb: "The house default. Fast off the mark, lands like it planned to.",
  },
  {
    id: "outExpo",
    bez: [0.16, 1, 0.3, 1],
    blurb: "Snaps to attention, then whispers into place. Good for reveals.",
  },
  {
    id: "inOutCubic",
    bez: [0.65, 0, 0.35, 1],
    blurb: "Symmetric. For moves that both start and end on screen.",
  },
  {
    id: "outBack",
    bez: [0.34, 1.56, 0.64, 1],
    blurb: "Overshoots by a breath and settles. Buttons love it.",
  },
  {
    id: "inOutBack",
    bez: [0.68, -0.55, 0.27, 1.55],
    blurb: "Winds up before it goes. Anticipation, straight from animation school.",
  },
  {
    id: "linear",
    bez: [0, 0, 1, 1],
    blurb: "No opinion. Fine for opacity, suspicious anywhere else.",
  },
];

export default function Curves() {
  const [active, setActive] = useState(PRESETS[0]);
  const ball = useRef(null);
  const runway = useRef(null);
  const anim = useRef(0);
  const reduced = useRef(false);

  useEffect(() => {
    const rmq = window.matchMedia("(prefers-reduced-motion: reduce)");
    reduced.current = rmq.matches;
    const onRM = (e) => (reduced.current = e.matches);
    rmq.addEventListener?.("change", onRM);
    return () => {
      rmq.removeEventListener?.("change", onRM);
      cancelAnimationFrame(anim.current);
    };
  }, []);

  const run = (preset) => {
    setActive(preset);
    cancelAnimationFrame(anim.current);
    if (reduced.current || !ball.current || !runway.current) return;
    const fn = cubicBezier(...preset.bez);
    const width = runway.current.clientWidth - 16;
    const start = performance.now();
    const durMs = 900;
    const step = (now) => {
      const u = Math.min((now - start) / durMs, 1);
      const v = fn(u);
      if (ball.current)
        ball.current.style.transform = `translate3d(${v * width}px, 0, 0)`;
      if (u < 1) anim.current = requestAnimationFrame(step);
    };
    anim.current = requestAnimationFrame(step);
  };

  const [x1, y1, x2, y2] = active.bez;
  const p1 = { x: x1 * S, y: (1 - y1) * S };
  const p2 = { x: x2 * S, y: (1 - y2) * S };
  const d = `M 0 ${S} C ${p1.x} ${p1.y} ${p2.x} ${p2.y} ${S} 0`;

  return (
    <div className="curves-grid">
      <div className="curve-plot">
        <svg viewBox="-14 -64 288 388" role="img" aria-label={`Easing curve ${active.id}`}>
          {/* grid */}
          {[0.25, 0.5, 0.75].map((g) => (
            <g key={g} stroke="#2b2e34" strokeWidth="1">
              <line x1={g * S} y1="0" x2={g * S} y2={S} />
              <line x1="0" y1={g * S} x2={S} y2={g * S} />
            </g>
          ))}
          <rect x="0" y="0" width={S} height={S} fill="none" stroke="#3a3e45" strokeWidth="1.2" />
          {/* control handles, like the editor's */}
          <line x1="0" y1={S} x2={p1.x} y2={p1.y} stroke="#2c5bff" strokeWidth="1.2" strokeDasharray="4 4" />
          <line x1={S} y1="0" x2={p2.x} y2={p2.y} stroke="#2c5bff" strokeWidth="1.2" strokeDasharray="4 4" />
          <path d={d} fill="none" stroke="#dda53e" strokeWidth="2.5" />
          <circle cx="0" cy={S} r="5" fill="#131417" stroke="#e7e8e3" strokeWidth="1.4" />
          <circle cx={S} cy="0" r="5" fill="#131417" stroke="#e7e8e3" strokeWidth="1.4" />
          <circle cx={p1.x} cy={p1.y} r="5.5" fill="#2c5bff" />
          <circle cx={p2.x} cy={p2.y} r="5.5" fill="#2c5bff" />
          <text x="0" y={S + 22} fill="#999ea6" fontSize="11" fontFamily="var(--font-spline), monospace">
            t = 0
          </text>
          <text x={S} y={S + 22} textAnchor="end" fill="#999ea6" fontSize="11" fontFamily="var(--font-spline), monospace">
            t = 1
          </text>
        </svg>
        <p className="curve-readout mono" aria-live="polite">
          cubic-bezier({active.bez.map((n) => n.toFixed(2)).join(", ")})
        </p>
      </div>

      <div>
        <div className="curve-chips" role="group" aria-label="Easing presets">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              className="curve-chip"
              aria-pressed={active.id === p.id}
              onClick={() => run(p)}
            >
              {p.id}
            </button>
          ))}
        </div>
        <p className="curve-blurb">{active.blurb}</p>
        <div className="runway" ref={runway} aria-hidden="true">
          <div className="runway-ticks" />
          <span className="runway-label">in</span>
          <span className="runway-label end">out</span>
          <div className="runway-ball" ref={ball} />
        </div>
      </div>
    </div>
  );
}
