// QA rig: real-GPU headless run. FPS floor + interaction contract.
import puppeteer from "puppeteer-core";

const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const URL = process.env.QA_URL || "http://localhost:3021";

const stats = (arr) => {
  const s = [...arr].sort((a, b) => a - b);
  const q = (p) => s[Math.min(s.length - 1, Math.floor(p * s.length))];
  return {
    n: s.length,
    avg: +(s.reduce((a, b) => a + b, 0) / s.length).toFixed(2),
    p50: +q(0.5).toFixed(2),
    p95: +q(0.95).toFixed(2),
    over25ms: s.filter((v) => v > 25).length,
  };
};

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: "new",
  args: ["--use-angle=metal", "--window-size=1440,940", "--hide-scrollbars"],
  defaultViewport: { width: 1440, height: 900 },
});
const page = await browser.newPage();
const errors = [];
page.on("console", (m) => {
  if (m.type() === "error") errors.push(m.text().slice(0, 200));
});
page.on("pageerror", (e) => errors.push("PAGEERROR " + String(e).slice(0, 200)));

await page.goto(URL, { waitUntil: "networkidle0", timeout: 60000 });
await page.waitForFunction(() => !document.querySelector(".boot"), { timeout: 30000 });
await new Promise((r) => setTimeout(r, 800));

// --- 1. ambient hero fps
const ambient = await page.evaluate(
  () =>
    new Promise((res) => {
      const t = [];
      let last = performance.now();
      const loop = (now) => {
        t.push(now - last);
        last = now;
        if (t.length < 240) requestAnimationFrame(loop);
        else res(t.slice(10));
      };
      requestAnimationFrame(loop);
    })
);
console.log("AMBIENT", JSON.stringify(stats(ambient)));

// --- 2. full-flight scrub fps (0 → 60s over ~12s, worst case)
const scrub = await page.evaluate(
  () =>
    new Promise((res) => {
      const max = document.documentElement.scrollHeight - innerHeight;
      const t = [];
      let last = performance.now();
      const start = last;
      const loop = (now) => {
        t.push(now - last);
        last = now;
        const p = Math.min(1, (now - start) / 12000);
        window.scrollTo(0, p * max);
        if (p < 1) requestAnimationFrame(loop);
        else res(t.slice(5));
      };
      requestAnimationFrame(loop);
    })
);
console.log("SCRUB", JSON.stringify(stats(scrub)));

// --- 3. state after full scrub: ended flag, kf count, act
await new Promise((r) => setTimeout(r, 1600));
console.log(
  "END-STATE",
  await page.evaluate(() => {
    const st = document.querySelector(".stage");
    return JSON.stringify({
      act: st.dataset.act,
      ended: st.dataset.ended,
      kf: document.querySelector(".kf-count")?.textContent,
      tc: document.querySelector(".tc-main")?.textContent,
    });
  })
);

// --- 4. transport: back-to-start, Space play, wheel takeover
await page.click('.tbtn[aria-label="Back to start"]');
await new Promise((r) => setTimeout(r, 1400));
await page.evaluate(() => document.activeElement && document.activeElement.blur());
await page.keyboard.press("Space");
await new Promise((r) => setTimeout(r, 1500));
const played = await page.evaluate(() => ({
  y: Math.round(scrollY),
  playing: document.querySelector(".tbtn-play")?.getAttribute("aria-pressed"),
}));
await page.mouse.wheel({ deltaY: 120 });
await new Promise((r) => setTimeout(r, 300));
const afterWheel = await page.evaluate(
  () => document.querySelector(".tbtn-play")?.getAttribute("aria-pressed")
);
console.log("PLAY", JSON.stringify({ played, afterWheel }));

// --- 5. playhead slider keyboard
await page.evaluate(() => document.querySelector(".playhead").focus());
await page.keyboard.press("ArrowRight");
await new Promise((r) => setTimeout(r, 700));
const slid = await page.evaluate(() => document.querySelector(".playhead").getAttribute("aria-valuenow"));
console.log("SLIDER", slid);

// --- 6. chapter click → act III region
await page.evaluate(() => {
  document.querySelectorAll(".chapter")[2].click();
});
await page.waitForFunction(() => document.querySelector(".stage").dataset.act === "2", { timeout: 8000 });
console.log("CHAPTER-III", "ok");

// --- 7. ruler pointer scrub (drag to ~75%)
const band = await page.$(".ruler-band");
const bb = await band.boundingBox();
await page.mouse.move(bb.x + bb.width * 0.2, bb.y + bb.height / 2);
await page.mouse.down();
await page.mouse.move(bb.x + bb.width * 0.75, bb.y + bb.height / 2, { steps: 8 });
await page.mouse.up();
await new Promise((r) => setTimeout(r, 900));
console.log(
  "DRAG",
  await page.evaluate(() => document.querySelector(".tc-main").textContent)
);

// --- 8. curve editor: keyboard edit propagates to readout + code panel
await page.evaluate(() => document.querySelectorAll(".chapter")[2].click());
await new Promise((r) => setTimeout(r, 1200));
const before = await page.evaluate(() => document.querySelector(".ce-readout")?.textContent);
await page.evaluate(() => document.querySelector(".ce-handle").focus());
for (let i = 0; i < 3; i++) await page.keyboard.press("ArrowUp");
const after = await page.evaluate(() => document.querySelector(".ce-readout")?.textContent);
const codeHasCurve = await page.evaluate(() => {
  const readout = document.querySelector(".ce-readout")?.textContent.replace(/\s/g, "");
  const code = document.querySelector(".cp-pre")?.textContent.replace(/\s/g, "");
  const m = readout && readout.match(/cubic-bezier\(([^)]*)\)/);
  return m ? code.includes(`cubic-bezier(${m[1]})`) : "no-match";
});
console.log("CURVE", JSON.stringify({ before, after, codeHasCurve }));

// --- 9. spring mode → code switches to linear()
await page.evaluate(() => {
  [...document.querySelectorAll(".chip-btn")].find((b) => b.textContent === "SPRING").click();
});
await new Promise((r) => setTimeout(r, 300));
const springCode = await page.evaluate(() => document.querySelector(".cp-pre").textContent.includes("linear("));
console.log("SPRING", springCode);

// --- 10. a11y snapshot basics
console.log(
  "A11Y",
  await page.evaluate(() => {
    const q = (s) => document.querySelectorAll(s).length;
    return JSON.stringify({
      h1: q("h1"),
      h2: q("h2"),
      main: q("main"),
      header: q("header"),
      sliders: q("[role='slider']"),
      skiplink: !!document.querySelector(".skip-link"),
      canvasHidden: document.querySelector("canvas.world")?.getAttribute("aria-hidden"),
    });
  })
);

console.log("CONSOLE-ERRORS", errors.length ? JSON.stringify(errors.slice(0, 6)) : "none");
await browser.close();
