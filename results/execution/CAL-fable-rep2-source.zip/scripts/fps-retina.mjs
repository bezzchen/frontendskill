import puppeteer from "puppeteer-core";
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const stats = (arr) => {
  const s = [...arr].sort((a, b) => a - b);
  const q = (p) => s[Math.min(s.length - 1, Math.floor(p * s.length))];
  return { n: s.length, avg: +(s.reduce((a, b) => a + b, 0) / s.length).toFixed(2), p50: +q(0.5).toFixed(2), p95: +q(0.95).toFixed(2), over25: s.filter((v) => v > 25).length };
};
const run = async (label, viewport, url) => {
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: "new",
    args: ["--use-angle=metal", "--hide-scrollbars"],
    defaultViewport: viewport,
  });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle0", timeout: 60000 });
  await page.waitForFunction(() => !document.querySelector(".boot"), { timeout: 30000 });
  await new Promise((r) => setTimeout(r, 700));
  const scrub = await page.evaluate(
    () => new Promise((res) => {
      const max = document.documentElement.scrollHeight - innerHeight;
      const t = []; let last = performance.now(); const start = last;
      const loop = (now) => {
        t.push(now - last); last = now;
        const p = Math.min(1, (now - start) / 12000);
        window.scrollTo(0, p * max);
        if (p < 1) requestAnimationFrame(loop); else res(t.slice(5));
      };
      requestAnimationFrame(loop);
    })
  );
  console.log(label, JSON.stringify(stats(scrub)));
  console.log(label + "-dpr", await page.evaluate(() => devicePixelRatio));
  await browser.close();
};
await run("RETINA-2X", { width: 1440, height: 900, deviceScaleFactor: 2 }, "http://localhost:3021");
await run("MOBILE-T1", { width: 390, height: 844, deviceScaleFactor: 3, isMobile: true, hasTouch: true }, "http://localhost:3021");
