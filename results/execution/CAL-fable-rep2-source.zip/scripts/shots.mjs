// Real-scroll screenshots (no virtual-time artifacts) against prod.
import puppeteer from "puppeteer-core";
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const OUT = "/private/tmp/claude-501/-Users-bezzchen-Documents/37b75f5e-0330-4278-8117-fba2895b3c92/scratchpad/shots";
const URL = process.env.QA_URL || "http://localhost:3022";
const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: "new",
  args: ["--use-angle=metal", "--hide-scrollbars"],
  defaultViewport: { width: 1440, height: 900 },
});
const page = await browser.newPage();
await page.goto(URL, { waitUntil: "networkidle0", timeout: 60000 });
await page.waitForFunction(() => !document.querySelector(".boot"), { timeout: 30000 });
await new Promise((r) => setTimeout(r, 600));
for (const t of [0.5, 14, 21, 32, 45, 53, 59.9]) {
  await page.evaluate((tt) => {
    const max = document.documentElement.scrollHeight - innerHeight;
    window.scrollTo(0, (tt / 60) * max);
  }, t);
  await new Promise((r) => setTimeout(r, 1900));
  await page.screenshot({ path: `${OUT}/real${t}.png` });
}
// mobile real
const mp = await browser.newPage();
await mp.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await mp.goto(URL, { waitUntil: "networkidle0", timeout: 60000 });
await mp.waitForFunction(() => !document.querySelector(".boot"), { timeout: 30000 });
for (const t of [0.5, 32]) {
  await mp.evaluate((tt) => {
    const max = document.documentElement.scrollHeight - innerHeight;
    window.scrollTo(0, (tt / 60) * max);
  }, t);
  await new Promise((r) => setTimeout(r, 1900));
  await mp.screenshot({ path: `${OUT}/mreal${t}.png` });
}
console.log("shots done");
await browser.close();
