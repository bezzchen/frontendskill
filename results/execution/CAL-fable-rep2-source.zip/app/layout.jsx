import "./globals.css";
import { Instrument_Serif, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";

const serif = Instrument_Serif({
  weight: "400",
  style: ["normal", "italic"],
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});
const sans = IBM_Plex_Sans({
  weight: ["400", "500"],
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});
const mono = IBM_Plex_Mono({
  weight: ["400", "500"],
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata = {
  title: "Meridian — the timeline is a place",
  description:
    "Meridian is a timeline-based motion editor for the web. Design springs, keyframes, and gesture-driven motion visually — ship production JavaScript and CSS. This launch page is itself a Meridian project: scroll to scrub it.",
  openGraph: {
    title: "Meridian — the timeline is a place",
    description:
      "A motion editor for the web. This launch page is one of its projects: 60 seconds, 3 tracks, 23 keyframes. Scroll to scrub it.",
    type: "website",
    images: [{ url: "/og.png", width: 1200, height: 630 }],
  },
};

export const viewport = {
  themeColor: "#05070B",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable} ${mono.variable}`}>
      <body>
        <noscript>
          <style>{`.card{opacity:1!important;transform:none!important}.boot{display:none!important}`}</style>
        </noscript>
        {children}
      </body>
    </html>
  );
}
