"use client";
import { useEffect, useRef } from "react";
import { store, useStoreVersion } from "./store";
import { timecode } from "./constants";

const RingMark = () => (
  <svg className="ringmark" viewBox="0 0 22 22" width="19" height="19" aria-hidden="true">
    <circle cx="11" cy="11" r="8.6" fill="none" stroke="currentColor" strokeWidth="1.4" />
    <ellipse cx="11" cy="11" rx="3.6" ry="8.6" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.65" />
    <circle cx="11" cy="2.4" r="1.9" fill="currentColor" />
  </svg>
);

export default function TopBar() {
  useStoreVersion();
  const st = store.get();
  const tcRef = useRef(null);

  useEffect(
    () =>
      store.onFrame((s) => {
        if (tcRef.current) tcRef.current.textContent = timecode(s.time);
      }),
    []
  );

  const toggleMotion = () => {
    const s = store.get();
    const next = s.motion === "full" ? "calm" : "full";
    try {
      localStorage.setItem("mrd-motion", next);
    } catch {}
    store.set({ motion: next, motionSource: "user", playing: false });
  };

  return (
    <header className="topbar">
      <div className="brand">
        <RingMark />
        <span className="brand-name serif">Meridian</span>
        <span className="chip mono">LAUNCH.MRD</span>
      </div>
      <div className="topbar-right">
        <span className="tc-top mono" aria-hidden="true">
          TC <span ref={tcRef}>00:00:00:00</span>
        </span>
        <button
          type="button"
          className="toggle mono"
          aria-pressed={st.motion === "calm"}
          onClick={toggleMotion}
          title="Calm trades the flight for composed stills — same story, no motion"
        >
          MOTION <b>{st.motion === "calm" ? "CALM" : "FULL"}</b>
        </button>
        <a className="btn btn-primary mono" href="mailto:hello@meridian.tools?subject=Early%20access">
          GET EARLY ACCESS
        </a>
      </div>
    </header>
  );
}
