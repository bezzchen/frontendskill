// Tier-0 fallback: no WebGL. The same world as a composed still — palette,
// spline, gates and ring — in CSS gradients and one inline SVG.
export default function Poster() {
  return (
    <div className="poster" aria-hidden="true">
      <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="mrd-spline" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0" stopColor="#FFB35C" stopOpacity="0.95" />
            <stop offset="0.55" stopColor="#FF8E3D" stopOpacity="0.6" />
            <stop offset="1" stopColor="#3E7DBF" stopOpacity="0.45" />
          </linearGradient>
          <filter id="mrd-glow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="7" />
          </filter>
        </defs>
        <g fill="none" strokeLinecap="round">
          <path
            d="M -80 760 C 240 640, 330 500, 560 540 S 900 720, 1020 560 S 940 330, 1120 300"
            stroke="url(#mrd-spline)"
            strokeWidth="10"
            opacity="0.55"
            filter="url(#mrd-glow)"
          />
          <path
            d="M -80 760 C 240 640, 330 500, 560 540 S 900 720, 1020 560 S 940 330, 1120 300"
            stroke="url(#mrd-spline)"
            strokeWidth="2.5"
          />
          <ellipse cx="1160" cy="345" rx="128" ry="96" stroke="#5A7FB8" strokeWidth="2" opacity="0.7" filter="url(#mrd-glow)" transform="rotate(-14 1160 345)" />
          <ellipse cx="1160" cy="345" rx="128" ry="96" stroke="#8FB4E8" strokeWidth="1.4" opacity="0.8" transform="rotate(-14 1160 345)" />
        </g>
        <g>
          {[
            [210, 655, 1],
            [430, 545, 1],
            [640, 570, 1],
            [880, 650, 0],
            [1005, 520, 0],
            [1078, 385, 0],
          ].map(([x, y, done], i) => (
            <rect
              key={i}
              x={x - 7}
              y={y - 7}
              width="14"
              height="14"
              transform={`rotate(45 ${x} ${y})`}
              fill={done ? "#FFB35C" : "none"}
              stroke={done ? "#FFB35C" : "#7DE9FF"}
              strokeWidth="1.6"
              opacity="0.9"
            />
          ))}
          <circle cx="700" cy="588" r="7" fill="#FFF2DD" />
          <circle cx="700" cy="588" r="22" fill="#FFB35C" opacity="0.25" filter="url(#mrd-glow)" />
        </g>
      </svg>
    </div>
  );
}
