"use client";
// The world: one continuous flight along the project's own timeline.
// Raw three.js — one scene, one camera, one RAF, custom GLSL throughout.
import * as THREE from "three";
import { DURATION, WORLD_GATES, SHUTTLE_SPAN, SHUTTLE_PERIOD } from "./constants";
import { clamp, lerp, smooth, easeInOut, makeEase } from "./easing";

let DBG = false;
try {
  DBG = typeof window !== "undefined" && new URLSearchParams(window.location.search).has("dbg");
} catch {}
const U0 = 0.022; // the comet starts slightly down the path so the camera has road behind it
const uOf = (t) => U0 + (clamp(t, 0, DURATION) / DURATION) * (1 - U0);

// ---------------------------------------------------------------- path
function buildPath() {
  const pts = [
    [0, 0.6, 8],
    [0, 0.4, -6],
    [-2.5, 1.0, -20],
    [-5.5, 2.2, -36],
    [-2, 3.2, -52],
    [4, 2.4, -66],
    [7.5, 0.8, -82],
    [4, -0.6, -98],
    [-3, -0.2, -112],
    [-7, 1.6, -126],
    [-4.5, 3.4, -140],
    [-1, 1.2, -152],
  ].map(([x, y, z]) => new THREE.Vector3(x, y, z));
  // Finale: the path closes into the Meridian ring.
  const C = new THREE.Vector3(0, 2.5, -176);
  const R = 16;
  const tilt = (18 * Math.PI) / 180;
  const bu = new THREE.Vector3(1, 0, 0);
  const bv = new THREE.Vector3(0, Math.sin(tilt), -Math.cos(tilt));
  const steps = 11;
  for (let i = 0; i <= steps; i++) {
    const th = ((-90 + (356 * i) / steps) * Math.PI) / 180;
    pts.push(
      C.clone()
        .addScaledVector(bu, Math.cos(th) * R)
        .addScaledVector(bv, Math.sin(th) * R)
    );
  }
  const curve = new THREE.CatmullRomCurve3(pts, false, "centripetal");
  curve.arcLengthDivisions = 1200;
  return { curve, ringCenter: C };
}

// Camera rig keyframes: t, back, up, side, ahead, fov — the flight is authored, not orbited.
const RIG = [
  [0, 0.026, 1.55, -2.45, 0.045, 63],
  [7, 0.024, 1.7, -1.6, 0.04, 64],
  [13, 0.024, 1.1, 0.95, 0.02, 64],
  [21, 0.024, 1.35, 0.8, 0.022, 64],
  [27, 0.046, 3.2, -4.4, 0.006, 55],
  [34, 0.044, 2.8, -4.0, 0.008, 55],
  [39, 0.03, 1.6, -1.5, 0.026, 62],
  [45, 0.026, 1.3, -1.0, 0.03, 64],
  [51, 0.026, 1.7, 0.5, 0.045, 68],
  [60, 0.026, 1.7, 0.5, 0.045, 68],
];

function rigAt(t, out) {
  let a = RIG[0];
  let b = RIG[RIG.length - 1];
  for (let i = 0; i < RIG.length - 1; i++) {
    if (t >= RIG[i][0] && t <= RIG[i + 1][0]) {
      a = RIG[i];
      b = RIG[i + 1];
      break;
    }
  }
  const f = easeInOut(clamp((t - a[0]) / Math.max(0.001, b[0] - a[0]), 0, 1));
  for (let k = 1; k <= 5; k++) out[k - 1] = lerp(a[k], b[k], f);
  return out;
}

// ---------------------------------------------------------------- textures
function glowTexture(inner = 0.0) {
  const s = 128;
  const cv = document.createElement("canvas");
  cv.width = cv.height = s;
  const g = cv.getContext("2d");
  const grad = g.createRadialGradient(s / 2, s / 2, s * 0.02, s / 2, s / 2, s / 2);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.25, `rgba(255,255,255,${0.55 + inner * 0.3})`);
  grad.addColorStop(0.6, "rgba(255,255,255,0.12)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, s, s);
  const tx = new THREE.CanvasTexture(cv);
  return tx;
}

function gateAtlasTexture() {
  // left cell: hollow diamond (ahead) · right cell: filled diamond (committed)
  const w = 256;
  const h = 128;
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const g = cv.getContext("2d");
  const draw = (cx, filled) => {
    const r = 34;
    g.save();
    g.translate(cx, h / 2);
    g.rotate(Math.PI / 4);
    g.shadowColor = "rgba(255,255,255,0.9)";
    g.shadowBlur = 22;
    g.lineWidth = 7;
    g.strokeStyle = "rgba(255,255,255,0.95)";
    g.fillStyle = filled ? "rgba(255,255,255,0.95)" : "rgba(255,255,255,0.22)";
    g.fillRect(-r / 1.42, -r / 1.42, (2 * r) / 1.42, (2 * r) / 1.42);
    g.strokeRect(-r / 1.42, -r / 1.42, (2 * r) / 1.42, (2 * r) / 1.42);
    g.restore();
  };
  draw(64, false);
  draw(192, true);
  return new THREE.CanvasTexture(cv);
}

// ---------------------------------------------------------------- shaders
const RIBBON_VERT = /* glsl */ `
  varying float vU;
  varying float vRim;
  varying float vDist;
  uniform float uTime, uWiden, uPulseAmp, uPulseFreq, uPulseCenter, uPulseSigma, uHalo;
  void main() {
    vU = uv.x;
    vec3 p = position;
    float reg = exp(-pow((vU - uPulseCenter) / uPulseSigma, 2.0));
    float pulse = sin(vU * uPulseFreq + uTime * 3.2) * uPulseAmp * reg;
    float w = uWiden + pulse;
    p += normal * w * (uHalo > 0.5 ? 2.2 : 1.0);
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    vDist = -mv.z;
    vec3 nV = normalize(normalMatrix * normal);
    vRim = 1.0 - abs(nV.z);
    gl_Position = projectionMatrix * mv;
  }
`;
const RIBBON_FRAG = /* glsl */ `
  precision highp float;
  varying float vU;
  varying float vRim;
  varying float vDist;
  uniform float uTime, uPlayU, uWarmth, uFlow, uIgnite, uRingLight, uHalo, uFogD, uTeal;
  void main() {
    float du = vU - uPlayU;
    float visited = 1.0 - smoothstep(-0.004, 0.004, du);
    vec3 futureCol = mix(vec3(0.16, 0.28, 0.55), vec3(0.13, 0.44, 0.52), uTeal);
    vec3 pastCol = mix(vec3(1.0, 0.42, 0.12), vec3(1.0, 0.66, 0.28), clamp(uWarmth, 0.0, 1.0));
    float dashAmt = 0.2 * smoothstep(70.0, 22.0, vDist);
    float flow = (1.0 - dashAmt) + dashAmt * smoothstep(0.3, 0.95, fract(vU * 420.0 - uTime * uFlow));
    float base = uHalo > 0.5 ? 0.038 : 0.52;
    vec3 col = mix(futureCol * (0.55 + 0.45 * flow), pastCol * flow, visited) * base;
    float g = exp(-abs(du) * 110.0);
    col += vec3(1.0, 0.62, 0.25) * g * (uHalo > 0.5 ? 0.3 : 1.35);
    // anticipation: the stretch just ahead of the playhead is locally lit
    col += futureCol * exp(-max(du, 0.0) * 90.0) * step(0.0, du) * 0.55;
    col += vec3(1.0, 0.7, 0.35) * uIgnite * exp(-vU * 26.0) * 2.4;
    col += vec3(1.0, 0.82, 0.55) * uRingLight * 0.5 * flow;
    float rim = uHalo > 0.5 ? (0.25 + 0.75 * vRim) : (0.55 + 0.45 * vRim);
    float nearFade = smoothstep(2.0, 10.0, vDist);
    col *= rim * nearFade * exp(-vDist * uFogD);
    gl_FragColor = vec4(col, 1.0);
  }
`;

const DUST_VERT = /* glsl */ `
  attribute float aSeed;
  attribute float aKind;
  uniform float uTime, uDrift, uPtrAmp, uGather, uDense, uSizeMul, uRingLight, uPxScale, uSpread, uFogD;
  uniform vec2 uPtr;
  uniform vec3 uTintA, uTintB;
  varying vec3 vColor;
  varying float vCore;
  void main() {
    float s = aSeed * 6.28318;
    vec3 p = position;
    float amp = (0.22 + uDrift * 1.35) * (aKind < 0.5 ? 1.0 : 0.45);
    p += vec3(sin(uTime * 0.31 + s * 3.1), cos(uTime * 0.24 + s * 5.7), sin(uTime * 0.27 + s * 7.3)) * amp;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    vec4 clip = projectionMatrix * mv;
    vec2 ndc = clip.xy / max(0.001, clip.w);
    vec2 d = ndc - uPtr;
    float L = length(d);
    float push = exp(-L * L * 10.0) * uPtrAmp;
    float dist0 = max(0.5, -mv.z);
    mv.xy += (d / max(L, 0.04)) * push * dist0 * 0.11;
    float gk = clamp(uGather * 1.7 - fract(aSeed * 13.7) * 0.7, 0.0, 1.0);
    gk = gk * gk * (3.0 - 2.0 * gk) * (aKind < 0.5 ? 1.0 : 0.3);
    if (gk > 0.001) {
      vec3 tv = vec3(
        (fract(aSeed * 7.13) - 0.5) * 2.6 + 3.2,
        (fract(aSeed * 3.71) - 0.5) * 3.8,
        -9.0 - fract(aSeed * 9.41) * 6.0
      );
      mv.xyz = mix(mv.xyz, tv, gk);
    }
    gl_Position = projectionMatrix * mv;
    float dist = max(0.5, -mv.z);
    float tw = 0.75 + 0.35 * sin(uTime * (1.0 + fract(aSeed * 5.3) * 2.0) + s);
    float base = aKind > 1.5 ? 1.6 + uRingLight * 1.8 : (aKind > 0.5 ? 1.35 : 1.0);
    gl_PointSize = clamp(uSizeMul * base * tw * uPxScale * (0.030 + 0.055 * fract(aSeed * 4.7)) / dist, 1.0, 34.0);
    float fog = exp(-dist * uFogD);
    float dense = 1.0 + uDense * (aKind > 0.5 ? 0.9 : 0.35);
    vColor = mix(uTintA, uTintB, fract(aSeed * 11.7) * uSpread) * fog * dense * tw;
    if (aKind > 1.5) vColor += vec3(1.0, 0.72, 0.38) * uRingLight * fog * 0.9;
    vCore = fract(aSeed * 2.9);
  }
`;
const DUST_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vColor;
  varying float vCore;
  void main() {
    vec2 q = gl_PointCoord - 0.5;
    float d = length(q);
    float a = smoothstep(0.5, 0.06, d);
    float core = smoothstep(0.16, 0.0, d) * (0.5 + vCore * 0.7);
    gl_FragColor = vec4(vColor * (a * 0.85 + core), 1.0);
  }
`;

const GATE_VERT = /* glsl */ `
  attribute float aT;
  uniform float uPlayT, uPxScale, uRingLight, uFogD;
  varying float vCell;
  varying float vGlow;
  varying float vFog;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    float dist = max(0.5, -mv.z);
    float passed = step(aT, uPlayT + 0.001);
    float pulse = exp(-abs(aT - uPlayT) * 1.3);
    vCell = passed;
    vGlow = pulse + uRingLight * 1.2;
    vFog = exp(-dist * uFogD);
    gl_Position = projectionMatrix * mv;
    gl_PointSize = clamp(uPxScale * (0.22 + pulse * 0.1 + uRingLight * 0.06) / dist, 11.0, 150.0);
  }
`;
const GATE_FRAG = /* glsl */ `
  precision highp float;
  uniform sampler2D uMap;
  varying float vCell;
  varying float vGlow;
  varying float vFog;
  void main() {
    vec2 uv = vec2(gl_PointCoord.x * 0.5 + vCell * 0.5, gl_PointCoord.y);
    vec4 tx = texture2D(uMap, uv);
    vec3 ahead = vec3(0.35, 0.75, 0.95);
    vec3 done = vec3(1.0, 0.62, 0.24);
    vec3 col = mix(ahead, done, vCell) * tx.a * (0.85 + vGlow * 1.0) * vFog;
    gl_FragColor = vec4(col, 1.0);
  }
`;

const TRAIL_VERT = /* glsl */ `
  attribute float aFade;
  uniform float uPxScale;
  varying float vFade;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    float dist = max(0.5, -mv.z);
    vFade = aFade;
    gl_Position = projectionMatrix * mv;
    gl_PointSize = clamp(uPxScale * (0.015 + 0.035 * aFade) / dist, 1.0, 30.0);
  }
`;
const TRAIL_FRAG = /* glsl */ `
  precision highp float;
  varying float vFade;
  void main() {
    vec2 q = gl_PointCoord - 0.5;
    float a = smoothstep(0.5, 0.05, length(q));
    gl_FragColor = vec4(vec3(1.0, 0.6, 0.22) * a * vFade * vFade * 1.4, 1.0);
  }
`;

const DOME_VERT = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
  }
`;
const DOME_FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vDir;
  uniform float uWarmth, uTeal;
  uniform vec3 uWarmDir;
  float hash(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453); }
  void main() {
    float h = vDir.y * 0.5 + 0.5;
    vec3 deep = mix(vec3(0.016, 0.021, 0.044), vec3(0.038, 0.050, 0.098), h);
    deep = mix(deep, deep * vec3(0.8, 1.25, 1.15), uTeal * 0.5);
    float band = exp(-pow(vDir.y * 3.4 + 0.35, 2.0));
    deep += vec3(0.020, 0.026, 0.052) * band;
    float w = pow(max(0.0, dot(vDir, uWarmDir)), 3.0);
    deep += uWarmth * vec3(0.10, 0.05, 0.016) * w;
    deep += (hash(vDir * 90.0) - 0.5) * 0.008;
    gl_FragColor = vec4(deep, 1.0);
  }
`;

// ---------------------------------------------------------------- engine
export function createEngine({ canvas, store, tier }) {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
      failIfMajorPerformanceCaveat: false,
    });
  } catch (err) {
    return null;
  }
  renderer.setClearColor(0x05070b, 1);
  renderer.toneMapping = THREE.NoToneMapping;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(66, 1, 0.1, 460);
  const { curve, ringCenter } = buildPath();

  const lean = tier < 2;
  let baseDpr = Math.min(window.devicePixelRatio || 1, lean ? 1.4 : 1.8);

  // dome
  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(240, 24, 12),
    new THREE.ShaderMaterial({
      vertexShader: DOME_VERT,
      fragmentShader: DOME_FRAG,
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uWarmth: { value: 0 },
        uTeal: { value: 0 },
        uWarmDir: { value: new THREE.Vector3(0, -0.1, -1).normalize() },
      },
    })
  );
  dome.renderOrder = -10;
  dome.frustumCulled = false;
  scene.add(dome);

  // ribbon core + halo
  const ribbonUniforms = {
    uTime: { value: 0 },
    uPlayU: { value: U0 },
    uWarmth: { value: 0 },
    uFlow: { value: 2.2 },
    uIgnite: { value: 0 },
    uRingLight: { value: 0 },
    uFogD: { value: lean ? 0.016 : 0.011 },
    uTeal: { value: 0 },
    uWiden: { value: 0 },
    uPulseAmp: { value: 0 },
    uPulseFreq: { value: 110 },
    uPulseCenter: { value: (uOf(SHUTTLE_SPAN[0]) + uOf(SHUTTLE_SPAN[1])) / 2 },
    uPulseSigma: { value: (uOf(SHUTTLE_SPAN[1]) - uOf(SHUTTLE_SPAN[0])) * 0.8 },
  };
  const mkRibbonMat = (halo) =>
    new THREE.ShaderMaterial({
      vertexShader: RIBBON_VERT,
      fragmentShader: RIBBON_FRAG,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      // uniform value objects are shared between core and halo on purpose:
      // setUniform() writes once, both materials see it.
      uniforms: { ...ribbonUniforms, uHalo: { value: halo } },
    });
  const ribbonCore = new THREE.Mesh(
    new THREE.TubeGeometry(curve, lean ? 800 : 1400, 0.085, lean ? 8 : 10, false),
    mkRibbonMat(0)
  );
  const ribbonHalo = new THREE.Mesh(
    new THREE.TubeGeometry(curve, lean ? 400 : 700, 0.34, 8, false),
    mkRibbonMat(1)
  );
  ribbonCore.frustumCulled = false;
  ribbonHalo.frustumCulled = false;
  scene.add(ribbonCore, ribbonHalo);

  // dust field
  const COUNT = lean ? 4200 : 13000;
  const pos = new Float32Array(COUNT * 3);
  const seed = new Float32Array(COUNT);
  const kind = new Float32Array(COUNT);
  {
    const tmp = new THREE.Vector3();
    const dir = new THREE.Vector3();
    let i = 0;
    const put = (v, k) => {
      pos[i * 3] = v.x;
      pos[i * 3 + 1] = v.y;
      pos[i * 3 + 2] = v.z;
      seed[i] = Math.random();
      kind[i] = k;
      i++;
    };
    const nCh = Math.floor(COUNT * 0.62);
    const nSky = Math.floor(COUNT * 0.3);
    for (let j = 0; j < nCh; j++) {
      curve.getPointAt(Math.random(), tmp);
      dir.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
      const r = 1.6 + Math.pow(Math.random(), 1.7) * 26;
      put(tmp.addScaledVector(dir, r), 0);
    }
    for (let j = 0; j < nSky; j++) {
      dir.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
      const r = 60 + Math.random() * 130;
      tmp.set(0, 10, -85).addScaledVector(dir, r);
      put(tmp, 1);
    }
    while (i < COUNT) {
      const th = Math.random() * Math.PI * 2;
      tmp.set(
        ringCenter.x + Math.cos(th) * 16,
        ringCenter.y + Math.sin(th) * 16 * 0.31,
        ringCenter.z - Math.sin(th) * 16 * 0.95
      );
      dir.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5);
      put(tmp.addScaledVector(dir, 4), 2);
    }
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  dustGeo.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
  dustGeo.setAttribute("aKind", new THREE.BufferAttribute(kind, 1));
  const dustUniforms = {
    uTime: { value: 0 },
    uDrift: { value: 0 },
    uPtrAmp: { value: 0 },
    uGather: { value: 0 },
    uDense: { value: 0 },
    uSizeMul: { value: 1.3 },
    uRingLight: { value: 0 },
    uPxScale: { value: 800 },
    uSpread: { value: 0 },
    uFogD: { value: lean ? 0.014 : 0.009 },
    uPtr: { value: new THREE.Vector2(10, 10) },
    uTintA: { value: new THREE.Color(0.42, 0.6, 1.0).multiplyScalar(0.55) },
    uTintB: { value: new THREE.Color(1.0, 0.62, 0.3).multiplyScalar(0.6) },
  };
  const dust = new THREE.Points(
    dustGeo,
    new THREE.ShaderMaterial({
      vertexShader: DUST_VERT,
      fragmentShader: DUST_FRAG,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      uniforms: dustUniforms,
    })
  );
  dust.frustumCulled = false;
  scene.add(dust);

  // keyframe gates
  const gateGeo = new THREE.BufferGeometry();
  {
    const gp = new Float32Array(WORLD_GATES.length * 3);
    const gt = new Float32Array(WORLD_GATES.length);
    const tmp = new THREE.Vector3();
    WORLD_GATES.forEach((g, i) => {
      curve.getPointAt(uOf(g.t), tmp);
      gp[i * 3] = tmp.x;
      gp[i * 3 + 1] = tmp.y;
      gp[i * 3 + 2] = tmp.z;
      gt[i] = g.t;
    });
    gateGeo.setAttribute("position", new THREE.BufferAttribute(gp, 3));
    gateGeo.setAttribute("aT", new THREE.BufferAttribute(gt, 1));
  }
  const gateUniforms = {
    uPlayT: { value: 0 },
    uPxScale: { value: 800 },
    uRingLight: { value: 0 },
    uFogD: { value: lean ? 0.014 : 0.009 },
    uMap: { value: gateAtlasTexture() },
  };
  const gates = new THREE.Points(
    gateGeo,
    new THREE.ShaderMaterial({
      vertexShader: GATE_VERT,
      fragmentShader: GATE_FRAG,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      uniforms: gateUniforms,
    })
  );
  gates.frustumCulled = false;
  scene.add(gates);

  // comet (playhead) — sprites are safe from point-size caps
  const glowTex = glowTexture(0.4);
  const cometCore = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: glowTex, color: 0xfff2dd, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })
  );
  cometCore.scale.setScalar(2.0);
  const cometHalo = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: glowTex, color: 0xff9a3d, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.5 })
  );
  cometHalo.scale.setScalar(4.8);
  scene.add(cometCore, cometHalo);

  // comet trail
  const TRAIL_N = 26;
  const trailGeo = new THREE.BufferGeometry();
  const trailPos = new Float32Array(TRAIL_N * 3);
  const trailFade = new Float32Array(TRAIL_N);
  for (let i = 0; i < TRAIL_N; i++) trailFade[i] = 1 - i / TRAIL_N;
  trailGeo.setAttribute("position", new THREE.BufferAttribute(trailPos, 3));
  trailGeo.setAttribute("aFade", new THREE.BufferAttribute(trailFade, 1));
  const trailUniforms = { uPxScale: { value: 800 } };
  const trail = new THREE.Points(
    trailGeo,
    new THREE.ShaderMaterial({
      vertexShader: TRAIL_VERT,
      fragmentShader: TRAIL_FRAG,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      uniforms: trailUniforms,
    })
  );
  trail.frustumCulled = false;
  scene.add(trail);

  // act III shuttles: bright one runs your curve, dim ghost runs linear
  const shuttle = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: glowTex, color: 0xbff3ff, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })
  );
  const shuttleGhost = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: glowTex, color: 0x9aa8c2, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.75 })
  );
  scene.add(shuttle, shuttleGhost);

  // ---------------------------------------------------------------- state
  const phases = [0, 0, 0, 0, 0];
  const phaseGates = [1, 2, 3, 4, 5].map((n) => WORLD_GATES.find((g) => g.phase === n));
  const tmpA = new THREE.Vector3();
  const tmpB = new THREE.Vector3();
  const tmpC = new THREE.Vector3();
  const tmpTan = new THREE.Vector3();
  const right = new THREE.Vector3();
  const UP = new THREE.Vector3(0, 1, 0);
  const camPos = new THREE.Vector3(0, 2, 14);
  const lookPos = new THREE.Vector3(0, 0, -10);
  const vantagePos = new THREE.Vector3(0, 27, -126);
  const shA = curve.getPointAt(uOf(SHUTTLE_SPAN[0]), new THREE.Vector3());
  const shB = curve.getPointAt(uOf(SHUTTLE_SPAN[1]), new THREE.Vector3());
  const rigOut = [0, 0, 0, 0, 0];
  const coolTint = new THREE.Color(0.42, 0.6, 1.0).multiplyScalar(0.55);
  const tealTint = new THREE.Color(0.3, 0.95, 0.85).multiplyScalar(0.58);

  let playT = 0;
  let clock = 0;
  let last = 0;
  let raf = null;
  let running = false;
  let wantActive = false;
  let disposed = false;
  let igniteV = 0;
  let endFlash = 0;
  let prevEnded = false;
  let pointer = { x: 10, y: 10, active: false };
  let parX = 0;
  let parY = 0;
  let ptrAmp = 0;
  let tapPulse = 0;
  let easeFn = makeEase(store.get().curve);
  let curveKey = "";
  let curveEnergy = 0.4;
  let fov = 66;

  const curveKeyOf = (c) =>
    c.mode === "spring" ? `s${c.stiffness},${c.damping}` : `b${c.p.join(",")}`;

  function refreshCurve(c) {
    const key = curveKeyOf(c);
    if (key === curveKey) return;
    curveKey = key;
    easeFn = makeEase(c);
    let over = 0;
    let dev = 0;
    for (let i = 0; i <= 24; i++) {
      const x = i / 24;
      const v = easeFn(x);
      if (v > 1) over = Math.max(over, v - 1);
      if (v < 0) over = Math.max(over, -v);
      dev += Math.abs(v - x);
    }
    curveEnergy = Math.min(1, over * 2.4 + (dev / 25) * 1.6);
  }
  refreshCurve(store.get().curve);

  // quality ladder
  const frameTimes = [];
  let qStep = 0;
  let qRestored = false;
  function applyQuality() {
    const dprSteps = [baseDpr, baseDpr * 0.82, baseDpr * 0.82, Math.max(1, baseDpr * 0.66), Math.max(1, baseDpr * 0.66)];
    const partSteps = [1, 1, 0.62, 0.62, 0.45];
    renderer.setPixelRatio(dprSteps[qStep]);
    dustGeo.setDrawRange(0, Math.floor(COUNT * partSteps[qStep]));
    if (qStep >= 4) ribbonHalo.visible = false;
  }
  function fpsMonitor(dt) {
    frameTimes.push(dt);
    if (frameTimes.length < 90) return;
    const sorted = [...frameTimes].sort((a, b) => a - b);
    const med = sorted[Math.floor(sorted.length / 2)];
    frameTimes.length = 0;
    if (med > 0.021 && qStep < 4) {
      qStep++;
      applyQuality();
    } else if (med < 0.011 && qStep > 0 && !qRestored) {
      qStep--;
      qRestored = true;
      applyQuality();
    }
  }

  function setUniform(name, v) {
    ribbonUniforms[name].value = v;
  }

  function update(t, dt, calm) {
    const st = store.get();
    refreshCurve(st.curve);
    const u = uOf(t);

    // world phases (act II property gates)
    for (let i = 0; i < 5; i++) {
      const gate = phaseGates[i];
      const target = t >= gate.t ? 1 : 0;
      phases[i] = calm ? target : phases[i] + (target - phases[i]) * Math.min(1, dt * 2.4);
    }
    const warmth = clamp((t / DURATION) * 1.15, 0, 1);
    const actIII = smooth(26, 29, t) * (1 - smooth(38, 41, t));
    const gather = smooth(41, 44, t) * (1 - smooth(51.5, 53.5, t));
    const ringLight = smooth(52, 56, t) * 0.55 + endFlash;

    setUniform("uTime", clock);
    setUniform("uPlayU", u);
    setUniform("uWarmth", warmth);
    setUniform("uTeal", phases[0]);
    setUniform("uWiden", phases[2] * 0.1);
    setUniform("uFlow", 2.2 + phases[2] * 2.6);
    setUniform("uPulseAmp", actIII * (0.02 + curveEnergy * 0.09));
    setUniform("uPulseFreq", 90 + curveEnergy * 150);
    setUniform("uIgnite", igniteV);
    setUniform("uRingLight", ringLight);

    dustUniforms.uTime.value = clock;
    dustUniforms.uDrift.value = phases[1];
    dustUniforms.uDense.value = phases[3];
    dustUniforms.uSpread.value = phases[4];
    dustUniforms.uGather.value = gather;
    dustUniforms.uRingLight.value = ringLight;
    dustUniforms.uTintA.value.copy(coolTint).lerp(tealTint, phases[0]);
    const ptrTarget = pointer.active && !calm ? 0.85 : 0;
    ptrAmp += (ptrTarget + tapPulse - ptrAmp) * Math.min(1, dt * 4);
    tapPulse *= Math.exp(-dt * 2.6);
    dustUniforms.uPtrAmp.value = ptrAmp;
    dustUniforms.uPtr.value.set(pointer.x, pointer.y);

    gateUniforms.uPlayT.value = t;
    gateUniforms.uRingLight.value = ringLight;

    // comet
    curve.getPointAt(u, tmpA);
    cometCore.position.copy(tmpA);
    cometHalo.position.copy(tmpA);
    const pulse = 1 + Math.sin(clock * 2.3) * 0.08 + ringLight * 0.5;
    cometCore.scale.setScalar(2.0 * pulse);
    cometHalo.scale.setScalar(4.8 * pulse);
    const camD = camera.position.distanceTo(tmpA);
    const nearK = smooth(1.8, 7.0, camD);
    cometCore.material.opacity = 0.55 + 0.45 * nearK;
    cometHalo.material.opacity = 0.5 * (0.35 + 0.65 * nearK);
    if (!calm) {
      // shift trail history
      for (let i = TRAIL_N - 1; i > 0; i--) {
        trailPos[i * 3] = trailPos[(i - 1) * 3];
        trailPos[i * 3 + 1] = trailPos[(i - 1) * 3 + 1];
        trailPos[i * 3 + 2] = trailPos[(i - 1) * 3 + 2];
      }
      trailPos[0] = tmpA.x;
      trailPos[1] = tmpA.y;
      trailPos[2] = tmpA.z;
      trailGeo.attributes.position.needsUpdate = true;
      trail.visible = true;
    } else {
      trail.visible = false;
    }

    // act III shuttles
    const shVis = actIII > 0.01;
    shuttle.visible = shVis;
    shuttleGhost.visible = shVis && !calm;
    if (shVis) {
      const cyc = (clock % (2 * SHUTTLE_PERIOD)) / SHUTTLE_PERIOD;
      const tri = calm ? 0.62 : cyc < 1 ? cyc : 2 - cyc;
      const p1 = easeFn(tri);
      tmpB.lerpVectors(shA, shB, p1);
      shuttle.position.copy(tmpB).addScaledVector(UP, 0.55);
      shuttle.scale.setScalar((0.85 + curveEnergy * 0.25) * actIII);
      tmpC.lerpVectors(shA, shB, tri);
      shuttleGhost.position.copy(tmpC).addScaledVector(UP, 1.15);
      shuttleGhost.scale.setScalar(0.66 * actIII);
    }

    dome.material.uniforms.uWarmth.value = warmth * (0.5 + ringLight);
    dome.material.uniforms.uTeal.value = phases[0];

    // ---------------- camera
    // calm mode: the camera follows the playhead in 2-second cuts — a strip of
    // stills driven only by the visitor's scrubbing, never continuous motion
    const ct = calm ? Math.min(DURATION, Math.floor(t / 2) * 2 + 1) : t;
    rigAt(ct, rigOut);
    let [back, up, side, ahead, fovT] = rigOut;
    if (calm) {
      // stills breathe wider: further back and higher so the comet stays framed
      back += 0.016;
      up += 1.1;
      ahead += 0.012;
    }
    const cu = uOf(ct);
    curve.getPointAt(clamp(cu - back, 0, 1), tmpB);
    curve.getPointAt(clamp(cu + ahead, 0, 1), tmpC);
    curve.getTangentAt(clamp(cu, 0, 1), tmpTan);
    right.crossVectors(tmpTan, UP);
    if (right.lengthSq() < 1e-4) right.set(1, 0, 0);
    right.normalize();
    tmpB.addScaledVector(UP, up).addScaledVector(right, side);
    const vb = easeInOut(smooth(52, 55.5, calm ? ct : t));
    if (vb > 0) {
      tmpB.lerp(vantagePos, vb);
      tmpC.lerp(ringCenter, vb);
      tmpC.x -= 6.5 * vb; // look-bias: the ring settles right of the end card
    }
    if (!calm) {
      tmpB.addScaledVector(right, Math.sin(clock * 0.13) * 0.18 + parX * 0.55);
      tmpB.addScaledVector(UP, Math.sin(clock * 0.17) * 0.12 + parY * 0.3);
    }
    const ck = calm || forceCut ? 1 : 1 - Math.exp(-dt * 6);
    camPos.lerp(tmpB, ck);
    lookPos.lerp(tmpC, ck);
    if (DBG) {
      document.title = `cam ${camPos.x.toFixed(1)},${camPos.y.toFixed(1)},${camPos.z.toFixed(1)} tgt ${tmpB.x.toFixed(1)},${tmpB.y.toFixed(1)},${tmpB.z.toFixed(1)} vb ${vb.toFixed(2)} t ${t.toFixed(1)} calm ${calm}`;
    }
    camera.position.copy(camPos);
    camera.lookAt(lookPos);
    if (!calm) camera.rotateZ(-side * 0.012 + Math.sin(clock * 0.11) * 0.004);
    const fovTarget = fovT;
    fov = calm || forceCut ? fovTarget : fov + (fovTarget - fov) * Math.min(1, dt * 4);
    forceCut = false;
    if (Math.abs(camera.fov - fov) > 0.01) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
    const pxScale = (renderer.domElement.height / 2) / Math.tan((fov * Math.PI) / 360);
    dustUniforms.uPxScale.value = pxScale;
    gateUniforms.uPxScale.value = pxScale;
    trailUniforms.uPxScale.value = pxScale;

    dome.position.copy(camera.position);

    igniteV *= Math.exp(-dt * 1.9);
    if (st.ended && !prevEnded) endFlash = 1.1;
    prevEnded = st.ended;
    endFlash *= Math.exp(-dt * 1.6);
  }

  let snapped = false;
  let forceCut = false;
  function frame(now) {
    if (!running || disposed) return;
    const dt = clamp((now - last) / 1000, 0.001, 0.05);
    last = now;
    clock += dt;
    const st = store.get();
    if (!snapped) {
      snapped = true;
      try {
        if (new URLSearchParams(window.location.search).has("snap")) {
          playT = st.targetTime;
          forceCut = true;
        }
      } catch {}
    }
    const k = 1 - Math.exp(-dt * 5.2);
    playT += (st.targetTime - playT) * k;
    if (Math.abs(st.targetTime - playT) < 0.0006) playT = st.targetTime;
    update(playT, dt, false);
    renderer.render(scene, camera);
    store.tick(playT);
    fpsMonitor(dt);
    raf = requestAnimationFrame(frame);
  }

  function start() {
    if (running || disposed) return;
    running = true;
    last = performance.now();
    raf = requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    raf = null;
  }

  let renderQueued = false;
  function renderOnce() {
    if (disposed || renderQueued) return;
    renderQueued = true;
    requestAnimationFrame(() => {
      renderQueued = false;
      if (disposed) return;
      const st = store.get();
      playT = st.targetTime;
      update(playT, 0.016, true);
      renderer.render(scene, camera);
      store.tick(playT);
    });
  }

  function resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    renderer.setPixelRatio(baseDpr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    applyQuality();
  }
  resize();

  const ready = new Promise((resolve) => {
    renderer.compileAsync
      ? renderer.compileAsync(scene, camera).then(() => {
          renderer.render(scene, camera);
          resolve();
        }).catch(() => {
          renderer.render(scene, camera);
          resolve();
        })
      : (renderer.render(scene, camera), resolve());
  });

  let contextLostCb = null;
  canvas.addEventListener("webglcontextlost", (e) => {
    e.preventDefault();
    stop();
    contextLostCb && contextLostCb();
  });

  return {
    ready,
    start,
    stop,
    renderOnce,
    resize,
    setActive(v) {
      wantActive = v;
      const st = store.get();
      if (st.motion === "calm") {
        stop();
        if (v) renderOnce();
        return;
      }
      v ? start() : stop();
    },
    setPointer(x, y, active) {
      pointer.x = x;
      pointer.y = y;
      pointer.active = active;
      parX = parX * 0.9 + x * 0.1;
      parY = parY * 0.9 + y * 0.1;
    },
    tap() {
      tapPulse = 1.0;
    },
    ignite() {
      igniteV = 1;
    },
    onContextLost(cb) {
      contextLostCb = cb;
    },
    dispose() {
      disposed = true;
      stop();
      scene.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) {
          if (o.material.map) o.material.map.dispose();
          o.material.dispose();
        }
      });
      renderer.dispose();
    },
  };
}
