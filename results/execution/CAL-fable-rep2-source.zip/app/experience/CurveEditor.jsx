"use client";
// Act III: the easing curve is the interface. What you shape here drives the
// shuttle in the world, the ribbon's pulse, and the exported code — same math.
import { useEffect, useRef } from "react";
import { store, useStoreVersion } from "./store";
import { CURVE_PRESETS, SHUTTLE_PERIOD } from "./constants";
import { clamp, makeEase, springSettleMs } from "./easing";

const W = 300;
const H = 174;
const PXD = 34;
const PYD = 18;
const X = (x) => PXD + x * (W - 2 * PXD);
const Y = (v) => PYD + ((1.5 - v) / 2) * (H - 2 * PYD);

const sameP = (a, b) => a.length === b.length && a.every((v, i) => Math.abs(v - b[i]) < 0.001);

export default function CurveEditor() {
  useStoreVersion();
  const curve = store.get().curve;
  const svgRef = useRef(null);
  const dotRef = useRef(null);
  const easeRef = useRef({ key: "", fn: null });

  const setCurve = (patch) => store.set({ curve: { ...store.get().curve, ...patch } });

  const toXY = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const sx = ((e.clientX - rect.left) / rect.width) * W;
    const sy = ((e.clientY - rect.top) / rect.height) * H;
    return {
      x: clamp((sx - PXD) / (W - 2 * PXD), 0, 1),
      y: clamp(1.5 - ((sy - PYD) / (H - 2 * PYD)) * 2, -0.5, 1.5),
    };
  };

  const startDrag = (idx) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    const move = (ev) => {
      const { x, y } = toXY(ev);
      const p = [...store.get().curve.p];
      p[idx * 2] = Math.round(x * 100) / 100;
      p[idx * 2 + 1] = Math.round(y * 100) / 100;
      setCurve({ mode: "bezier", p });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    move(e);
  };

  const handleKeys = (idx) => (e) => {
    const dx = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
    const dy = e.key === "ArrowUp" ? 1 : e.key === "ArrowDown" ? -1 : 0;
    if (!dx && !dy) return;
    e.preventDefault();
    const stp = e.shiftKey ? 0.1 : 0.02;
    const p = [...store.get().curve.p];
    p[idx * 2] = clamp(Math.round((p[idx * 2] + dx * stp) * 100) / 100, 0, 1);
    p[idx * 2 + 1] = clamp(Math.round((p[idx * 2 + 1] + dy * stp) * 100) / 100, -0.5, 1.5);
    setCurve({ mode: "bezier", p });
  };

  // preview dot: runs only in full motion, only while the editor is on screen
  useEffect(() => {
    const el = svgRef.current;
    const dot = dotRef.current;
    if (!el || !dot) return;
    let raf = null;
    let visible = false;
    const easeOf = (c) => {
      const key = c.mode === "spring" ? `s${c.stiffness},${c.damping}` : `b${c.p.join(",")}`;
      if (easeRef.current.key !== key) easeRef.current = { key, fn: makeEase(c) };
      return easeRef.current.fn;
    };
    const running = () => visible && !document.hidden && store.get().motion === "full";
    const loop = () => {
      if (!running()) {
        raf = null;
        return;
      }
      const s = store.get();
      const cyc = ((performance.now() / 1000) % (2 * SHUTTLE_PERIOD)) / SHUTTLE_PERIOD;
      const tri = cyc < 1 ? cyc : 2 - cyc;
      const f = easeOf(s.curve);
      dot.setAttribute("cx", X(tri));
      dot.setAttribute("cy", Y(clamp(f(tri), -0.5, 1.5)));
      raf = requestAnimationFrame(loop);
    };
    const ensure = () => {
      if (running() && raf === null) raf = requestAnimationFrame(loop);
      dot.style.opacity = store.get().motion === "full" ? "1" : "0";
    };
    const io = new IntersectionObserver((entries) => {
      visible = entries[0] ? entries[0].isIntersecting : false;
      ensure();
    });
    io.observe(el);
    const unsub = store.onState(ensure);
    document.addEventListener("visibilitychange", ensure);
    return () => {
      io.disconnect();
      unsub();
      document.removeEventListener("visibilitychange", ensure);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const p = curve.p;
  let springPts = "";
  if (curve.mode === "spring") {
    const f = makeEase(curve);
    const pts = [];
    for (let i = 0; i <= 60; i++) {
      const x = i / 60;
      pts.push(`${X(x).toFixed(1)},${Y(clamp(f(x), -0.5, 1.5)).toFixed(1)}`);
    }
    springPts = pts.join(" ");
  }

  return (
    <div className="curve-editor">
      <div className="ce-chips" role="group" aria-label="Easing presets">
        {CURVE_PRESETS.map((pr) => (
          <button
            key={pr.id}
            type="button"
            className="chip-btn mono"
            aria-pressed={curve.mode === "bezier" && sameP(pr.p, p)}
            onClick={() => setCurve({ mode: "bezier", p: [...pr.p] })}
          >
            {pr.label.toUpperCase()}
          </button>
        ))}
        <button
          type="button"
          className="chip-btn mono"
          aria-pressed={curve.mode === "spring"}
          onClick={() => setCurve({ mode: "spring" })}
        >
          SPRING
        </button>
      </div>

      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="ce-svg" role="img" aria-label="Easing curve plot">
        <rect className="ce-unit" x={X(0)} y={Y(1)} width={X(1) - X(0)} height={Y(0) - Y(1)} />
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={`v${g}`} className="ce-grid" x1={X(g)} y1={Y(1.5)} x2={X(g)} y2={Y(-0.5)} />
        ))}
        {[-0.5, 0.5, 1.5].map((g) => (
          <line key={`h${g}`} className="ce-grid" x1={X(0)} y1={Y(g)} x2={X(1)} y2={Y(g)} />
        ))}
        <line className="ce-linear" x1={X(0)} y1={Y(0)} x2={X(1)} y2={Y(1)} />
        {curve.mode === "bezier" ? (
          <>
            <path
              className="ce-curve"
              d={`M ${X(0)} ${Y(0)} C ${X(p[0])} ${Y(p[1])}, ${X(p[2])} ${Y(p[3])}, ${X(1)} ${Y(1)}`}
            />
            <line className="ce-hline" x1={X(0)} y1={Y(0)} x2={X(p[0])} y2={Y(p[1])} />
            <line className="ce-hline" x1={X(1)} y1={Y(1)} x2={X(p[2])} y2={Y(p[3])} />
            <circle className="ce-anchor" cx={X(0)} cy={Y(0)} r="3.5" />
            <circle className="ce-anchor" cx={X(1)} cy={Y(1)} r="3.5" />
            {[0, 1].map((idx) => (
              <circle
                key={idx}
                className="ce-handle"
                tabIndex={0}
                role="slider"
                aria-label={`Control point ${idx + 1} — arrows move it, shift for coarse`}
                aria-valuemin={-0.5}
                aria-valuemax={1.5}
                aria-valuenow={p[idx * 2 + 1]}
                aria-valuetext={`x ${p[idx * 2]}, y ${p[idx * 2 + 1]}`}
                cx={X(p[idx * 2])}
                cy={Y(p[idx * 2 + 1])}
                r="7"
                onPointerDown={startDrag(idx)}
                onKeyDown={handleKeys(idx)}
              />
            ))}
          </>
        ) : (
          <polyline className="ce-curve" points={springPts} fill="none" />
        )}
        <circle ref={dotRef} className="ce-dot" r="4.5" cx={X(0)} cy={Y(0)} />
      </svg>

      {curve.mode === "spring" && (
        <div className="ce-springs">
          <label className="mono">
            STIFFNESS
            <input
              type="range"
              min="40"
              max="400"
              step="5"
              value={curve.stiffness}
              onChange={(e) => setCurve({ stiffness: Number(e.target.value) })}
            />
            <b>{curve.stiffness}</b>
          </label>
          <label className="mono">
            DAMPING
            <input
              type="range"
              min="4"
              max="40"
              step="1"
              value={curve.damping}
              onChange={(e) => setCurve({ damping: Number(e.target.value) })}
            />
            <b>{curve.damping}</b>
          </label>
        </div>
      )}

      <p className="ce-readout mono">
        {curve.mode === "bezier" ? (
          <>
            cubic-bezier(<b>{p.join(", ")}</b>)
          </>
        ) : (
          <>
            spring(<b>{curve.stiffness}</b>, <b>{curve.damping}</b>) ≈ <b>{springSettleMs(curve.stiffness, curve.damping)}ms</b>
          </>
        )}
      </p>
    </div>
  );
}
