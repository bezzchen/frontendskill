"use client";
// Orchestrator: owns the canvas, scroll→time mapping, motion mode, capability
// tier, engine lifecycle (pause on hidden/offscreen), boot, and the play loop.
import { useCallback, useEffect, useRef, useState } from "react";
import { store, useStoreVersion } from "./store";
import { DURATION } from "./constants";
import { togglePlay } from "./controls";
import TopBar from "./TopBar";
import TimelineDock from "./TimelineDock";
import Poster from "./Poster";

export default function Experience({ children }) {
  useStoreVersion();
  const st = store.get();
  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const maxScrollRef = useRef(1);
  const intersectingRef = useRef(true);
  const mountTRef = useRef(0);
  const leftRef = useRef(false);
  const [ready, setReady] = useState(false); // world compiled (or no world needed)
  const [lockMode, setLockMode] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const [gone, setGone] = useState(false);

  const beginLeave = useCallback(() => {
    if (leftRef.current) return;
    leftRef.current = true;
    setLeaving(true);
    engineRef.current?.ignite();
    const calm = store.get().motion !== "full" || store.get().tier === 0;
    window.setTimeout(
      () => {
        setGone(true);
        store.set({ booted: true });
      },
      calm ? 180 : 800
    );
  }, []);

  // ---- mount: detection + global wiring
  useEffect(() => {
    mountTRef.current = performance.now();
    const qs = new URLSearchParams(window.location.search);
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    let saved = null;
    try {
      saved = localStorage.getItem("mrd-motion");
    } catch {}
    const qMotion = qs.get("motion");
    const motion =
      qMotion === "calm" || qMotion === "full"
        ? qMotion
        : saved === "calm" || saved === "full"
          ? saved
          : mq.matches
            ? "calm"
            : "full";
    const motionSource = qMotion ? "query" : saved ? "user" : "auto";

    let tier = 2;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const dm = navigator.deviceMemory || 8;
    const cores = navigator.hardwareConcurrency || 8;
    if (coarse || window.innerWidth < 820 || dm <= 4 || cores <= 4) tier = 1;
    try {
      const probe = document.createElement("canvas");
      if (!probe.getContext("webgl2") && !probe.getContext("webgl")) tier = 0;
    } catch {
      tier = 0;
    }
    const qTier = qs.get("tier");
    if (qTier === "0" || qTier === "1" || qTier === "2") tier = Number(qTier);
    store.set({ motion, motionSource, tier });

    const onMq = () => {
      if (store.get().motionSource === "auto")
        store.set({ motion: mq.matches ? "calm" : "full", playing: false });
    };
    mq.addEventListener?.("change", onMq);

    const measure = () => {
      maxScrollRef.current = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    };
    measure();
    const t1 = window.setTimeout(measure, 500);
    // debug/test hooks: ?t=<s> scroll-jumps there; ?lock=<s> pins the playhead
    // without scrolling (used by the screenshot harness)
    const qT = parseFloat(qs.get("t"));
    if (!Number.isNaN(qT)) {
      requestAnimationFrame(() => {
        measure();
        window.scrollTo(0, (Math.max(0, Math.min(DURATION, qT)) / DURATION) * maxScrollRef.current);
      });
    }
    const qLock = parseFloat(qs.get("lock"));
    const locked = !Number.isNaN(qLock);
    if (locked) {
      setLockMode(true);
      store.setTarget(qLock);
      window.setTimeout(() => {
        const s = store.get();
        if (s.motion !== "full" || s.tier === 0) {
          store.tick(s.targetTime);
        }
        engineRef.current?.renderOnce();
      }, 60);
    }
    const onResize = () => {
      measure();
      engineRef.current?.resize();
      if (store.get().motion !== "full") engineRef.current?.renderOnce();
    };
    window.addEventListener("resize", onResize);

    const onScroll = () => {
      if (locked) return;
      store.setTarget((window.scrollY / maxScrollRef.current) * DURATION);
      const s = store.get();
      if (s.motion !== "full" || s.tier === 0 || !engineRef.current) {
        store.tick(s.targetTime);
        engineRef.current?.renderOnce();
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    // Space = play/pause, editor style (only in full motion, never on controls)
    const onKey = (e) => {
      if (e.code !== "Space" || e.repeat) return;
      const t = e.target;
      if (t && t.closest?.("button, a, input, textarea, select, [role='slider'], [contenteditable='true']")) return;
      if (store.get().motion !== "full") return;
      e.preventDefault();
      togglePlay();
    };
    window.addEventListener("keydown", onKey);

    // pointer → gesture field + parallax; taps ripple on touch
    const onMove = (e) => {
      if (e.pointerType === "touch") return;
      engineRef.current?.setPointer(
        (e.clientX / window.innerWidth) * 2 - 1,
        -((e.clientY / window.innerHeight) * 2 - 1),
        true
      );
    };
    const onLeave = () => engineRef.current?.setPointer(10, 10, false);
    const onDown = (e) => {
      if (e.pointerType !== "touch") return;
      engineRef.current?.setPointer(
        (e.clientX / window.innerWidth) * 2 - 1,
        -((e.clientY / window.innerHeight) * 2 - 1),
        false
      );
      engineRef.current?.tap();
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerdown", onDown, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);

    return () => {
      window.clearTimeout(t1);
      mq.removeEventListener?.("change", onMq);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
      document.documentElement.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  // ---- engine lifecycle, keyed on tier
  useEffect(() => {
    const tier = store.get().tier;
    if (tier === 0) {
      setReady(true);
      return;
    }
    if (!canvasRef.current) return;
    let cancelled = false;

    const syncActive = () => {
      const e = engineRef.current;
      if (!e) return;
      const vis = !document.hidden && intersectingRef.current;
      if (store.get().motion === "full") e.setActive(vis);
      else {
        e.setActive(false);
        if (vis) e.renderOnce();
      }
    };

    (async () => {
      const mod = await import("./engine");
      if (cancelled) return;
      const engine = mod.createEngine({ canvas: canvasRef.current, store, tier });
      if (!engine) {
        store.set({ tier: 0 });
        return;
      }
      engineRef.current = engine;
      engine.onContextLost(() => {
        engineRef.current = null;
        store.set({ tier: 0, playing: false });
      });
      await engine.ready;
      if (cancelled) return;
      setReady(true);
      syncActive();
    })();

    const onVis = () => syncActive();
    document.addEventListener("visibilitychange", onVis);
    const io = new IntersectionObserver((entries) => {
      intersectingRef.current = entries[0] ? entries[0].isIntersecting : true;
      syncActive();
    });
    io.observe(canvasRef.current);
    const unsub = store.onState(syncActive);

    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", onVis);
      io.disconnect();
      unsub();
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, [st.tier]);

  // ---- boot exit
  useEffect(() => {
    if (!ready || gone) return;
    const calm = store.get().motion !== "full" || store.get().tier === 0;
    const elapsed = performance.now() - mountTRef.current;
    const hold = calm ? 100 : Math.max(80, 1000 - elapsed);
    const t = window.setTimeout(beginLeave, hold);
    const onEsc = (e) => {
      if (e.key === "Escape") beginLeave();
    };
    window.addEventListener("keydown", onEsc);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", onEsc);
    };
  }, [ready, gone, beginLeave]);

  // ---- play transport: advances scroll in real time; any user input takes over
  useEffect(() => {
    if (!st.playing) return;
    let raf = null;
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const max = maxScrollRef.current;
      const y = window.scrollY + (max / DURATION) * dt;
      window.scrollTo(0, y);
      if (y >= max - 1) {
        store.set({ playing: false });
        return;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    const cancel = () => store.set({ playing: false });
    const onNavKey = (e) => {
      if (["PageDown", "PageUp", "ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) cancel();
    };
    window.addEventListener("wheel", cancel, { passive: true });
    window.addEventListener("touchmove", cancel, { passive: true });
    window.addEventListener("keydown", onNavKey);
    return () => {
      if (raf) cancelAnimationFrame(raf);
      window.removeEventListener("wheel", cancel);
      window.removeEventListener("touchmove", cancel);
      window.removeEventListener("keydown", onNavKey);
    };
  }, [st.playing]);

  return (
    <div
      className={"stage" + (lockMode ? " lockmode" : "")}
      data-act={st.act}
      data-motion={st.motion}
      data-tier={st.tier}
      data-ended={st.ended ? "1" : "0"}
    >
      <a className="skip-link" href="#content">
        Skip to content
      </a>
      {st.tier > 0 ? (
        <canvas ref={canvasRef} className="world" aria-hidden="true" />
      ) : (
        <Poster />
      )}
      <div className="vignette" aria-hidden="true" />
      <TopBar />
      <main id="content" className="content">
        {children}
      </main>
      <TimelineDock />
      {!gone && (
        <div
          className={"boot" + (leaving ? " boot-leaving" : "")}
          onClick={() => ready && beginLeave()}
          aria-hidden="true"
        >
          <div className="boot-inner">
            <p className="boot-kicker mono">MERIDIAN · MOTION EDITOR FOR THE WEB</p>
            <div className="boot-mark serif">Meridian</div>
            <p className="boot-line mono">LAUNCH.MRD — 60S @ 60FPS · 3 TRACKS · 23 KEYFRAMES</p>
            <div className="boot-progress" aria-hidden="true">
              <span className={ready ? "isdone" : ""} />
            </div>
            <p className="boot-line mono dim">{ready ? "READY — ROLLING" : "COMPILING WORLD…"}</p>
          </div>
        </div>
      )}
    </div>
  );
}
