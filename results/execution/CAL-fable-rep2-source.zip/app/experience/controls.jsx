"use client";
// Transport actions shared by the dock, the hero, and keyboard shortcuts.
import { store, useStoreVersion } from "./store";
import { DURATION } from "./constants";

export function seekTo(t, smoothScroll = true) {
  const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  const y = (Math.max(0, Math.min(DURATION, t)) / DURATION) * max;
  const calm = store.get().motion !== "full";
  window.scrollTo({ top: y, behavior: smoothScroll && !calm ? "smooth" : "auto" });
}

export function togglePlay() {
  const s = store.get();
  if (s.motion !== "full") return;
  if (!s.playing && s.time >= DURATION - 0.1) seekTo(0, false);
  store.set({ playing: !s.playing });
}

export function PressPlay() {
  useStoreVersion();
  const s = store.get();
  return (
    <button
      type="button"
      className="btn btn-ghost mono play-only"
      onClick={togglePlay}
      aria-pressed={s.playing}
    >
      {s.playing ? "❚❚ PAUSE" : "▶ PRESS PLAY — 60S"}
    </button>
  );
}

export function Replay() {
  return (
    <button type="button" className="btn btn-ghost mono" onClick={() => seekTo(0.001, true)}>
      ⏮ WATCH IT AGAIN
    </button>
  );
}
