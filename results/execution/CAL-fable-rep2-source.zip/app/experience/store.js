"use client";
// A deliberately tiny external store. Two channels:
//  - "frame": high-frequency (every rendered frame) — DOM refs subscribe, React never re-renders.
//  - "state": discrete changes (act, keyframe count, motion mode, curve edits) — React subscribes.
import { useSyncExternalStore } from "react";
import { DURATION, actIndexAt, kfCountAt } from "./constants";
import { clamp } from "./easing";

const frameListeners = new Set();
const stateListeners = new Set();
let version = 0;

const state = {
  targetTime: 0,
  time: 0, // smoothed, engine-owned
  act: 0,
  kfPassed: 1,
  playing: false,
  motion: "full", // 'full' | 'calm'
  motionSource: "auto", // 'auto' | 'user' | 'query'
  tier: 2, // 2 desktop full · 1 lean · 0 no-WebGL poster
  booted: false,
  ended: false,
  curve: { mode: "bezier", p: [0.62, -0.18, 0.24, 1.18], stiffness: 170, damping: 14 },
};

function emitState() {
  version++;
  for (const fn of stateListeners) fn(state);
}

export const store = {
  get: () => state,
  version: () => version,
  set(patch) {
    Object.assign(state, patch);
    emitState();
  },
  setTarget(t) {
    state.targetTime = clamp(t, 0, DURATION);
  },
  // Called by the engine each rendered frame (or directly on scroll in calm/tier-0).
  tick(time) {
    state.time = time;
    const act = actIndexAt(time);
    const kf = kfCountAt(time);
    let discrete = false;
    if (act !== state.act) {
      state.act = act;
      discrete = true;
    }
    if (kf !== state.kfPassed) {
      state.kfPassed = kf;
      discrete = true;
    }
    if (!state.ended && time >= DURATION - 0.05) {
      state.ended = true;
      discrete = true;
    }
    for (const fn of frameListeners) fn(state);
    if (discrete) emitState();
  },
  onFrame(fn) {
    frameListeners.add(fn);
    return () => frameListeners.delete(fn);
  },
  onState(fn) {
    stateListeners.add(fn);
    return () => stateListeners.delete(fn);
  },
};

const subscribe = (fn) => store.onState(fn);

// React hook: re-render on any discrete state change, read fields directly.
export function useStoreVersion() {
  return useSyncExternalStore(subscribe, store.version, () => 0);
}
