// Shared motion math. The WebGL world, the curve editor, and the code
// exporter all evaluate easing through these exact functions — the curve
// you see is literally the curve you ship.

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export const easeInOut = (t) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

// Standard CSS cubic-bezier(x1, y1, x2, y2) evaluator: solve x(t)=x, return y(t).
export function cubicBezier(x1, y1, x2, y2) {
  const cx = 3 * x1;
  const bx = 3 * (x2 - x1) - cx;
  const ax = 1 - cx - bx;
  const cy = 3 * y1;
  const by = 3 * (y2 - y1) - cy;
  const ay = 1 - cy - by;
  const sampleX = (t) => ((ax * t + bx) * t + cx) * t;
  const sampleY = (t) => ((ay * t + by) * t + cy) * t;
  const sampleDX = (t) => (3 * ax * t + 2 * bx) * t + cx;
  return (x) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 6; i++) {
      const d = sampleDX(t);
      if (Math.abs(d) < 1e-6) break;
      t = clamp(t - (sampleX(t) - x) / d, 0, 1);
    }
    let lo = 0;
    let hi = 1;
    if (Math.abs(sampleX(t) - x) > 1e-4) {
      while (hi - lo > 1e-5) {
        t = (lo + hi) / 2;
        if (sampleX(t) < x) lo = t;
        else hi = t;
      }
    }
    return sampleY(t);
  };
}

// Damped spring, closed form, normalized to settle at u = 1.
// Returns f(u) for u in [0, 1] where the window is the spring's settle time.
export function springEase(stiffness, damping) {
  const w0 = Math.sqrt(Math.max(1, stiffness));
  const zeta = damping / (2 * Math.sqrt(Math.max(1, stiffness)));
  const settle = -Math.log(0.001) / Math.max(0.0001, zeta * w0);
  if (zeta < 1) {
    const wd = w0 * Math.sqrt(1 - zeta * zeta);
    return (u) => {
      const t = clamp(u, 0, 1) * settle;
      const e = Math.exp(-zeta * w0 * t);
      return 1 - e * (Math.cos(wd * t) + ((zeta * w0) / wd) * Math.sin(wd * t));
    };
  }
  // critically damped / overdamped approximation
  return (u) => {
    const t = clamp(u, 0, 1) * settle;
    return 1 - (1 + w0 * t) * Math.exp(-w0 * t);
  };
}

export function springSettleMs(stiffness, damping) {
  const w0 = Math.sqrt(Math.max(1, stiffness));
  const zeta = damping / (2 * Math.sqrt(Math.max(1, stiffness)));
  return Math.round((-Math.log(0.001) / Math.max(0.0001, zeta * w0)) * 1000);
}

// Sample a spring into CSS linear() stops.
export function springLinearStops(stiffness, damping, n = 16) {
  const f = springEase(stiffness, damping);
  const out = [];
  for (let i = 0; i <= n; i++) {
    out.push(Number(f(i / n).toFixed(3)));
  }
  return out;
}

// Evaluate the current curve state (bezier or spring) as f(u), u in [0,1].
export function makeEase(curve) {
  if (curve.mode === "spring") return springEase(curve.stiffness, curve.damping);
  const [x1, y1, x2, y2] = curve.p;
  return cubicBezier(x1, y1, x2, y2);
}
