"use client";
// The signature element: a real timeline. Minimap of the world and its controller.
import { useEffect, useRef } from "react";
import { store, useStoreVersion } from "./store";
import { ACTS, TRACKS, DURATION, KF_TOTAL, timecode, pad2 } from "./constants";
import { seekTo, togglePlay } from "./controls";
import { clamp } from "./easing";

const pct = (t) => `${(t / DURATION) * 100}%`;

const IconStart = () => (
  <svg viewBox="0 0 12 12" width="11" height="11" aria-hidden="true">
    <path d="M2 1v10M11 1L4 6l7 5z" fill="currentColor" stroke="currentColor" strokeWidth="1" strokeLinejoin="round" />
  </svg>
);
const IconPlay = () => (
  <svg viewBox="0 0 12 12" width="11" height="11" aria-hidden="true">
    <path d="M2.5 1.2L11 6l-8.5 4.8z" fill="currentColor" />
  </svg>
);
const IconPause = () => (
  <svg viewBox="0 0 12 12" width="11" height="11" aria-hidden="true">
    <path d="M2.5 1.5h2.6v9H2.5zM6.9 1.5h2.6v9H6.9z" fill="currentColor" />
  </svg>
);
const IconNext = () => (
  <svg viewBox="0 0 14 12" width="12" height="11" aria-hidden="true">
    <path d="M1 1.2L7 6l-6 4.8zM7 1.2L13 6l-6 4.8z" fill="currentColor" />
  </svg>
);

export default function TimelineDock() {
  useStoreVersion();
  const st = store.get();
  const rulerRef = useRef(null);
  const phRef = useRef(null);
  const progRef = useRef(null);
  const tcRef = useRef(null);
  const actRef = useRef(null);
  const kfRef = useRef(null);
  const widthRef = useRef(1);

  useEffect(() => {
    const apply = (s) => {
      const f = s.time / DURATION;
      if (phRef.current) {
        phRef.current.style.transform = `translateX(${f * widthRef.current}px)`;
        phRef.current.setAttribute("aria-valuenow", s.time.toFixed(1));
        phRef.current.setAttribute(
          "aria-valuetext",
          `${s.time.toFixed(1)} seconds — act ${ACTS[s.act].num}, ${ACTS[s.act].name.toLowerCase()}`
        );
      }
      if (progRef.current) progRef.current.style.transform = `scaleX(${f})`;
      if (tcRef.current) tcRef.current.textContent = timecode(s.time);
      if (actRef.current) actRef.current.textContent = `ACT ${ACTS[s.act].num} · ${ACTS[s.act].name}`;
      if (kfRef.current) kfRef.current.textContent = `K ${pad2(s.kfPassed)}/${KF_TOTAL}`;
    };
    const ro = new ResizeObserver(() => {
      widthRef.current = rulerRef.current ? rulerRef.current.clientWidth : 1;
      apply(store.get());
    });
    if (rulerRef.current) {
      widthRef.current = rulerRef.current.clientWidth;
      ro.observe(rulerRef.current);
    }
    const un = store.onFrame(apply);
    apply(store.get());
    return () => {
      un();
      ro.disconnect();
    };
  }, []);

  const scrub = (e) => {
    const el = rulerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const f = clamp((e.clientX - rect.left) / rect.width, 0, 1);
    seekTo(f * DURATION, false);
  };
  const startScrub = (e) => {
    if (e.button !== undefined && e.button !== 0) return;
    e.preventDefault();
    store.set({ playing: false });
    scrub(e);
    const move = (ev) => scrub(ev);
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const onSliderKeys = (e) => {
    const s = store.get();
    let t = null;
    const stp = e.shiftKey ? 5 : 1;
    if (e.key === "ArrowRight" || e.key === "ArrowUp") t = s.time + stp;
    else if (e.key === "ArrowLeft" || e.key === "ArrowDown") t = s.time - stp;
    else if (e.key === "Home") t = 0;
    else if (e.key === "End") t = DURATION;
    else if (e.key === "PageUp") t = ACTS[Math.max(0, s.act - 1)].t0 + 0.01;
    else if (e.key === "PageDown") t = ACTS[Math.min(ACTS.length - 1, s.act + 1)].t0 + 0.01;
    if (t !== null) {
      e.preventDefault();
      store.set({ playing: false });
      seekTo(t, false);
    }
  };

  const nextAct = () => seekTo(ACTS[Math.min(ACTS.length - 1, st.act + 1)].t0 + 0.01, true);

  return (
    <div className="dock" role="region" aria-label="Timeline transport">
      <div className="dock-left">
        <button type="button" className="tbtn" aria-label="Back to start" onClick={() => seekTo(0, true)}>
          <IconStart />
        </button>
        {st.motion === "full" ? (
          <button
            type="button"
            className="tbtn tbtn-play"
            aria-label={st.playing ? "Pause" : "Play the page"}
            aria-pressed={st.playing}
            onClick={togglePlay}
          >
            {st.playing ? <IconPause /> : <IconPlay />}
          </button>
        ) : (
          <button type="button" className="tbtn tbtn-play" aria-label="Next act" onClick={nextAct}>
            <IconNext />
          </button>
        )}
        <div className="tc-block mono">
          <span className="tc-main" ref={tcRef}>
            00:00:00:00
          </span>
          <span className="tc-sub" ref={actRef}>
            ACT I · ORIGIN
          </span>
        </div>
      </div>

      <div className="dock-ruler" ref={rulerRef}>
        <div className="chapters">
          {ACTS.map((a) => (
            <button
              key={a.id}
              type="button"
              className={"chapter mono" + (st.act === a.i ? " on" : "")}
              style={{ left: pct(a.t0) }}
              onClick={() => seekTo(a.t0 + 0.01, true)}
            >
              <b>{a.num}</b>
              <span className="chapter-name"> {a.name}</span>
            </button>
          ))}
        </div>
        <div className="ruler-band" onPointerDown={startScrub}>
          <div className="ticks" aria-hidden="true" />
          <div className="progress" ref={progRef} aria-hidden="true" />
        </div>
        <div className="tracks" aria-hidden="true">
          {TRACKS.map((tr) => (
            <div className="track" key={tr.name}>
              <span className="track-name mono">{tr.name}</span>
              {tr.kf.map((t) => (
                <i key={t} className={"kf" + (st.time >= t ? " done" : "")} style={{ left: pct(t) }} />
              ))}
            </div>
          ))}
        </div>
        <div
          className="playhead"
          ref={phRef}
          role="slider"
          tabIndex={0}
          aria-label="Playhead"
          aria-valuemin={0}
          aria-valuemax={DURATION}
          aria-valuenow={0}
          onKeyDown={onSliderKeys}
          onPointerDown={startScrub}
        >
          <span className="playhead-cap" aria-hidden="true" />
        </div>
      </div>

      <div className="dock-right mono">
        <span className="kf-count" ref={kfRef}>
          K 01/{KF_TOTAL}
        </span>
        <span className="hint">SPACE ▸ PLAY</span>
      </div>
    </div>
  );
}
