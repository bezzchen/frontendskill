// launch.mrd — the project this page plays.
// Single source of truth for the timeline: the DOM dock, the WebGL world,
// the copy, and the exported code all read from here.

export const DURATION = 60; // project seconds
export const FPS = 60;
export const VH_PER_SECOND = 13; // scroll density: 1 project second = 13vh of scroll

export const ACTS = [
  { i: 0, num: "I", id: "origin", name: "ORIGIN", t0: 0, t1: 12 },
  { i: 1, num: "II", id: "keyframes", name: "KEYFRAMES", t0: 12, t1: 26 },
  { i: 2, num: "III", id: "curves", name: "CURVES", t0: 26, t1: 40 },
  { i: 3, num: "IV", id: "ship", name: "SHIP", t0: 40, t1: 52 },
  { i: 4, num: "V", id: "premiere", name: "PREMIERE", t0: 52, t1: 60 },
];

// Three visible tracks. 23 keyframes total.
export const TRACKS = [
  { name: "CAMERA", kf: [0, 12, 26, 40, 52] },
  { name: "WORLD", kf: [2, 13, 15.5, 18, 20.5, 23, 31, 45, 56, 60] },
  { name: "CURVE", kf: [6, 27, 29, 33, 36, 38, 42, 48] },
];

export const ALL_KF = TRACKS.flatMap((t) => t.kf).sort((a, b) => a - b);
export const KF_TOTAL = ALL_KF.length; // 23

// Gates rendered inside the 3D world (the WORLD track).
// phase 1..5 = the five properties act II re-keys: palette, drift, width, density, hue.
export const WORLD_GATES = [
  { t: 2 },
  { t: 13, phase: 1 },
  { t: 15.5, phase: 2 },
  { t: 18, phase: 3 },
  { t: 20.5, phase: 4 },
  { t: 23, phase: 5 },
  { t: 31 },
  { t: 45 },
  { t: 56 },
  { t: 60 },
];

// Act III shuttle runs between these two times on the path.
export const SHUTTLE_SPAN = [31, 37];
export const SHUTTLE_PERIOD = 1.9; // seconds per pass — also the exported duration

export const CURVE_PRESETS = [
  { id: "linear", label: "Linear", p: [0, 0, 1, 1] },
  { id: "glide", label: "Glide", p: [0.25, 0.1, 0.25, 1] },
  { id: "snap", label: "Snap", p: [0.85, 0, 0.12, 1] },
  { id: "overshoot", label: "Overshoot", p: [0.62, -0.18, 0.24, 1.18] },
];

export function actIndexAt(t) {
  for (let i = ACTS.length - 1; i >= 0; i--) {
    if (t >= ACTS[i].t0) return i;
  }
  return 0;
}

export function kfCountAt(t) {
  let n = 0;
  for (let i = 0; i < ALL_KF.length; i++) {
    if (ALL_KF[i] <= t + 1e-6) n++;
    else break;
  }
  return n;
}

// SMPTE-style timecode 00:00:SS:FF at 60fps
export function timecode(t) {
  const tt = Math.max(0, Math.min(DURATION, t));
  const s = Math.floor(tt);
  const f = Math.floor((tt - s) * FPS);
  if (s >= 60) return "00:01:00:00"; // the film ends exactly on the minute
  return `00:00:${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`;
}

export const pad2 = (n) => String(n).padStart(2, "0");
