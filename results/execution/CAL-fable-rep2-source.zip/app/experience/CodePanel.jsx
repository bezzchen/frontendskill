"use client";
// Act IV: not a mockup. The page's own curve state, serialized live.
import { useState } from "react";
import { store, useStoreVersion } from "./store";
import { SHUTTLE_PERIOD } from "./constants";
import { springLinearStops, springSettleMs } from "./easing";

const fmt = (n) => String(Number(n.toFixed(2)));

function easingText(curve) {
  if (curve.mode === "spring") return `linear(${springLinearStops(curve.stiffness, curve.damping, 14).join(", ")})`;
  return `cubic-bezier(${curve.p.map(fmt).join(", ")})`;
}
function durationMs(curve) {
  return curve.mode === "spring" ? springSettleMs(curve.stiffness, curve.damping) : Math.round(SHUTTLE_PERIOD * 1000);
}

function buildText(tab, curve) {
  const ease = easingText(curve);
  const dur = durationMs(curve);
  const head =
    curve.mode === "spring"
      ? `// spring(stiffness ${curve.stiffness}, damping ${curve.damping}) sampled to linear()\n`
      : "";
  if (tab === "js") {
    return (
      `// launch.mrd → shuttle · exported by Meridian\n${head}` +
      `const shuttle = document.querySelector(".shuttle");\n\n` +
      `shuttle.animate(\n  { translate: ["0 0", "240px 0"] },\n  {\n` +
      `    duration: ${dur},\n    direction: "alternate",\n    iterations: Infinity,\n` +
      `    easing: "${ease}",\n  },\n);\n`
    );
  }
  return (
    `/* launch.mrd → shuttle · exported by Meridian */\n` +
    `.shuttle {\n  animation: shuttle ${dur}ms infinite alternate;\n` +
    `  animation-timing-function: ${ease};\n}\n\n` +
    `@keyframes shuttle {\n  to { translate: 240px 0; }\n}\n`
  );
}

export default function CodePanel() {
  useStoreVersion();
  const curve = store.get().curve;
  const [tab, setTab] = useState("js");
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(buildText(tab, curve));
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {}
  };

  const ease = easingText(curve);
  const dur = durationMs(curve);

  return (
    <div className="code-panel" role="region" aria-label="Export preview — updates live with the curve above">
      <div className="cp-head">
        <div className="cp-tabs" role="tablist" aria-label="Export format">
          <button type="button" role="tab" aria-selected={tab === "js"} className="cp-tab mono" onClick={() => setTab("js")}>
            JS
          </button>
          <button type="button" role="tab" aria-selected={tab === "css"} className="cp-tab mono" onClick={() => setTab("css")}>
            CSS
          </button>
        </div>
        <span className="cp-note mono">ZERO RUNTIME · NO LOCK-IN</span>
        <button type="button" className="cp-copy mono" onClick={copy}>
          {copied ? "COPIED ✓" : "COPY"}
        </button>
      </div>
      <pre className="cp-pre" tabIndex={0}>
        <code>
          {tab === "js" ? (
            <>
              <span className="cmt">{"// launch.mrd → shuttle · exported by Meridian"}</span>
              {"\n"}
              {curve.mode === "spring" && (
                <>
                  <span className="cmt">{`// spring(stiffness ${curve.stiffness}, damping ${curve.damping}) sampled to linear()`}</span>
                  {"\n"}
                </>
              )}
              <span className="kw">const</span> shuttle = document.<span className="fn">querySelector</span>(
              <span className="str">&quot;.shuttle&quot;</span>);{"\n\n"}
              shuttle.<span className="fn">animate</span>({"(\n"}
              {"  { translate: ["}
              <span className="str">&quot;0 0&quot;</span>
              {", "}
              <span className="str">&quot;240px 0&quot;</span>
              {"] },\n"}
              {"  {\n"}
              {"    duration: "}
              <span className="live">{dur}</span>
              {",\n    direction: "}
              <span className="str">&quot;alternate&quot;</span>
              {",\n    iterations: "}
              <span className="kw">Infinity</span>
              {",\n    easing: "}
              <span className="str">
                &quot;<span className="live">{ease}</span>&quot;
              </span>
              {",\n  },\n);"}
            </>
          ) : (
            <>
              <span className="cmt">{"/* launch.mrd → shuttle · exported by Meridian */"}</span>
              {"\n"}
              <span className="fn">.shuttle</span>
              {" {\n  "}
              <span className="kw">animation</span>
              {": shuttle "}
              <span className="live">{dur}ms</span>
              {" infinite alternate;\n  "}
              <span className="kw">animation-timing-function</span>
              {": "}
              <span className="live">{ease}</span>
              {";\n}\n\n"}
              <span className="kw">@keyframes</span>
              <span className="fn"> shuttle</span>
              {" {\n  to { translate: "}
              <span className="num">240px 0</span>
              {"; }\n}"}
            </>
          )}
        </code>
      </pre>
    </div>
  );
}
