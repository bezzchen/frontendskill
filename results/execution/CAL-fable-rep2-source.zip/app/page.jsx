import Experience from "./experience/Experience";
import CurveEditor from "./experience/CurveEditor";
import CodePanel from "./experience/CodePanel";
import { PressPlay, Replay } from "./experience/controls";
import { timecode } from "./experience/constants";

// Section heights: 1 project second = 13vh of scroll. 60s + a 100vh tail.
export default function Home() {
  return (
    <Experience>
      {/* ACT I — ORIGIN */}
      <section className="act" data-card="0" id="act-origin" aria-labelledby="h-origin" style={{ height: "156vh" }}>
        <div className="card hero-card card-left">
          <p className="eyebrow mono">MERIDIAN · PRIVATE BETA</p>
          <h1 id="h-origin" className="display">
            The timeline is <em className="nobr">a place.</em>
          </h1>
          <p className="premise mono">
            THIS PAGE IS A MERIDIAN PROJECT — <b>LAUNCH.MRD</b> · 60 SECONDS ·{" "}
            <span className="nobr">SCROLL TO SCRUB IT</span>
          </p>
          <p className="body">
            Meridian is a motion editor for the web. Springs, keyframes, and gesture-driven motion on
            real tracks — designed visually, shipped as production JavaScript and CSS.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary mono" href="mailto:hello@meridian.tools?subject=Early%20access">
              GET EARLY ACCESS
            </a>
            <PressPlay />
          </div>
          <p className="caption">No install — the editor runs in your browser.</p>
        </div>
      </section>

      {/* ACT II — KEYFRAMES */}
      <section className="act" data-card="1" id="act-keyframes" aria-labelledby="h-keyframes" style={{ height: "182vh" }}>
        <div className="card card-right">
          <p className="eyebrow mono">
            ACT II · <span className="amber">TC {timecode(12)}</span> · KEYFRAMES
          </p>
          <h2 id="h-keyframes" className="display2">
            Set a keyframe. The world <em>remembers.</em>
          </h2>
          <p className="body">
            Every property lives on a track — position, color, anything you can name. The five gates
            ahead, K-05 through K-09, each re-key this sky: palette, drift, width, density, hue. Cross
            one and the world commits to it. Scrub back, and it un-happens.
          </p>
          <p className="caption">The dust bending around your cursor is a gesture track doing its job.</p>
        </div>
      </section>

      {/* ACT III — CURVES */}
      <section className="act" data-card="2" id="act-curves" aria-labelledby="h-curves" style={{ height: "182vh" }}>
        <div className="card card-left">
          <p className="eyebrow mono">
            ACT III · <span className="amber">TC {timecode(26)}</span> · CURVES
          </p>
          <h2 id="h-curves" className="display2">
            Easing is a shape. <em>Bend it.</em>
          </h2>
          <p className="body">
            Drag the handles. The bright shuttle out there runs your curve; the dim one runs linear, so
            you can see exactly what character you added. Or hand it to physics — a spring with
            stiffness and damping, sampled into keyframes you can ship.
          </p>
          <CurveEditor />
          <p className="caption">There is no apply button. The curve you see is the curve you ship.</p>
        </div>
      </section>

      {/* ACT IV — SHIP */}
      <section className="act" data-card="3" id="act-ship" aria-labelledby="h-ship" style={{ height: "156vh" }}>
        <div className="card card-right">
          <p className="eyebrow mono">
            ACT IV · <span className="amber">TC {timecode(40)}</span> · SHIP
          </p>
          <h2 id="h-ship" className="display2">
            Scrub it. <em>Ship it.</em>
          </h2>
          <p className="body">
            One click compiles the timeline to dependency-free JavaScript or CSS — no runtime, no
            lock-in. This panel is not a mockup: it is this page&apos;s own shuttle curve, serialized
            live while you play with it.
          </p>
          <CodePanel />
        </div>
      </section>

      {/* ACT V — PREMIERE */}
      <section className="act" data-card="4" id="act-premiere" aria-labelledby="h-premiere" style={{ height: "104vh" }}>
        <div className="card card-left card-final">
          <p className="eyebrow mono">
            ACT V · <span className="amber">TC {timecode(52)}</span> · PREMIERE
          </p>
          <h2 id="h-premiere" className="display2">
            Your project starts at <em>00:00.</em>
          </h2>
          <p className="body">
            The line below has been the film all along — one ring, sixty seconds, twenty-three
            keyframes. Meridian previews every breakpoint and builds the reduced-motion cut beside the
            full one. This page ships both: try <b className="mono">CALM</b>, top right.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary mono" href="mailto:hello@meridian.tools?subject=Early%20access">
              GET EARLY ACCESS
            </a>
            <Replay />
          </div>
          <p className="caption">Private beta · hello@meridian.tools</p>
        </div>
      </section>

      <div className="tail">
        <footer className="site-footer mono">
          <span>BUILT IN MERIDIAN — LAUNCH.MRD · 60S · 3 TRACKS · 23 KEYFRAMES</span>
          <a href="mailto:hello@meridian.tools">HELLO@MERIDIAN.TOOLS</a>
          <span>© 2026 MERIDIAN TOOLS</span>
        </footer>
      </div>
    </Experience>
  );
}
