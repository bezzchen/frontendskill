"use client";

import { useEffect, useState } from "react";
import { initMotionStore, getMotion, setMotion, subscribeMotion, isMotionLocked } from "./motionStore";

export default function MotionToggle() {
  const [motion, setLocal] = useState("full");

  useEffect(() => {
    setLocal(initMotionStore());
    return subscribeMotion(setLocal);
  }, []);

  const reduced = motion === "reduced";
  return (
    <button
      type="button"
      className="chip-btn"
      aria-pressed={reduced}
      disabled={typeof window !== "undefined" && isMotionLocked()}
      onClick={() => setMotion(getMotion() === "reduced" ? "full" : "reduced")}
      title={reduced ? "Switch to the full-motion experience" : "Switch to the low-motion folio"}
    >
      Motion&nbsp;{reduced ? "off" : "on"}
    </button>
  );
}
