// Tiny pubsub linking DOM copy (botanical ledger) and the WebGL scene.
const state = { hover: -1, beat: -1 };
const subs = new Set();

export function setHover(i) {
  if (state.hover === i) return;
  state.hover = i;
  subs.forEach((fn) => fn(state));
}
export function setBeat(i) {
  if (state.beat === i) return;
  state.beat = i;
  subs.forEach((fn) => fn(state));
}
export function getBus() {
  return state;
}
export function subscribeBus(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}

// Travel the run to a given progress. Scroll stays the single owner of
// the timeline — this only drives the scroll position; the engine
// follows it exactly as it follows the wheel.
export function scrollToProgress(p) {
  const wrap = document.querySelector(".stage-wrap");
  if (!wrap) return;
  const travel = Math.max(1, wrap.offsetHeight - window.innerHeight);
  window.scrollTo({ top: p * travel, behavior: "smooth" });
}
