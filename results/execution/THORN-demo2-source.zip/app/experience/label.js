// The bottle label, drawn once into a canvas texture using the page's own fonts.
export function drawLabel(canvas) {
  const W = 640;
  const H = 880;
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  const css = getComputedStyle(document.documentElement);
  const display = (css.getPropertyValue("--font-display") || "Georgia").trim() || "Georgia";
  const sans = (css.getPropertyValue("--font-sans") || "Arial").trim() || "Arial";

  // paper
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, "#f2ead7");
  grad.addColorStop(1, "#e7dcc2");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // rules
  ctx.strokeStyle = "#7a3f1c";
  ctx.lineWidth = 3;
  ctx.strokeRect(26, 26, W - 52, H - 52);
  ctx.lineWidth = 1;
  ctx.strokeRect(40, 40, W - 80, H - 80);

  ctx.fillStyle = "#23231d";
  ctx.textAlign = "center";

  const caps = (size, spacing, weight) => {
    ctx.font = `${weight || 600} ${size}px ${sans}`;
    try { ctx.letterSpacing = `${spacing}px`; } catch (e) { /* older engines */ }
  };

  caps(21, 9);
  ctx.fillStyle = "#7a3f1c";
  ctx.fillText("SMALL BATCH · LONDON", W / 2, 118);

  ctx.fillStyle = "#1d1d18";
  ctx.font = `500 92px ${display}`;
  try { ctx.letterSpacing = "6px"; } catch (e) {}
  ctx.fillText("Thornmere", W / 2, 250);

  // five botanical marks
  ctx.fillStyle = "#7a3f1c";
  for (let i = 0; i < 5; i++) {
    const x = W / 2 + (i - 2) * 46;
    ctx.save();
    ctx.translate(x, 306);
    ctx.rotate(Math.PI / 4);
    ctx.fillRect(-5, -5, 10, 10);
    ctx.restore();
  }

  ctx.fillStyle = "#23231d";
  caps(30, 12);
  ctx.fillText("LONDON DRY GIN", W / 2, 386);

  caps(19, 6, 500);
  ctx.fillStyle = "#4b4a40";
  ctx.fillText("JUNIPER · CORIANDER · ANGELICA", W / 2, 452);
  ctx.fillText("ORRIS · LEMON PEEL", W / 2, 484);

  ctx.strokeStyle = "#7a3f1c";
  ctx.beginPath();
  ctx.moveTo(150, 540);
  ctx.lineTo(W - 150, 540);
  ctx.stroke();

  ctx.font = `italic 400 30px ${display}`;
  try { ctx.letterSpacing = "0px"; } catch (e) {}
  ctx.fillStyle = "#33322b";
  ctx.fillText("Distilled once, in copper.", W / 2, 600);

  caps(22, 7);
  ctx.fillStyle = "#23231d";
  ctx.fillText("43.1% VOL — 70 CL", W / 2, 682);

  caps(18, 6, 500);
  ctx.fillStyle = "#7a3f1c";
  ctx.fillText("BATCH Nº 03 — BOTTLE 217 / 400", W / 2, 764);
}
