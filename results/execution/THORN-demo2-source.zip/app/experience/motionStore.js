// Tiny shared store for the motion preference.
// Initial value follows prefers-reduced-motion; the header toggle overrides it
// (persisted); OS-level changes keep being honoured unless the user overrode.
const KEY = "thornmere-motion";

const store = {
  state: "full", // "full" | "reduced"
  overridden: false,
  locked: false,
  listeners: new Set(),
  initialized: false,
};

function apply(next) {
  if (next === store.state) return;
  store.state = next;
  if (typeof document !== "undefined") {
    document.documentElement.dataset.motion = next;
  }
  store.listeners.forEach((fn) => fn(next));
}

export function initMotionStore() {
  if (store.initialized || typeof window === "undefined") return store.state;
  store.initialized = true;
  let saved = null;
  try {
    saved = window.localStorage.getItem(KEY);
  } catch (e) {
    /* storage unavailable — follow the media query */
  }
  const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (saved === "full" || saved === "reduced") {
    store.overridden = true;
    apply(saved);
  } else {
    apply(mq.matches ? "reduced" : "full");
  }
  mq.addEventListener("change", (e) => {
    if (!store.overridden) apply(e.matches ? "reduced" : "full");
  });
  return store.state;
}

export function getMotion() {
  return store.state;
}

export function setMotion(next) {
  if (store.locked) return;
  store.overridden = true;
  try {
    window.localStorage.setItem(KEY, next);
  } catch (e) {
    /* fine */
  }
  apply(next);
}

// WebGL unavailable: the folio IS the page. Not persisted; toggle disabled.
export function lockReduced() {
  store.overridden = true;
  store.locked = true;
  apply("reduced");
}

export function isMotionLocked() {
  return store.locked;
}

export function subscribeMotion(fn) {
  store.listeners.add(fn);
  return () => store.listeners.delete(fn);
}
