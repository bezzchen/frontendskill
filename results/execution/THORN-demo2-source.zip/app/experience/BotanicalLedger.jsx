"use client";

import { useEffect, useState } from "react";
import { BOTANICALS } from "./botanicals";
import { setHover, subscribeBus, getBus, scrollToProgress } from "./bus";
import { pForBeat } from "./timeline";
import { initMotionStore, getMotion, subscribeMotion } from "./motionStore";

export default function BotanicalLedger() {
  const [active, setActive] = useState(-1);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    setReduced(initMotionStore() === "reduced");
    const un1 = subscribeMotion((m) => setReduced(m === "reduced"));
    const un2 = subscribeBus((s) => setActive(s.hover > -1 ? s.hover : s.beat));
    const b = getBus();
    setActive(b.hover > -1 ? b.hover : b.beat);
    return () => { un1(); un2(); };
  }, []);

  const shown = active > -1 ? active : 0;

  return (
    <>
      <ol className="botanical-list">
        {BOTANICALS.map((b, i) => {
          const inner = (
            <>
              <span className="num" aria-hidden="true">{String(i + 1).padStart(2, "0")}</span>
              <span className="name">
                {b.name}
                <i className="latin">{b.latin}</i>
              </span>
            </>
          );
          return (
            <li key={b.id}>
              {reduced ? (
                <div className="botanical-row is-active">
                  {inner}
                  <span className="note">{b.note}</span>
                </div>
              ) : (
                <button
                  type="button"
                  className={`botanical-row${active === i ? " is-active" : ""}`}
                  onMouseEnter={() => setHover(i)}
                  onMouseLeave={() => setHover(-1)}
                  onFocus={() => setHover(i)}
                  onBlur={() => setHover(-1)}
                  onClick={() => scrollToProgress(pForBeat(i))}
                  aria-label={`${b.name} — take the camera to its plate`}
                >
                  {inner}
                  {/* hidden in full motion (the caption slot reads it);
                      surfaced by the no-JS folio styles */}
                  <span className="note">{b.note}</span>
                </button>
              )}
            </li>
          );
        })}
      </ol>
      {/* one fixed slot for the active botanical's note: the panel never
          pumps its height, and the note reads as a stable caption */}
      {!reduced && (
        <p className="ledger-caption" aria-live="polite">
          <span key={shown} className="ledger-caption-text">
            {BOTANICALS[shown].note}
          </span>
        </p>
      )}
    </>
  );
}
