"use client";

import { useState } from "react";

export default function LedgerForm() {
  const [note, setNote] = useState("");

  return (
    <form
      className="ledger-form"
      onSubmit={(e) => {
        e.preventDefault();
        setNote("Noted. (Thornmere is a demo — nothing was sent anywhere.)");
      }}
      aria-describedby="ledger-note"
    >
      <label className="sr-only" htmlFor="ledger-email">
        Email address
      </label>
      <input
        id="ledger-email"
        className="ledger-input"
        type="email"
        name="email"
        autoComplete="off"
        placeholder="you@example.com"
        required
      />
      <button className="btn" type="submit">
        Join the ledger
      </button>
      <p id="ledger-note" className="ledger-note" role="status">
        {note || "First word of each batch. Nothing else, ever."}
      </p>
    </form>
  );
}
