import "./globals.css";
import { Fraunces, Archivo } from "next/font/google";

const fraunces = Fraunces({
  subsets: ["latin"],
  axes: ["opsz", "SOFT", "WONK"],
  style: ["normal", "italic"],
  variable: "--font-display",
  display: "swap",
});

const archivo = Archivo({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata = {
  title: "Thornmere — London Dry Gin",
  description:
    "A small-batch London dry gin: five botanicals, one copper still, four hundred numbered bottles a batch. Scroll the run — from plate to vapour to glass.",
};

export const viewport = {
  themeColor: "#070b08",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en-GB" className={`${fraunces.variable} ${archivo.variable}`} data-motion="full">
      <head>
        <noscript>
          {/* Without JS the page reads as the static folio: no 900vh stage, plates shown inline. */}
          <style>{`
            .stage-wrap { height: auto !important; }
            .stage-sticky { position: relative !important; height: 60svh !important; }
            .act { position: static !important; height: auto !important; }
            .act-pin { position: static !important; height: auto !important; padding-block: 3rem !important; }
            .act-copy { opacity: 1 !important; transform: none !important; pointer-events: auto !important; }
            .arrival-copy { opacity: 1 !important; }
            .botanical-row .note { display: block !important; grid-column: 2; }
            .folio-plates { display: grid !important; }
            .loader { display: none !important; }
            .scroll-cue { display: none !important; }
            .act-rail { display: none !important; }
            .arrival-copy { background: none !important; }
            .arrival-title, .arrival-sub, .imprint { animation: none !important; opacity: 1 !important; }
          `}</style>
        </noscript>
      </head>
      <body>{children}</body>
    </html>
  );
}
