import Link from "next/link";

export const metadata = {
  title: "Colophon - Jordan Lee",
  description: "How the experience constellation is built.",
};

export default function Colophon() {
  return (
    <main className="mx-auto max-w-2xl space-y-8 px-6 py-16">
      <header className="space-y-3">
        <p className="text-sm uppercase tracking-[0.2em] text-[var(--muted)]">Colophon</p>
        <h1 className="text-4xl font-semibold tracking-tight">
          How the constellation is built
        </h1>
      </header>

      <div className="space-y-4 leading-7 text-[var(--muted)]">
        <p>
          The experience constellation draws 500 marks with{" "}
          <strong className="text-[var(--foreground)]">PixiJS 8</strong> inside
          a single bounded canvas; the rest of this site is ordinary
          server-rendered React. Every badge lives on one texture atlas, so the
          whole field renders as a single batched draw call.
        </p>
        <p>
          The simulation pauses when the section scrolls out of view or the
          tab is hidden. With reduced motion enabled it stops entirely and
          renders single frames on demand, keeping filtering, regrouping, and
          selection fully usable. Touch devices get a lighter profile: fewer
          marks, a capped pixel ratio, and a 30fps ceiling.
        </p>
        <p>
          Every mark on the canvas is also a plain button in the browse list,
          so keyboard and screen-reader users work with the same data through
          real DOM.
        </p>
      </div>

      <p>
        <Link className="underline underline-offset-4" href="/">
          Back to the portfolio
        </Link>
      </p>
    </main>
  );
}
