// PixiJS engine for the experience constellation.
//
// Ownership: this module owns the canvas, the only render loop, and all GPU
// resources. React (ExperienceConstellation.jsx) owns every piece of DOM and
// calls the handle's setters; the engine reports back through callbacks.
//
// Architecture notes (verified against the installed pixi.js@8.19.0 source):
// - One texture atlas (a single CanvasSource) backs every node sprite, so the
//   whole field batches into a single draw call; the two highlight rings are
//   a second (Graphics) batch.
// - Pixi's EventSystem is disabled (`eventFeatures` all false) and detached
//   via `setTargetElement(null)`, which removes EventsTicker from
//   `Ticker.system`; with zero listeners that ticker cancels its rAF
//   (Ticker.remove -> _cancelIfNeeded). Interaction is three DOM listeners
//   owned here, with manual nearest-node picking - no 500 interactive
//   display objects.
// - The app ticker is private (sharedTicker defaults to false) and is the
//   only loop. It stops when the section leaves the viewport
//   (IntersectionObserver), when the document is hidden (visibilitychange),
//   and under reduced motion, where the scene renders once per state change
//   instead ("render on demand").

const TAU = Math.PI * 2;
const GOLDEN = Math.PI * (3 - Math.sqrt(5));

function hashUnit(seed, salt) {
  const x = Math.sin(seed * 127.1 + salt * 311.7) * 43758.5453;
  return x - Math.floor(x);
}

export function createConstellationEngine(host, opts) {
  const {
    items,
    categories,
    mobile,
    onHover,
    onSelect,
    onClusters,
  } = opts;

  // ---- profile: lower-cost mobile/touch mode ------------------------------
  const profile = mobile
    ? {
        // Balanced half: alternating groups of four keep all categories
        // (the dataset cycles categories by index, so plain i % 2 would
        // drop two categories entirely).
        items: items.filter((_, i) => i % 8 < 4),
        dprCap: 1.5,
        maxFPS: 30,
        proximity: false, // no hover displacement on touch
        antialias: false,
        driftAmp: 2.5,
        sizeMin: 15,
        sizeMax: 23,
      }
    : {
        items,
        dprCap: 2,
        maxFPS: 0, // uncapped -> display refresh
        proximity: true,
        antialias: true,
        driftAmp: 4.5,
        sizeMin: 17,
        sizeMax: 28,
      };

  const catIndex = Object.fromEntries(categories.map((c, i) => [c.id, i]));

  const state = {
    destroyed: false,
    app: null,
    PIXI: null,
    nodes: [],
    ring: null,
    hoverRing: null,
    atlasSource: null,
    mode: "field", // 'field' | 'category'
    filter: null, // category id or null
    selectedId: null,
    hoverId: null,
    reducedMotion: !!opts.reducedMotion,
    pointer: { x: 0, y: 0, active: false },
    inView: true,
    docVisible: typeof document === "undefined" ? true : !document.hidden,
    dirty: false,
    time: 0,
    frames: 0,
    lastPauseReason: null,
    width: 0,
    height: 0,
    io: null,
    ro: null,
    removeDom: null,
  };

  // ---- texture atlas ------------------------------------------------------
  // One 2D canvas holds every "logo" badge; every sprite's Texture is a
  // sub-frame of the same TextureSource, so the sprite batcher emits one
  // draw call for the whole field.
  function buildAtlas(PIXI) {
    const cell = 80;
    const cols = Math.ceil(Math.sqrt(profile.items.length));
    const rows = Math.ceil(profile.items.length / cols);
    const canvas = document.createElement("canvas");
    canvas.width = cols * cell;
    canvas.height = rows * cell;
    const ctx = canvas.getContext("2d");

    profile.items.forEach((item, i) => {
      const cx = (i % cols) * cell;
      const cy = Math.floor(i / cols) * cell;
      const cat = categories[catIndex[item.category]];
      const h1 = hashUnit(item.seed, 1);
      const pad = 6;
      const size = cell - pad * 2;
      const r = 18;

      ctx.save();
      ctx.translate(cx + pad, cy + pad);

      // Badge: two-tone vertical gradient in the category hue.
      const g = ctx.createLinearGradient(0, 0, 0, size);
      g.addColorStop(0, shade(cat.color, 0.12 + h1 * 0.1));
      g.addColorStop(1, shade(cat.color, -0.28 + h1 * 0.08));
      roundRect(ctx, 0, 0, size, size, r);
      ctx.fillStyle = g;
      ctx.fill();

      // Motif variety behind the monogram.
      ctx.globalAlpha = 0.22;
      ctx.strokeStyle = "#ffffff";
      ctx.fillStyle = "#ffffff";
      ctx.lineWidth = 5;
      const motif = Math.floor(hashUnit(item.seed, 2) * 4);
      if (motif === 0) {
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size * 0.34, 0, TAU);
        ctx.stroke();
      } else if (motif === 1) {
        ctx.beginPath();
        ctx.moveTo(size * 0.16, size * 0.84);
        ctx.lineTo(size * 0.84, size * 0.16);
        ctx.stroke();
      } else if (motif === 2) {
        ctx.beginPath();
        ctx.arc(size * 0.72, size * 0.3, size * 0.16, 0, TAU);
        ctx.fill();
      } // motif 3: plain
      ctx.globalAlpha = 1;

      // Monogram.
      ctx.fillStyle = "rgba(255,255,255,0.94)";
      ctx.font = `700 ${Math.round(size * 0.42)}px system-ui, -apple-system, 'Segoe UI', sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(item.monogram, size / 2, size / 2 + 1);
      ctx.restore();
    });

    const source = new PIXI.CanvasSource({ resource: canvas });
    const textures = profile.items.map(
      (_, i) =>
        new PIXI.Texture({
          source,
          frame: new PIXI.Rectangle(
            (i % cols) * cell,
            Math.floor(i / cols) * cell,
            cell,
            cell
          ),
        })
    );
    return { source, textures };
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function shade(hex, amount) {
    const n = parseInt(hex.slice(1), 16);
    const ch = (v) =>
      Math.max(0, Math.min(255, Math.round(v + amount * 255)))
        .toString(16)
        .padStart(2, "0");
    return `#${ch(n >> 16)}${ch((n >> 8) & 255)}${ch(n & 255)}`;
  }

  // ---- layouts ------------------------------------------------------------
  function layoutField() {
    const { width: w, height: h } = state;
    const padX = 44;
    const padY = 40;
    const n = state.nodes.length;
    for (let i = 0; i < n; i++) {
      const node = state.nodes[i];
      const t = (i + 0.5) / n;
      const rr = Math.sqrt(t);
      const th = i * GOLDEN;
      const jx = (hashUnit(node.item.seed, 3) - 0.5) * 26;
      const jy = (hashUnit(node.item.seed, 4) - 0.5) * 26;
      node.lx = w / 2 + Math.cos(th) * rr * (w / 2 - padX) + jx;
      node.ly = h / 2 + Math.sin(th) * rr * (h / 2 - padY) + jy;
    }
    return null; // no cluster labels in field mode
  }

  function layoutCategory() {
    const { width: w, height: h } = state;
    const twoByTwo = w < 700;
    const colCount = twoByTwo ? 2 : 4;
    const spacing = twoByTwo
      ? Math.min(w / 2, h / 2) / 16
      : Math.min(w / 4, h) / 12.5;
    const totals = {};
    for (const node of state.nodes) {
      totals[node.item.category] = (totals[node.item.category] ?? 0) + 1;
    }
    const centers = categories.map((c, i) => {
      const y = twoByTwo ? (Math.floor(i / colCount) + 0.5) / 2 : 0.54;
      const rMax = spacing * Math.sqrt((totals[c.id] ?? 1) + 0.6);
      return {
        id: c.id,
        label: c.label,
        x: ((i % colCount) + 0.5) / colCount,
        y,
        labelY: Math.max(0.06, y - (rMax * (twoByTwo ? 1 : 0.86) + 24) / h),
      };
    });
    const counts = {};
    for (const node of state.nodes) {
      const k = (counts[node.item.category] =
        (counts[node.item.category] ?? 0) + 1) - 1;
      const c = centers[catIndex[node.item.category]];
      const rr = spacing * Math.sqrt(k + 0.6);
      const th = k * GOLDEN + catIndex[node.item.category] * 1.7;
      node.lx = c.x * w + Math.cos(th) * rr;
      node.ly = c.y * h + Math.sin(th) * rr * (twoByTwo ? 1 : 0.86);
    }
    return centers;
  }

  function relayout() {
    if (!state.width || !state.height) return;
    const centers = state.mode === "category" ? layoutCategory() : layoutField();
    onClusters?.(centers);
  }

  // ---- per-frame simulation ----------------------------------------------
  function targetsFor(node) {
    const filtered = state.filter && node.item.category !== state.filter;
    const selected = node.item.id === state.selectedId;
    const hovered = node.item.id === state.hoverId;
    // Dimmed nodes get a dark tint as well as low alpha: the tint caps the
    // brightness that stacked translucent sprites can re-accumulate in
    // dense cluster cores (measured ~0.5x without it).
    let alpha = filtered ? 0.22 : 1;
    let scale = filtered ? 0.7 : 1;
    let tint = filtered ? 0x565c6b : 0xffffff;
    if (hovered && !filtered) scale *= 1.3;
    if (selected) {
      scale *= 1.25;
      alpha = 1;
      tint = 0xffffff;
    }
    return { alpha, scale, tint };
  }

  function tick(ticker) {
    const dt = Math.min(ticker.deltaMS, 50) / 1000;
    state.time += dt;
    state.frames++;

    const ease = 1 - Math.exp(-6 * dt);
    const easeFast = 1 - Math.exp(-10 * dt);
    const { pointer } = state;
    const proxR = 120;
    const drift = state.reducedMotion ? 0 : profile.driftAmp;

    // Hover pick once per frame, not per pointermove event.
    if (profile.proximity && pointer.active) pickHover(pointer.x, pointer.y);

    for (const node of state.nodes) {
      const s1 = node.item.seed * 977;
      let dx =
        drift *
        Math.sin(state.time * node.w1 + s1) *
        (0.6 + hashUnit(node.item.seed, 5));
      let dy = drift * Math.cos(state.time * node.w2 + s1 * 1.7);

      if (profile.proximity && pointer.active && !state.reducedMotion) {
        const px = node.x - pointer.x;
        const py = node.y - pointer.y;
        if (Math.abs(px) < proxR && Math.abs(py) < proxR) {
          const d = Math.hypot(px, py);
          if (d < proxR && d > 0.001) {
            const f = (1 - d / proxR) ** 2 * 30;
            dx += (px / d) * f;
            dy += (py / d) * f;
          }
        }
      }

      node.x += (node.lx + dx - node.x) * ease;
      node.y += (node.ly + dy - node.y) * ease;

      const t = targetsFor(node);
      node.alpha += (t.alpha - node.alpha) * easeFast;
      node.scaleMul += (t.scale - node.scaleMul) * easeFast;

      node.sprite.position.set(node.x, node.y);
      node.sprite.alpha = node.alpha;
      node.sprite.tint = t.tint;
      const px2 = node.size * node.scaleMul;
      node.sprite.width = px2;
      node.sprite.height = px2;
    }
    syncRings();
  }

  // Reduced-motion path: place everything at its target and render one frame.
  function settle() {
    for (const node of state.nodes) {
      node.x = node.lx;
      node.y = node.ly;
      const t = targetsFor(node);
      node.alpha = t.alpha;
      node.scaleMul = t.scale;
      node.sprite.position.set(node.x, node.y);
      node.sprite.alpha = node.alpha;
      node.sprite.tint = t.tint;
      const px = node.size * node.scaleMul;
      node.sprite.width = px;
      node.sprite.height = px;
    }
    syncRings();
  }

  function syncRings() {
    const sel = state.nodes.find((n) => n.item.id === state.selectedId);
    const hov =
      state.hoverId != null && state.hoverId !== state.selectedId
        ? state.nodes.find((n) => n.item.id === state.hoverId)
        : null;
    updateRing(state.ring, sel, 0xffffff, 2);
    updateRing(state.hoverRing, hov, 0xffffff, 1.2);
  }

  function updateRing(ring, node, color, widthPx) {
    if (!ring) return;
    if (!node) {
      ring.visible = false;
      return;
    }
    const r = (node.size * node.scaleMul) / 2 + 5;
    ring.visible = true;
    ring.position.set(node.x, node.y);
    if (Math.abs(ring.__r - r) > 0.5) {
      ring.__r = r;
      ring.clear();
      ring.circle(0, 0, r).stroke({ color, width: widthPx, alpha: 0.9 });
    }
  }

  // ---- picking (manual; Pixi events disabled) -----------------------------
  function pickAt(x, y, radius) {
    let best = null;
    let bestD = radius * radius;
    for (const node of state.nodes) {
      const dx = node.x - x;
      const dy = node.y - y;
      const d = dx * dx + dy * dy;
      if (d < bestD) {
        bestD = d;
        best = node;
      }
    }
    return best;
  }

  function pickHover(x, y) {
    const hit = pickAt(x, y, 26);
    const id = hit ? hit.item.id : null;
    if (id !== state.hoverId) {
      state.hoverId = id;
      state.app.canvas.style.cursor = hit ? "pointer" : "default";
      onHover?.(hit ? hit.item : null);
      markDirty();
    }
  }

  // ---- run/pause management ----------------------------------------------
  function shouldRun() {
    return (
      !state.destroyed &&
      !!state.app &&
      state.inView &&
      state.docVisible &&
      !state.reducedMotion
    );
  }

  function syncRunning() {
    if (!state.app) return;
    const run = shouldRun();
    const ticker = state.app.ticker;
    // Pixi's SchedulerSystem keeps a listener on Ticker.system by default
    // (it drives periodic GPU-resource GC). Pause that library ticker in
    // lockstep with ours; this page is the only Pixi consumer. Ticker
    // autoStart semantics revive it for any future listener, and
    // app.destroy() removes the scheduler listener entirely.
    const system = state.PIXI?.Ticker.system;
    if (run) {
      state.lastPauseReason = null;
      if (system && !system.started) system.start();
      if (!ticker.started) ticker.start();
    } else {
      state.lastPauseReason = state.destroyed
        ? "destroyed"
        : !state.inView
          ? "offscreen"
          : !state.docVisible
            ? "document-hidden"
            : "reduced-motion";
      if (ticker.started) ticker.stop();
      if (system?.started) system.stop();
      if (state.dirty) flushDirty();
    }
  }

  function markDirty() {
    if (shouldRun()) return; // the loop will paint it
    state.dirty = true;
    flushDirty();
  }

  function flushDirty() {
    // Never render while offscreen or hidden; the flag is flushed on return.
    if (!state.app || !state.inView || !state.docVisible) return;
    state.dirty = false;
    if (state.reducedMotion) settle();
    state.onDemandRenders = (state.onDemandRenders ?? 0) + 1;
    state.app.render();
  }

  // ---- init ---------------------------------------------------------------
  async function init() {
    const PIXI = await import("pixi.js");
    if (state.destroyed) return;
    state.PIXI = PIXI;

    const rect = host.getBoundingClientRect();
    state.width = Math.max(320, rect.width);
    state.height = Math.max(280, rect.height);

    const app = new PIXI.Application();
    const dpr = Math.min(
      profile.dprCap,
      (typeof window !== "undefined" && window.devicePixelRatio) || 1
    );
    await app.init({
      width: state.width,
      height: state.height,
      backgroundAlpha: 0,
      antialias: profile.antialias,
      resolution: dpr,
      autoDensity: true,
      preference: "webgl",
      autoStart: false,
      eventFeatures: { move: false, globalMove: false, click: false, wheel: false },
    });
    if (state.destroyed) {
      // Unmounted while awaiting init (e.g. React strict-mode dev remount).
      app.destroy({ removeView: true }, { children: true, texture: true, textureSource: true });
      return;
    }
    state.app = app;

    // Fully detach Pixi's event system: removes its DOM listeners and takes
    // EventsTicker off Ticker.system, whose rAF then cancels (verified in
    // pixi 8.19.0: Ticker.remove -> _cancelIfNeeded when the queue empties).
    app.renderer.events.setTargetElement(null);
    if (profile.maxFPS > 0) app.ticker.maxFPS = profile.maxFPS;

    // Scene ---------------------------------------------------------------
    const { source, textures } = buildAtlas(PIXI);
    state.atlasSource = source;
    const field = new PIXI.Container();
    app.stage.addChild(field);

    state.nodes = profile.items.map((item, i) => {
      const sprite = new PIXI.Sprite(textures[i]);
      sprite.anchor.set(0.5);
      const size =
        profile.sizeMin +
        hashUnit(item.seed, 6) * (profile.sizeMax - profile.sizeMin);
      sprite.width = size;
      sprite.height = size;
      field.addChild(sprite);
      return {
        item,
        sprite,
        size,
        x: state.width / 2,
        y: state.height / 2,
        lx: state.width / 2,
        ly: state.height / 2,
        alpha: 0,
        scaleMul: 1,
        w1: 0.25 + hashUnit(item.seed, 7) * 0.3,
        w2: 0.2 + hashUnit(item.seed, 8) * 0.3,
      };
    });

    state.hoverRing = new PIXI.Graphics();
    state.hoverRing.__r = -1;
    state.ring = new PIXI.Graphics();
    state.ring.__r = -1;
    app.stage.addChild(state.hoverRing, state.ring);

    host.appendChild(app.canvas);
    app.canvas.setAttribute("aria-hidden", "true");
    relayout();
    if (state.reducedMotion) settle();
    app.ticker.add(tick);

    // Interaction: three DOM listeners, engine-owned ------------------------
    const canvas = app.canvas;
    const onMove = (e) => {
      state.pointer.x = e.offsetX;
      state.pointer.y = e.offsetY;
      state.pointer.active = e.pointerType !== "touch";
      // While the loop is paused (reduced motion), pick per event instead.
      if (state.pointer.active && !shouldRun()) {
        pickHover(e.offsetX, e.offsetY);
      }
    };
    const onLeave = () => {
      state.pointer.active = false;
      if (state.hoverId != null) {
        state.hoverId = null;
        canvas.style.cursor = "default";
        onHover?.(null);
        markDirty();
      }
    };
    const onClick = (e) => {
      const hit = pickAt(e.offsetX, e.offsetY, mobile ? 30 : 22);
      setSelected(hit ? hit.item.id : null, true);
    };
    canvas.addEventListener("pointermove", onMove, { passive: true });
    canvas.addEventListener("pointerleave", onLeave, { passive: true });
    canvas.addEventListener("click", onClick);
    state.removeDom = () => {
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("click", onClick);
    };

    // Pause when offscreen / hidden ----------------------------------------
    state.io = new IntersectionObserver(
      (entries) => {
        state.inView = entries[0]?.isIntersecting ?? true;
        syncRunning();
      },
      { rootMargin: "48px", threshold: 0 }
    );
    state.io.observe(host);

    document.addEventListener("visibilitychange", onVisibility);

    state.ro = new ResizeObserver((entries) => {
      const box = entries[0]?.contentRect;
      if (!box || box.width < 10 || box.height < 10 || !state.app) return;
      if (
        Math.abs(box.width - state.width) < 1 &&
        Math.abs(box.height - state.height) < 1
      )
        return;
      state.width = box.width;
      state.height = box.height;
      state.app.renderer.resize(box.width, box.height);
      relayout();
      markDirty();
    });
    state.ro.observe(host);

    // Debug/verification hook (tiny, removed on destroy).
    if (typeof window !== "undefined") {
      window.__constellationDebug = {
        get frames() { return state.frames; },
        get onDemandRenders() { return state.onDemandRenders ?? 0; },
        get dirty() { return state.dirty; },
        get running() { return !!state.app?.ticker.started; },
        get inView() { return state.inView; },
        get docVisible() { return state.docVisible; },
        get reducedMotion() { return state.reducedMotion; },
        get lastPauseReason() { return state.lastPauseReason; },
        get nodeCount() { return state.nodes.length; },
        get mobileProfile() { return !!mobile; },
        get systemTickerListeners() { return PIXI.Ticker.system.count; },
        get systemTickerStarted() { return PIXI.Ticker.system.started; },
        get sharedTickerStarted() { return PIXI.Ticker.shared.started; },
        get renderer() { return state.app?.renderer.name; },
        // Times the real per-frame path (sim tick + Pixi render) on the CPU.
        // Timestamps continue from the ticker's own clock so repeated calls
        // stay monotonic (earlier calls leave lastTime in the future).
        benchmark(n = 120) {
          if (!state.app) return null;
          const ticker = state.app.ticker;
          const base = Math.max(performance.now(), ticker.lastTime);
          const t0 = performance.now();
          for (let i = 0; i < n; i++) {
            ticker.update(base + (i + 1) * (1000 / 60));
          }
          return (performance.now() - t0) / n;
        },
      };
    }

    syncRunning();
    markDirty(); // paint the first frame even when starting paused
  }

  function onVisibility() {
    state.docVisible = !document.hidden;
    syncRunning();
  }

  // ---- handle -------------------------------------------------------------
  function setMode(mode) {
    if (mode === state.mode) return;
    state.mode = mode;
    relayout();
    markDirty();
  }

  function setFilter(filter) {
    if (filter === state.filter) return;
    state.filter = filter;
    markDirty();
  }

  function setSelected(id, fromCanvas = false) {
    if (id === state.selectedId) return;
    state.selectedId = id;
    const node = state.nodes.find((n) => n.item.id === id);
    onSelect?.(node ? node.item : null, { fromCanvas });
    markDirty();
  }

  function setReducedMotion(reduced) {
    if (reduced === state.reducedMotion) return;
    state.reducedMotion = reduced;
    syncRunning();
    markDirty();
  }

  function destroy() {
    if (state.destroyed) return;
    state.destroyed = true;
    state.io?.disconnect();
    state.ro?.disconnect();
    document.removeEventListener("visibilitychange", onVisibility);
    state.removeDom?.();
    if (typeof window !== "undefined" && window.__constellationDebug) {
      delete window.__constellationDebug;
    }
    if (state.app) {
      state.app.ticker.remove(tick);
      // Removes the canvas, destroys the stage tree, all node textures and
      // the shared atlas TextureSource, and releases the GL context.
      state.app.destroy(
        { removeView: true },
        { children: true, texture: true, textureSource: true }
      );
      state.app = null;
    }
    state.nodes = [];
    state.atlasSource = null;
  }

  init();

  return {
    setMode,
    setFilter,
    setSelected,
    setReducedMotion,
    destroy,
    nodesDrawn: profile.items.length,
  };
}
