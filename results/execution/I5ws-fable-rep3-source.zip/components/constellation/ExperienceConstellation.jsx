"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  constellationItems,
  constellationCategories,
  categoryById,
} from "@/components/ConstellationData";
import { createConstellationEngine } from "@/components/constellation/engine";

// React owns every piece of DOM here (controls, status, list); the Pixi
// engine owns the canvas and the render loop. Selection state round-trips
// through the engine so canvas clicks and list buttons stay in sync.
export function ExperienceConstellation() {
  const hostRef = useRef(null);
  const engineRef = useRef(null);

  const [mode, setMode] = useState("field");
  const [filter, setFilter] = useState(null);
  const [selected, setSelected] = useState(null);
  const [hovered, setHovered] = useState(null);
  const [clusters, setClusters] = useState(null);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [canvasNodes, setCanvasNodes] = useState(constellationItems.length);

  const counts = useMemo(() => {
    const c = {};
    for (const item of constellationItems) {
      c[item.category] = (c[item.category] ?? 0) + 1;
    }
    return c;
  }, []);

  const grouped = useMemo(
    () =>
      constellationCategories.map((cat) => ({
        cat,
        items: constellationItems.filter((i) => i.category === cat.id),
      })),
    []
  );

  // Mount the engine once. Guarded for strict-mode double-invoke: destroy()
  // is safe before, during, and after the engine's async init.
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;

    // A zero innerWidth means the tab has no layout yet (background or
    // prerendered load) - only a real, positive narrow width counts as mobile.
    const coarse =
      window.matchMedia("(pointer: coarse)").matches ||
      (window.innerWidth > 0 && window.innerWidth < 768);
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduceMotion(media.matches);

    const engine = createConstellationEngine(host, {
      items: constellationItems,
      categories: constellationCategories,
      mobile: coarse,
      reducedMotion: media.matches,
      onHover: setHovered,
      onSelect: (item) => setSelected(item),
      onClusters: setClusters,
    });
    engineRef.current = engine;
    setCanvasNodes(engine.nodesDrawn);

    // Follow OS-level changes live; the user toggle below writes the same state.
    const onMedia = (e) => setReduceMotion(e.matches);
    media.addEventListener("change", onMedia);

    return () => {
      media.removeEventListener("change", onMedia);
      engineRef.current = null;
      engine.destroy();
    };
  }, []);

  useEffect(() => { engineRef.current?.setMode(mode); }, [mode]);
  useEffect(() => { engineRef.current?.setFilter(filter); }, [filter]);
  useEffect(() => { engineRef.current?.setReducedMotion(reduceMotion); }, [reduceMotion]);

  const select = (id) => engineRef.current?.setSelected(id);

  const filterLabel = filter ? categoryById[filter].label : "all disciplines";
  const canvasLabel =
    `Constellation map of ${constellationItems.length} engagements` +
    (mode === "category" ? ", grouped by discipline" : "") +
    `, showing ${filterLabel}. The same items are available in the browse list below.`;

  return (
    <section aria-labelledby="constellation-title" className="space-y-6">
      <div className="max-w-3xl space-y-3">
        <h2 id="constellation-title" className="text-3xl font-semibold">
          Experience constellation
        </h2>
        <p className="text-[var(--muted)]">
          {`Ten years of tools, collaborations, and engagements — ${constellationItems.length} in total — drawn as one field. Hover to stir it, click a mark to inspect it, or regroup everything by discipline.`}
        </p>
      </div>

      {/* Control surface: plain buttons, mirrored onto the canvas engine. */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
        <div role="group" aria-label="Layout" className="flex overflow-hidden rounded-lg border border-[var(--line)]">
          {[
            ["field", "Constellation"],
            ["category", "By discipline"],
          ].map(([value, label]) => (
            <button
              key={value}
              type="button"
              aria-pressed={mode === value}
              onClick={() => setMode(value)}
              className={`px-3 py-1.5 text-sm ${
                mode === value
                  ? "bg-[var(--foreground)] text-[var(--background)]"
                  : "bg-[var(--surface)] text-[var(--muted)]"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div role="group" aria-label="Filter by discipline" className="flex flex-wrap gap-2">
          <button
            type="button"
            aria-pressed={filter === null}
            onClick={() => setFilter(null)}
            className={`rounded-full border px-3 py-1 text-sm ${
              filter === null
                ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                : "border-[var(--line)] bg-[var(--surface)] text-[var(--muted)]"
            }`}
          >
            All {constellationItems.length}
          </button>
          {constellationCategories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              aria-pressed={filter === cat.id}
              onClick={() => setFilter(filter === cat.id ? null : cat.id)}
              className={`flex items-center gap-2 rounded-full border px-3 py-1 text-sm ${
                filter === cat.id
                  ? "border-[var(--foreground)] bg-[var(--foreground)] text-[var(--background)]"
                  : "border-[var(--line)] bg-[var(--surface)] text-[var(--muted)]"
              }`}
            >
              <span
                aria-hidden="true"
                className="h-2.5 w-2.5 rounded-full"
                style={{ backgroundColor: cat.color }}
              />
              {cat.label} {counts[cat.id]}
            </button>
          ))}
        </div>

        <label className="flex cursor-pointer items-center gap-2 text-sm text-[var(--muted)]">
          <input
            type="checkbox"
            checked={reduceMotion}
            onChange={(e) => setReduceMotion(e.target.checked)}
          />
          Reduce motion
        </label>
      </div>

      {/* The bounded spectacle. Everything inside the panel is canvas or
          decorative overlay; semantics live in the controls and the list. */}
      <div
        className="relative overflow-hidden rounded-2xl border border-[var(--line)]"
        style={{
          background:
            "radial-gradient(120% 90% at 28% -12%, #1b2334 0%, #0d1017 52%, #0a0c12 100%)",
        }}
      >
        <div
          ref={hostRef}
          role="img"
          aria-label={canvasLabel}
          className="h-[420px] w-full md:h-[560px]"
        />
        {mode === "category" &&
          clusters?.map((c) => (
            <span
              key={c.id}
              aria-hidden="true"
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/15 bg-black/45 px-3 py-1 text-xs font-medium tracking-wide text-white/85 backdrop-blur-sm"
              style={{
                left: `${c.x * 100}%`,
                top: `${(c.labelY ?? c.y) * 100}%`,
              }}
            >
              {c.label}
            </span>
          ))}
        <p className="pointer-events-none absolute bottom-3 left-4 text-xs text-white/45">
          {canvasNodes} of {constellationItems.length} marks drawn
          {canvasNodes < constellationItems.length ? " (touch profile)" : ""}
        </p>
        <p
          aria-hidden="true"
          className="pointer-events-none absolute bottom-3 right-4 text-xs text-white/45"
        >
          {hovered ? hovered.label : " "}
        </p>
      </div>

      {/* Selection status + detail card (announced politely). */}
      <div aria-live="polite" className="min-h-24">
        {selected ? (
          <div className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-[var(--line)] bg-[var(--surface)] p-4">
            <div className="flex items-start gap-3">
              <span
                aria-hidden="true"
                className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-lg text-sm font-bold text-white"
                style={{ backgroundColor: categoryById[selected.category].color }}
              >
                {selected.monogram}
              </span>
              <div>
                <h3 className="font-semibold">{selected.label}</h3>
                <p className="text-sm text-[var(--muted)]">
                  {categoryById[selected.category].label} &middot; since{" "}
                  {selected.year} &middot; {selected.engagements}{" "}
                  {selected.engagements === 1 ? "engagement" : "engagements"}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => select(null)}
              className="rounded-md border border-[var(--line)] px-3 py-1.5 text-sm text-[var(--muted)]"
            >
              Clear selection
            </button>
          </div>
        ) : (
          <p className="text-sm text-[var(--muted)]">
            Nothing selected. Click a mark on the map or pick from the list
            below.
          </p>
        )}
      </div>

      {/* Full semantic representation of the same items, outside the canvas. */}
      <details className="rounded-xl border border-[var(--line)] bg-[var(--surface)]">
        <summary className="cursor-pointer px-4 py-3 font-medium">
          Browse all {constellationItems.length} engagements as a list
        </summary>
        <div className="grid gap-6 border-t border-[var(--line)] p-4 md:grid-cols-2">
          {grouped.map(({ cat, items }) => (
            <section key={cat.id} aria-labelledby={`cat-${cat.id}`}>
              <h3 id={`cat-${cat.id}`} className="mb-2 flex items-center gap-2 font-semibold">
                <span
                  aria-hidden="true"
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: cat.color }}
                />
                {cat.label} ({items.length})
              </h3>
              <ul className="max-h-72 space-y-0.5 overflow-y-auto pr-2">
                {items.map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      aria-pressed={selected?.id === item.id}
                      onClick={() => select(item.id)}
                      className={`w-full rounded px-2 py-1 text-left text-sm ${
                        selected?.id === item.id
                          ? "bg-[var(--foreground)] text-[var(--background)]"
                          : "text-[var(--muted)] hover:bg-[var(--background)]"
                      }`}
                    >
                      {item.label}
                      <span className="opacity-60"> &middot; {item.year}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </details>

      <p className="text-sm text-[var(--muted)]">
        <Link className="underline underline-offset-4" href="/colophon">
          How this visualization is built
        </Link>
      </p>
    </section>
  );
}
