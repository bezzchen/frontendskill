// Deterministic dataset for the experience constellation.
// Everything here is seeded so server and client render identical markup.

export const constellationCategories = [
  { id: "engineering", label: "Engineering", color: "#5B9DFF", dim: "#274066" },
  { id: "research", label: "Research", color: "#4CC38A", dim: "#1F4A38" },
  { id: "design", label: "Design", color: "#F5A455", dim: "#5C4026" },
  { id: "math", label: "Math", color: "#B08DF5", dim: "#443261" },
];

const CATEGORY_IDS = constellationCategories.map((c) => c.id);

function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PRE = [
  "Nova", "Quen", "Halo", "Vera", "Osti", "Lume", "Arc", "Pell",
  "Sable", "Ryn", "Calla", "Ferro", "Iso", "Mira", "Tarn", "Eido",
  "Brill", "Corva", "Delta", "Hollow",
];

const MID = [
  "grid", "form", "fold", "line", "ware", "field", "loop", "craft",
  "scope", "cell", "frame", "graph", "wave", "byte", "point", "trace",
  "shape", "range", "stack", "gate", "mark", "path", "root", "span", "kite",
];

const SUFFIX = {
  engineering: ["Systems", "Works", "Forge", "Infra"],
  research: ["Lab", "Institute", "Observatory", "Research"],
  design: ["Studio", "Atelier", "Type", "Form Co"],
  math: ["Theory", "Group", "Prime", "Fold"],
};

export const constellationItems = Array.from({ length: 500 }, (_, index) => {
  const category = CATEGORY_IDS[index % 4];
  const rand = mulberry32((index + 1) * 2654435761);
  const pre = PRE[index % PRE.length];
  const mid = MID[Math.floor(index / PRE.length) % MID.length];
  const suffix = SUFFIX[category][Math.floor(rand() * SUFFIX[category].length)];
  return {
    id: index,
    label: `${pre}${mid} ${suffix}`,
    monogram: `${pre[0]}${mid[0].toUpperCase()}`,
    category,
    year: 2014 + Math.floor(rand() * 12),
    engagements: 1 + Math.floor(rand() * 14),
    // Stable per-item randomness reused by the canvas engine (size, drift phase, motif).
    seed: rand(),
  };
});

export const categoryById = Object.fromEntries(
  constellationCategories.map((c) => [c.id, c])
);
