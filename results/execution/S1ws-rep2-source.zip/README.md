# meridian-launch

Launch page for Meridian, a timeline-based motion editor for the web.

Built with Next.js, React, and Tailwind CSS. No other runtime dependencies: the
visual system is raw WebGL2.

## The idea

Meridian is the line the sun crosses at noon, so the page is one day on a
timeline. Scrolling moves the sun. Thousands of animation *frames* stand on a
light-table ground and cast real shadows that lengthen, swing and vanish at noon;
the sky, the paper, the panels and the headline's own shadow all derive from the
same sun function. By day the frames are ink (an animator's spacing chart); after
dusk they become light and condense into the exported CSS.

Acts (each 10 s of a 50 s master timeline, scrubbed by scroll or the bar):

1. Dawn: the field and the playhead. The pointer is a time lens.
2. Morning: keyframes. Edit the easing curve; the field re-spaces itself.
3. Noon: springs. Set stiffness, damping and mass; flick the graph.
4. Dusk: export. The values you set become CSS (`cubic-bezier`, `linear()`).
5. Night: early access. Typing sends ripples along the horizon of frames.

## Development

```bash
npm install
npm run dev
```

## Layout of the code

- `lib/timeline.js` - master timeline, sun model, easing/spring solvers, timecode.
- `lib/store.js` - one mutable model read per frame, plus a tiny React subscription.
- `components/field/` - WebGL2 renderer (`renderer.js`), GLSL (`shaders.js`),
  glyph sampling for the export act (`glyphs.js`), the canvas host with the
  pause rules and capability tiers (`FieldCanvas.jsx`), and an SVG fallback.
- `components/ui/` - curve editor, spring panel, code export, timeline bar.
- `components/acts/Acts.jsx` - the five acts' content.
- `components/Experience.jsx` - scroll to time, motion preference, DOM theming, playback.

## Motion, accessibility, performance

- `prefers-reduced-motion: reduce` selects Calm motion: nothing moves on its own,
  scroll and controls scrub a deterministic still, acts dissolve instead of flying,
  autoplay is off. The toggle in the bar overrides either way and is remembered.
- Rendering pauses when the document is hidden or the canvas leaves the viewport.
- Capability tiers (high/mid/low) scale frame count, pixel density and the night
  bloom; an adaptive step-down triggers on measured frame time. Without WebGL2 an
  SVG variant keeps the identity.
- Everything is reachable by keyboard; focusing a control in a hidden act moves the
  playhead there. `window.__meridian` exposes read-only state for verification.
