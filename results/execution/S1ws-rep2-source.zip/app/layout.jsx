import localFont from "next/font/local";
import "./globals.css";

const sans = localFont({
  src: [
    { path: "./fonts/InstrumentSans.woff2", style: "normal", weight: "400 700" },
    { path: "./fonts/InstrumentSans-Italic.woff2", style: "italic", weight: "400 700" },
  ],
  variable: "--font-sans",
  display: "swap",
  fallback: ["Helvetica Neue", "Arial", "sans-serif"],
});
const serif = localFont({
  src: [
    { path: "./fonts/InstrumentSerif.woff2", style: "normal", weight: "400" },
    { path: "./fonts/InstrumentSerif-Italic.woff2", style: "italic", weight: "400" },
  ],
  variable: "--font-serif",
  display: "swap",
  fallback: ["Iowan Old Style", "Georgia", "serif"],
});

export const metadata = {
  title: "Meridian - a timeline for motion on the web",
  description:
    "Meridian is a timeline-based motion editor for the web. Draw timing by hand, tune springs, and ship the result as plain CSS and JavaScript.",
};

export const viewport = {
  themeColor: "#e9d4c0",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${sans.variable} ${serif.variable}`}>
      <body>{children}</body>
    </html>
  );
}
