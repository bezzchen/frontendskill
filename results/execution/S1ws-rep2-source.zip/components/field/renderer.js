import { FRAME_VS, FRAME_FS, SCREEN_VS, GROUND_FS, BLUR_FS, COMPOSITE_FS } from "./shaders";

// ---- tiny mat4 -----------------------------------------------------------------
function perspective(out, fovy, aspect, near, far) {
  const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
  out.fill(0);
  out[0] = f / aspect; out[5] = f; out[10] = (far + near) * nf; out[11] = -1; out[14] = 2 * far * near * nf;
  return out;
}
function lookAt(out, eye, center, up) {
  let zx = eye[0] - center[0], zy = eye[1] - center[1], zz = eye[2] - center[2];
  let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
  let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx;
  l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  out[0] = xx; out[1] = yx; out[2] = zx; out[3] = 0;
  out[4] = xy; out[5] = yy; out[6] = zy; out[7] = 0;
  out[8] = xz; out[9] = yz; out[10] = zz; out[11] = 0;
  out[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
  out[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
  out[14] = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
  out[15] = 1;
  return out;
}
function multiply(out, a, b) {
  const o = new Float32Array(16);
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    o[j * 4 + i] = a[i] * b[j * 4] + a[4 + i] * b[j * 4 + 1] + a[8 + i] * b[j * 4 + 2] + a[12 + i] * b[j * 4 + 3];
  }
  out.set(o);
  return out;
}
function invert(out, m) {
  const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3], a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7];
  const a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11], a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15];
  const b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10, b03 = a01 * a12 - a02 * a11;
  const b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12, b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30;
  const b08 = a20 * a33 - a23 * a30, b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
  let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
  if (!det) return null;
  det = 1 / det;
  out[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det; out[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
  out[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det; out[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
  out[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det; out[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
  out[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det; out[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
  out[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det; out[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
  out[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det; out[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
  out[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det; out[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det;
  out[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det; out[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
  return out;
}
function transformPoint(m, v) {
  const x = v[0], y = v[1], z = v[2];
  const w = m[3] * x + m[7] * y + m[11] * z + m[15] || 1;
  return [
    (m[0] * x + m[4] * y + m[8] * z + m[12]) / w,
    (m[1] * x + m[5] * y + m[9] * z + m[13]) / w,
    (m[2] * x + m[6] * y + m[10] * z + m[14]) / w,
  ];
}

// ---- GL helpers -----------------------------------------------------------------
function compile(gl, type, src) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(sh);
    gl.deleteShader(sh);
    throw new Error("Shader compile failed: " + log);
  }
  return sh;
}
function program(gl, vs, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error("Program link failed: " + gl.getProgramInfoLog(p));
  const uniforms = {};
  const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) {
    const info = gl.getActiveUniform(p, i);
    const name = info.name.replace(/\[0\]$/, "");
    uniforms[name] = gl.getUniformLocation(p, info.name);
  }
  return { p, u: uniforms };
}
function floatTex(gl, w, h, internal, format, data) {
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D, 0, internal, w, h, 0, format, gl.FLOAT, data);
  return t;
}

export const GLYPH_TEX_SIZE = 256;

export class FieldRenderer {
  constructor(canvas) {
    const gl = canvas.getContext("webgl2", {
      alpha: false,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      powerPreference: "high-performance",
    });
    if (!gl) throw new Error("WebGL2 unavailable");
    this.gl = gl;
    this.canvas = canvas;
    this.frames = program(gl, FRAME_VS, FRAME_FS);
    this.ground = program(gl, SCREEN_VS, GROUND_FS);
    this.blur = program(gl, SCREEN_VS, BLUR_FS);
    this.composite = program(gl, SCREEN_VS, COMPOSITE_FS);
    this.vao = gl.createVertexArray();

    this.easeTex = floatTex(gl, 256, 1, gl.R32F, gl.RED, new Float32Array(256));
    this.springTex = floatTex(gl, 512, 1, gl.R32F, gl.RED, new Float32Array(512));
    this.glyphTex = floatTex(gl, GLYPH_TEX_SIZE, GLYPH_TEX_SIZE, gl.RGBA32F, gl.RGBA, null);
    this.glyphCount = 0;

    this.proj = new Float32Array(16);
    this.view = new Float32Array(16);
    this.viewProj = new Float32Array(16);
    this.invViewProj = new Float32Array(16);
    this.eye = [0, 1, 5];
    this.width = 1; this.height = 1; this.dpr = 1;
    this.bloom = { enabled: false, fbo: [], tex: [], w: 0, h: 0, ok: false };
    this.n = 0; this.trackN = 0;
    this.drawCalls = 0;
  }

  setTier({ n, trackN, dpr, bloom }) {
    this.n = n; this.trackN = trackN; this.dpr = dpr; this.bloom.enabled = bloom;
    this.resize(this.cssW || 1, this.cssH || 1);
  }

  resize(cssW, cssH) {
    const gl = this.gl;
    this.cssW = cssW; this.cssH = cssH;
    const w = Math.max(1, Math.round(cssW * this.dpr)), h = Math.max(1, Math.round(cssH * this.dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w; this.canvas.height = h;
    }
    this.width = w; this.height = h;
    if (this.bloom.enabled) this.ensureBloom(Math.max(1, w >> 2), Math.max(1, h >> 2));
  }

  ensureBloom(w, h) {
    const gl = this.gl, b = this.bloom;
    if (b.w === w && b.h === h && b.ok) return;
    for (const f of b.fbo) gl.deleteFramebuffer(f);
    for (const t of b.tex) gl.deleteTexture(t);
    b.fbo = []; b.tex = []; b.w = w; b.h = h; b.ok = true;
    for (let i = 0; i < 2; i++) {
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      const f = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) b.ok = false;
      b.fbo.push(f); b.tex.push(t);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  setEase(lut) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, this.easeTex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 256, 1, gl.RED, gl.FLOAT, lut);
  }
  setSpring(lut) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, this.springTex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, 512, 1, gl.RED, gl.FLOAT, lut);
  }
  setGlyphs(data, count) {
    const gl = this.gl;
    const S = GLYPH_TEX_SIZE;
    const full = new Float32Array(S * S * 4);
    full.set(data.subarray(0, Math.min(data.length, S * S * 4)));
    gl.bindTexture(gl.TEXTURE_2D, this.glyphTex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, S, S, gl.RGBA, gl.FLOAT, full);
    this.glyphCount = Math.min(count, S * S);
  }

  // cam: { eye:[x,y,z], target:[x,y,z], fov }
  setCamera(cam) {
    const aspect = this.width / this.height;
    perspective(this.proj, (cam.fov * Math.PI) / 180, aspect, 0.1, 120);
    lookAt(this.view, cam.eye, cam.target, [0, 1, 0]);
    multiply(this.viewProj, this.proj, this.view);
    invert(this.invViewProj, this.viewProj);
    this.eye = cam.eye;
  }

  // Ray from a CSS-pixel point through the camera, intersected with the ground plane y=0.
  groundHit(cssX, cssY) {
    const nx = (cssX / this.cssW) * 2 - 1, ny = 1 - (cssY / this.cssH) * 2;
    const far = transformPoint(this.invViewProj, [nx, ny, 1]);
    const e = this.eye;
    const dx = far[0] - e[0], dy = far[1] - e[1], dz = far[2] - e[2];
    if (dy >= -1e-4) return null;
    const t = -e[1] / dy;
    if (t > 60) return null;
    return [e[0] + dx * t, 0, e[2] + dz * t];
  }

  render(s) {
    // s: { T, idle, motion, blendW, sun:[x,y,z], kUp, kGlow, night, cx, playX, lens:[x,z,k],
    //      glyphRect:[x0,y0,w,h], track:[x0,len], easeHead, springHead, impulses: Float32Array(32), detail }
    const gl = this.gl;
    this.drawCalls = 0;
    gl.bindVertexArray(this.vao);
    gl.viewport(0, 0, this.width, this.height);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);

    // 1. sky + ground
    gl.disable(gl.BLEND);
    let P = this.ground;
    gl.useProgram(P.p);
    gl.uniform3fv(P.u.uEye, this.eye);
    gl.uniformMatrix4fv(P.u.uInvViewProj, false, this.invViewProj);
    gl.uniform3fv(P.u.uSun, s.sun);
    gl.uniform1f(P.u.uKUp, s.kUp);
    gl.uniform1f(P.u.uKGlow, s.kGlow);
    gl.uniform1f(P.u.uNight, s.night);
    gl.uniform1f(P.u.uPlayX, s.playX);
    gl.uniform1f(P.u.uDetail, s.detail);
    gl.uniform1f(P.u.uIdle, s.idle);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this.drawCalls++;

    // 2. shadows, 3. frames
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    P = this.frames;
    gl.useProgram(P.p);
    this.bindFrameUniforms(s);
    gl.uniform1f(P.u.uGlowPass, 0);
    if (s.sun[1] > 0.06 && s.night < 0.99) {
      gl.uniform1f(P.u.uShadowPass, 1);
      gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, this.n);
      this.drawCalls++;
    }
    gl.uniform1f(P.u.uShadowPass, 0);
    gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, this.n);
    this.drawCalls++;

    // 4. bloom at night (quarter-res glow pass, separable blur, additive composite)
    const b = this.bloom;
    if (b.enabled && b.ok && s.night > 0.02) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, b.fbo[0]);
      gl.viewport(0, 0, b.w, b.h);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.uniform1f(P.u.uGlowPass, 1);
      gl.uniform2f(P.u.uViewport, b.w, b.h);
      gl.uniform1f(P.u.uPx, this.dpr * 0.25);
      gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, this.n);
      this.drawCalls++;
      // blur H -> fbo1, blur V -> fbo0
      gl.disable(gl.BLEND);
      const B = this.blur;
      gl.useProgram(B.p);
      gl.activeTexture(gl.TEXTURE0);
      gl.uniform1i(B.u.uTex, 0);
      gl.bindFramebuffer(gl.FRAMEBUFFER, b.fbo[1]);
      gl.bindTexture(gl.TEXTURE_2D, b.tex[0]);
      gl.uniform2f(B.u.uDir, 1 / b.w, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, b.fbo[0]);
      gl.bindTexture(gl.TEXTURE_2D, b.tex[1]);
      gl.uniform2f(B.u.uDir, 0, 1 / b.h);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      this.drawCalls += 2;
      // composite
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, this.width, this.height);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);
      const C = this.composite;
      gl.useProgram(C.p);
      gl.bindTexture(gl.TEXTURE_2D, b.tex[0]);
      gl.uniform1i(C.u.uTex, 0);
      gl.uniform1f(C.u.uGain, 0.85 * s.night);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      this.drawCalls++;
    }
    gl.bindVertexArray(null);
  }

  bindFrameUniforms(s) {
    const gl = this.gl, u = this.frames.u;
    gl.uniformMatrix4fv(u.uViewProj, false, this.viewProj);
    gl.uniform2f(u.uViewport, this.width, this.height);
    gl.uniform1f(u.uP11, this.proj[5]);
    gl.uniform1f(u.uT, s.T);
    gl.uniform1f(u.uIdle, s.idle);
    gl.uniform1f(u.uMotion, s.motion);
    gl.uniform1f(u.uBlendW, s.blendW);
    gl.uniform1f(u.uNight, s.night);
    gl.uniform1f(u.uKUp, s.kUp);
    gl.uniform1f(u.uCx, s.cx);
    gl.uniform1f(u.uPlayX, s.playX);
    gl.uniform1f(u.uPx, this.dpr);
    gl.uniform3fv(u.uSun, s.sun);
    gl.uniform3fv(u.uLens, s.lens);
    gl.uniform4fv(u.uGlyphRect, s.glyphRect);
    gl.uniform1i(u.uGlyphCount, this.glyphCount);
    gl.uniform1f(u.uTrackN, this.trackN);
    gl.uniform2fv(u.uTrack, s.track);
    gl.uniform1f(u.uEaseHead, s.easeHead);
    gl.uniform1f(u.uSpringHead, s.springHead);
    gl.uniform4fv(u.uImpulse, s.impulses);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.glyphTex); gl.uniform1i(u.uGlyphTex, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.easeTex); gl.uniform1i(u.uEaseLUT, 1);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, this.springTex); gl.uniform1i(u.uSpringLUT, 2);
    gl.activeTexture(gl.TEXTURE0);
  }

  dispose() {
    const gl = this.gl;
    for (const p of [this.frames, this.ground, this.blur, this.composite]) gl.deleteProgram(p.p);
    for (const t of [this.easeTex, this.springTex, this.glyphTex, ...this.bloom.tex]) gl.deleteTexture(t);
    for (const f of this.bloom.fbo) gl.deleteFramebuffer(f);
    gl.deleteVertexArray(this.vao);
    const ext = gl.getExtension("WEBGL_lose_context");
    if (ext) ext.loseContext();
  }
}
