// Rasterizes the export code block to an offscreen canvas and samples it into
// glyph targets (adapted from the ParticleText sampling idea: fillText ->
// getImageData -> strided alpha threshold). Targets are normalized to the
// block's box so the shader can register them to the live DOM rect.
// Each target: [x, y, order, 0] with y measured downward.

export const CODE_FONT = 'ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace';

export function measureAdvance(fontPx) {
  const c = document.createElement("canvas");
  const ctx = c.getContext("2d");
  ctx.font = `${fontPx}px ${CODE_FONT}`;
  return ctx.measureText("M").width;
}

export function buildGlyphTargets({ lines, fontPx, lineHeightPx, maxCount, scale = 2 }) {
  const cols = Math.max(...lines.map((l) => l.length), 1);
  const adv = measureAdvance(fontPx);
  const wCss = Math.ceil(cols * adv);
  const hCss = Math.ceil(lines.length * lineHeightPx);
  const W = Math.max(1, Math.round(wCss * scale)), H = Math.max(1, Math.round(hCss * scale));
  const c = document.createElement("canvas");
  c.width = W; c.height = H;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.scale(scale, scale);
  ctx.fillStyle = "#fff";
  ctx.font = `${fontPx}px ${CODE_FONT}`;
  ctx.textBaseline = "alphabetic";
  const ascent = fontPx * 0.8;
  const pad = (lineHeightPx - fontPx) / 2;
  lines.forEach((line, i) => ctx.fillText(line, 0, i * lineHeightPx + pad + ascent));
  const img = ctx.getImageData(0, 0, W, H).data;
  // Choose a stride so the count lands under maxCount.
  let stride = 1;
  let count = 0;
  for (;;) {
    count = 0;
    for (let y = 0; y < H; y += stride) for (let x = 0; x < W; x += stride) if (img[(y * W + x) * 4 + 3] > 110) count++;
    if (count <= maxCount || stride > 8) break;
    stride++;
  }
  const out = new Float32Array(Math.min(count, maxCount) * 4);
  let i = 0;
  const totalChars = lines.reduce((a, l) => a + l.length, 0) || 1;
  const lineOffsets = [];
  lines.reduce((a, l) => { lineOffsets.push(a); return a + l.length; }, 0);
  for (let y = 0; y < H; y += stride) {
    for (let x = 0; x < W; x += stride) {
      if (i >= out.length) break;
      if (img[(y * W + x) * 4 + 3] > 110) {
        const cx = x / scale, cy = y / scale;
        const li = Math.min(lines.length - 1, Math.floor(cy / lineHeightPx));
        const ci = Math.min(lines[li].length, Math.floor(cx / adv));
        const order = (lineOffsets[li] + ci) / totalChars;
        // jitter inside the sample cell so stripes never read as a grid
        const jx = (Math.sin(x * 12.9898 + y * 78.233) * 0.5 + 0.5) * stride;
        const jy = (Math.sin(x * 39.346 + y * 11.135) * 0.5 + 0.5) * stride;
        out[i++] = (x + jx) / W;
        out[i++] = (y + jy) / H;
        out[i++] = order;
        out[i++] = 0;
      }
    }
  }
  // shuffle deterministically so early ids are spread over the block
  const n = i / 4;
  let seed = 1234567;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  for (let k = n - 1; k > 0; k--) {
    const j = Math.floor(rnd() * (k + 1));
    for (let q = 0; q < 4; q++) { const t = out[k * 4 + q]; out[k * 4 + q] = out[j * 4 + q]; out[j * 4 + q] = t; }
  }
  return { data: out.subarray(0, n * 4), count: n, widthCss: wCss, heightCss: hCss, advance: adv };
}
