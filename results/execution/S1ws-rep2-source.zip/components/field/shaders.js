// GLSL ES 3.00 sources. The "frame" program is stateless: every instance's
// position is a pure function of (instance id, master time T, idle time, params),
// so the field scrubs deterministically - the same promise the product makes.

export const FRAME_VS = /* glsl */ `#version 300 es
precision highp float;
precision highp int;

uniform mat4 uViewProj;
uniform vec2 uViewport;
uniform float uP11;        // projection[1][1], for pixel sizing
uniform float uT;          // master time (s)
uniform float uIdle;       // idle clock (s), frozen in calm mode
uniform float uMotion;     // 1 full, 0 calm
uniform float uBlendW;     // act blend half-width (s)
uniform float uNight;
uniform float uKUp;
uniform float uCx;         // camera x (dolly along the timeline)
uniform float uPlayX;      // playhead x
uniform float uPx;         // device pixel ratio
uniform vec3 uSun;
uniform vec3 uLens;        // ground x, ground z, strength
uniform vec4 uGlyphRect;   // ndc: x0, y0 (bottom), w, h
uniform int uGlyphCount;
uniform sampler2D uGlyphTex;   // 256x256 RGBA32F: x, y (0..1, y down), order (0..1)
uniform sampler2D uEaseLUT;    // 256x1 R32F
uniform sampler2D uSpringLUT;  // 512x1 R32F
uniform float uTrackN;
uniform vec2 uTrack;       // x0 relative to camera, length
uniform float uEaseHead;
uniform float uSpringHead;
uniform vec4 uImpulse[8];  // x, t0, strength, 0
uniform float uShadowPass;
uniform float uGlowPass;

out vec2 vLocal;
out vec4 vColor;
out vec2 vSize;
out float vSoft;

const float B1 = 10.0, B2 = 20.0, B3 = 30.0, B4 = 40.0;
const vec3 INK = vec3(0.078, 0.102, 0.180);
const vec3 SUN = vec3(1.0, 0.62, 0.18);
const vec3 GLOW = vec3(1.0, 0.86, 0.66);
const vec3 SHADOW = vec3(0.149, 0.188, 0.369);

float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }

float lut(sampler2D s, float u, float n) {
  float x = clamp(u, 0.0, 1.0) * (n - 1.0);
  float i = floor(x);
  float f = x - i;
  float a = texelFetch(s, ivec2(int(i), 0), 0).r;
  float b = texelFetch(s, ivec2(int(min(i + 1.0, n - 1.0)), 0), 0).r;
  return mix(a, b, f);
}

void main() {
  float id = float(gl_InstanceID);
  vec2 c = vec2(float(gl_VertexID & 1) * 2.0 - 1.0, float((gl_VertexID >> 1) & 1) * 2.0 - 1.0);
  vLocal = c;
  float h0 = hash11(id + 0.13), h1 = hash11(id + 7.7), h2 = hash11(id + 19.1), h3 = hash11(id + 41.3);
  float h4 = hash11(id + 77.7); // role: which frames are visible in which act
  bool isStar = h4 > 0.97;      // ~3% of frames are stars at night (shared by acts D and E)

  bool isGlyph = id < float(uGlyphCount);
  vec4 g = vec4(0.0);
  if (isGlyph) g = texelFetch(uGlyphTex, ivec2(int(mod(id, 256.0)), int(id / 256.0)), 0);

  // Act weights. Staggered per frame so acts dissolve into each other;
  // glyph frames arrive in reading order.
  float Ts = uT + (h3 - 0.5) * 2.4;
  float b3 = B3 + (isGlyph ? (g.z * 3.0 - 1.0) : 0.0);
  float s1 = smoothstep(B1 - uBlendW, B1 + uBlendW, Ts);
  float s2 = smoothstep(B2 - uBlendW, B2 + uBlendW, Ts);
  float s3 = smoothstep(b3 - uBlendW, b3 + uBlendW, Ts);
  float s4 = smoothstep(B4 - uBlendW, B4 + uBlendW, Ts);
  float wA = 1.0 - s1, wB = s1 - s2, wC = s2 - s3, wD = s3 - s4, wE = s4;

  // --- A: dawn field. Frames drift along the timeline; the pointer is a time lens.
  float spd = 0.10 + 0.22 * h3;
  float xr = mod(h0 * 18.0 + uIdle * spd * uMotion, 18.0) - 9.0;
  float zA = -6.5 + h1 * 8.5;
  float xA = uCx + xr;
  vec2 dl = vec2(xA - uLens.x, zA - uLens.y);
  float lensF = uLens.z * exp(-dot(dl, dl) * 1.1);
  xA -= lensF * 0.95;
  float hA = 0.08 + 0.36 * h2 * h2;
  float catchA = exp(-pow((xA - uPlayX) * 4.5, 2.0));
  float tintA = catchA * 0.85 + lensF * 0.5;
  float aA = 0.22 + catchA * 0.5;
  vec3 PA = vec3(xA, 0.0, zA);
  if (h4 > 0.45) { // the rest is far dust
    PA = vec3(uCx + (h0 - 0.5) * 30.0, 0.0, -9.0 + h1 * 3.0);
    hA = 0.03 + 0.06 * h2; aA = 0.05; tintA = 0.0;
  }

  // --- B: spacing chart. Frames evenly spaced in time, placed by the eased value.
  float onTrack = id < uTrackN ? 1.0 : 0.0;
  float u = (id + 0.5) / uTrackN;
  float e = lut(uEaseLUT, u, 256.0);
  vec3 PB; float hB, aB, tintB;
  if (onTrack > 0.5) {
    PB = vec3(uCx + uTrack.x + e * uTrack.y, 0.0, 0.25 + (h1 - 0.5) * 0.22);
    hB = 0.46 + (h2 - 0.5) * 0.05;
    tintB = smoothstep(0.014, 0.0, abs(u - uEaseHead));
    aB = 0.16 + tintB * 0.7;
  } else {
    PB = vec3(uCx + (h0 - 0.5) * 22.0, 0.0, -7.5 + h1 * 3.0);
    hB = 0.05 + 0.1 * h2; aB = 0.06; tintB = 0.0;
  }

  // --- C: value graph. Height is the spring response; the head sweeps time.
  float sv = lut(uSpringLUT, u, 512.0);
  vec3 PC; float hC, aC, tintC;
  if (onTrack > 0.5) {
    PC = vec3(uCx + uTrack.x + u * uTrack.y, 0.0, 0.25 + (h1 - 0.5) * 0.22);
    hC = 0.10 + clamp(sv, -0.35, 1.45) * 0.62;
    float head = smoothstep(0.016, 0.0, abs(u - uSpringHead));
    float past = 1.0 - smoothstep(uSpringHead, uSpringHead + 0.01, u);
    tintC = head;
    aC = mix(0.08, 0.26, past) + head * 0.7;
  } else {
    PC = PB; hC = hB; aC = aB; tintC = 0.0;
  }

  // --- D: the export. Glyph frames form the code block; the rest are stars.
  vec2 ndcD; float pxD, aD, tintD;
  if (isGlyph) {
    ndcD = vec2(uGlyphRect.x + g.x * uGlyphRect.z, uGlyphRect.y + (1.0 - g.y) * uGlyphRect.w);
    pxD = 2.3 * uPx; aD = 0.9; tintD = 0.12;
  } else {
    ndcD = vec2(h0 * 2.0 - 1.0, 0.12 + h1 * 0.88);
    pxD = (0.8 + 1.4 * h2) * uPx;
    float tw = 0.5 + 0.5 * sin(uIdle * (0.8 + 1.8 * h3) * uMotion + h0 * 40.0);
    aD = isStar ? (0.25 + 0.6 * tw) * uNight : 0.0;
    tintD = 0.0;
  }

  // --- E: rest. A thin horizon of frames; typing sends ripples along it. Stars stay in the sky.
  vec3 PE; float hE, aE, tintE, wE_w;
  if (isStar) {
    // handled in screen space below (same placement as act D, so the stars persist)
    PE = vec3(uCx, 0.0, -1.4); hE = 0.0; wE_w = 0.0; aE = 0.0; tintE = 0.0;
  } else if (h4 > 0.14) {
    PE = vec3(uCx + (h0 - 0.5) * 30.0, 0.0, -9.0 + h1 * 3.0);
    hE = 0.03 + 0.06 * h2; wE_w = 0.012; aE = 0.05 * (1.0 - uNight); tintE = 0.0;
  } else {
    float xE = uCx + (h0 * 26.0 - 13.0) + uIdle * 0.06 * uMotion;
    float ripple = 0.0;
    for (int i = 0; i < 8; i++) {
      vec4 im = uImpulse[i];
      float dt = uIdle - im.y;
      if (im.z > 0.0 && dt > 0.0) {
        float dx = xE - im.x;
        ripple += im.z * 0.26 * exp(-dt * 1.0) * exp(-abs(dx) * 0.55) * sin(abs(dx) * 5.0 - dt * 9.0);
      }
    }
    PE = vec3(xE, 0.0, -1.4 + (h1 - 0.5) * 0.7);
    hE = abs(0.02 + 0.05 * h3 + ripple); wE_w = 0.012;
    aE = 0.24; tintE = clamp(ripple * 3.0, 0.0, 1.0);
  }
  if (isStar) { wD += wE; wE = 0.0; }

  // --- Blend world configs, then mix with the screen-space export.
  float wW = max(wA + wB + wC + wE, 1e-4);
  vec3 P = (wA * PA + wB * PB + wC * PC + wE * PE) / wW;
  float H = (wA * hA + wB * hB + wC * hC + wE * hE) / wW;
  float W = (wA * 0.012 + wB * 0.012 + wC * 0.012 + wE * wE_w) / wW;
  float alphaW = (wA * aA + wB * aB + wC * aC + wE * aE) / wW;
  float tintW = (wA * tintA + wB * tintB + wC * tintC + wE * tintE) / wW;
  float purity = wA * wA + wB * wB + wC * wC + wD * wD + wE * wE;
  float trans = 1.0 - purity;
  P.y += uMotion * trans * (0.5 + 1.6 * h2) * step(P.y, 0.5);

  vec3 up = vec3(0.0, 1.0, 0.0);
  vec3 center = P + up * H * 0.5;

  if (uShadowPass > 0.5) {
    // Ground shadow of a frame standing at P with height H, cast by the sun.
    float sy = max(uSun.y, 0.06);
    vec3 sdir = vec3(-uSun.x, 0.0, -uSun.z) / sy;
    vec3 axis = sdir * H;
    float len = length(axis) + 1e-4;
    vec3 ad = axis / len;
    vec3 perp = normalize(cross(ad, up));
    float sw = W * 1.6 + len * 0.03;
    vec3 world = P + ad * len * (c.y * 0.5 + 0.5) + perp * sw * c.x * 0.5;
    vec4 clip = uViewProj * vec4(world, 1.0);
    gl_Position = clip;
    float shortF = clamp(1.4 / max(len, 0.2), 0.3, 1.0);
    float grounded = step(P.y, 0.5);
    float distF = clamp(7.0 / max(clip.w, 0.1), 0.0, 1.0);
    float aS = 0.2 * uKUp * shortF * grounded * (1.0 - wD) * (1.0 - uNight) * step(0.06, uSun.y) * distF;
    aS *= clamp(alphaW * 3.0, 0.0, 1.0);
    vColor = vec4(SHADOW, aS);
    vSize = vec2(8.0);
    vSoft = 1.0;
    return;
  }

  vec4 clipC = uViewProj * vec4(center, 1.0);
  float wclip = max(clipC.w, 0.05);
  vec2 ndcC = clipC.xy / wclip;
  float pxPerUnit = uP11 * uViewport.y * 0.5 / wclip;
  vec2 pxW = vec2(W, H) * pxPerUnit;
  vec2 pxWc = max(pxW, vec2(1.0));
  float cov = (pxW.x * pxW.y) / (pxWc.x * pxWc.y);
  vec2 ndcWq = ndcC + c * pxWc / uViewport * 2.0;
  vec2 pxDc = vec2(max(pxD, 1.0));
  vec2 ndcDq = ndcD + c * pxDc / uViewport * 2.0;

  vec2 ndc = mix(ndcWq, ndcDq, wD);
  vSize = mix(pxWc, pxDc, wD);
  float alpha = mix(alphaW * cov, aD, wD);
  float tint = mix(tintW, tintD, wD);
  if (clipC.w < 0.05 && wD < 0.5) alpha = 0.0;

  vec3 dayCol = mix(INK, SUN, tint);
  vec3 nightCol = mix(GLOW, SUN, tint * 0.6);
  vec3 col = mix(dayCol, nightCol, uNight);
  if (uGlowPass > 0.5) {
    // Only light contributes to bloom: night frames, plus anything sun-lit.
    float lit = max(uNight, tint);
    alpha *= lit * 0.7;
    col = mix(col, vec3(1.0, 0.9, 0.75), 0.3);
  }
  vColor = vec4(col, alpha);
  vSoft = 0.0;
  gl_Position = vec4(ndc, 0.0, 1.0);
}
`;

export const FRAME_FS = /* glsl */ `#version 300 es
precision highp float;
in vec2 vLocal;
in vec4 vColor;
in vec2 vSize;
in float vSoft;
out vec4 o;
void main() {
  vec2 aa = mix(1.4 / max(vSize, vec2(1.0)), vec2(0.62), vSoft);
  vec2 e = smoothstep(vec2(1.0), vec2(1.0) - 2.0 * aa, abs(vLocal));
  float a = vColor.a * e.x * e.y;
  o = vec4(vColor.rgb * a, a);
}
`;

export const SCREEN_VS = /* glsl */ `#version 300 es
precision highp float;
out vec2 vNdc;
out vec2 vUv;
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)) * 2.0 - 1.0;
  vNdc = p;
  vUv = p * 0.5 + 0.5;
  gl_Position = vec4(p, 0.0, 1.0);
}
`;

// Sky, sun, paper ground with the timeline ruler etched into it.
export const GROUND_FS = /* glsl */ `#version 300 es
precision highp float;
in vec2 vNdc;
out vec4 o;
uniform vec3 uEye;
uniform mat4 uInvViewProj;
uniform vec3 uSun;
uniform float uKUp, uKGlow, uNight;
uniform float uPlayX;
uniform float uDetail;
uniform float uIdle;

const vec3 PAPER = vec3(0.945, 0.933, 0.906);
const vec3 NIGHT_INK = vec3(0.051, 0.063, 0.141);
const vec3 NIGHT_HZ = vec3(0.102, 0.129, 0.271);
const vec3 DAY_Z = vec3(0.498, 0.616, 0.839);
const vec3 DAY_HZ = vec3(0.914, 0.933, 0.961);
const vec3 GLOW_HZ = vec3(0.953, 0.694, 0.518);
const vec3 GLOW_Z = vec3(0.333, 0.388, 0.624);
const vec3 WARM = vec3(0.941, 0.765, 0.612);
const vec3 INK = vec3(0.078, 0.102, 0.180);

float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }

void main() {
  vec4 pFar = uInvViewProj * vec4(vNdc, 1.0, 1.0);
  vec3 dir = normalize(pFar.xyz / pFar.w - uEye);
  vec3 zen = mix(NIGHT_INK, DAY_Z, uKUp); zen = mix(zen, GLOW_Z, uKGlow * 0.6);
  vec3 hz = mix(NIGHT_HZ, DAY_HZ, uKUp); hz = mix(hz, GLOW_HZ, uKGlow);
  vec3 col;
  if (dir.y >= 0.0) {
    float t = pow(clamp(dir.y * 1.7, 0.0, 1.0), 0.55);
    col = mix(hz, zen, t);
    float sd = max(dot(dir, uSun), 0.0);
    float vis = smoothstep(-0.03, 0.02, uSun.y);
    col += vis * (vec3(1.0, 0.94, 0.82) * pow(sd, 1400.0) * 1.1
                + vec3(1.0, 0.72, 0.48) * pow(sd, 16.0) * 0.26 * (0.35 + uKGlow));
  } else {
    float tt = -uEye.y / dir.y;
    vec3 hit = uEye + dir * tt;
    vec3 ground = mix(NIGHT_INK * 1.12, PAPER, uKUp);
    ground = mix(ground, WARM, uKGlow * 0.35);
    float fade = exp(-tt * 0.08);
    float trackZ = 0.25;
    float widen = tt * 0.0035;
    float lineZ = 1.0 - smoothstep(0.004, 0.011 + widen, abs(hit.z - trackZ));
    float minor = (1.0 - smoothstep(0.005, 0.012 + widen, abs(fract(hit.x * 5.0 + 0.5) - 0.5) / 5.0)) * step(abs(hit.z - trackZ), 0.07);
    float major = (1.0 - smoothstep(0.007, 0.017 + widen, abs(fract(hit.x + 0.5) - 0.5))) * step(abs(hit.z - trackZ), 0.2);
    float ruler = max(lineZ * 0.5, max(minor * 0.3, major * 0.55)) * fade * uDetail;
    vec3 inkCol = mix(INK, vec3(0.72, 0.76, 0.92), uNight);
    col = mix(ground, inkCol, ruler * mix(0.5, 0.4, uNight));
    float ph = 1.0 - smoothstep(0.003, 0.009 + widen * 0.6, abs(hit.x - uPlayX));
    float nearFade = smoothstep(0.8, 2.2, tt);
    col = mix(col, vec3(1.0, 0.62, 0.18), ph * 0.55 * fade * nearFade * (1.0 - 0.75 * uNight));
    float fog = 1.0 - exp(-tt * 0.05);
    col = mix(col, hz, fog);
  }
  // paper grain, very light
  float gr = hash21(vNdc * 1000.0 + fract(uIdle) * 10.0) - 0.5;
  col += gr * 0.018 * uDetail;
  o = vec4(col, 1.0);
}
`;

export const BLUR_FS = /* glsl */ `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 o;
uniform sampler2D uTex;
uniform vec2 uDir; // in texel units
void main() {
  vec4 s = texture(uTex, vUv) * 0.227;
  s += (texture(uTex, vUv + uDir * 1.385) + texture(uTex, vUv - uDir * 1.385)) * 0.316;
  s += (texture(uTex, vUv + uDir * 3.231) + texture(uTex, vUv - uDir * 3.231)) * 0.070;
  o = s;
}
`;

export const COMPOSITE_FS = /* glsl */ `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 o;
uniform sampler2D uTex;
uniform float uGain;
void main() {
  vec4 s = texture(uTex, vUv);
  o = vec4(s.rgb * uGain, 0.0);
}
`;
