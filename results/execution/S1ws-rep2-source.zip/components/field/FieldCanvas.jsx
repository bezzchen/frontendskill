"use client";
import { useEffect, useRef } from "react";
import { FieldRenderer } from "./renderer";
import { store, setState, emitFrame, setStarter } from "@/lib/store";
import { DURATION, SPRING_WINDOW, clamp, dayMix, sunDirection, themeAt, easeLUT, springLUT, smoothstep } from "@/lib/timeline";

// Capability recipe. Identity (frames + shadows + sun) is preserved in every tier;
// what scales is count, pixel density and the night bloom.
export const TIERS = {
  high: { n: 40000, trackN: 720, dpr: 1.5, bloom: true, detail: 1 },
  mid: { n: 20000, trackN: 560, dpr: 1.25, bloom: true, detail: 1 },
  low: { n: 9000, trackN: 360, dpr: 1, bloom: false, detail: 0.7 },
};
function pickTier() {
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const w = window.innerWidth;
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory || 8;
  if (coarse || w < 768) return "low";
  if (cores <= 4 || mem <= 4) return "mid";
  return "high";
}

// Camera per act: eyeY, eyeZ, lookAheadX, targetY, fov
const CAMS = [
  [0.75, 4.6, 0.7, 0.5, 46],
  [1.35, 4.0, 1.55, 0.45, 44],
  [1.9, 4.2, 1.55, 0.55, 44],
  [1.2, 4.8, 0.0, 1.3, 46],
  [0.55, 5.2, 0.0, 0.45, 48],
];
function actWeights(T, w = 1.6) {
  const s1 = smoothstep(10 - w, 10 + w, T), s2 = smoothstep(20 - w, 20 + w, T);
  const s3 = smoothstep(30 - w, 30 + w, T), s4 = smoothstep(40 - w, 40 + w, T);
  return [1 - s1, s1 - s2, s2 - s3, s3 - s4, s4];
}
function cameraAt(T, aspect) {
  const w = actWeights(T);
  const p = [0, 0, 0, 0, 0];
  for (let k = 0; k < 5; k++) for (let j = 0; j < 5; j++) p[j] += w[k] * CAMS[k][j];
  const cx = T * 0.55;
  const portrait = aspect < 1;
  const lookX = p[2] * (portrait ? 0.25 : 1);
  return {
    eye: [cx, p[0] + (portrait ? 0.45 : 0), p[1] * (portrait ? 1.15 : 1)],
    target: [cx + lookX, p[3] - (portrait ? 0.3 : 0), 0],
    fov: p[4] * (portrait ? 1.2 : 1),
    cx,
    lookX,
    weights: w,
  };
}

export default function FieldCanvas() {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    let renderer;
    try {
      renderer = new FieldRenderer(canvas);
    } catch (e) {
      setState({ gl: "none" });
      return undefined;
    }
    setState({ gl: "ok" });

    // Loop state (declared before anything can call start()).
    let raf = 0, last = 0;
    let visible = true;
    let hidden = document.visibilityState === "hidden";

    let tierName = pickTier();
    const applyTier = (name) => {
      tierName = name;
      const t = TIERS[name];
      renderer.setTier({ n: t.n, trackN: t.trackN, dpr: Math.min(window.devicePixelRatio || 1, t.dpr), bloom: t.bloom });
      setState({ tier: name, tierN: t.n });
    };
    applyTier(tierName);

    // Sizing
    const host = canvas.parentElement;
    const resize = () => {
      const r = host.getBoundingClientRect();
      renderer.resize(Math.max(1, r.width), Math.max(1, r.height));
      store.dirty = true;
      start();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(host);
    resize();

    // Pause rules: offscreen (IntersectionObserver on the canvas itself) and hidden document.
    const io = new IntersectionObserver(
      (entries) => {
        visible = entries[0].isIntersecting;
        if (visible) start(); else store.running = false;
      },
      { threshold: 0 }
    );
    io.observe(canvas);
    const onVis = () => {
      hidden = document.visibilityState === "hidden";
      if (!hidden) start(); else store.running = false;
    };
    document.addEventListener("visibilitychange", onVis);

    // Pointer -> time lens (full motion only)
    const onMove = (e) => {
      store.pointer.x = e.clientX; store.pointer.y = e.clientY; store.pointer.active = true;
      if (store.mode === "full") start();
    };
    const onLeave = () => { store.pointer.active = false; };
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerdown", onMove, { passive: true });
    window.addEventListener("blur", onLeave);
    document.addEventListener("pointerleave", onLeave);

    // Versions of uploaded data
    let easeV = -1, springV = -1, glyphV = -1;
    const impulses = store.impulses;
    const glyphRect = new Float32Array([0, 0, 0, 0]);
    const track = new Float32Array([0, 2]);
    let lensK = 0;

    // Adaptive tier from measured frame time
    let acc = 0, accN = 0;

    function shouldRun() { return visible && !hidden && (store.mode === "full" || store.dirty); }

    function start() {
      if (raf || !shouldRun()) return;
      last = performance.now();
      store.running = true;
      raf = requestAnimationFrame(frame);
    }

    function frame(now) {
      raf = 0;
      if (!shouldRun()) { store.running = false; return; }
      const dt = Math.min(0.1, Math.max(0, (now - last) / 1000));
      last = now;
      const full = store.mode === "full";
      if (full) store.idle += dt;
      renderOnce(dt, full);
      store.dirty = false;
      store.frameCount++;
      if (full) {
        acc += dt; accN++;
        if (accN >= 90) {
          store.fps = accN / acc;
          const avg = acc / accN;
          if (avg > 0.024 && tierName !== "low") applyTier(tierName === "high" ? "mid" : "low");
          acc = 0; accN = 0;
        }
        store.running = true;
        raf = requestAnimationFrame(frame);
      } else {
        store.running = false;
      }
    }

    function renderOnce(dt, full) {
      if (store.easeVersion !== easeV) { easeV = store.easeVersion; renderer.setEase(easeLUT(store.bezier)); }
      if (store.springVersion !== springV) { springV = store.springVersion; renderer.setSpring(springLUT(store.spring)); }
      if (store.glyphVersion !== glyphV && store.glyphs) { glyphV = store.glyphVersion; renderer.setGlyphs(store.glyphs, store.glyphCount); }

      const T = store.T;
      const aspect = renderer.width / renderer.height;
      const cam = cameraAt(T, aspect);
      renderer.setCamera(cam);
      const d = dayMix(T);
      const sun = sunDirection(T);

      // Lens: pointer ray onto the ground, eased in/out
      const target = full && store.pointer.active && T < 14 ? 1 : 0;
      lensK += (target - lensK) * Math.min(1, dt * 5);
      let lens = [0, 0, 0];
      if (lensK > 0.005 && store.pointer.active) {
        const hit = renderer.groundHit(store.pointer.x, store.pointer.y);
        if (hit) lens = [hit[0], hit[2], lensK];
      }

      // Export block registration
      const el = store.glyphEl;
      if (el && T > 26 && T < 44) {
        const r = el.getBoundingClientRect();
        const vw = renderer.cssW, vh = renderer.cssH;
        glyphRect[0] = (r.left / vw) * 2 - 1;
        glyphRect[1] = 1 - (r.bottom / vh) * 2;
        glyphRect[2] = (r.width / vw) * 2;
        glyphRect[3] = (r.height / vh) * 2;
      }

      // Track placement relative to the look direction
      const len = clamp(aspect * 1.8, 1.5, 3.0);
      track[0] = cam.lookX - len * 0.5 + (aspect < 1 ? 0 : 0.9);
      track[1] = len;

      // Heads: in full motion the current frame sweeps on the idle clock (a live preview);
      // in calm motion it follows the act-local scroll position (scrub to inspect).
      let easeHead, springHead;
      if (full) {
        easeHead = (store.idle * 0.38) % 1;
        const since = store.idle - store.springTrigger;
        if (T > 18 && T < 32 && since > SPRING_WINDOW + 2.2) store.springTrigger = store.idle;
        springHead = clamp((store.idle - store.springTrigger) / SPRING_WINDOW, 0, 1);
      } else {
        easeHead = clamp((T - 10) / 10, 0, 1);
        springHead = clamp((T - 20) / 10, 0, 1);
      }
      store.easeHead = easeHead; store.springHead = springHead;

      renderer.render({
        T, idle: store.idle, motion: full ? 1 : 0, blendW: full ? 1.6 : 0.03,
        sun, kUp: d.kUp, kGlow: d.kGlow, night: d.night,
        cx: cam.cx, playX: cam.cx + cam.lookX * 0.55, lens, glyphRect, track,
        easeHead, springHead, impulses, detail: TIERS[tierName].detail,
      });

      emitFrame({ T, theme: themeAt(T), weights: cam.weights, full });
    }

    const unstart = setStarter(start);
    store.dirty = true;
    start();

    // Debug/verification handle (read-only)
    window.__meridian = {
      get running() { return store.running; },
      get frameCount() { return store.frameCount; },
      get fps() { return store.fps; },
      get tier() { return store.tier; },
      get mode() { return store.mode; },
      get playing() { return store.playing; },
      get T() { return store.T; },
      get drawCalls() { return renderer.drawCalls; },
      get instances() { return renderer.n; },
      get visible() { return visible; },
      get hidden() { return hidden; },
      // Renders exactly one frame at an optional master time. Does not start the loop
      // and does not bypass the pause rules; exists for review and verification.
      step(T) {
        if (typeof T === "number") store.T = clamp(T, 0, DURATION);
        renderOnce(1 / 60, store.mode === "full");
        store.frameCount++;
      },
    };

    return () => {
      unstart();
      if (raf) cancelAnimationFrame(raf);
      ro.disconnect(); io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onMove);
      window.removeEventListener("blur", onLeave);
      document.removeEventListener("pointerleave", onLeave);
      renderer.dispose();
      delete window.__meridian;
    };
  }, []);

  return <canvas ref={ref} className="field-canvas" aria-hidden="true" />;
}
