"use client";
import { useEffect, useRef } from "react";
import { store, emitFrame, setStarter } from "@/lib/store";
import { themeAt, actWeights, cubicBezierSolver, springSolver, SPRING_WINDOW } from "@/lib/timeline";

// No-WebGL2 variant: the same frames-and-shadows idea drawn as SVG lines,
// updated on demand (scroll and control changes). Identity, not spectacle.
const N = 140;
export default function SvgFallback() {
  const ref = useRef(null);
  useEffect(() => {
    let raf = 0;
    const draw = (T) => {
      const svg = ref.current;
      if (!svg) return;
      const th = themeAt(T);
      const w = actWeights(T);
      const ease = cubicBezierSolver(...store.bezier);
      const sp = store.spring;
      const spring = springSolver(sp.stiffness, sp.damping, sp.mass, 0);
      const horizonY = 44;
      let out = "";
      const shx = th.shX * 6, shy = th.shY * 6;
      for (let i = 0; i < N; i++) {
        const u = (i + 0.5) / N;
        const h0 = ((i * 9301 + 49297) % 233280) / 233280;
        // position along x per act, then blend
        const xA = h0 * 100, xB = 20 + ease(u) * 60, xC = 20 + u * 60, xE = h0 * 100;
        const hA = 4 + h0 * 8, hB = 9, hC = 3 + Math.max(0, Math.min(1.5, spring(u * SPRING_WINDOW))) * 12, hE = 0.8;
        const x = w[0] * xA + w[1] * xB + w[2] * xC + w[3] * xE + w[4] * xE;
        const h = w[0] * hA + w[1] * hB + w[2] * hC + w[3] * hE + w[4] * hE;
        const y = horizonY + 30 + ((i * 7) % 13) * 1.2 * (w[0] + w[4] + w[3]);
        const a = 0.35 * (1 - th.night) + 0.7 * th.night;
        const col = th.night > 0.5 ? "rgba(255,220,170," + a + ")" : "rgba(20,26,46," + a + ")";
        if (th.shA > 0.01) {
          out += `<line x1="${x.toFixed(2)}" y1="${y.toFixed(2)}" x2="${(x + shx * h * 0.6).toFixed(2)}" y2="${(y + shy * h * 0.6).toFixed(2)}" stroke="rgba(38,48,94,${th.shA.toFixed(2)})" stroke-width="0.5" />`;
        }
        out += `<line x1="${x.toFixed(2)}" y1="${y.toFixed(2)}" x2="${x.toFixed(2)}" y2="${(y - h).toFixed(2)}" stroke="${col}" stroke-width="0.35" />`;
      }
      svg.innerHTML = out;
    };
    const emit = () => {
      raf = 0;
      const T = store.T;
      draw(T);
      emitFrame({ T, theme: themeAt(T), weights: actWeights(T), full: false });
      store.dirty = false;
    };
    const start = () => { if (!raf) raf = requestAnimationFrame(emit); };
    const un = setStarter(start);
    start();
    return () => { un(); if (raf) cancelAnimationFrame(raf); };
  }, []);
  return <svg ref={ref} className="field-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" />;
}
