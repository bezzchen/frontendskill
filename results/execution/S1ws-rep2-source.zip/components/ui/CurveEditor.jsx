"use client";
import { useRef } from "react";
import { useStore, setBezier } from "@/lib/store";
import { cubicBezierSolver, bezierCss, BEZIER_PRESETS, clamp, fmt } from "@/lib/timeline";

const YMIN = -0.5, YMAX = 1.5;
const toPct = (x, y) => [x * 100, (1 - (y - YMIN) / (YMAX - YMIN)) * 100];

export default function CurveEditor() {
  const bez = useStore((s) => s.bezier);
  const stageRef = useRef(null);
  const f = cubicBezierSolver(bez[0], bez[1], bez[2], bez[3]);

  let d = "";
  for (let i = 0; i <= 64; i++) {
    const x = i / 64;
    const [px, py] = toPct(x, f(x));
    d += (i ? " L" : "M") + px.toFixed(2) + " " + py.toFixed(2);
  }
  const p0 = toPct(0, 0), p1 = toPct(bez[0], bez[1]), p2 = toPct(bez[2], bez[3]), p3 = toPct(1, 1);
  const y0 = toPct(0, 0)[1], y1 = toPct(0, 1)[1];

  const update = (i, x, y) => {
    const b = bez.slice();
    b[i * 2] = clamp(x, 0, 1);
    b[i * 2 + 1] = clamp(y, YMIN, YMAX);
    setBezier(b);
  };

  const onPointerDown = (i) => (e) => {
    e.preventDefault();
    const el = e.currentTarget;
    el.setPointerCapture(e.pointerId);
    el.focus();
    const move = (ev) => {
      const r = stageRef.current.getBoundingClientRect();
      const x = (ev.clientX - r.left) / r.width;
      const yPx = (ev.clientY - r.top) / r.height;
      update(i, x, YMIN + (1 - yPx) * (YMAX - YMIN));
    };
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
  };

  // Keyboard: arrows move 0.05, Shift for 0.01 (after the Motion+ editor's convention).
  const onKey = (i) => (e) => {
    const step = e.shiftKey ? 0.01 : 0.05;
    let x = bez[i * 2], y = bez[i * 2 + 1];
    switch (e.key) {
      case "ArrowLeft": x -= step; break;
      case "ArrowRight": x += step; break;
      case "ArrowUp": y += step; break;
      case "ArrowDown": y -= step; break;
      default: return;
    }
    e.preventDefault();
    update(i, x, y);
  };

  const field = (idx, label) => (
    <label key={idx}>
      {label}
      <input
        type="number" step="0.01" inputMode="decimal"
        min={idx % 2 === 0 ? 0 : YMIN} max={idx % 2 === 0 ? 1 : YMAX}
        value={bez[idx]}
        onChange={(e) => {
          const v = parseFloat(e.target.value);
          if (Number.isNaN(v)) return;
          const b = bez.slice();
          b[idx] = idx % 2 === 0 ? clamp(v, 0, 1) : clamp(v, YMIN, YMAX);
          setBezier(b);
        }}
      />
    </label>
  );

  return (
    <div>
      <div className="presets" role="group" aria-label="Easing presets">
        {BEZIER_PRESETS.map((p) => {
          const on = p.value.every((v, i) => Math.abs(v - bez[i]) < 0.005);
          return (
            <button key={p.name} type="button" className="chip" aria-pressed={on} onClick={() => setBezier(p.value)}>
              {p.name}
            </button>
          );
        })}
      </div>
      <div className="curve">
        <div className="curve-stage" ref={stageRef}>
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            <line className="grid" x1="0" x2="100" y1={y0} y2={y0} />
            <line className="grid" x1="0" x2="100" y1={y1} y2={y1} />
            <line className="arm" x1={p0[0]} y1={p0[1]} x2={p1[0]} y2={p1[1]} vectorEffect="non-scaling-stroke" />
            <line className="arm" x1={p3[0]} y1={p3[1]} x2={p2[0]} y2={p2[1]} vectorEffect="non-scaling-stroke" />
            <path className="path" d={d} vectorEffect="non-scaling-stroke" />
            <rect className="diamond" x="-1.6" y="-1.6" width="3.2" height="3.2" transform={`translate(${p0[0]} ${p0[1]}) rotate(45)`} vectorEffect="non-scaling-stroke" />
            <rect className="diamond" x="-1.6" y="-1.6" width="3.2" height="3.2" transform={`translate(${p3[0]} ${p3[1]}) rotate(45)`} vectorEffect="non-scaling-stroke" />
          </svg>
          {[p1, p2].map((p, i) => (
            <button
              key={i}
              type="button"
              className="handle"
              style={{ left: `${p[0]}%`, top: `${p[1]}%` }}
              aria-label={`Control point ${i + 1}: x ${fmt(bez[i * 2])}, y ${fmt(bez[i * 2 + 1])}. Arrow keys move it, hold Shift for fine steps.`}
              onPointerDown={onPointerDown(i)}
              onKeyDown={onKey(i)}
            />
          ))}
        </div>
        <div className="curve-fields">
          {field(0, "x1")}{field(1, "y1")}{field(2, "x2")}{field(3, "y2")}
        </div>
      </div>
      <code className="readout" aria-live="polite" aria-atomic="true">{bezierCss(bez)}</code>
    </div>
  );
}
