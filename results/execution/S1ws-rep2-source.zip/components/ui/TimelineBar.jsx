"use client";
import { useEffect, useRef, useState } from "react";
import { store, useStore, setState, onFrame, requestRender } from "@/lib/store";
import { ACTS, DURATION, timecode, actAt } from "@/lib/timeline";

export default function TimelineBar({ seek }) {
  const mode = useStore((s) => s.mode);
  const playing = useStore((s) => s.playing);
  const tcRef = useRef(null), rangeRef = useRef(null), headRef = useRef(null);
  const activeRef = useRef(0);
  const lastInputRef = useRef(-1e9);
  const [active, setActive] = useState(0);

  useEffect(() => {
    return onFrame(({ T }) => {
      const tc = timecode(T);
      if (tcRef.current) tcRef.current.textContent = tc;
      if (rangeRef.current) {
        // Do not fight the visitor: leave the value alone right after they moved it.
        if (performance.now() - lastInputRef.current > 250) rangeRef.current.value = String(T);
        rangeRef.current.setAttribute("aria-valuetext", `${tc}, ${ACTS[actAt(T)].scene}`);
      }
      if (headRef.current) headRef.current.style.setProperty("--p", `${(T / DURATION) * 100}%`);
      const a = actAt(T);
      if (a !== activeRef.current) { activeRef.current = a; setActive(a); }
    });
  }, []);

  const toggleMode = () => {
    const next = store.mode === "full" ? "calm" : "full";
    try { localStorage.setItem("meridian-motion", next); } catch {}
    setState({ mode: next, playing: false });
    requestRender();
  };

  return (
    <div className="tbar" role="region" aria-label="Timeline">
      <button
        type="button" className="tbar-play"
        onClick={() => setState({ playing: !store.playing })}
        disabled={mode !== "full"}
        aria-label={playing ? "Pause" : "Play the page"}
        title={mode !== "full" ? "Autoplay is off in calm motion" : playing ? "Pause" : "Play the page from here"}
      >
        {playing ? (
          <svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="2" width="4" height="12" /><rect x="9" y="2" width="4" height="12" /></svg>
        ) : (
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2l11 6-11 6z" /></svg>
        )}
      </button>
      <output className="tbar-tc" aria-live="off">
        <span ref={tcRef}>00:00:00:00</span>
        <small>{ACTS[active].scene}, {ACTS[active].title.toLowerCase()}</small>
      </output>
      <div className="tbar-lane">
        <input
          ref={rangeRef}
          type="range" className="tbar-scrub"
          min="0" max={DURATION} step="0.05" defaultValue="0"
          aria-label="Playhead"
          onInput={(e) => { lastInputRef.current = performance.now(); seek(parseFloat(e.target.value), "instant"); }}
          onPointerDown={() => setState({ playing: false })}
        />
        <ol className="tbar-clips" aria-label="Scenes">
          {ACTS.map((a, i) => (
            <li key={a.id}>
              <button type="button" onClick={() => { setState({ playing: false }); seek(a.start + 0.6, "smooth"); }} aria-current={active === i ? "true" : undefined} aria-label={`${a.scene}: ${a.title}`}>
                <span className="clip-scene">{a.scene}</span>
                <span className="clip-title">{a.title}</span>
              </button>
            </li>
          ))}
        </ol>
        <div className="tbar-head" ref={headRef} aria-hidden="true" />
      </div>
      <button type="button" className="tbar-motion" aria-pressed={mode === "calm"} onClick={toggleMode}>
        <span className="tbar-motion-label">Calm motion</span>
        <small>{mode === "calm" ? "on: scroll scrubs, nothing moves on its own" : "off"}</small>
      </button>
    </div>
  );
}
