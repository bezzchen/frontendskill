"use client";
import { useEffect, useMemo, useRef } from "react";
import { store, useStore, setSpring, retriggerSpring, onFrame } from "@/lib/store";
import { springSolver, springSettleMs, SPRING_WINDOW, clamp, fmt } from "@/lib/timeline";

const W = 160, H = 70, YMIN = -0.45, YMAX = 1.65;
const px = (t, v) => [(t / SPRING_WINDOW) * W, (1 - (v - YMIN) / (YMAX - YMIN)) * H];

export default function SpringPanel() {
  const sp = useStore((s) => s.spring);
  const version = useStore((s) => s.springVersion);
  const graphRef = useRef(null);
  const headRef = useRef(null);
  const pastRef = useRef(null);

  const solver = useMemo(() => springSolver(sp.stiffness, sp.damping, sp.mass, sp.v0 || 0), [version]);
  const path = useMemo(() => {
    let d = "";
    for (let i = 0; i <= 128; i++) {
      const t = (i / 128) * SPRING_WINDOW;
      const [x, y] = px(t, solver(t));
      d += (i ? " L" : "M") + x.toFixed(2) + " " + y.toFixed(2);
    }
    return d;
  }, [solver]);
  const settle = useMemo(() => springSettleMs({ ...sp, v0: 0 }), [version]);

  // The head and the "already played" portion follow the field's clock.
  useEffect(() => {
    let lastHead = -1;
    return onFrame(() => {
      const h = store.springHead;
      if (Math.abs(h - lastHead) < 0.0005) return;
      lastHead = h;
      const t = h * SPRING_WINDOW;
      const [x, y] = px(t, solver(t));
      if (headRef.current) { headRef.current.setAttribute("cx", x.toFixed(2)); headRef.current.setAttribute("cy", y.toFixed(2)); }
      if (pastRef.current) {
        const n = Math.max(1, Math.round(h * 128));
        let d = "";
        for (let i = 0; i <= n; i++) {
          const tt = (i / 128) * SPRING_WINDOW;
          const [xx, yy] = px(tt, solver(tt));
          d += (i ? " L" : "M") + xx.toFixed(2) + " " + yy.toFixed(2);
        }
        pastRef.current.setAttribute("d", d);
      }
    });
  }, [solver]);

  // Flick: drag on the graph, release -> initial velocity.
  const onPointerDown = (e) => {
    const el = graphRef.current;
    el.setPointerCapture(e.pointerId);
    let lastY = e.clientY, lastT = performance.now(), vel = 0;
    const move = (ev) => {
      const now = performance.now();
      const dt = Math.max(1, now - lastT) / 1000;
      const r = el.getBoundingClientRect();
      const dv = -((ev.clientY - lastY) / r.height) * (YMAX - YMIN);
      vel = vel * 0.5 + (dv / dt) * 0.5;
      lastY = ev.clientY; lastT = now;
    };
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
      const v0 = Math.abs(vel) < 0.5 ? -7 : clamp(vel, -14, 14);
      setSpring({ v0 }, true);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
  };

  const range = (key, label, min, max, step) => (
    <label key={key}>
      <span>{label}</span>
      <input
        type="range" min={min} max={max} step={step} value={sp[key]}
        onChange={(e) => setSpring({ [key]: parseFloat(e.target.value) }, true)}
      />
      <output>{fmt(sp[key], 1)}</output>
    </label>
  );

  const tY = px(0, 1)[1], zY = px(0, 0)[1];

  return (
    <div>
      <div
        className="spring-graph" ref={graphRef} onPointerDown={onPointerDown}
        role="img" aria-label={`Spring response graph. Settles in ${settle} milliseconds.`}
        title="Drag and release to flick"
      >
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          <line className="grid" x1="0" x2={W} y1={zY} y2={zY} vectorEffect="non-scaling-stroke" />
          <line className="target" x1="0" x2={W} y1={tY} y2={tY} vectorEffect="non-scaling-stroke" />
          <path className="path" d={path} vectorEffect="non-scaling-stroke" />
          <path className="past" ref={pastRef} d="" vectorEffect="non-scaling-stroke" />
          <circle className="head" ref={headRef} r="2.6" cx="0" cy={zY} vectorEffect="non-scaling-stroke" />
        </svg>
      </div>
      <div className="ranges">
        {range("stiffness", "Stiffness", 20, 600, 5)}
        {range("damping", "Damping", 1, 60, 0.5)}
        {range("mass", "Mass", 0.2, 5, 0.1)}
      </div>
      <div className="btn-row">
        <button type="button" className="btn btn-quiet" onClick={() => setSpring({ v0: -7 }, true)}>Flick</button>
        <button type="button" className="btn btn-quiet" onClick={() => { if (sp.v0) setSpring({ v0: 0 }, true); else retriggerSpring(); }}>Replay</button>
        <code className="readout">spring({fmt(sp.stiffness, 0)}, {fmt(sp.damping, 1)}, {fmt(sp.mass, 1)}) settles in {settle} ms</code>
      </div>
    </div>
  );
}
