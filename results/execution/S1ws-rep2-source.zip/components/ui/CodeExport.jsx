"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { store, useStore, setGlyphs } from "@/lib/store";
import { bezierCss, springLinearCss, clamp } from "@/lib/timeline";
import { buildGlyphTargets, measureAdvance } from "@/components/field/glyphs";

function wrapValues(prefix, values, indent, width) {
  const lines = [];
  let cur = indent + prefix;
  values.forEach((v, i) => {
    const piece = v + (i < values.length - 1 ? ", " : ");");
    if (cur.length + piece.length > width) { lines.push(cur.replace(/\s+$/, "")); cur = indent + "  " + piece; }
    else cur += piece;
  });
  lines.push(cur);
  return lines;
}

export function buildLines(bez, sp) {
  const { ms, values } = springLinearCss({ ...sp, v0: 0 });
  return [
    ".card {",
    "  transition: transform 600ms",
    `    ${bezierCss(bez)};`,
    "}",
    "",
    ".card.springy {",
    `  transition-duration: ${ms}ms;`,
    "  transition-timing-function:",
    ...wrapValues("linear(", values, "    ", 44),
    "}",
  ];
}

export default function CodeExport() {
  const bez = useStore((s) => s.bezier);
  const sp = useStore((s) => s.spring);
  const springV = useStore((s) => s.springVersion);
  const lines = useMemo(() => buildLines(bez, sp), [bez, springV]);
  const text = lines.join("\n");
  const preRef = useRef(null);
  const wrapRef = useRef(null);
  const [status, setStatus] = useState("");

  // Size the block to the panel, then rasterize the same text with the same
  // metrics so the field's glyph targets land exactly under the DOM glyphs.
  useEffect(() => {
    const pre = preRef.current, wrap = wrapRef.current;
    if (!pre || !wrap) return undefined;
    let t = 0;
    const compute = () => {
      const cols = Math.max(...lines.map((l) => l.length));
      const inner = wrap.clientWidth - 32;
      const ratio = measureAdvance(20) / 20;
      const fontPx = clamp(Math.floor(inner / (cols * ratio)), 10, 15);
      const lh = Math.round(fontPx * 1.55);
      pre.style.fontSize = fontPx + "px";
      pre.style.lineHeight = lh + "px";
      const maxCount = Math.floor(store.tierN * 0.55);
      const g = buildGlyphTargets({ lines, fontPx, lineHeightPx: lh, maxCount });
      setGlyphs(g.data, g.count, pre);
    };
    const schedule = () => { clearTimeout(t); t = setTimeout(compute, 140); };
    schedule();
    const ro = new ResizeObserver(schedule);
    ro.observe(wrap);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, [lines]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setStatus("Copied to your clipboard.");
    } catch {
      setStatus("Copy is blocked here. Select the code and copy it by hand.");
    }
  };

  return (
    <div>
      <div className="code-wrap" ref={wrapRef}>
        <pre ref={preRef} tabIndex={0} aria-label="Exported CSS"><code>{text}</code></pre>
      </div>
      <div className="btn-row">
        <button type="button" className="btn" onClick={copy}>Copy CSS</button>
        <span className="copy-status" role="status">{status}</span>
      </div>
    </div>
  );
}
