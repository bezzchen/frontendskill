"use client";
import { useState } from "react";
import CurveEditor from "@/components/ui/CurveEditor";
import SpringPanel from "@/components/ui/SpringPanel";
import CodeExport from "@/components/ui/CodeExport";
import { store, useStore, addImpulse } from "@/lib/store";

export function ActDawn({ seek }) {
  const mode = useStore((s) => s.mode);
  return (
    <section className="act" data-act="0" id="dawn" aria-labelledby="h-dawn">
      <div className="hero">
        <h1 id="h-dawn">Meridian</h1>
        <div className="lede">
          <p>
            A timeline for motion on the web. Draw the timing by hand, tune the physics, and ship the
            result as plain CSS and JavaScript.
          </p>
          <div className="btn-row">
            <a className="btn" href="#night" onClick={(e) => { e.preventDefault(); seek(40.6, "smooth"); }}>Get early access</a>
            <a className="btn btn-quiet" href="#morning" onClick={(e) => { e.preventDefault(); seek(10.6, "smooth"); }}>See how it works</a>
          </div>
          <p className="hint">
            Scroll to move the day; the sun is the playhead.
            {mode === "full" ? <> Press <kbd>Space</kbd> to let the page play itself.</> : null}
          </p>
        </div>
      </div>
    </section>
  );
}

export function ActMorning() {
  return (
    <section className="act" data-act="1" id="morning" aria-labelledby="h-morning">
      <div className="act-panel">
        <h2 id="h-morning">Timing you can see</h2>
        <p>
          Every frame stands on the timeline. Drag the curve and the field re-spaces itself: where frames
          bunch, the motion is slow; where they spread, it is fast. It is the spacing chart animators draw
          on paper, live.
        </p>
        <CurveEditor />
      </div>
    </section>
  );
}

export function ActNoon() {
  return (
    <section className="act" data-act="2" id="noon" aria-labelledby="h-noon">
      <div className="act-panel">
        <h2 id="h-noon">Physics, not guesswork</h2>
        <p>
          Springs settle the way real things do. Set stiffness, damping and mass, then flick the graph to
          test the response. Behind you, the field draws the value of every frame.
        </p>
        <SpringPanel />
      </div>
    </section>
  );
}

export function ActDusk() {
  return (
    <section className="act" data-act="3" id="dusk" aria-labelledby="h-dusk">
      <div className="act-panel">
        <h2 id="h-dusk">Ship the motion you drew</h2>
        <p>
          Meridian exports what you designed as plain CSS, with no runtime and nothing to install. These
          are the values you just set.
        </p>
        <CodeExport />
      </div>
    </section>
  );
}

function AccessForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");
  const [done, setDone] = useState(false);
  const ripple = (strength) => {
    if (store.mode !== "full") return;
    addImpulse(store.T * 0.55 + (Math.random() - 0.5) * 3, strength);
  };
  return (
    <form
      className="access"
      onSubmit={(e) => {
        e.preventDefault();
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { setStatus("Enter an email address like name@studio.com."); return; }
        setDone(true);
        setStatus(`Requested. We will write to ${email} when a seat opens.`);
        ripple(1.6);
      }}
    >
      <label htmlFor="access-email">Work email</label>
      <div className="row">
        <input
          id="access-email" type="email" name="email" autoComplete="email" placeholder="name@studio.com"
          value={email} disabled={done}
          onChange={(e) => { setEmail(e.target.value); ripple(0.55); }}
        />
        <button type="submit" className="btn" disabled={done}>Request an invite</button>
      </div>
      <p className="status" role="status">{status}</p>
    </form>
  );
}

export function ActNight() {
  return (
    <section className="act" data-act="4" id="night" aria-labelledby="h-night">
      <div className="act-panel">
        <h2 id="h-night">Start your timeline</h2>
        <p>Meridian is in private beta. Leave your email and we will send an invite as seats open.</p>
        <AccessForm />
        <p className="fine">Or write to <a href="mailto:hello@meridian.tools">hello@meridian.tools</a>.</p>
      </div>
    </section>
  );
}
