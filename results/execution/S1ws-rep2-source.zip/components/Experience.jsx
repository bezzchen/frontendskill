"use client";
import { useCallback, useEffect, useRef } from "react";
import FieldCanvas from "@/components/field/FieldCanvas";
import SvgFallback from "@/components/field/SvgFallback";
import TimelineBar from "@/components/ui/TimelineBar";
import { ActDawn, ActMorning, ActNoon, ActDusk, ActNight } from "@/components/acts/Acts";
import { store, useStore, setState, onFrame, requestRender } from "@/lib/store";
import { ACTS, DURATION, clamp, toCss, mix3, smoothstep, PALETTE } from "@/lib/timeline";

const WHITE = [1, 1, 1], BLACK = [0, 0, 0];

export default function Experience() {
  const rootRef = useRef(null);
  const actsRef = useRef(null);
  const gl = useStore((s) => s.gl);
  const mode = useStore((s) => s.mode);
  const tier = useStore((s) => s.tier);
  const playing = useStore((s) => s.playing);

  // Master time from scroll.
  const scrollableFor = () => {
    const el = rootRef.current;
    return el ? Math.max(1, el.offsetHeight - window.innerHeight) : 1;
  };
  const seek = useCallback((T, behavior = "instant") => {
    const el = rootRef.current;
    if (!el) return;
    const top = el.offsetTop + (clamp(T, 0, DURATION) / DURATION) * scrollableFor();
    const b = store.mode === "full" ? behavior : "instant";
    store.expectedScrollY = top;
    window.scrollTo({ top, behavior: b === "smooth" ? "smooth" : "instant" });
    if (b !== "smooth") {
      // Instant seeks update time now rather than one scroll event later.
      store.T = clamp(T, 0, DURATION);
      requestRender();
    }
  }, []);

  useEffect(() => {
    const el = rootRef.current;
    el.setAttribute("data-ready", "");
    const onScroll = () => {
      // Autoplay owns the scroll position while it runs; any other scroll (wheel, keys,
      // scrollbar, touch) that moves the page away from where autoplay put it hands control back.
      if (store.playing && Math.abs(window.scrollY - store.expectedScrollY) > 3) setState({ playing: false });
      const p = clamp((window.scrollY - el.offsetTop) / scrollableFor(), 0, 1);
      store.T = p * DURATION;
      requestRender();
    };
    onScroll();
    // Deep links: #morning, #noon, ... land on that act's opening frame.
    const applyHash = () => {
      const id = (window.location.hash || "").slice(1);
      const i = ACTS.findIndex((a) => a.id === id);
      if (i >= 0) seek(ACTS[i].start + 0.6, "instant");
    };
    applyHash();
    window.addEventListener("hashchange", applyHash);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("hashchange", applyHash);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [seek]);

  // Motion preference: system setting first, then the visitor's own choice.
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => {
      let saved = null;
      try { saved = localStorage.getItem("meridian-motion"); } catch {}
      const mode = saved === "full" || saved === "calm" ? saved : mq.matches ? "calm" : "full";
      setState({ reduced: mq.matches, mode, playing: false });
      requestRender();
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  // Per-frame DOM theming from the same sun model the shaders use.
  useEffect(() => {
    // Variables go on <html> so the fixed top bar and timeline bar follow the day too.
    const s = document.documentElement.style;
    const sections = Array.from(actsRef.current.querySelectorAll(".act"));
    return onFrame(({ T, theme, weights, full }) => {
      // Sky and ground blend continuously; the UI switches decisively mid-twilight so text
      // never sits in a low-contrast middle.
      const ui = smoothstep(0.2, 0.55, theme.night);
      const fg = mix3(PALETTE.ink, PALETTE.paper, ui);
      const accent = mix3(PALETTE.ultramarine, PALETTE.periwinkle, ui);
      const panel = mix3(mix3(theme.ground, WHITE, 0.55), mix3(PALETTE.nightInk, BLACK, 0.2), ui);
      s.setProperty("--ground", toCss(theme.ground));
      s.setProperty("--horizon", toCss(theme.horizon));
      s.setProperty("--fg", toCss(fg));
      s.setProperty("--fg-muted", toCss(fg, 0.7));
      s.setProperty("--accent", toCss(accent));
      s.setProperty("--panel", toCss(panel, 0.82 + 0.15 * ui));
      s.setProperty("--line", toCss(fg, 0.16));
      s.setProperty("--night", theme.night.toFixed(3));
      s.setProperty("--sh-x", theme.shX.toFixed(3));
      s.setProperty("--sh-y", theme.shY.toFixed(3));
      s.setProperty("--sh-len", Math.hypot(theme.shX, theme.shY).toFixed(3));
      s.setProperty("--sh-a", theme.shA.toFixed(3));
      s.setProperty("--code-solid", full ? smoothstep(31.4, 33.8, T).toFixed(3) : "1");
      sections.forEach((sec, i) => {
        const v = weights[i];
        sec.style.setProperty("--vis", v.toFixed(3));
        sec.setAttribute("data-active", v > 0.5 ? "true" : "false");
      });
    });
  }, []);

  // Playback: the page plays itself at 1x by scrolling. Any input hands control back.
  useEffect(() => {
    if (!playing) return undefined;
    let raf = 0, last = performance.now();
    const step = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      let T = store.T + dt;
      if (T >= DURATION) { T = DURATION; setState({ playing: false }); }
      seek(T, "instant");
      if (store.playing) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [playing, seek]);

  // Any scroll input hands control back from autoplay (registered once, checks the store).
  useEffect(() => {
    const stop = () => { if (store.playing) setState({ playing: false }); };
    const SCROLL_KEYS = new Set(["PageDown", "PageUp", "ArrowDown", "ArrowUp", "Home", "End"]);
    const onKey = (e) => { if (SCROLL_KEYS.has(e.key) && (e.target === document.body || e.target === document.documentElement)) stop(); };
    window.addEventListener("wheel", stop, { passive: true });
    window.addEventListener("touchstart", stop, { passive: true });
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("wheel", stop);
      window.removeEventListener("touchstart", stop);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  // Space plays/pauses when nothing else owns the key.
  useEffect(() => {
    const onKey = (e) => {
      if (e.code !== "Space" || e.repeat) return;
      const t = e.target;
      const editable = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "BUTTON" || t.tagName === "A" || t.isContentEditable);
      if (editable || store.mode !== "full") return;
      e.preventDefault();
      setState({ playing: !store.playing });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // The playhead follows keyboard focus: tabbing into a hidden act brings it on screen.
  const onFocusCapture = (e) => {
    const sec = e.target.closest && e.target.closest(".act");
    if (sec && sec.getAttribute("data-active") !== "true") {
      const i = parseInt(sec.getAttribute("data-act"), 10);
      seek(ACTS[i].start + 4.5, "instant");
    }
  };

  return (
    <>
      <a className="skip" href="#content">Skip to content</a>
      <header className="topbar">
        <a className="wordmark" href="#dawn" onClick={(e) => { e.preventDefault(); seek(0, "smooth"); }}>Meridian</a>
        <nav className="topnav" aria-label="Page">
          <a href="#morning" onClick={(e) => { e.preventDefault(); seek(10.6, "smooth"); }}>How it works</a>
          <a href="#dusk" onClick={(e) => { e.preventDefault(); seek(30.6, "smooth"); }}>Export</a>
          <a href="#night" onClick={(e) => { e.preventDefault(); seek(40.6, "smooth"); }}>Early access</a>
        </nav>
      </header>

      <div id="experience" className="experience" ref={rootRef} data-mode={mode} data-tier={tier} style={{ height: "1100vh" }}>
        <div className="stage">
          {gl === "none" ? <SvgFallback /> : <FieldCanvas />}
          <main id="content" className="acts" ref={actsRef} onFocusCapture={onFocusCapture}>
            <p className="sr-only">
              Behind this page a field of animation frames stands on a timeline, casting shadows that move as you scroll through one day, from dawn to night.
            </p>
            <ActDawn seek={seek} />
            <ActMorning />
            <ActNoon />
            <ActDusk />
            <ActNight />
          </main>
        </div>
      </div>

      <TimelineBar seek={seek} />

      <footer className="site-footer">
        <div>
          <a className="wordmark" href="#dawn" onClick={(e) => { e.preventDefault(); seek(0, "smooth"); }}>Meridian</a>
          <p>A timeline-based motion editor for the web.</p>
        </div>
        <div>
          <p><a href="mailto:hello@meridian.tools">hello@meridian.tools</a></p>
          <p>Private beta. Invites go out in small batches.</p>
        </div>
        <div>
          <p>This page respects reduced-motion settings and works with a keyboard; the timeline bar has a scrubbable playhead.</p>
        </div>
      </footer>
    </>
  );
}
